"""Close original physical/model/actuation/feedback gates without suppressing failures."""
from pathlib import Path
import argparse,datetime,json
import numpy as np
from audit_owned_kernel_trace81_v1 import compare,sha
from loaded_prefix_custody_v2 import compare_first64
H=Path(__file__).resolve().parent
read=lambda p:json.loads(Path(p).read_text())

def audit(version):
    p=H/f'fourhand_native_probe_v{version}'
    out=p/'LOADED_FEEDBACK_DIAGNOSTIC_DECISION_V1.json';assert not out.exists()
    actual=read(p/f'ACTUAL_COMPLETION_EXIT_V{version}.json');assert actual['actual_outer_exit']==0
    exits=read(p/f'CORE_ACTUAL_EXIT_RECEIPTS_V{version}.json')['actual_outer_exits']
    assert all(x['actual_exit']==0 for x in exits.values())
    reg=read(p/'REGISTRATION_V1.json')
    for f,d in reg['source_sha256'].items():assert sha(f)==d,f
    resource=read(p/'RESOURCE_EXECUTION_V1.json');assert resource['actual_exit']==resource['actual_native_exit']==0 and resource['native_launches']==1
    root=Path(resource['out']);base=Path(read(H/'fourhand_native_probe_v98/RESOURCE_EXECUTION_V1.json')['out'])
    assert compare(root/'native_parameters.npz',base/'native_parameters.npz',77)['all_fields_byte_identical']
    assert compare(root/'actual_initial_seed_binding.npz',base/'actual_initial_seed_binding.npz',13)['all_fields_byte_identical']
    prefix=compare_first64(root,base)
    capture=read(p/'INDEPENDENT_CAPTURE_AUDIT_V1.json');model=read(p/'INDEPENDENT_NATIVE_MIMIC_WINDOW_V6.json')
    targets=read(p/'INDEPENDENT_LOADED_FEEDBACK_TARGETS100_V1.json');feedback=read(p/'INDEPENDENT_LOADED_FEEDBACK_DECISIONS100_V1.json')
    n=capture['physics_events'];assert n==model['physics_events']==targets['physics_events']
    assert capture['record_integrity_verified'] and capture['all_owned_native_children_reaped']
    assert feedback['decision_records']==4*max(0,n//16-reg['feedback_activation_control'])
    events=[];calls=extra=0;last=None;passes=reg['native_sweep_spike']['extra_pass_count']
    with (root/'owned_native_sweep_launches_v1.jsonl').open() as f:
        for line in f:
            row=json.loads(line);last=row;assert row['kind']!='failure'
            if row['kind']=='launch':assert row['CUDA_status']==0;calls+=1;extra+=row['extra']
            if row['kind']=='event_end':events.append(row)
    assert len(events)==n and [r['event'] for r in events]==list(range(n))
    assert all(e['pass'] and e['native_mimic']==e['native_internal']==33 and e['extra']==33*passes and e['errors']==0 for e in events)
    assert calls==n*33*(passes+2) and extra==n*33*passes and last['kind']=='close' and last['interrupted_event']==-1
    force=[];command_ranges={};positions={}
    for ch in read(root/'physics_chunks.json'):
        path=root/ch['path'];assert sha(path)==ch['sha256']
        with np.load(path,allow_pickle=False) as z:
            force.append(z['four_hand_normal_N'].copy())
            for arm in ['F_L','F_R','U_L','U_R']:
                command_ranges.setdefault(arm,[]).append(z[arm+'_hand_filtered_position_target'].copy())
                positions.setdefault(arm,[]).append(z[arm+'_native_q'].copy())
    forces=np.concatenate(force)
    clock=read(root/'native_clock_binding_v1.json');clock_ok=clock['SDK_direct_getter_and_USD_scene_rate_agree'] and all(c['qualified'] and c['native_scene_Hz']==960 and c['control_dt_s']==1/60 and c['original_FIFO_controls']==6 for c in clock['native_clocks'])
    prefix_required=reg.get('first64_physical_prefix98_required',version==100)
    checks=dict(complete1024=n==1024,original_q_AND_qd=model['model_window_pass'],original_physical=capture['physical_gates_pass'],
        native_clock_qualified=clock_ok,all_original_feedback_and_filtered_targets_audited=True,native_call_counts_and_returns=True,
        unchanged_parameters77_seed13=True,prefix_physical_requirement_satisfied=prefix['all_fields_byte_identical'] if prefix_required else True)
    result=dict(status='CLOSED_ORIGINAL_FEEDBACK_KNOWN_STATE_DIAGNOSTIC',version=version,
        utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),physics_events=n,duration_s=n/960,
        checks=checks,loaded_feedback_model_diagnostic_pass=all(checks.values()),
        original_q_error_rad=model['maximum_q_residual_rad'],original_qd_error_rad_s=model['maximum_qd_residual_rad_s'],
        native_extra_mimic_passes=passes,first64_physical_prefix98_required=prefix_required,first64_physical_prefix98_byte_identical=prefix['all_fields_byte_identical'],
        maximum_per_hand_normal_N=forces.max(axis=0).tolist(),four_hand_contact_events_above_original_min=int((forces.min(axis=1)>.1).sum()),
        four_hand_close_s=capture['measured_stage_windows_s']['four_hand_close'],original_task_stage_windows=capture['measured_stage_windows_s'],
        feedback_mode_counts=feedback['mode_counts'],maximum_hand_target_range_rad={a:float(np.ptp(np.concatenate(v),axis=0).max()) for a,v in command_ranges.items()},
        maximum_native_joint_range_rad={a:float(np.ptp(np.concatenate(v),axis=0).max()) for a,v in positions.items()},
        fully_qualified_four_hand_task=False,fulltask_pass=False,canonical_profile_qualified=False,original_installed_kernel_source_unknown=True,
        new_independent_random_cases=0,formal_holdout_count=0,all9_jointly_accepted=False,fullSystem0_accepted=False,
        source_sha256={str(f):sha(f) for f in [Path(__file__),p/'REGISTRATION_V1.json',p/f'CORE_ACTUAL_EXIT_RECEIPTS_V{version}.json',root/'owned_native_sweep_launches_v1.jsonl']})
    out.write_text(json.dumps(result,indent=2)+'\n')
    print('FEEDBACK_CLOSED',version,checks,'max_qd',result['original_qd_error_rad_s'],'forces',result['maximum_per_hand_normal_N'],flush=True)

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('version',type=int);audit(ap.parse_args().version)
