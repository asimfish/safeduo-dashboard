"""Check actual native initialization and every submitted recorded target."""
from pathlib import Path
import argparse
import json
import numpy as np
from audit_short_contact_sources_v1 import sha

H = Path(__file__).resolve().parent
ARMS = ('F_L', 'F_R', 'U_L', 'U_R')


def main(version):
    p = H/f'fourhand_native_probe_v{version}'
    out = p/'INDEPENDENT_SHORT_CONTACT_TARGET_TAPE_V1.json'
    assert not out.exists()
    reg = json.loads((p/'REGISTRATION_V1.json').read_text())
    raw = Path(json.loads((p/'RESOURCE_EXECUTION_V1.json').read_text())['out'])
    fixture = Path(reg['contact_reproducer']['fixture'])
    assert sha(fixture) == reg['contact_reproducer']['fixture_sha256']
    capture = json.loads((p/'INDEPENDENT_CAPTURE_AUDIT_V1.json').read_text())
    assert capture['record_integrity_verified'] and 0 < capture['physics_events'] <= 1024
    events = 0
    with np.load(fixture) as seed, np.load(raw/'actual_initial_seed_binding.npz') as initial:
        np.testing.assert_allclose(initial['object_state'][0], seed['object_seed'], atol=1e-7, rtol=0)
        for arm in ARMS:
            for key, source in [('_q','_native_q_seed'), ('_qd','_native_qd_seed'), ('_target','_actual_full_position_target_seed')]:
                np.testing.assert_array_equal(initial[arm+key], seed[arm+source])
        for row in json.loads((raw/'physics_chunks.json').read_text()):
            f = raw/row['path']; assert sha(f) == row['sha256']
            with np.load(f) as z:
                for i, event in enumerate(z['physics_event']):
                    assert int(event) == events and str(z['phase'][i]) == 'CLOSE'
                    tape_index = min(events, 7)
                    for arm in ARMS:
                        for key in ['_actual_full_position_target', '_full_motor_actual_target_before']:
                            np.testing.assert_array_equal(z[arm+key][i], seed[arm+'_actual_full_position_target_tape'][tape_index])
                        np.testing.assert_array_equal(z[arm+'_hand_nominal_position_target'][i], seed[arm+'_hand_nominal_position_target_tape'][tape_index])
                        if events == 0:
                            np.testing.assert_array_equal(z[arm+'_motor_control_q_before'][i], seed[arm+'_native_q_seed'])
                            np.testing.assert_array_equal(z[arm+'_motor_control_qd_before'][i], seed[arm+'_native_qd_seed'])
                    events += 1
    assert events == capture['physics_events']
    result = dict(status='PASS_INITIAL_NATIVE_STATE_AND_EVERY_RECORDED_TARGET_BINDING', version=version,
                  physics_events=events, source_event=11271, target_source_events=list(range(11272,11280)),
                  after_tape='hold last', no_fulltask_or_formal_acceptance=True,
                  source_sha256={str(x):sha(x) for x in [Path(__file__), fixture, raw/'actual_initial_seed_binding.npz']},
                  fullSystem0_accepted=False, formal_holdout_count=0)
    out.write_text(json.dumps(result, indent=2)+'\n'); print(result['status'], events, flush=True)


if __name__ == '__main__':
    ap=argparse.ArgumentParser(); ap.add_argument('version', type=int); main(ap.parse_args().version)
