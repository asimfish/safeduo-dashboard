"""After qualified98, change only recorded-target hold to original hand feedback."""
from pathlib import Path
import ast, copy, datetime, hashlib, json, shutil, subprocess

H=Path(__file__).resolve().parent
old=H/'fourhand_native_probe_v98';P=H/'fourhand_native_probe_v99'
read=lambda p:json.loads(Path(p).read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()


def main():
    assert not P.exists()
    qualified=read(old/'LOADED_NATIVE98_DIAGNOSTIC_DECISION_V1.json')
    assert qualified['long_known_state_model_diagnostic_pass'] and all(qualified['checks'].values())
    assert read(old/'INDEPENDENT_CLOSURE_ACTUAL_EXIT_V98.json')['actual_exit']==0
    reg=copy.deepcopy(read(old/'REGISTRATION_V1.json'))
    for f,d in reg['source_sha256'].items():assert sha(f)==d,f
    P.mkdir()
    for f in old.iterdir():
        if f.suffix in ['.py','.usda'] or f.name=='PRIVATE_KIT_USER_CONFIG_FROZEN_V1.json':shutil.copyfile(f,P/f.name)
    shutil.copytree(old/'private_kit_user_data',P/'private_kit_user_data')
    source=(old/'native_common_beam_v1.py').read_text()
    source=source.replace("target_producer='Recorded eight submitted targets, then hold last; no task feedback'", "target_producer='Exact64-step held prefix; then original four-hand force/joint feedback with original per-microstep target filter'")
    source=source.replace("method='LONG_NATIVE60_PRECONTACT_STATE_TARGET_REPLAY'", "method='LOADED_NATIVE60_FOUR_HAND_FEEDBACK_AFTER_PURE64_PREFIX'")
    needle="""            nominal_hand_targets={};filtered_targets={}
            for sub in range(substeps):
                tape_index=min(step*substeps+sub,7)"""
    assert source.count(needle)==1
    source=source.replace(needle,"""            nominal_hand_targets={};filtered_targets={}
            active_feedback=step>=reg['feedback_activation_control']
            if active_feedback:
                clock=step*dt
                for ai,a in enumerate(ARMS):
                    view=env._arms[a].root_physx_view;handids=hands.ids[a][0]
                    d=grip.update(a,step,clock,clock,array(view.get_dof_positions())[0,handids],
                        array(view.get_dof_velocities())[0,handids],parameters[a+'_hard_limits'][0,handids],
                        array(hands.is_thumb[a]),hands.cur[a],hands.cur_thumb[a],four[ai])
                    grip_decisions[a]=d
                    hands.command(a,d.finger_fraction,1./reg['feedback_grip_settings']['relax_rate'],d.thumb_fraction)
                previous_hand_targets={a:array(env._arms[a].root_physx_view.get_dof_position_targets())[0,hands.ids[a][0]] for a in ARMS}
                hands.step()
                for a in ARMS:
                    fraction=torch.where(hands.is_thumb[a],torch.full_like(hands.open_q[a],hands.cur_thumb[a]),torch.full_like(hands.open_q[a],hands.cur[a]))
                    nominal_hand_targets[a]=array(hands.open_q[a]+fraction*(hands.far_q[a]-hands.open_q[a]))
                    env._arms[a].set_joint_position_target(torch.as_tensor(previous_hand_targets[a],device=env.device,dtype=env._arms[a].data.joint_pos_target.dtype)[None],joint_ids=hands.ids[a][0])
            for sub in range(substeps):
                tape_index=min(step*substeps+sub,7)""")
    needle="""                for a in ARMS:
                    full=repro[a+'_actual_full_position_target_tape'][tape_index]
                    env._arms[a].set_joint_position_target(torch.as_tensor(full,device=env.device))
                    nominal_hand_targets[a]=repro[a+'_hand_nominal_position_target_tape'][tape_index]
                    filtered_targets[a]=full[0,hands.ids[a][0]]"""
    assert source.count(needle)==1
    source=source.replace(needle,"""                for a in ARMS:
                    if not active_feedback:
                        full=repro[a+'_actual_full_position_target_tape'][tape_index]
                        env._arms[a].set_joint_position_target(torch.as_tensor(full,device=env.device))
                        nominal_hand_targets[a]=repro[a+'_hand_nominal_position_target_tape'][tape_index]
                        filtered_targets[a]=full[0,hands.ids[a][0]]
                    else:
                        ids=hands.ids[a][0]
                        previous=array(env._arms[a].root_physx_view.get_dof_position_targets())[0,ids]
                        filtered=coupled_filtered_hand_targets([parameters[a+'_joint_names'][i] for i in ids],
                            nominal_hand_targets[a],previous,parameters[a+'_hard_limits'][0,ids],cfg.sim.dt,
                            True,coupled_meta['assets'][a]['relations'],**reg['interior_hand_target_settings'])
                        filtered_targets[a]=filtered
                        env._arms[a].set_joint_position_target(torch.as_tensor(filtered,device=env.device,dtype=env._arms[a].data.joint_pos_target.dtype)[None],joint_ids=ids)""")
    source=source.replace("else 'SHORT_REPRODUCTION_WINDOW_COMPLETE'", "else 'ORIGINAL_FEEDBACK_CLOSE_WINDOW_COMPLETE'")
    ast.parse(source);(P/'native_common_beam_v1.py').write_text(source)
    launch=H/'launch_native_clock_admission_v99.py'
    text=(H/'launch_native_clock_admission_v98.py').read_text().replace('v98','v99').replace('V98','V99').replace('NATIVE98','NATIVE99')
    needle="    reg=read(P/'REGISTRATION_V1.json')";assert text.count(needle)==1
    text=text.replace(needle,"    assert read(H/'fourhand_native_probe_v98/LOADED_NATIVE98_DIAGNOSTIC_DECISION_V1.json')['long_known_state_model_diagnostic_pass']\n"+needle)
    assert not launch.exists();launch.write_text(text)
    target=H/'audit_loaded_feedback_targets99_v1.py'
    text=(H/'audit_coupled_hand_targets_native_v3.py').read_text()
    text=text.replace("hard=params[a+'_hard_limits'][0,ids];opened=params[a+'_initial_q'][0,ids];far=params[a+'_coupled_hand_far_q']", "hard=params[a+'_hard_limits'][0,ids];opened=refs[a+'_hand_open_q'];far=params[a+'_coupled_hand_far_q']")
    text=text.replace("    records=[]\n", "    initial=np.load(raw/'actual_initial_seed_binding.npz');fixture=np.load(reg['contact_reproducer']['fixture']);activation=reg['feedback_activation_control']*microsteps(reg)\n    assert activation==64\n    records=[]\n")
    text=text.replace("previous=opened if e==0 else d[a+'_actual_full_position_target'][e-1,0,ids]", "previous=initial[a+'_target'][0,ids] if e==0 else d[a+'_actual_full_position_target'][e-1,0,ids]")
    needle="            if filtered:\n                expected=expected_target"
    assert text.count(needle)==1
    text=text.replace(needle,"            if e<activation:\n                nominal=fixture[a+'_hand_nominal_position_target_tape'][min(e,7)]\n                expected=fixture[a+'_actual_full_position_target_tape'][min(e,7),0,ids]\n            elif filtered:\n                expected=expected_target")
    text=text.replace("            if filtered:\n                rate=", "            if filtered and e>=activation:\n                rate=")
    text=text.replace('INDEPENDENT_COUPLED_HAND_TARGETS_V3','INDEPENDENT_LOADED_FEEDBACK_TARGETS99_V1')
    text=text.replace('PASS_INDEPENDENT_PER_MICROSTEP_COUPLED_NATIVE_TARGET_BINDING','PASS_INDEPENDENT_LOADED_PREFIX_AND_FEEDBACK_HAND_TARGET_BINDING')
    assert not target.exists();ast.parse(text);target.write_text(text)
    feedback=H/'audit_loaded_feedback_decisions99_v1.py'
    text=(H/'audit_feedback_grip_native_v4.py').read_text()
    text=text.replace('INDEPENDENT_COUPLED_HAND_TARGETS_V2','INDEPENDENT_LOADED_FEEDBACK_TARGETS99_V1').replace('PASS_INDEPENDENT_ALL_PHASE_COUPLED_NATIVE_TARGET_BINDING','PASS_INDEPENDENT_LOADED_PREFIX_AND_FEEDBACK_HAND_TARGET_BINDING')
    text=text.replace("    for event in range(microsteps(reg),len(data['physics_event']),microsteps(reg)):", "    refs=np.load(reg['coupled_reference_endpoints']);activation=reg['feedback_activation_control']*microsteps(reg)\n    assert activation==64\n    for event in range(activation,len(data['physics_event']),microsteps(reg)):")
    text=text.replace("openq=params[arm+'_initial_q'][0,hand]", "openq=refs[arm+'_hand_open_q']")
    text=text.replace('INDEPENDENT_FEEDBACK_GRIP_AUDIT_V4','INDEPENDENT_LOADED_FEEDBACK_DECISIONS99_V1')
    assert not feedback.exists();ast.parse(text);feedback.write_text(text)
    reg.update(attempt_version=99,scientific_candidate_version=99,registered_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        previous_failed_attempt=None,execution_only_retry=False,feedback_activation_control=4,
        change_scope='Exact64-step prefix of qualified98 followed by960 microsteps of original FeedbackGrip and original0.02rad/s coupled target filter. Arm commands remain held through originalFIFO6; all original physical/model/force/prelift gates unchanged. No LIFT or fulltask.')
    reg['private_asset_settings']=dict(reg['private_asset_settings'],private_directory=str(P/'private_kit_user_data'))
    sources={}
    for f in reg['source_sha256']:
        dest=Path(f.replace('fourhand_native_probe_v98','fourhand_native_probe_v99').replace('launch_native_clock_admission_v98','launch_native_clock_admission_v99'))
        if dest.parent==P and dest.name in ['STARTUP_CONFIG_CORRECTION_PROOF_V1.json','ALL_NATIVE_BIND_SOURCES_PREFLIGHT_V1.json']:continue
        if not dest.exists():
            assert Path(f).is_relative_to(old),f
            dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(f,dest)
        sources[str(dest)]=sha(dest)
    # Keep the predecessor's closure, not just its worker, in the frozen lineage.
    for f in [Path(__file__),launch,target,feedback,old/'LOADED_NATIVE98_DIAGNOSTIC_DECISION_V1.json',old/'INDEPENDENT_CLOSURE_ACTUAL_EXIT_V98.json']:
        sources[str(f)]=sha(f)
    reg['source_sha256']=sources
    (P/'REGISTRATION_V1.json').write_text(json.dumps(reg,indent=2)+'\n')
    for f in [P/'native_common_beam_v1.py',launch,target,feedback]:subprocess.run(['/usr/bin/python3','-m','py_compile',str(f)],check=True)
    plan=dict(candidate=99,baseline=98,registered_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        maximum_native_executions=1,maximum_scheduler_wait_s=900,maximum_native_wall_s=600,maximum_physics_events=1024,
        unchanged_first64_all164_fields_required=True,all77_parameters_and13_seed_fields_unchanged_required=True,
        only_controller_change='Original force/joint FeedbackGrip reactivated after64 steps; same original0.02rad/s per-microstep filter',
        all_original_q_AND_qd_physical_and_four_hand_prelift_gates_unchanged=True,
        original_hand_open_reference='Frozen coupled operational endpoints, distinct from captured partially-closed seed',
        fulltask_phase_ceiling='CLOSE',new_independent_random_cases=0,formal_holdout_count=0,fullSystem0_accepted=False,
        source_sha256={str(f):sha(f) for f in [Path(__file__),P/'REGISTRATION_V1.json',launch,target,feedback]})
    out=H/'LOADED_FEEDBACK99_PROSPECTIVE_PLAN_V1.json';assert not out.exists();out.write_text(json.dumps(plan,indent=2)+'\n')
    print('FROZEN99_ORIGINAL_FEEDBACK_AFTER_PURE64_PREFIX; ORIGINAL_RATE_AND_PHYSICAL_GATES_UNCHANGED',flush=True)


if __name__=='__main__':main()
