"""Use actual97 configuration and reject clock/material/asset-root alterations."""
from pathlib import Path
from copy import deepcopy
import json
import unittest
from kit_startup_config_contract98_v1 import effective_config

P = Path(__file__).resolve().parent / 'fourhand_native_probe_v97'
original = json.loads((P / 'PRIVATE_KIT_USER_CONFIG_FROZEN_V1.json').read_text())
observed = json.loads((P / 'private_kit_user_data/user.config.json').read_text())


class ConfigContract(unittest.TestCase):
    def test_actual_capture_has_only_the_registered_change(self):
        result = effective_config(original, observed, 1 / 960, 16)
        self.assertEqual(result, observed)
        self.assertEqual(original['persistent']['simulation']['minFrameRate'], 12)

    def test_physics_clock_changes_are_rejected(self):
        for dt, sub in [(1 / 480, 16), (1 / 960, 8)]:
            with self.assertRaises(ValueError):
                effective_config(original, observed, dt, sub)

    def test_unregistered_settings_are_rejected(self):
        altered = deepcopy(observed)
        altered['persistent']['simulation']['unregisteredSolverOverride'] = 64
        with self.assertRaises(ValueError):
            effective_config(original, altered, 1 / 960, 16)

    def test_changed_existing_setting_is_rejected(self):
        altered = deepcopy(observed)
        altered['persistent']['simulation']['minFrameRate'] = 30
        with self.assertRaises(ValueError):
            effective_config(original, altered, 1 / 960, 16)

    def test_unchanged_stale_startup_setting_is_rejected(self):
        with self.assertRaises(ValueError):
            effective_config(original, original, 1 / 960, 16)

    def test_wrong_setting_type_is_rejected(self):
        altered = deepcopy(observed)
        altered['persistent']['simulation']['minFrameRate'] = 60.0
        with self.assertRaises(ValueError):
            effective_config(original, altered, 1 / 960, 16)


if __name__ == '__main__':
    unittest.main()
