"""Freeze effective60Hz startup before a new run; preserve97's failed gate."""
from pathlib import Path
import copy, datetime, hashlib, json, shutil, subprocess
from kit_startup_config_contract98_v1 import effective_config

H = Path(__file__).resolve().parent
old = H / 'fourhand_native_probe_v97'
P = H / 'fourhand_native_probe_v98'
read = lambda p: json.loads(Path(p).read_text())
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()


def main():
    assert not P.exists()
    failure = read(old / 'ACTUAL_CONFIG_CUSTODY_FAILURE_V97.json')
    assert failure['actual_outer_exit'] == 1 and failure['native_launches_actual'] == 1
    diagnosis = read(old / 'RUNTIME_CONFIG_WRITEBACK_DIAGNOSIS_V1.json')
    before = old / 'PRIVATE_KIT_USER_CONFIG_FROZEN_V1.json'
    runtime = old / 'private_kit_user_data/user.config.json'
    assert sha(before) == diagnosis['before_sha256']
    assert sha(runtime) == diagnosis['after_sha256']
    reg = copy.deepcopy(read(old / 'REGISTRATION_V1.json'))
    effective_config(read(before), read(runtime), reg['physics_dt_s'], reg['physics_substeps_per_control'])
    for f, digest in reg['source_sha256'].items():
        # Only the independently diagnosed original97 failure is exempt here.
        # Its original receipt/hash stays immutable; all fresh98 sources will
        # again be checked byte-for-byte before AND after execution.
        if Path(f) != runtime:
            assert sha(f) == digest, f
    P.mkdir()
    for f in old.iterdir():
        if f.suffix in ['.py', '.usda']:
            shutil.copyfile(f, P / f.name)
    shutil.copytree(old / 'private_kit_user_data', P / 'private_kit_user_data')
    frozen = P / before.name
    shutil.copyfile(runtime, frozen)
    assert sha(frozen) == sha(P / 'private_kit_user_data/user.config.json') == diagnosis['after_sha256']
    launch = H / 'launch_native_clock_admission_v98.py'
    audit = H / 'audit_loaded_native98_v2.py'
    for source, dest in [(H / 'launch_native_clock_admission_v97.py', launch), (H / 'audit_loaded_native97_v2.py', audit)]:
        assert not dest.exists()
        text = source.read_text().replace('v97', 'v98').replace('V97', 'V98').replace('NATIVE97', 'NATIVE98').replace('version=97', 'version=98')
        if dest == launch:
            needle = "            record['actual_exit']=actual;save(record)"
            assert text.count(needle) == 1
            text = text.replace(needle, """            j=receipt.get('jobs',[{}])[0]
            launched=bool(j.get('actual_native_pid') is not None or j.get('native_candidate_processes_including_owned_forks') or out.exists())
            record.update(actual_exit=actual,native_launches=int(launched),actual_native_exit=j.get('actual_native_exit'),
                actual_native_pid=j.get('actual_native_pid'),native_owned_process_reaped_and_absent=j.get('native_owned_process_reaped_and_absent'),out=str(out))
            save(record)""")
        dest.write_text(text)
    subprocess.run(['/usr/bin/python3', '-m', 'py_compile', str(launch), str(audit)], check=True)
    reg.update(attempt_version=98, previous_failed_attempt=97, registered_utc=now(),
        execution_only_retry=True,
        execution_GPU_qualification='GPU1 shared supervised isolated native probe; original scientific94 worker unchanged.',
        change_scope='Prospective startup config12->60 matches original native960Hz/16 substeps. All other keys and all scientific thresholds unchanged.97 remains failed. Fresh98 retains unchanged-all-source pre/post byte gates.')
    reg.pop('retry_of_unlaunched_attempt', None)
    reg['private_asset_settings'] = dict(reg['private_asset_settings'], private_directory=str(P / 'private_kit_user_data'))
    sources = {}
    for f in reg['source_sha256']:
        dest = Path(f.replace('fourhand_native_probe_v97', 'fourhand_native_probe_v98').replace('launch_native_clock_admission_v97', 'launch_native_clock_admission_v98').replace('audit_loaded_native97_v2', 'audit_loaded_native98_v2'))
        if dest.name == 'ALL_NATIVE_BIND_SOURCES_PREFLIGHT_V1.json' and dest.parent == P:
            continue
        if not dest.exists():
            assert Path(f).is_relative_to(old), f
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(f, dest)
        sources[str(dest)] = sha(dest)
    worker = P / 'native_common_beam_v1.py'
    assert sha(worker) == sha(H / 'fourhand_native_probe_v94/native_common_beam_v1.py')
    sdk = Path('/home/liyufeng/miniforge3/envs/safeduo/lib/python3.11/site-packages/isaacsim/exts/isaacsim.core.api/isaacsim/core/api/physics_context/physics_context.py')
    proof = P / 'STARTUP_CONFIG_CORRECTION_PROOF_V1.json'
    proof.write_text(json.dumps(dict(utc=now(), change={'path':'/persistent/simulation/minFrameRate','before':12,'after':60},
        other_keys_changed=0, new_keys=0, native_clock_unchanged=True, original_model_physical_task_gates_unchanged=True,
        original97_qualification=False, native_launches=0, effective_startup_sha256=sha(frozen),
        SDK_source=str(sdk), SDK_source_sha256=sha(sdk), SDK_set_physics_dt_min_steps_formula='int(int(1/dt)/substeps)',
        SDK_location_lines=[256,285], original_physics_dt_s=1/960, original_substeps=16,
        fullSystem0_accepted=False), indent=2) + '\n')
    template = read(H / 'FOURHAND_NATIVE_PROBE_PLAN_V97_DISPATCH0.json')
    argv = template['jobs'][0]['argv']; binds = []
    for i, flag in enumerate(argv):
        if flag not in ['--bind','--ro-bind']: continue
        source = Path(argv[i+1].replace('fourhand_native_probe_v97','fourhand_native_probe_v98'))
        assert source.exists(), source
        binds.append(dict(flag=flag, source=str(source), destination=argv[i+2], source_exists=True,
            source_sha256=sha(source) if source.is_file() else None))
    preflight = P / 'ALL_NATIVE_BIND_SOURCES_PREFLIGHT_V1.json'
    preflight.write_text(json.dumps(dict(all_sources_exist=True, binds=binds,
        private_config_source_sha256=sha(frozen), private_config_copy_sha256=sha(P/'private_kit_user_data/user.config.json'),
        native_worker94_byte_identical=True, native_launches=0), indent=2) + '\n')
    for f in [Path(__file__), H/'kit_startup_config_contract98_v1.py', H/'test_kit_startup_config_contract98_v1.py',
              H/'KIT_STARTUP_CONFIG_CPU_ACTUAL_EXIT_V98.json', launch, audit, proof, preflight, frozen,
              P/'private_kit_user_data/user.config.json', sdk]:
        sources[str(f)] = sha(f)
    reg['source_sha256'] = sources
    (P / 'REGISTRATION_V1.json').write_text(json.dumps(reg, indent=2) + '\n')
    plan = copy.deepcopy(read(H / 'LOADED_NATIVE97_PRENATIVE_SETUP_RETRY_PROSPECTIVE_PLAN_V1.json'))
    plan.update(attempt=98, registered_utc=now(), setup_change='Immutable effective60 startup and mutable runtime copy both frozen at same canonical captured bytes; preserve every pre/post source hash gate.',
        counter_change='Record actual native launch and exit from execution receipt even when outer post-source gate fails.',
        native97_actual_outer_exit=1, native97_accepted=False,
        source_sha256={str(f):sha(f) for f in [P/'REGISTRATION_V1.json', launch, audit, preflight, proof, Path(__file__)]})
    prospective = H / 'LOADED_NATIVE98_STARTUP_CONFIG_PROSPECTIVE_PLAN_V1.json'
    assert not prospective.exists()
    prospective.write_text(json.dumps(plan, indent=2) + '\n')
    print('FROZEN98_EFFECTIVE60_CONFIG', len(sources), 'SOURCES', len(binds), 'BINDS; WORKER94_IDENTICAL; ORIGINAL_GATES_UNCHANGED', flush=True)


if __name__ == '__main__':
    main()
