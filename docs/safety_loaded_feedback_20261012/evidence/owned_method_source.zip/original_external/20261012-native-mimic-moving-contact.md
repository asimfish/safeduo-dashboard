# ADR: Native mimic convergence during feedback hand motion

## Status

Proposed bounded diagnostic iteration. No full-task, canonical or learned safety
adoption. A passing held target is insufficient for a moving contact.

## Context

Independently closed98 passes1024 held-target microsteps with original q AND qd
limits, physical gates and exact64-step physical prefix93. Fresh100 restores the
original hand feedback after the same64 steps; its unchanged0.02rad/s filter
produces a left-thumb3 velocity relation residual0.0001140032rad/s at event198,
exceeding the original0.0001 limit. Left hand contact at that event is0.06831N;
other three hands have no contact. Original physical gates pass. The failed
native samples and the abort after that control period remain immutable.

## Candidates

| Approach | Benefit | Limitation |
| --- | --- | --- |
| A: Reduce the already0.02rad/s command rate | May reduce transient error | Existing target lag implies about30seconds to reach nominal F2 target; slowing worsens task timing and does not test solver convergence at the same commands |
| B: Increase only native extra mimic sweeps8 to16 | Tests convergence at unchanged controller inputs, original constraint rows and physical properties | Numerical diagnostic, opaque installed kernel source unknown; actual moving contact must independently qualify |
| C: Modify or project follower q/qd | Could hide residual | Rejected: changes physical state outside the original solver and invalidates acceptance |

## Decision and interface

Select B under `spike/native_mimic_feedback_sweep16_v1/`. Change only the
pre-existing C start interface's admitted maximum pass count8 to16, then register
exactly16 passes. Keep2048 event ledger capacity, native33 solve pairs, opaque
argument copying, context/stream/session matching, failure propagation, abort
and original actuation unchanged. No descriptor dereference or q/qd writes.
No kernel source or ABI change is claimed. Existing JSON/NPZ remain boundaries.

Retain13 CPU boundary scenarios and add a16-pass forwarding/count/argument-copy
case which rejects17. Compile with warnings as errors and freeze all sources
before the one finite native execution on admitted GPU1. Reuse the byte-identical
feedback100 worker and all77 native arrays/13 initial-state fields. Maximum1024
microsteps/64 controls; preserve original1e-4 q AND qd and all physical/contact/
force/effort/target gates. Compare common first208 steps separately from the longer
window. Changing solver passes can change physical states; do not require their
64-step byte equality to8-pass100. Their submitted prefix targets stay identical.

## Impact

Only owned spike files and fresh101 prospective registration/diagnostic closure
change. Existing held98 and failed100 are immutable. Maximum native runtime600s,
same GPU1 shared admission12288MiB/80%, owned7680MiB and free4096MiB guards.
Full four-hand/prelift qualification remains required before lift. This iteration
permits at most two bounded spikes; the16-pass comparison is the first.
