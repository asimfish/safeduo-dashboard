"""Audit the1024-step known-state extension and exact64-step prefix custody."""
from pathlib import Path
import datetime,json
import numpy as np
from audit_owned_kernel_trace81_v1 import compare,sha
from audit_short_hand_pd_filter_decision_v1 import longest
H=Path(__file__).resolve().parent
read=lambda p:json.loads(Path(p).read_text())
def main():
    p=H/'fourhand_native_probe_v98';target=p/'LOADED_NATIVE98_DIAGNOSTIC_DECISION_V1.json';assert not target.exists()
    planfile=H/'LOADED_NATIVE_WINDOW94_PROSPECTIVE_PLAN_V1.json';plan=read(planfile)
    for f,d in plan['source_sha256'].items():assert sha(f)==d,f
    assert read(p/'ACTUAL_COMPLETION_EXIT_V98.json')['actual_outer_exit']==0
    assert all(x['actual_exit']==0 for x in read(p/'CORE_ACTUAL_EXIT_RECEIPTS_V98.json')['actual_outer_exits'].values())
    reg=read(p/'REGISTRATION_V1.json')
    for f,d in reg['source_sha256'].items():assert sha(f)==d,f
    r=read(p/'RESOURCE_EXECUTION_V1.json');assert r['actual_exit']==r['actual_native_exit']==0 and r['native_launches']==1
    root=Path(r['out']);base=Path(read(H/'fourhand_native_probe_v93/RESOURCE_EXECUTION_V1.json')['out'])
    native=compare(root/'native_parameters.npz',base/'native_parameters.npz',77)
    seed=compare(root/'actual_initial_seed_binding.npz',base/'actual_initial_seed_binding.npz',13)
    assert native['all_fields_byte_identical'] and seed['all_fields_byte_identical']
    from loaded_prefix_custody_v2 import compare_first64
    try:
        prefix_report=compare_first64(root,base)
        prefix_pure=prefix_report['all_fields_byte_identical'];prefix_rows=prefix_report['rows'];prefix_error=None
    except ValueError as e:
        prefix_pure=False;prefix_rows=[];prefix_error=str(e)
    clock=read(root/'native_clock_binding_v1.json')
    clocks_qualified=clock['SDK_direct_getter_and_USD_scene_rate_agree'] and bool(clock['native_clocks']) and all(
        c['qualified'] and c['native_scene_Hz']==960 and c['native_getter_dt_s']==c['registered_physics_dt_s']==1/960
        and c['control_dt_s']==1/60 and c['physics_substeps_per_control']==16 and c['original_FIFO_controls']==6 and c['FIFO_s']==.1 for c in clock['native_clocks'])
    capture=read(p/'INDEPENDENT_CAPTURE_AUDIT_V1.json');model=read(p/'INDEPENDENT_NATIVE_MIMIC_WINDOW_V6.json');n=capture['physics_events']
    assert n==model['physics_events'] and 0<n<=1024
    assert capture['record_integrity_verified'] and capture['all_owned_native_children_reaped']
    log=root/'owned_native_sweep_launches_v1.jsonl';events=[];calls=0;extra=0;last=None
    with log.open() as f:
        for line in f:
            row=json.loads(line);last=row;assert row['kind']!='failure'
            if row['kind']=='launch':assert row['CUDA_status']==0;calls+=1;extra+=row['extra']
            if row['kind']=='event_end':events.append(row)
    assert len(events)==n and [e['event'] for e in events]==list(range(n))
    assert all(e['pass'] and e['native_mimic']==e['native_internal']==33 and e['extra']==264 and e['errors']==0 for e in events)
    assert calls==n*330 and extra==n*264 and last['kind']=='close' and last['interrupted_event']==-1
    forces=[];times=[];files=[]
    for c in read(root/'physics_chunks.json'):
        f=root/c['path'];assert sha(f)==c['sha256'];files.append(f)
        with np.load(f,allow_pickle=False) as z:forces.append(z['four_hand_normal_N'].copy());times.append(z['state_time_s'].copy())
    force=np.concatenate(forces);time=np.concatenate(times);assert len(force)==n
    job=read(H/'fourhand_native_probe_v98_execution.json')['jobs'][0];assert job['actual_native_exit']==0 and job['native_owned_process_reaped_and_absent']
    checks=dict(complete1024=n==1024,original_q_AND_qd=model['model_window_pass'],original_physical=capture['physical_gates_pass'],
        first64_164_fields_byte_equal93=prefix_pure,native_clock_qualified=clocks_qualified,all_native_extra_call_counts_and_returns_pass=True)
    result=dict(status='CLOSED_LONG_KNOWN_STATE_NATIVE_MIMIC_STABILITY_DIAGNOSTIC',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        version=98,baseline=93,physics_events=n,observed_duration_s=n/960,checks=checks,
        long_known_state_model_diagnostic_pass=all(checks.values()),first64_prefix_custody=prefix_rows,first64_prefix_error=prefix_error,
        all77_native_parameters_and13_seed_fields_byte_identical93=True,
        original_q_error_rad=model['maximum_q_residual_rad'],original_qd_error_rad_s=model['maximum_qd_residual_rad_s'],
        maximum_per_hand_normal_N=force.max(axis=0).tolist(),additional_F_L_weak_contact_consecutive_events=longest(force[:,0]>.005),
        four_hand_contact_above_original_min_events=int((force.min(axis=1)>.1).sum()),
        original_four_hand_continuous_contact_s=capture['measured_stage_windows_s']['four_hand_close'],
        all_required_task_stage_windows_pass=capture['all_task_stage_time_windows_pass'],
        original_source_commit_unknown=True,fulltask_qualified=False,canonical_profile_qualified=False,candidate_adopted=False,
        new_independent_random_cases=0,formal_holdout_count=0,all9_jointly_accepted=False,fullSystem0_accepted=False,
        source_sha256={str(f):sha(f) for f in [Path(__file__),planfile,p/'CORE_ACTUAL_EXIT_RECEIPTS_V98.json',log,*files]})
    target.write_text(json.dumps(result,indent=2)+'\n')
    print('LONG_NATIVE98_CLOSED',checks,'qd',model['maximum_qd_residual_rad_s'],'four_hand_s',result['original_four_hand_continuous_contact_s'],flush=True)
if __name__=='__main__':main()
