"""Real seed/reference/prefix and independent XML/filter seam regression."""
from pathlib import Path
import ast,json,sys,unittest
import numpy as np
H=Path(__file__).resolve().parent
sys.path.insert(0,str(H/'fourhand_native_probe_v100'))
from coupled_hand_filter_v1 import coupled_filtered_hand_targets
from audit_loaded_feedback_targets100_v1 import matrix,expected_target
reg=json.loads((H/'fourhand_native_probe_v100/REGISTRATION_V1.json').read_text())
meta=json.loads(Path(reg['coupled_assets']).read_text())
raw=Path(json.loads((H/'fourhand_native_probe_v98/RESOURCE_EXECUTION_V1.json').read_text())['out'])


class FeedbackContract(unittest.TestCase):
    def test_audit_result_contract(self):
        target=ast.parse((H/'audit_loaded_feedback_targets100_v1.py').read_text())
        feedback=ast.parse((H/'audit_loaded_feedback_decisions100_v1.py').read_text())
        status=next(n.value.value for n in ast.walk(target) if isinstance(n,ast.keyword) and n.arg=='status')
        expected=[n.comparators[0].value for n in ast.walk(feedback) if isinstance(n,ast.Compare) and isinstance(n.left,ast.Subscript) and isinstance(n.left.slice,ast.Constant) and n.left.slice.value=='status' and isinstance(n.comparators[0],ast.Constant)]
        self.assertIn(status,expected)

    def test_original_open_reference_is_distinct_from_physical_seed(self):
        with np.load(reg['coupled_reference_endpoints']) as refs,np.load(reg['contact_reproducer']['fixture']) as seed,np.load(raw/'native_parameters.npz') as params:
            for ai,arm in enumerate(['F_L','F_R','U_L','U_R']):
                names=params[arm+'_joint_names'].tolist();hn=meta['assets'][arm]['hand_joint_names'];ids=[names.index(n) for n in hn]
                opened=refs[arm+'_hand_open_q'];far=refs[arm+'_hand_far_q']
                self.assertGreater(float(abs(seed[arm+'_native_q_seed'][0,ids]-opened).max()),.05)
                progress=np.where(['thumb' in n for n in hn],seed['thumb_fraction'][ai],seed['finger_fraction'][ai])
                np.testing.assert_allclose(opened+progress*(far-opened),seed[arm+'_hand_nominal_position_target_tape'][-1],atol=1e-6,rtol=0)

    def test_all64_prefix_targets_are_bound_to_original_tape(self):
        with np.load(reg['contact_reproducer']['fixture']) as seed:
            ledger=json.loads((raw/'physics_chunks.json').read_text())
            for chunk in ledger[:2]:
                with np.load(raw/chunk['path']) as z:
                    for i,e in enumerate(z['physics_event']):
                        for arm in ['F_L','F_R','U_L','U_R']:
                            np.testing.assert_array_equal(z[arm+'_actual_full_position_target'][i],seed[arm+'_actual_full_position_target_tape'][min(int(e),7)])

    def test_first_feedback_filter_matches_original_urdf_oracle(self):
        ledger=json.loads((raw/'physics_chunks.json').read_text())
        with np.load(raw/ledger[1]['path']) as z,np.load(raw/'native_parameters.npz') as params,np.load(reg['contact_reproducer']['fixture']) as seed:
            for arm in ['F_L','F_R','U_L','U_R']:
                hn=meta['assets'][arm]['hand_joint_names'];names=params[arm+'_joint_names'].tolist();ids=[names.index(n) for n in hn]
                previous=z[arm+'_actual_full_position_target'][-1,0,ids];nominal=seed[arm+'_hand_nominal_position_target_tape'][-1];hard=params[arm+'_hard_limits'][0,ids]
                roots,A,b=matrix(hn,meta['assets'][arm]['original_URDF']);rootids=[hn.index(n) for n in roots]
                expected=expected_target(hn,A,b,rootids,nominal,previous,hard,reg['physics_dt_s'],True,reg['interior_hand_target_settings'])
                actual=coupled_filtered_hand_targets(hn,nominal,previous,hard,reg['physics_dt_s'],True,meta['assets'][arm]['relations'],**reg['interior_hand_target_settings'])
                np.testing.assert_allclose(actual,expected,atol=1e-12,rtol=0)
                bad=nominal.copy();followers=[i for i in range(len(hn)) if i not in rootids];bad[followers[0]]+=.01
                with self.assertRaises(AssertionError):expected_target(hn,A,b,rootids,bad,previous,hard,reg['physics_dt_s'],True,reg['interior_hand_target_settings'])


if __name__=='__main__':unittest.main()
