"""Copy frozen S2, change only admission bound, add real16-pass CPU boundary."""
from pathlib import Path
import shutil
H=Path(__file__).resolve().parent
old=H/'spike/native_mimic_loaded_window_v1';P=H/'spike/native_mimic_feedback_sweep16_v1'
assert not P.exists();P.mkdir()
for name in ['bridge.cpp','native_boundary.py','fake_driver.cpp','test_boundary.py']:
    shutil.copyfile(old/name,P/name)
text=(P/'bridge.cpp').read_text();assert text.count('extra_pass_count>8')==1
(P/'bridge.cpp').write_text(text.replace('extra_pass_count>8','extra_pass_count>16'))
text=(P/'test_boundary.py').read_text().replace("'event_capacity']","'event_capacity','high_pass_count']")
needle="        passes=0 if name=='disabled' else 2";assert text.count(needle)==1
text=text.replace(needle,"""        if name=='high_pass_count':
            assert bridge.safeduo_sweep_start(str(path).encode(),17,1)==-1
            assert bridge.safeduo_sweep_start(str(path).encode(),16,1)==0
            assert call(1)==call(2)==0
            assert bridge.safeduo_sweep_prepare()==0
            fake.fake_reset();assert bridge.safeduo_sweep_event_begin(0)==0
            original=struct.unpack('<I',struct.pack('<f',values[1].value))[0]
            assert call(1)==0
            values[1].value=.9
            assert call(2)==0 and fake.fake_count()==18
            assert [fake.fake_role(i) for i in range(18)]==[1,2]+[1]*16
            assert all(fake.fake_scalar(i)==original for i in [0]+list(range(2,18)))
            assert bridge.safeduo_sweep_event_end(0)==0
            assert json.loads(path.read_text().splitlines()[-1])['extra']==16
            assert bridge.safeduo_sweep_stop()==0
            return
        passes=0 if name=='disabled' else 2""")
(P/'test_boundary.py').write_text(text)
print('SPIKE_ONLY_BOUND8_TO16_AND_ONE_CPU16_SCENARIO_PREPARED')
