"""Test0.10 versus0.02 target rate after independently closed16-pass feedback."""
from pathlib import Path
import copy,datetime,hashlib,json,shutil,subprocess
H=Path(__file__).resolve().parent;old=H/'fourhand_native_probe_v101';P=H/'fourhand_native_probe_v102'
read=lambda p:json.loads(Path(p).read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
    assert not P.exists();closed=read(old/'LOADED_FEEDBACK_DIAGNOSTIC_DECISION_V1.json')
    assert closed['loaded_feedback_model_diagnostic_pass'] and closed['physics_events']==1024
    reg=copy.deepcopy(read(old/'REGISTRATION_V1.json'))
    for f,d in reg['source_sha256'].items():assert sha(f)==d,f
    P.mkdir()
    for f in old.iterdir():
        if f.suffix in ['.py','.usda'] or f.name=='PRIVATE_KIT_USER_CONFIG_FROZEN_V1.json':shutil.copyfile(f,P/f.name)
    shutil.copytree(old/'private_kit_user_data',P/'private_kit_user_data')
    launcher=H/'launch_native_clock_admission_v102.py';assert not launcher.exists()
    launcher.write_text((H/'launch_native_clock_admission_v101.py').read_text().replace('v101','v102').replace('V101','V102').replace('NATIVE101','NATIVE102'))
    subprocess.run(['/usr/bin/python3','-m','py_compile',str(launcher)],check=True)
    reg.update(attempt_version=102,scientific_candidate_version=102,registered_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        first64_physical_prefix_baseline=101,first64_physical_prefix98_required=True,
        change_scope='One controller intervention relative to101: requested hand target slew0.02->0.10rad/s. Same16 native passes, byte-identical worker, initial state, all77 parameters and all original physical/model/prelift limits. Exact64 physical prefix101 required. Actual hand-speed<=0.05rad/s prelift gate unchanged; no lift or task adoption.')
    reg['interior_hand_target_settings']=dict(reg['interior_hand_target_settings'],max_target_rate_rad_s=.10)
    reg['private_asset_settings']=dict(reg['private_asset_settings'],private_directory=str(P/'private_kit_user_data'))
    sources={}
    for f in reg['source_sha256']:
        out=Path(f.replace('fourhand_native_probe_v101','fourhand_native_probe_v102').replace('launch_native_clock_admission_v101','launch_native_clock_admission_v102'))
        if not out.exists():
            assert Path(f).is_relative_to(old),f
            out.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(f,out)
        sources[str(out)]=sha(out)
    for f in [Path(__file__),old/'LOADED_FEEDBACK_DIAGNOSTIC_DECISION_V1.json',old/'CORE_ACTUAL_EXIT_RECEIPTS_V101_V2.json',H/'audit_loaded_feedback_window_v2.py']:sources[str(f)]=sha(f)
    assert sha(P/'native_common_beam_v1.py')==sha(old/'native_common_beam_v1.py')
    reg['source_sha256']=sources;(P/'REGISTRATION_V1.json').write_text(json.dumps(reg,indent=2)+'\n')
    plan=dict(candidate=102,baseline=101,registered_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        only_changed_scientific_setting='requested_hand_target_rate0.02->0.10rad/s',maximum_native_executions=1,maximum_native_wall_s=600,maximum_scheduler_wait_s=900,maximum_physics_events=1024,
        first64_all164_physical_fields_identical101_required=True,all77_parameters_and13_seed_fields_identical98_required=True,
        common101_102_window='Use all common actually captured physics steps; incomplete cases remain failures.',
        original_q_AND_qd_tolerance=1e-4,all_original_physical_and_task_gates_unchanged=True,original_actual_hand_speed_prelift_limit_rad_s=.05,
        formal_holdout_count=0,new_independent_random_cases=0,fullSystem0_accepted=False,
        source_sha256={str(f):sha(f) for f in [Path(__file__),P/'REGISTRATION_V1.json',launcher,H/'audit_loaded_feedback_window_v2.py']})
    out=H/'LOADED_FEEDBACK102_RATE_PROSPECTIVE_PLAN_V1.json';assert not out.exists();out.write_text(json.dumps(plan,indent=2)+'\n')
    print('FROZEN102_SINGLE_RATE_INTERVENTION; MODEL_PHYSICAL_AND_ACTUAL_HAND_SPEED_GATES_UNCHANGED',flush=True)
if __name__=='__main__':main()
