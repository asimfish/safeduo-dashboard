"""Regression for scalar metadata and contact points beyond the number of time rows."""
from pathlib import Path
import copy,hashlib,json,tempfile,unittest
import numpy as np
from loaded_prefix_custody_v2 import compare_first64,prefix_chunks,sha

class Custody(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.root=Path(self.temp.name);self.a=self.root/'a';self.b=self.root/'b'
        self.values={'state_time_s':np.arange(32,dtype=np.float64),'object_normal_schema':np.asarray('ragged-v1'),'object_normal_event_offsets':np.arange(33,dtype=np.int64)*11,'object_normal_points':np.arange(352*3,dtype=np.float64).reshape(352,3)}
        self.values.update({f'field_{i}':np.arange(32,dtype=np.float32) for i in range(160)});assert len(self.values)==164
        self.write(self.a);self.write(self.b)
    def tearDown(self):self.temp.cleanup()
    def write(self,p,change=None):
        p.mkdir(exist_ok=True);ledger=[]
        for start in [0,32]:
            arrays={k:v.copy() for k,v in self.values.items()}
            if start==32 and change:change(arrays)
            f=p/f'physics_{start:05d}_{start+32:05d}.npz';np.savez(f,**arrays);ledger.append({'start':start,'stop':start+32,'path':f.name,'sha256':sha(f)})
        (p/'physics_chunks.json').write_text(json.dumps(ledger))
    def test_complete_scalar_ragged_and_time_arrays(self):
        d=compare_first64(self.a,self.b);self.assertTrue(d['all_fields_byte_identical']);self.assertEqual(d['field_comparisons'],328)
    def test_late_contact_point_must_be_compared(self):
        self.write(self.a,lambda z:z['object_normal_points'].__setitem__((200,2),-12345));d=compare_first64(self.a,self.b);self.assertFalse(d['all_fields_byte_identical']);self.assertEqual([r['field'] for r in d['rows'] if not r['byte_identical']],['object_normal_points'])
    def test_terminal_ragged_offset_must_be_compared(self):
        self.write(self.a,lambda z:z['object_normal_event_offsets'].__setitem__(32,111111));self.assertFalse(compare_first64(self.a,self.b)['all_fields_byte_identical'])
    def test_scalar_change_rejects(self):
        self.write(self.a,lambda z:z.__setitem__('object_normal_schema',np.asarray('changed')));self.assertFalse(compare_first64(self.a,self.b)['all_fields_byte_identical'])
    def test_dtype_change_rejects(self):
        self.write(self.a,lambda z:z.__setitem__('field_0',z['field_0'].astype(np.float64)));self.assertFalse(compare_first64(self.a,self.b)['all_fields_byte_identical'])
    def test_missing_field_rejects(self):
        self.write(self.a,lambda z:z.pop('field_0'))
        with self.assertRaises(ValueError):compare_first64(self.a,self.b)
    def test_source_bytes_corruption_rejects(self):
        f=self.a/'physics_00032_00064.npz';f.write_bytes(f.read_bytes()+b'changed')
        with self.assertRaisesRegex(ValueError,'hash mismatch'):compare_first64(self.a,self.b)
    def test_missing_prefix_and_overlapping_ledger_reject(self):
        p=self.a/'physics_chunks.json';d=json.loads(p.read_text());p.write_text(json.dumps(d[:1]))
        with self.assertRaisesRegex(ValueError,'not fully'):prefix_chunks(self.a)
        d[1]['start']=16;p.write_text(json.dumps(d))
        with self.assertRaisesRegex(ValueError,'contiguous'):prefix_chunks(self.a)

if __name__=='__main__':unittest.main()
