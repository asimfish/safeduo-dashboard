"""Single-variable native16-vs8 convergence test at unchanged moving feedback."""
from pathlib import Path
import copy,datetime,hashlib,json,shutil,subprocess
H=Path(__file__).resolve().parent;old=H/'fourhand_native_probe_v100';P=H/'fourhand_native_probe_v101';S=H/'spike/native_mimic_feedback_sweep16_v1'
read=lambda p:json.loads(Path(p).read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()

def main():
    assert not P.exists()
    failed=read(old/'LOADED_FEEDBACK_DIAGNOSTIC_DECISION_V1.json')
    assert failed['physics_events']==208 and not failed['loaded_feedback_model_diagnostic_pass']
    assert failed['checks']['original_physical'] and failed['checks']['all_original_feedback_and_filtered_targets_audited']
    cpu=read(S/'CPU_BOUNDARY_VERIFICATION_V1.json');assert cpu['actual_exit']==0 and cpu['CPU_boundary_scenarios']==14
    for f,d in cpu['source_sha256'].items():assert sha(f)==d,f
    reg=copy.deepcopy(read(old/'REGISTRATION_V1.json'))
    for f,d in reg['source_sha256'].items():assert sha(f)==d,f
    P.mkdir()
    for f in old.iterdir():
        if f.suffix in ['.py','.usda'] or f.name=='PRIVATE_KIT_USER_CONFIG_FROZEN_V1.json':shutil.copyfile(f,P/f.name)
    shutil.copytree(old/'private_kit_user_data',P/'private_kit_user_data')
    launcher=H/'launch_native_clock_admission_v101.py';assert not launcher.exists()
    text=(H/'launch_native_clock_admission_v100.py').read_text().replace('v100','v101').replace('V100','V101').replace('NATIVE100','NATIVE101')
    launcher.write_text(text);subprocess.run(['/usr/bin/python3','-m','py_compile',str(launcher)],check=True)
    reg.update(attempt_version=101,scientific_candidate_version=101,registered_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        first64_physical_prefix98_required=False,
        change_scope='One numerical intervention relative to100: native extra mimic passes8->16. Byte-identical feedback worker, original0.02rad/s filter, seed and all77 physical parameters. Same1024 maximum and all original q AND qd/physical/force/task thresholds. Compare common208 separately from full1024. Changed physical prefix permitted and reported; identical submitted prefix targets required.')
    reg['native_sweep_spike']=dict(reg['native_sweep_spike'],library=str(S/'bridge.so'),extra_pass_count=16)
    reg['private_asset_settings']=dict(reg['private_asset_settings'],private_directory=str(P/'private_kit_user_data'))
    sources={}
    for f in reg['source_sha256']:
        target=Path(f.replace('fourhand_native_probe_v100','fourhand_native_probe_v101').replace('launch_native_clock_admission_v100','launch_native_clock_admission_v101'))
        if not target.exists():
            assert Path(f).is_relative_to(old),f
            target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(f,target)
        sources[str(target)]=sha(target)
    for f in [Path(__file__),S/'bridge.cpp',S/'bridge.so',S/'test_boundary.py',S/'fake_driver.cpp',S/'fake_driver.so',S/'CPU_BOUNDARY_VERIFICATION_V1.json',
              old/'LOADED_FEEDBACK_DIAGNOSTIC_DECISION_V1.json',H/'audit_loaded_feedback_window_v1.py',Path('/home/liyufeng/safeduo/docs/adr/20261012-native-mimic-moving-contact.md')]:sources[str(f)]=sha(f)
    assert sha(P/'native_common_beam_v1.py')==sha(old/'native_common_beam_v1.py')
    reg['source_sha256']=sources;(P/'REGISTRATION_V1.json').write_text(json.dumps(reg,indent=2)+'\n')
    plan=dict(candidate=101,baseline=100,registered_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        maximum_native_executions=1,maximum_native_wall_s=600,maximum_scheduler_wait_s=900,maximum_physics_events=1024,
        only_changed_scientific_setting='extra_mimic_passes8->16',byte_identical_feedback_worker100=True,
        all77_native_parameters_and13_seed_fields_byte_identical98_required=True,
        first64_submitted_targets_identical100_required=True,first64_physical_arrays_byte_equality_not_required_due_to_solver_intervention=True,
        common_window_steps=208,original_q_AND_qd_tolerance=1e-4,all_original_physical_force_and_task_gates_unchanged=True,
        original_hand_target_rate_rad_s=.02,formal_holdout_count=0,new_independent_random_cases=0,fullSystem0_accepted=False,
        source_sha256={str(f):sha(f) for f in [Path(__file__),P/'REGISTRATION_V1.json',launcher,H/'audit_loaded_feedback_window_v1.py',S/'CPU_BOUNDARY_VERIFICATION_V1.json']})
    out=H/'LOADED_FEEDBACK101_SWEEP16_PROSPECTIVE_PLAN_V1.json';assert not out.exists();out.write_text(json.dumps(plan,indent=2)+'\n')
    print('FROZEN101_NATIVE16_ONLY; FEEDBACK100_WORKER_IDENTICAL; ORIGINAL_THRESHOLDS_AND_PARAMETERS_UNCHANGED',flush=True)
if __name__=='__main__':main()
