"""Validate the one prospective startup correction; reject unrelated drift."""
from copy import deepcopy


def effective_config(original, runtime_observation, physics_dt, substeps):
    if physics_dt != 1 / 960 or substeps != 16:
        raise ValueError('Original 960Hz/16-substep clock required')
    before = original['persistent']['simulation']['minFrameRate']
    after = runtime_observation['persistent']['simulation']['minFrameRate']
    if type(before) is not int or before != 12 or type(after) is not int or after != 60:
        raise ValueError('Expected captured startup12 and native writeback60')
    expected = deepcopy(original)
    expected['persistent']['simulation']['minFrameRate'] = 60
    if expected != runtime_observation:
        raise ValueError('Unrelated runtime configuration drift')
    return expected
