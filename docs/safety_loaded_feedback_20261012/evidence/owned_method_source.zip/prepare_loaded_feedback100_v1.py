"""Correct the prelaunch-only audit99 label mismatch in a fresh registration."""
from pathlib import Path
import copy,datetime,hashlib,json,shutil,subprocess
H=Path(__file__).resolve().parent;old=H/'fourhand_native_probe_v99';P=H/'fourhand_native_probe_v100'
read=lambda p:json.loads(Path(p).read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()

def main():
    assert not P.exists() and not (old/'RESOURCE_EXECUTION_V1.json').exists()
    assert read(old/'PRELAUNCH_AUDIT_CONTRACT_FAILURE_V1.json')['actual_exit']==1
    reg=copy.deepcopy(read(old/'REGISTRATION_V1.json'))
    for f,d in reg['source_sha256'].items():assert sha(f)==d,f
    P.mkdir()
    for f in old.iterdir():
        if f.suffix in ['.py','.usda'] or f.name=='PRIVATE_KIT_USER_CONFIG_FROZEN_V1.json':shutil.copyfile(f,P/f.name)
    shutil.copytree(old/'private_kit_user_data',P/'private_kit_user_data')
    mapping={'fourhand_native_probe_v99':'fourhand_native_probe_v100','launch_native_clock_admission_v99':'launch_native_clock_admission_v100','audit_loaded_feedback_targets99':'audit_loaded_feedback_targets100','audit_loaded_feedback_decisions99':'audit_loaded_feedback_decisions100'}
    for f in [H/'launch_native_clock_admission_v99.py',H/'audit_loaded_feedback_targets99_v1.py',H/'audit_loaded_feedback_decisions99_v1.py']:
        name=f.name
        for a,b in mapping.items():name=name.replace(a,b)
        out=H/name;assert not out.exists();text=f.read_text().replace('v99','v100').replace('V99','V100').replace('NATIVE99','NATIVE100').replace('TARGETS99','TARGETS100').replace('DECISIONS99','DECISIONS100')
        if 'decisions' in name:text=text.replace('PASS_INDEPENDENT_LOADED_PREFIX_AND_FEEDBACK_HAND_TARGET_BINDING','PASS_INDEPENDENT_ALL_MICROSTEP_COUPLED_NATIVE_TARGET_BINDING')
        out.write_text(text);subprocess.run(['/usr/bin/python3','-m','py_compile',str(out)],check=True)
    reg.update(attempt_version=100,scientific_candidate_version=99,registered_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        change_scope='Original99 scientific controller unchanged. Correct only its prelaunch audit result label mismatch; original99 native launch count0/failure preserved.')
    reg['private_asset_settings']=dict(reg['private_asset_settings'],private_directory=str(P/'private_kit_user_data'))
    sources={}
    for f in reg['source_sha256']:
        name=f
        for a,b in mapping.items():name=name.replace(a,b)
        out=Path(name)
        if not out.exists():
            assert Path(f).is_relative_to(old),f
            out.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(f,out)
        sources[str(out)]=sha(out)
    for f in [Path(__file__),old/'PRELAUNCH_AUDIT_CONTRACT_FAILURE_V1.json']:
        sources[str(f)]=sha(f)
    assert sha(P/'native_common_beam_v1.py')==sha(old/'native_common_beam_v1.py')
    reg['source_sha256']=sources;(P/'REGISTRATION_V1.json').write_text(json.dumps(reg,indent=2)+'\n')
    plan=copy.deepcopy(read(H/'LOADED_FEEDBACK99_PROSPECTIVE_PLAN_V1.json'))
    plan.update(candidate=100,scientific_candidate=99,setup_change='Prelaunch audit label seam corrected; worker99 byte-identical.',
        native99_launches=0,source_sha256={str(f):sha(f) for f in [Path(__file__),P/'REGISTRATION_V1.json',H/'launch_native_clock_admission_v100.py',H/'audit_loaded_feedback_targets100_v1.py',H/'audit_loaded_feedback_decisions100_v1.py']})
    out=H/'LOADED_FEEDBACK100_PROSPECTIVE_PLAN_V1.json';assert not out.exists();out.write_text(json.dumps(plan,indent=2)+'\n')
    print('FROZEN100_FEEDBACK99_WORKER_IDENTICAL; CORRECTED_PRELAUNCH_AUDIT_LABEL_ONLY',flush=True)
if __name__=='__main__':main()
