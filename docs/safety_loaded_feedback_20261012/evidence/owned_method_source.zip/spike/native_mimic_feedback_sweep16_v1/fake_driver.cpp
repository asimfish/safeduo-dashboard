// CPU-only CUDA boundary fixture. Does not create a GPU context or launch a kernel.
#include <cuda.h>
#include <vector>
#include <cstring>
#include <cstdint>
namespace {
struct Entry {uintptr_t function;uint32_t scalar;};
std::vector<Entry> entries;
uintptr_t context=0x50;
int failed_role=0,failed_ordinal=0,seen[4]={};
bool bad_layout=false;
}
extern "C" CUresult CUDAAPI cuLaunchKernel(CUfunction f,unsigned,unsigned,unsigned,unsigned,unsigned,unsigned,unsigned,CUstream,void** params,void**){
 uintptr_t role=reinterpret_cast<uintptr_t>(f);uint32_t scalar=0;
 if(role==1&&params)std::memcpy(&scalar,params[1],4);
 entries.push_back({role,scalar});
 if(role<4&&int(role)==failed_role&&++seen[role]==failed_ordinal)return CUDA_ERROR_UNKNOWN;
 return CUDA_SUCCESS;
}
extern "C" CUresult CUDAAPI cuFuncGetName(const char** name,CUfunction f){
 auto role=reinterpret_cast<uintptr_t>(f);
 *name=role==1?"artiSolveInternalTendonAndMimicJointConstraints1T":role==2?"artiSolveInternalConstraintsTGS1T":"unrelated";
 return CUDA_SUCCESS;
}
extern "C" CUresult CUDAAPI cuFuncGetParamInfo(CUfunction f,size_t i,size_t* offset,size_t* size){
 const size_t sizes[]={8,4,4,4,1,1};
 if(reinterpret_cast<uintptr_t>(f)==1&&i<6){*offset=i*8;*size=(bad_layout&&i==2)?8:sizes[i];return CUDA_SUCCESS;}
 if(reinterpret_cast<uintptr_t>(f)==2&&i==0){*offset=0;*size=8;return CUDA_SUCCESS;}
 return CUDA_ERROR_INVALID_VALUE;
}
extern "C" CUresult CUDAAPI cuCtxGetCurrent(CUcontext* ctx){*ctx=reinterpret_cast<CUcontext>(context);return CUDA_SUCCESS;}
extern "C" int fake_count(){return int(entries.size());}
extern "C" int fake_role(int i){return int(entries.at(i).function);}
extern "C" uint32_t fake_scalar(int i){return entries.at(i).scalar;}
extern "C" void fake_reset(){entries.clear();std::memset(seen,0,sizeof(seen));failed_role=0;failed_ordinal=0;}
extern "C" void fake_failure(int role,int ordinal){failed_role=role;failed_ordinal=ordinal;}
extern "C" void fake_context(uintptr_t value){context=value;}
extern "C" void fake_bad_layout(int value){bad_layout=value!=0;}
