"""Exercise forwarding and failure boundaries without CUDA hardware or SDK imports."""
from pathlib import Path
import ctypes as C
import json,os,struct,subprocess,sys,tempfile
P=Path(__file__).resolve().parent
SCENARIOS=['disabled','copied_arguments','stream','descriptor','context','missing_pair','original_error','extra_error','stale_event','stale_session','unsupported_ABI','abort_during_event','event_capacity','high_pass_count']

def case(name):
    fake=C.CDLL(str(P/'fake_driver.so'),mode=C.RTLD_GLOBAL)
    bridge=C.CDLL(None)
    launch=bridge.cuLaunchKernel
    launch.argtypes=[C.c_void_p,*([C.c_uint]*7),C.c_void_p,C.POINTER(C.c_void_p),C.c_void_p]
    launch.restype=C.c_int
    bridge.safeduo_sweep_start.argtypes=[C.c_char_p,C.c_int,C.c_int]
    fake.fake_scalar.restype=C.c_uint32
    values=[C.c_uint64(0x100),C.c_float(.3),C.c_float(.001),C.c_float(960),C.c_uint8(1),C.c_uint8(1)]
    params=(C.c_void_p*6)(*[C.addressof(v) for v in values])
    def call(role,stream=0x40):return launch(role,1,1,1,32,1,1,0,stream,params,None)
    with tempfile.TemporaryDirectory(prefix='safeduo-sweep-cpu-') as folder:
        path=Path(folder)/'log.jsonl'
        if name=='high_pass_count':
            assert bridge.safeduo_sweep_start(str(path).encode(),17,1)==-1
            assert bridge.safeduo_sweep_start(str(path).encode(),16,1)==0
            assert call(1)==call(2)==0
            assert bridge.safeduo_sweep_prepare()==0
            fake.fake_reset();assert bridge.safeduo_sweep_event_begin(0)==0
            original=struct.unpack('<I',struct.pack('<f',values[1].value))[0]
            assert call(1)==0
            values[1].value=.9
            assert call(2)==0 and fake.fake_count()==18
            assert [fake.fake_role(i) for i in range(18)]==[1,2]+[1]*16
            assert all(fake.fake_scalar(i)==original for i in [0]+list(range(2,18)))
            assert bridge.safeduo_sweep_event_end(0)==0
            assert json.loads(path.read_text().splitlines()[-1])['extra']==16
            assert bridge.safeduo_sweep_stop()==0
            return
        passes=0 if name=='disabled' else 2
        assert bridge.safeduo_sweep_start(str(path).encode(),passes,1)==0
        assert call(1)==call(2)==0
        if name=='unsupported_ABI':
            fake.fake_bad_layout(1);assert bridge.safeduo_sweep_prepare()==-3
            assert bridge.safeduo_sweep_event_begin(0)==-1
            assert bridge.safeduo_sweep_stop()==0
            return
        assert bridge.safeduo_sweep_prepare()==0
        fake.fake_reset()
        if name=='event_capacity':
            for index in range(2048):
                assert bridge.safeduo_sweep_event_begin(index)==0
                assert call(1)==call(2)==0
                assert bridge.safeduo_sweep_event_end(index)==0
            assert bridge.safeduo_sweep_event_begin(2048)==-1
            assert bridge.safeduo_sweep_abort()==0
            return
        assert bridge.safeduo_sweep_event_begin(0)==0
        if name=='missing_pair':
            assert call(2)==1
            assert fake.fake_count()==1
        else:
            if name=='abort_during_event':
                assert call(1)==0
                assert bridge.safeduo_sweep_abort()==0
                assert call(2)==0 and fake.fake_count()==2
                assert bridge.safeduo_sweep_abort()==0
                assert json.loads(path.read_text().splitlines()[-1])['interrupted_event']==0
                return
            original=struct.unpack('<I',struct.pack('<f',values[1].value))[0]
            assert call(1)==0
            if name in ['stale_event','stale_session']:
                assert bridge.safeduo_sweep_event_end(0)==-2
                if name=='stale_session':
                    assert bridge.safeduo_sweep_stop()==0
                    path=Path(folder)/'restart.jsonl'
                    assert bridge.safeduo_sweep_start(str(path).encode(),2,1)==0
                    assert call(1)==call(2)==0
                    assert bridge.safeduo_sweep_prepare()==0
                    fake.fake_reset();assert bridge.safeduo_sweep_event_begin(0)==0
                else:
                    assert bridge.safeduo_sweep_event_begin(1)==0
                assert call(2)==1
                assert bridge.safeduo_sweep_event_end(0 if name=='stale_session' else 1)==-2
                assert bridge.safeduo_sweep_stop()==0
                return
            if name=='stream':result=call(2,0x41)
            else:
                if name=='descriptor':values[0].value=0x200
                if name=='context':fake.fake_context(0x51)
                if name=='original_error':fake.fake_failure(2,1)
                if name=='extra_error':fake.fake_failure(1,1)
                if name=='copied_arguments':values[1].value=.9
                result=call(2)
            if name in ['disabled','copied_arguments']:
                assert result==0
                roles=[fake.fake_role(i) for i in range(fake.fake_count())]
                assert roles==([1,2] if passes==0 else [1,2,1,1])
                if passes:assert all(fake.fake_scalar(i)==original for i in [0,2,3])
                assert bridge.safeduo_sweep_event_end(0)==0
                rows=[json.loads(s) for s in path.read_text().splitlines()]
                assert rows[-1]['extra']==passes and rows[-1]['errors']==0
                assert bridge.safeduo_sweep_stop()==0
                return
            assert result==(999 if name in ['original_error','extra_error'] else 1)
            assert fake.fake_count()==(3 if name=='extra_error' else 2)
        assert bridge.safeduo_sweep_event_end(0)==-2
        assert bridge.safeduo_sweep_stop()==0

def main():
    if len(sys.argv)>1:case(sys.argv[1]);print('CPU_BOUNDARY_PASS',sys.argv[1]);return
    for scenario in SCENARIOS:
        r=subprocess.run([sys.executable,'-B',str(Path(__file__)),scenario],env={**os.environ,'LD_PRELOAD':str(P/'bridge.so')},capture_output=True,text=True,timeout=20)
        print(r.stdout.strip(),flush=True)
        if r.returncode:print(r.stderr,flush=True);raise SystemExit(r.returncode)
    print('CPU_ONLY13_BOUNDARY_CASES_PASS_NO_NATIVE_SAFETY_CLAIM',flush=True)

if __name__=='__main__':main()
