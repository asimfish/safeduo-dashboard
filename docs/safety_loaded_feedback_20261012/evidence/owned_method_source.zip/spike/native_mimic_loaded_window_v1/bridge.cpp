// Owned-process numerical diagnostic. No tensor writes or GPU descriptor reads.
#include <cuda.h>
#include <dlfcn.h>
#include <array>
#include <atomic>
#include <cstdio>
#include <cstring>
#include <mutex>
#include <unordered_map>

namespace {
using Launch = CUresult (CUDAAPI *)(CUfunction,unsigned,unsigned,unsigned,unsigned,unsigned,unsigned,unsigned,CUstream,void**,void**);
using Name = CUresult (CUDAAPI *)(const char**,CUfunction);
using Param = CUresult (CUDAAPI *)(CUfunction,size_t,size_t*,size_t*);
using Context = CUresult (CUDAAPI *)(CUcontext*);
std::mutex gate;
std::atomic<bool> active{false};
std::atomic<int> event{-1};
std::atomic<unsigned> generation{0};
FILE* log_file=nullptr;
int passes=0,expected=0,next_event=0;
bool prepared=false;
CUfunction mimic=nullptr,internal=nullptr;
std::unordered_map<CUfunction,int> roles;
struct Count {int native_mimic=0,native_internal=0,extra=0,errors=0;};
std::array<Count,2048> counts;
constexpr size_t argument_sizes[6]={8,4,4,4,1,1};
struct Cache {
 bool fresh=false;
 int epoch=-1;
 unsigned generation=0;
 CUfunction function=nullptr;
 CUcontext context=nullptr;
 CUstream stream=nullptr;
 unsigned gx=0,gy=0,gz=0,bx=0,by=0,bz=0,shared=0;
 std::array<std::array<unsigned char,8>,6> bytes{};
};
thread_local Cache cached;

template<class T> T resolve(const char* name){return reinterpret_cast<T>(dlsym(RTLD_NEXT,name));}
Launch real_launch(){static Launch f=resolve<Launch>("cuLaunchKernel");return f;}
int role_of(CUfunction f){
 std::lock_guard<std::mutex> lock(gate);
 auto found=roles.find(f);if(found!=roles.end())return found->second;
 if(roles.size()>=4096)return -1;
 static Name get_name=resolve<Name>("cuFuncGetName");
 const char* name=nullptr;int role=-1;
 if(get_name&&get_name(&name,f)==CUDA_SUCCESS&&name){
  if(std::strcmp(name,"artiSolveInternalTendonAndMimicJointConstraints1T")==0){role=0;mimic=f;}
  if(std::strcmp(name,"artiSolveInternalConstraintsTGS1T")==0){role=1;internal=f;}
 }
 roles.emplace(f,role);return role;
}
CUresult fail(int e,const char* reason,CUresult status=CUDA_ERROR_INVALID_VALUE){
 std::lock_guard<std::mutex> lock(gate);
 if(e>=0&&e<2048){++counts[e].errors;}
 if(log_file){std::fprintf(log_file,"{\"kind\":\"failure\",\"event\":%d,\"reason\":\"%s\",\"CUDA_status\":%d}\n",e,reason,int(status));}
 cached.fresh=false;return status;
}
void record(int e,int role,CUresult status,int extra){
 std::lock_guard<std::mutex> lock(gate);
 if(extra){counts[e].extra+=extra;}
 else if(role==0){++counts[e].native_mimic;}
 else{++counts[e].native_internal;}
 if(status!=CUDA_SUCCESS){++counts[e].errors;}
 std::fprintf(log_file,"{\"kind\":\"launch\",\"event\":%d,\"role\":%d,\"extra\":%d,\"CUDA_status\":%d}\n",e,role,extra,int(status));
}
}

extern "C" CUresult CUDAAPI cuLaunchKernel(CUfunction f,unsigned gx,unsigned gy,unsigned gz,
 unsigned bx,unsigned by,unsigned bz,unsigned shared,CUstream stream,void** params,void** extra){
 auto real=real_launch();if(!real)return CUDA_ERROR_NOT_INITIALIZED;
 if(!active.load())return real(f,gx,gy,gz,bx,by,bz,shared,stream,params,extra);
 int role=role_of(f),e=event.load();
 if(role<0||e<0)return real(f,gx,gy,gz,bx,by,bz,shared,stream,params,extra);
 if(e>=2048||!prepared)return fail(e,"unprepared_or_out_of_window");
 if(role==0&&passes>0){
  if(!params||extra)return fail(e,"unsupported_mimic_launch_parameter_representation");
  static Context get_context=resolve<Context>("cuCtxGetCurrent");
  CUcontext ctx=nullptr;
  if(!get_context||get_context(&ctx)!=CUDA_SUCCESS||!ctx)return fail(e,"missing_mimic_context");
  cached.fresh=false;cached.epoch=e;cached.generation=generation.load();cached.function=f;cached.context=ctx;cached.stream=stream;
  cached.gx=gx;cached.gy=gy;cached.gz=gz;cached.bx=bx;cached.by=by;cached.bz=bz;cached.shared=shared;
  for(int i=0;i<6;++i){if(!params[i])return fail(e,"missing_CPU_argument");std::memcpy(cached.bytes[i].data(),params[i],argument_sizes[i]);}
  cached.fresh=true;
 }
 CUresult result=real(f,gx,gy,gz,bx,by,bz,shared,stream,params,extra);
 record(e,role,result,0);
 if(result!=CUDA_SUCCESS){cached.fresh=false;return result;}
 if(role!=1||passes==0)return result;
 if(!cached.fresh||cached.epoch!=e||cached.generation!=generation.load()||cached.stream!=stream||cached.function!=mimic)
  return fail(e,"missing_fresh_same_thread_event_stream_mimic");
 static Context get_context=resolve<Context>("cuCtxGetCurrent");CUcontext ctx=nullptr;
 if(!get_context||get_context(&ctx)!=CUDA_SUCCESS||ctx!=cached.context)return fail(e,"context_mismatch");
 if(!params||extra||!params[0]||std::memcmp(params[0],cached.bytes[0].data(),8)!=0)
  return fail(e,"opaque_descriptor_identity_mismatch");
 cached.fresh=false; // Consume once; do not reuse across another internal call.
 void* copied[6];for(int i=0;i<6;++i)copied[i]=cached.bytes[i].data();
 for(int i=0;i<passes;++i){
  CUresult added=real(cached.function,cached.gx,cached.gy,cached.gz,cached.bx,cached.by,cached.bz,
       cached.shared,cached.stream,copied,nullptr);
  record(e,0,added,1);if(added!=CUDA_SUCCESS)return added;
 }
 return result;
}

extern "C" int safeduo_sweep_start(const char* path,int extra_pass_count,int expected_native_sweeps){
 std::lock_guard<std::mutex> lock(gate);
 if(active||log_file||extra_pass_count<0||extra_pass_count>8||expected_native_sweeps<1||expected_native_sweeps>256)return -1;
 log_file=std::fopen(path,"wx");if(!log_file)return -2;
 passes=extra_pass_count;expected=expected_native_sweeps;counts={};roles.clear();
 mimic=nullptr;internal=nullptr;prepared=false;next_event=0;event=-1;++generation;active=true;
 std::fprintf(log_file,"{\"kind\":\"start\",\"extra_pass_count\":%d,\"expected_native_sweeps\":%d}\n",passes,expected);
 return 0;
}
extern "C" int safeduo_sweep_prepare(){
 std::lock_guard<std::mutex> lock(gate);
 if(!active||prepared||!mimic||!internal)return -1;
 static Param get_param=resolve<Param>("cuFuncGetParamInfo");if(!get_param)return -2;
 size_t offset=0,size=0;
 for(size_t i=0;i<6;++i){if(get_param(mimic,i,&offset,&size)!=CUDA_SUCCESS||size!=argument_sizes[i])return -3;}
 if(get_param(mimic,6,&offset,&size)!=CUDA_ERROR_INVALID_VALUE)return -4;
 if(get_param(internal,0,&offset,&size)!=CUDA_SUCCESS||size!=8)return -5;
 prepared=true;
 std::fprintf(log_file,"{\"kind\":\"prepared\",\"mimic_sizes\":[8,4,4,4,1,1],\"internal_parameters_interpreted\":false}\n");
 std::fflush(log_file);return 0;
}
extern "C" int safeduo_sweep_event_begin(int index){
 std::lock_guard<std::mutex> lock(gate);
 if(!active||!prepared||event>=0||index!=next_event||index<0||index>=2048)return -1;
 event=index;return 0;
}
extern "C" int safeduo_sweep_event_end(int index){
 std::lock_guard<std::mutex> lock(gate);
 if(event!=index||index<0||index>=2048)return -1;
 const auto c=counts[index];event=-1;++next_event;
 bool good=c.native_mimic==expected&&c.native_internal==expected&&c.extra==passes*expected&&c.errors==0;
 std::fprintf(log_file,"{\"kind\":\"event_end\",\"event\":%d,\"native_mimic\":%d,\"native_internal\":%d,\"extra\":%d,\"errors\":%d,\"pass\":%s}\n",index,c.native_mimic,c.native_internal,c.extra,c.errors,good?"true":"false");
 std::fflush(log_file);return good?0:-2;
}
extern "C" int safeduo_sweep_stop(){
 std::lock_guard<std::mutex> lock(gate);
 if(!active||!log_file||event>=0)return -1;
 active=false;prepared=false;std::fflush(log_file);std::fclose(log_file);log_file=nullptr;return 0;
}

extern "C" int safeduo_sweep_abort(){
 std::lock_guard<std::mutex> lock(gate);
 int interrupted=event.load();active=false;event=-1;prepared=false;
 if(log_file){std::fprintf(log_file,"{\"kind\":\"close\",\"interrupted_event\":%d}\n",interrupted);std::fflush(log_file);std::fclose(log_file);log_file=nullptr;}
 return 0;
}
