"""Exact first64-step custody for complete32-step NPZ chunks, including ragged packets."""
from pathlib import Path
import hashlib,json
import numpy as np

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def prefix_chunks(folder):
    folder=Path(folder);ledger=json.loads((folder/'physics_chunks.json').read_text())
    chunks=[];expected_start=0
    for row in ledger:
        if expected_start==64:break
        if row['start']!=expected_start or row['stop']!=expected_start+32:
            raise ValueError('Complete contiguous32-step prefix chunks are required; do not slice ragged packets')
        f=folder/row['path']
        if sha(f)!=row['sha256']:raise ValueError('Physics chunk source hash mismatch')
        with np.load(f,allow_pickle=False) as z:
            arrays={k:z[k].copy() for k in z.files}
        if len(arrays)!=164:raise ValueError('Exactly164 original physical fields required')
        if arrays['state_time_s'].shape!=(32,):raise ValueError('Time-row count mismatch')
        chunks.append({'start':row['start'],'stop':row['stop'],'source':str(f),'sha256':row['sha256'],'arrays':arrays})
        expected_start=row['stop']
    if expected_start!=64:raise ValueError('First64 steps not fully captured')
    return chunks

def compare_first64(candidate,baseline):
    a=prefix_chunks(candidate);b=prefix_chunks(baseline);rows=[]
    for ca,cb in zip(a,b):
        aa=ca['arrays'];bb=cb['arrays']
        if set(aa)!=set(bb):raise ValueError('Physical field identities differ')
        for k in sorted(aa):
            equal=aa[k].shape==bb[k].shape and aa[k].dtype==bb[k].dtype and aa[k].tobytes()==bb[k].tobytes()
            rows.append({'start':ca['start'],'stop':ca['stop'],'field':k,'byte_identical':equal,'candidate_shape':list(aa[k].shape),'baseline_shape':list(bb[k].shape)})
    return {'all_fields_byte_identical':all(r['byte_identical'] for r in rows),'chunks':2,'fields_per_chunk':164,'field_comparisons':328,'rows':rows,'source_sha256':{c['source']:c['sha256'] for c in a+b}}
