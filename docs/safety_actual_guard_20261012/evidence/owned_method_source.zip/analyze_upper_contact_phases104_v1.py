"""Read-only contact phase localization; geometric causation remains unproved."""
from pathlib import Path
import hashlib
import json
import numpy as np

H = Path(__file__).resolve().parent
P = H / 'fourhand_native_probe_v104'
read = lambda p: json.loads(Path(p).read_text())
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()


def intervals(mask):
    padded = np.r_[False, mask, False]
    starts = np.flatnonzero(np.diff(padded.astype(int)) == 1)
    ends = np.flatnonzero(np.diff(padded.astype(int)) == -1)
    return [dict(first_event=int(s), last_event=int(e - 1), samples=int(e - s), duration_s=(e - s) / 960) for s, e in zip(starts, ends)]


def main():
    out = P / 'UPPER_CONTACT_PHASE_DIAGNOSIS_V1.json'
    assert not out.exists()
    reg = read(P / 'REGISTRATION_V1.json')
    raw = Path(read(P / 'RESOURCE_EXECUTION_V1.json')['out'])
    identity = read(raw / 'native_task_identity.json')
    params = np.load(raw / 'native_parameters.npz', allow_pickle=False)
    refs = np.load(reg['coupled_reference_endpoints'], allow_pickle=False)
    keys = ['physics_event', 'state_time_s', 'object_state', 'four_hand_normal_N', 'feedback_grip_mode',
            'feedback_grip_finger_fraction', 'feedback_grip_thumb_fraction', 'object_normal_filter_abs_normal_sum_N']
    keys += [a + s for a in ('U_L', 'U_R') for s in ('_native_q', '_native_qd', '_actual_full_position_target')]
    pieces = {k: [] for k in keys}
    sources = {}
    for c in read(raw / 'physics_chunks.json'):
        f = raw / c['path']
        assert sha(f) == c['sha256']
        sources[str(f)] = c['sha256']
        with np.load(f, allow_pickle=False) as z:
            for k in keys:
                pieces[k].append(z[k].copy())
    d = {k: np.concatenate(v) for k, v in pieces.items()}
    assert np.array_equal(d['physics_event'], np.arange(7392))
    position = d['object_state'][:, :3]
    hands = {}
    for ai, a in ((2, 'U_L'), (3, 'U_R')):
        names = params[a + '_joint_names'].tolist()
        ids = refs[a + '_hand_indices']
        stroke = refs[a + '_hand_far_q'] - refs[a + '_hand_open_q']
        usable = abs(stroke) > 1e-8
        target = d[a + '_actual_full_position_target'][:, 0, ids]
        contact = d['four_hand_normal_N'][:, ai]
        above = contact > .1
        peak = int(np.argmax(contact))
        last = int(np.flatnonzero(above)[-1]) if above.any() else None
        milestones = {'peak_normal': peak, 'final': len(contact) - 1}
        if last is not None:
            milestones['last_above_original_minimum'] = last
        observations = {}
        for label, e in milestones.items():
            fractions = (target[e, usable] - refs[a + '_hand_open_q'][usable]) / stroke[usable]
            observations[label] = dict(event=e, time_s=float(d['state_time_s'][e]), payload_normal_N=float(contact[e]),
                finger_fraction=float(d['feedback_grip_finger_fraction'][e, ai]),
                thumb_fraction=float(d['feedback_grip_thumb_fraction'][e, ai]),
                actual_submitted_stroke_fraction_min=float(fractions.min()), actual_submitted_stroke_fraction_max=float(fractions.max()),
                actual_target_to_native_q_max_gap_rad=float(abs(target[e] - d[a + '_native_q'][e, 0, ids]).max()),
                actual_maximum_hand_speed_rad_s=float(abs(d[a + '_native_qd'][e, 0, ids]).max()),
                payload_displacement_from_first_measured_state_m=(position[e] - position[0]).tolist())
        links = {}
        thumb_force = np.zeros(len(contact))
        finger_force = np.zeros(len(contact))
        for index in identity['hand_partner_indices'][a]:
            path = identity['partners'][index]
            force = d['object_normal_filter_abs_normal_sum_N'][:, index]
            if 'thumb' in path:
                thumb_force += force
            elif any(n in path for n in ('index', 'middle', 'ring', 'little', 'pinky')):
                finger_force += force
            if force.max() > 1e-6:
                links[path] = dict(peak_normal_N=float(force.max()), peak_event=int(np.argmax(force)),
                                  final_normal_N=float(force[-1]), samples_above_original_minimum=int((force > .1).sum()))
        episodes = intervals(above)
        opposing = intervals((thumb_force > .1) & (finger_force > .1))
        hands[a] = dict(milestones=observations, payload_contact_episodes=episodes,
                       longest_payload_contact_s=max((x['duration_s'] for x in episodes), default=0.),
                       thumb_and_other_fingers_above_minimum_episodes=opposing,
                       thumb_and_finger_contact_is_not_a_wrench_or_grasp_certificate=True,
                       per_original_partner_normal=links, final_zero_contact=bool(contact[-1] == 0))
    for f in (Path(__file__), P / 'REGISTRATION_V1.json', raw / 'native_task_identity.json', raw / 'native_parameters.npz',
              Path(reg['coupled_reference_endpoints']), P / 'LOADED104_CAUSAL_FRONTIER_V2.json'):
        sources[str(f)] = sha(f)
    result = dict(status='OBSERVATIONAL_UPPER_CONTACT_PHASE_LOCALIZATION_ONLY', native_version=104, physics_events=7392,
                  hands=hands, payload_vertical_displacement_range_m=[float((position[:, 2] - position[0, 2]).min()), float((position[:, 2] - position[0, 2]).max())],
                  geometry_root_cause_proven=False, no_pose_or_endpoint_mutation=True,
                  current_paired_native105_only_changes_actual_guard_commands=True,
                  next_geometry_intervention='Use these exact contact-loss events and original collider transforms to choose one upper pose or endpoint counterfactual after105 closes; keep full original geometric/contact/model gates.',
                  new_random_cases=0, formal_holdout_count=0, fulltask_pass=False, fullSystem0_accepted=False, source_sha256=sources)
    out.write_text(json.dumps(result, indent=2) + '\n')
    print(result['status'], {a: dict(last_above=hands[a]['milestones'].get('last_above_original_minimum'),
                                   contact_links=len(hands[a]['per_original_partner_normal'])) for a in hands}, flush=True)


if __name__ == '__main__':
    main()
