"""One controller counterfactual; the qualified native boundary is unchanged."""
from pathlib import Path
import ast
import copy
import datetime
import hashlib
import json
import shutil

H = Path(__file__).resolve().parent
OLD = H / 'fourhand_native_probe_v104'
P = H / 'fourhand_native_probe_v105'
CPU = H / 'feedback_actual_target_spike_v1'
read = lambda p: json.loads(Path(p).read_text())
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()


def replace_once(text, before, after):
    assert text.count(before) == 1, before
    return text.replace(before, after)


def main():
    assert not P.exists()
    assert not read(OLD / 'LOADED_FEEDBACK_DURATION_DECISION_V1.json')['loaded_feedback_model_diagnostic_pass']
    assert read(CPU / 'RECORDED_INPUT_COMMAND_REPLAY_V1.json')['status'] == 'PASS_RECORDED_INPUT_COMMAND_INVARIANT_ONLY'
    exits = read(CPU / 'CPU_ACTUAL_EXIT_RECEIPTS_V1.json')
    assert exits['expected_red_reproduction']['actual_exit_code'] == 1
    assert exits['unit_and_property_test']['actual_exit_code'] == exits['full_recorded_input_replay']['actual_exit_code'] == 0
    for f, d in exits['source_sha256'].items():
        assert sha(f) == d
    reg = copy.deepcopy(read(OLD / 'REGISTRATION_V1.json'))
    for f, d in reg['source_sha256'].items():
        assert sha(f) == d, f
    P.mkdir()
    for f in OLD.iterdir():
        if f.suffix in ('.py', '.usda') or f.name == 'PRIVATE_KIT_USER_CONFIG_FROZEN_V1.json':
            shutil.copyfile(f, P / f.name)
    shutil.copytree(OLD / 'private_kit_user_data', P / 'private_kit_user_data')
    shutil.copyfile(CPU / 'actual_guard_nominal_v1.py', P / 'actual_guard_nominal_v1.py')
    worker = P / 'native_common_beam_v1.py'
    text = worker.read_text()
    text = replace_once(text, '        from coupled_hand_filter_v1 import coupled_filtered_hand_targets',
                        '        from coupled_hand_filter_v1 import coupled_filtered_hand_targets\n        from actual_guard_nominal_v1 import actual_guard_nominal')
    before = '                        filtered=coupled_filtered_hand_targets([parameters[a+\'_joint_names\'][i] for i in ids],'
    after = """                        d=grip_decisions[a]
                        guarded=actual_guard_nominal([parameters[a+'_joint_names'][i] for i in ids],
                            nominal_hand_targets[a],previous,array(hands.open_q[a]),array(hands.far_q[a]),
                            parameters[a+'_hard_limits'][0,ids],coupled_meta['assets'][a]['relations'],
                            d.mode,d.thumb_guard,d.finger_guard,dt,reg['feedback_grip_settings']['relax_rate'])
                        nominal_hand_targets[a]=guarded.astype(nominal_hand_targets[a].dtype)
""" + before
    text = replace_once(text, before, after)
    ast.parse(text)
    worker.write_text(text)
    launcher = H / 'launch_native_clock_admission_v105.py'
    capture = H / 'audit_loaded_native_capture105_v1.py'
    target = H / 'audit_loaded_actual_guard_targets105_v1.py'
    feedback = H / 'audit_loaded_actual_guard_decisions105_v1.py'
    closure = H / 'audit_loaded_actual_guard_window105_v1.py'
    assert not launcher.exists() and not capture.exists()
    launcher.write_text((H / 'launch_native_clock_admission_v104.py').read_text().replace('v104', 'v105').replace('V104', 'V105').replace('NATIVE104', 'NATIVE105'))
    capture.write_text((H / 'audit_loaded_native_capture104_v1.py').read_text().replace('assert version == 104', 'assert version == 105').replace('duration-only', 'actual-target guard counterfactual'))
    assert all(f.exists() for f in (target, feedback, closure)), 'Independent oracles must exist before freeze'
    reg.update(attempt_version=105, scientific_candidate_version=105, registered_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
               first64_physical_prefix_baseline=104, duration_prefix_baseline_version=104, duration_prefix_required_events=3488,
               independent_target_auditor=str(target), independent_feedback_auditor=str(feedback),
               independent_capture_auditor=str(capture),
               change_scope='Only actual submitted command anchoring in HOLD/RELAX/JOINT_GUARD. SEEK,960Hz/60Hz,FIFO6,16 native passes,8192capacity,8192horizon,0.10rad/s filter, original74 limits/24 q AND qd/model/contact/task gates and all77 physics/13 initial fields unchanged. First3488complete-event-chunks all164 fields must match104. No new random cases, lift or learnedSystem0.')
    reg['actual_target_guard_policy'] = dict(helper=str(P / 'actual_guard_nominal_v1.py'),
        hold='Use actual previous submitted target, clearing nominal backlog',
        relax='Open from actual previous submitted target; stop at registered open endpoint',
        joint_guard='Open guarded group from actual submitted target, hold other group',
        seek='Original nominal fraction and target filter unchanged',
        original_nominal_field_semantics='Guarded desired target after actual-command anchoring; float32 type preserved',
        common_prefix_required_complete_events=3488, baseline_first_guard_event=3504,
        target_float_binding_tolerance_rad=1e-7, guard_label_does_not_certify_physical_stopping=True)
    reg['private_asset_settings'] = dict(reg['private_asset_settings'], private_directory=str(P / 'private_kit_user_data'))
    sources = {}
    for f in reg['source_sha256']:
        old = Path(f)
        if old.is_relative_to(OLD):
            new = P / old.relative_to(OLD)
        elif old == H / 'launch_native_clock_admission_v104.py':
            new = launcher
        elif old == H / 'audit_loaded_native_capture104_v1.py':
            new = capture
        else:
            new = old
        if not new.exists():
            new.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(old, new)
        sources[str(new)] = sha(new)
    for f in (Path(__file__), P / 'actual_guard_nominal_v1.py', target, feedback, closure, CPU / 'CPU_ACTUAL_EXIT_RECEIPTS_V1.json',
              CPU / 'RECORDED_INPUT_COMMAND_REPLAY_V1.json', CPU / 'PROSPECTIVE_PLAN_V1.json', OLD / 'LOADED104_CAUSAL_FRONTIER_V2.json',
              OLD / 'LOADED_FEEDBACK_DURATION_DECISION_V1.json', OLD / 'CORE_ACTUAL_EXIT_RECEIPTS_V104.json'):
        sources[str(f)] = sha(f)
    reg['source_sha256'] = sources
    (P / 'REGISTRATION_V1.json').write_text(json.dumps(reg, indent=2) + '\n')
    plan = dict(candidate=105, baseline=104, registered_utc=reg['registered_utc'],
        only_scientific_change=reg['actual_target_guard_policy'], maximum_native_executions=1,
        maximum_native_wall_s=1800, maximum_scheduler_wait_s=900, physics_Hz=960, maximum_physics_events=8192,
        all77_physics_and13_seed_fields_identical98_required=True, first3488_all164_physical_fields_identical104_required=True,
        original_q_AND_qd_tolerance=1e-4, original_physical_and_task_gates_unchanged=True,
        original_actual_hand_speed_prelift_limit_rad_s=.05, native_solver_changes=0, native_kernel_changes=0,
        formal_holdout_count=0, new_random_cases=0, no_lift_enabled=True, fullSystem0_accepted=False,
        abort='Keep original failure abort after full16-step control. Preserve every failed sample; no rerun of a native failure.',
        rejection='Any original model/physical gate failure, missing custody, pre-intervention prefix mismatch or guard command invariant failure rejects this diagnostic.',
        source_sha256={str(f):sha(f) for f in (Path(__file__), P / 'REGISTRATION_V1.json', launcher, capture, target, feedback, closure)})
    out = H / 'LOADED_ACTUAL_GUARD105_PROSPECTIVE_PLAN_V1.json'
    assert not out.exists()
    out.write_text(json.dumps(plan, indent=2) + '\n')
    print('FROZEN105_ACTUAL_TARGET_GUARD;UNCHANGED_NATIVE16_AND_8192;ORIGINAL_GATES;COMMON_PREFIX3488', flush=True)


if __name__ == '__main__':
    main()
