"""Frozen-source and independent original-XML command checks before native105."""
from pathlib import Path
import ast
import hashlib
import json
import sys
import numpy as np

H = Path(__file__).resolve().parent
P = H / 'fourhand_native_probe_v105'
OLD = H / 'fourhand_native_probe_v104'
sys.path.insert(0, str(P))
from actual_guard_nominal_v1 import actual_guard_nominal
from audit_loaded_actual_guard_targets105_v1 import matrix, expected_guard_nominal

read = lambda p: json.loads(Path(p).read_text())
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()


def main():
    out = P / 'CPU_PREFLIGHT_VERIFICATION_V1.json'
    assert not out.exists()
    reg, oldreg = read(P / 'REGISTRATION_V1.json'), read(OLD / 'REGISTRATION_V1.json')
    allowed = {'attempt_version', 'scientific_candidate_version', 'registered_utc', 'first64_physical_prefix_baseline',
               'duration_prefix_baseline_version', 'duration_prefix_required_events', 'independent_target_auditor',
               'independent_feedback_auditor', 'independent_capture_auditor', 'change_scope', 'actual_target_guard_policy',
               'private_asset_settings', 'source_sha256'}
    changed = {k for k in set(reg) | set(oldreg) if reg.get(k) != oldreg.get(k)}
    assert changed == allowed, changed ^ allowed
    assert reg['maximum_controls'] == oldreg['maximum_controls'] == 512
    assert reg['native_sweep_spike'] == oldreg['native_sweep_spike']
    for f, d in reg['source_sha256'].items():
        assert sha(f) == d, f
    for f in P.glob('*.py'):
        ast.parse(f.read_text())
    for f in ('audit_loaded_actual_guard_targets105_v1.py', 'audit_loaded_actual_guard_decisions105_v1.py'):
        assert 'from actual_guard_nominal_v1' not in (H / f).read_text()
    raw = Path(read(OLD / 'RESOURCE_EXECUTION_V1.json')['out'])
    params = np.load(raw / 'native_parameters.npz', allow_pickle=False)
    refs = np.load(reg['coupled_reference_endpoints'], allow_pickle=False)
    assets = read(reg['coupled_assets'])['assets']
    arms = ('F_L', 'F_R', 'U_L', 'U_R')
    keys = ['physics_event', 'feedback_grip_mode', 'feedback_grip_finger_fraction', 'feedback_grip_thumb_fraction',
            'feedback_grip_thumb_guard', 'feedback_grip_finger_guard']
    keys += [a + '_actual_full_position_target' for a in arms]
    pieces = {k: [] for k in keys}
    for c in read(raw / 'physics_chunks.json'):
        path = raw / c['path']
        assert sha(path) == c['sha256']
        with np.load(path, allow_pickle=False) as z:
            for k in keys:
                pieces[k].append(z[k].copy())
    d = {k: np.concatenate(v) for k, v in pieces.items()}
    assert np.array_equal(d['physics_event'], np.arange(7392))
    comparisons = 0
    max_error = 0.
    for ai, a in enumerate(arms):
        allnames = params[a + '_joint_names'].tolist()
        names = assets[a]['hand_joint_names']
        ids = [allnames.index(n) for n in names]
        roots, A, b = matrix(names, assets[a]['original_URDF'])
        rootids = [names.index(n) for n in roots]
        opened, far = refs[a + '_hand_open_q'], refs[a + '_hand_far_q']
        thumb = np.array(['thumb' in n for n in names])
        for e in range(64, 7392):
            progress = np.where(thumb, d['feedback_grip_thumb_fraction'][e, ai], d['feedback_grip_finger_fraction'][e, ai])
            nominal = (opened + progress * (far - opened)).astype(np.float32)
            previous = d[a + '_actual_full_position_target'][e - 1, 0, ids]
            mode = str(d['feedback_grip_mode'][e, ai])
            tg, fg = bool(d['feedback_grip_thumb_guard'][e, ai]), bool(d['feedback_grip_finger_guard'][e, ai])
            candidate = actual_guard_nominal(names, nominal, previous, opened, far, params[a + '_hard_limits'][0, ids],
                                            assets[a]['relations'], mode, tg, fg, reg['control_dt_s'], reg['feedback_grip_settings']['relax_rate']).astype(np.float32)
            independent = expected_guard_nominal(names, A, b, rootids, opened, far, nominal, previous, mode, tg, fg,
                                                 reg['control_dt_s'], reg['feedback_grip_settings']['relax_rate'])
            error = float(abs(candidate - independent).max())
            assert error <= 1e-6, (a, e, error)
            max_error = max(max_error, error)
            comparisons += 1
    result = dict(status='PASS_FROZEN105_SINGLE_CONTROLLER_CHANGE', changed_registration_keys=sorted(changed),
                  frozen_sources=len(reg['source_sha256']), native_boundary_and_all_registered_physics_unchanged=True,
                  independent_XML_guard_reference_comparisons=comparisons, maximum_reference_difference_rad=max_error,
                  original_physical_and_model_thresholds_unchanged=True, native_executions_so_far=0, fullSystem0_accepted=False,
                  source_sha256={str(f):sha(f) for f in (Path(__file__), P / 'REGISTRATION_V1.json', H / 'LOADED_ACTUAL_GUARD105_PROSPECTIVE_PLAN_V1.json')})
    out.write_text(json.dumps(result, indent=2) + '\n')
    print(result['status'], comparisons, 'max_oracle_error', max_error, flush=True)


if __name__ == '__main__':
    main()
