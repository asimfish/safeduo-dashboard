"""Publish a paired controller diagnostic without promoting full acceptance."""
from pathlib import Path
import copy,csv,datetime,hashlib,html,json,re,shutil,subprocess,sys,zipfile,xml.etree.ElementTree as ET
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
P=Path(__file__).resolve().parent
H=P.parent
W=Path('/mnt/nas/data/lyf/double_hand/safeduo_dashboard_loaded_duration_20261012')
SLUG='safety_actual_guard_20261012'
R=W/'docs'/SLUG
sys.path.insert(0,str(H/'loaded_duration_report_delivery_v1'))
from native_video_pts_v1 import encode
from report_archive_utils_v1 import archive_parts,longest,figure
read=lambda p:json.loads(Path(p).read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
esc=lambda s:html.escape(str(s))
def write(p,v):Path(p).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')

def main():
    assert not R.exists() and not (P/'BUILD_MANIFEST_V1.json').exists()
    base=subprocess.check_output(['git','-c','core.filemode=false','rev-parse','HEAD'],cwd=W,text=True).strip()
    assert base=='e0933705ee7ae6817665f1df432515e84f2f8b63'
    versions=[104,105];decisions={};roots={};regs={}
    for v in versions:
        p=H/f'fourhand_native_probe_v{v}'
        assert read(p/f'ACTUAL_COMPLETION_EXIT_V{v}.json')['actual_outer_exit']==0
        assert all(x['actual_exit']==0 for x in read(p/f'CORE_ACTUAL_EXIT_RECEIPTS_V{v}.json')['actual_outer_exits'].values())
        decisions[v]=read(p/('LOADED_FEEDBACK_DURATION_DECISION_V1.json' if v==104 else 'LOADED_ACTUAL_GUARD_DECISION_V1.json'))
        roots[v]=Path(read(p/'RESOURCE_EXECUTION_V1.json')['out']);regs[v]=read(p/'REGISTRATION_V1.json')
    assert not decisions[104]['loaded_feedback_model_diagnostic_pass'] and decisions[105]['loaded_feedback_model_diagnostic_pass']
    assert decisions[105]['physical_prefix_events']==3488 and decisions[105]['physical_prefix_byte_identical']
    for d in ('media','evidence','figures'):(R/d).mkdir(parents=True,exist_ok=False)
    curves, media, archives, rows, state_summary = {}, [], [], [], []
    assets = read(regs[105]['coupled_assets'])['assets']
    for v in versions:
        p, raw = H / f'fourhand_native_probe_v{v}', roots[v]
        if v == 105:
            archives.extend(archive_parts(raw, v))
        for name in ['REGISTRATION_V1.json', 'RESOURCE_EXECUTION_V1.json', f'ACTUAL_COMPLETION_EXIT_V{v}.json',
                     f'CORE_ACTUAL_EXIT_RECEIPTS_V{v}.json', f'CORE_ACTUAL_EXIT_RECEIPTS_V{v}_V2.json',
                     'INDEPENDENT_CAPTURE_AUDIT_V1.json', 'INDEPENDENT_NATIVE_MIMIC_WINDOW_V6.json', 'INDEPENDENT_FULL_MOTOR_EFFORT_V4.json',
                     'INDEPENDENT_LOADED_FEEDBACK_TARGETS100_V1.json', 'INDEPENDENT_LOADED_FEEDBACK_DECISIONS100_V1.json',
                     'INDEPENDENT_CAMERA_FRAMING_V2.json', 'CAMERA_FRAMING_ACTUAL_EXIT_V1.json',
                     'INDEPENDENT_LOAD_ONLY_PRELIFT_INTENT_V1.json', 'PRELIFT_INTENT_ACTUAL_EXIT_V1.json',
                     'LOADED104_CAUSAL_FRONTIER_V2.json', 'CAUSAL_FRONTIER_ACTUAL_EXIT_V2.json',
                     'PREFIX_PHYSICAL_CUSTODY_V1.json', 'DURATION_DECISION_ACTUAL_EXIT_V1.json', 'CPU_PREFLIGHT_ACTUAL_EXIT_V1.json', 'PREPARATION_AND_PREFLIGHT_ACTUAL_EXITS_V1.json', 'ACTUAL_GUARD_DECISION_ACTUAL_EXIT_V1.json', 'UPPER_CONTACT_PHASE_DIAGNOSIS_V1.json', 'UPPER_CONTACT_PHASE_ACTUAL_EXIT_V1.json']:
            if (p / name).exists():
                shutil.copyfile(p / name, R / f'evidence/{v}_{name}')
        write(R / f'evidence/{v}_DECISION_V1.json', decisions[v])
        with np.load(raw / 'native_parameters.npz', allow_pickle=False) as params:
            relations = []
            for a, asset in assets.items():
                names = params[a + '_joint_names'].tolist()
                for j in ET.parse(asset['original_URDF']).findall('joint'):
                    m = j.find('mimic')
                    if m is not None and j.get('name') in asset['hand_joint_names']:
                        relations.append((a, names.index(j.get('name')), names.index(m.get('joint')), float(m.get('multiplier', '1')), float(m.get('offset', '0'))))
            assert len(relations) == 24
            pieces = []
            for ch in read(raw / 'physics_chunks.json'):
                f = raw / ch['path']
                assert sha(f) == ch['sha256']
                with np.load(f, allow_pickle=False) as z:
                    qe, ve = [], []
                    for a, si, mi, m, o in relations:
                        qe.append(abs(z[a + '_native_q'][:, 0, si] - m * z[a + '_native_q'][:, 0, mi] - o))
                        ve.append(abs(z[a + '_native_qd'][:, 0, si] - m * z[a + '_native_qd'][:, 0, mi]))
                    pieces.append(np.column_stack([z['physics_event'], z['state_time_s'], np.max(qe, axis=0), np.max(ve, axis=0),
                        z['four_hand_normal_N'], z['prelift_friction_capacity_proxy_N'], z['prelift_weight_reserve_N'],
                        z['prelift_max_hand_speed_rad_s'], z['prelift_native_hand_min_margin_rad'], z['prelift_ready']]))
        data = curves[v] = np.concatenate(pieces)
        n = len(data)
        assert n == decisions[v]['physics_events']
        assert abs(float(data[:, 3].max()) - decisions[v]['original_qd_error_rad_s']) < 1e-12
        rows.extend([[v, *row.tolist()] for row in data])
        state_summary.append(dict(version=v, observed_events=n, planned_events=regs[v]['contact_reproducer']['maximum_physics_events'],
            per_hand_peak_normal_N=data[:, 4:8].max(axis=0).tolist(), per_hand_last_normal_N=data[-1, 4:8].tolist(),
            per_hand_contact_samples_above_point1_N=(data[:, 4:8] > .1).sum(axis=0).tolist(),
            per_hand_longest_contact_s=[longest(data[:, 1], data[:, k] > .1) for k in range(4, 8)],
            all_four_contact_samples=int((data[:, 4:8].min(axis=1) > .1).sum()),
            all_four_longest_contact_s=longest(data[:, 1], data[:, 4:8].min(axis=1) > .1),
            prelift_ready_samples=int(data[:, 12].sum()), prelift_ready_longest_s=longest(data[:, 1], data[:, 12].astype(bool)),
            capacity_peak_N=float(data[:, 8].max()), capacity_last_N=float(data[-1, 8]),
            final_hand_speed_rad_s=float(data[-1, 10]), final_joint_margin_rad=float(data[-1, 11]),
            independent_initial_states=1, new_random_cases=0, formal_holdout_count=0))
        frames = read(raw / 'camera_frames.json')
        for view in ['top', 'front', 'side', 'overview']:
            selected = sorted((x for x in frames if x['view'] == view), key=lambda x: x['state_time_s'])
            assert selected[0]['state_time_s'] == 0 and abs(selected[-1]['state_time_s'] - n / 960) <= 1e-12
            for f in selected:
                assert sha(raw / f['path']) == f['sha256']
            if v == 104:
                prior = next(x for x in read(W/'docs/safety_sustained_fourhand_20261012/MEDIA_TIMESTAMPS_AND_CUSTODY_V1.json')['videos'] if x['version']==v and x['view']==view)
                item=copy.deepcopy(prior);item['video']='../safety_sustained_fourhand_20261012/'+item['video'];item['poster']='../safety_sustained_fourhand_20261012/'+item['poster']
                assert sha((R/item['video']).resolve())==item['video_sha256'];assert sha((R/item['poster']).resolve())==item['poster_sha256']
                media.append(item)
            else:
                poster, video = R / f'media/{v}_{view}_last.png', R / f'media/{v}_{view}.mp4'
                shutil.copyfile(raw / selected[-1]['path'], poster)
                encoded = encode(raw, selected, video, P / f'encoded_source_{v}_{view}')
                media.append(dict(version=v, view=view, video=str(video.relative_to(R)), poster=str(poster.relative_to(R)),original_frames=selected,native_first_state_time_s=0,native_last_state_time_s=n/960,final_frame_display_hold_s=1/15,exact_frame_pts=encoded,video_sha256=sha(video),poster_sha256=sha(poster)))
    header = ['version', 'physics_event', 'native_state_time_s', 'q_residual_max_rad', 'qd_residual_max_rad_s',
              'F_L_normal_N', 'F_R_normal_N', 'U_L_normal_N', 'U_R_normal_N', 'capacity_proxy_N', 'required_weight_reserve_N',
              'max_hand_speed_rad_s', 'min_joint_margin_rad', 'prelift_ready']
    with (R / 'PER_STEP_METRICS_V1.csv').open('w', newline='') as f:
        writer = csv.writer(f, lineterminator='\n')
        writer.writerow(header)
        writer.writerows(rows)
    write(R / 'CONTACT_AND_PRELIFT_SUMMARY_V1.json', dict(rows=state_summary, independent_states=1, success_rate_CI=None,
        reason_no_CI='One chosen development state and temporally dependent events do not define independent trials.'))
    write(R / 'RAW_ARCHIVE_MANIFEST_V1.json', dict(archives=archives, all_parts_required=True,
        baseline104_full_raw_manifest='../safety_sustained_fourhand_20261012/RAW_ARCHIVE_MANIFEST_V1.json'))
    write(R / 'MEDIA_TIMESTAMPS_AND_CUSTODY_V1.json', dict(videos=media, source='Original native RGB and recorded time stamps; final display hold adds no physical events.'))
    guard={};guard_curves={};observed_forces={}
    for v in versions:
        raw=roots[v];pieces=[]
        for c in read(raw/'physics_chunks.json'):
            with np.load(raw/c['path'],allow_pickle=False) as z:
                pieces.append({k:z[k].copy() for k in ['physics_event','state_time_s','feedback_grip_mode']+[a+'_actual_full_position_target' for a in ('F_L','F_R','U_L','U_R')]})
        data={k:np.concatenate([p[k] for p in pieces]) for k in pieces[0]};reg=regs[v];refs=np.load(reg['coupled_reference_endpoints'],allow_pickle=False);initial=np.load(raw/'actual_initial_seed_binding.npz',allow_pickle=False)
        summary={};rates={}
        for ai,a in enumerate(('F_L','F_R','U_L','U_R')):
            ids=refs[a+'_hand_indices'];actual=data[a+'_actual_full_position_target'][:,0,ids]
            delta=np.diff(np.concatenate([initial[a+'_target'][0,ids][None],actual]),axis=0)
            closing=np.maximum(delta*np.sign(refs[a+'_hand_far_q']-refs[a+'_hand_open_q']),0).max(axis=1)
            stats={}
            for mode in ('HOLD','RELAX','JOINT_GUARD'):
                mask=data['feedback_grip_mode'][:,ai]==mode
                stats[mode]=dict(native_samples=int(mask.sum()),actual_closing_samples=int((closing[mask]>1e-7).sum()),maximum_closing_rate_rad_s=float(closing[mask].max()*960) if mask.any() else None)
            summary[a]=stats;rates[a]=np.where(data['feedback_grip_mode'][:,ai]=='HOLD',closing*960,np.nan)
        guard[v]=summary;guard_curves[v]=(data['state_time_s'],rates)
        feedback=read(H/f'fourhand_native_probe_v{v}/INDEPENDENT_LOADED_FEEDBACK_DECISIONS100_V1.json')
        observed_forces[v]={a:max(x['normal_N'] for x in feedback['records'] if x['arm']==a) for a in ('F_L','F_R','U_L','U_R')}
    assert guard[105]['F_L']['HOLD']['native_samples']==4688 and guard[105]['F_L']['HOLD']['actual_closing_samples']==0
    write(R/'ACTUAL_GUARD_SUMMARY_V1.json',dict(versions=guard,controller_observed_force_peak_N=observed_forces,command_binding_tolerance_rad=1e-7,original_q_AND_qd_tolerance=1e-4,native105_RELAX_exercised=False,native105_JOINT_GUARD_exercised=False,command_stop_is_not_physical_stop=True))
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'axes.grid':True,'grid.alpha':.2,'svg.hashsalt':'safeduo-actual-guard'})
    colors={104:'#b45335',105:'#197b7e'}
    fig,axes=plt.subplots(2,2,figsize=(12,7),sharex=True)
    for i,ax in enumerate(axes.flat):
        for v in versions:ax.plot(curves[v][:,1],curves[v][:,4+i],label=str(v),color=colors[v],linewidth=1)
        ax.axhline(.1,color='#b91c1c',ls='--',label='Original contact threshold 0.1N');ax.set_title(('F_L','F_R','U_L','U_R')[i]);ax.set_ylabel('Native normal force (N)');ax.set_xlabel('Native time (s)')
    axes[0,0].legend();fig.tight_layout();figure('four_hand_contact',fig)
    fig,axes=plt.subplots(3,1,figsize=(12,9),sharex=True)
    for v in versions:
        axes[0].plot(curves[v][:,1],curves[v][:,3],label=str(v),color=colors[v],lw=.9)
        axes[1].plot(*[guard_curves[v][0],guard_curves[v][1]['F_L']],label=str(v),color=colors[v],lw=1)
        axes[2].plot(curves[v][:,1],curves[v][:,8],label=str(v),color=colors[v],lw=.9)
    axes[0].axhline(1e-4,color='#b91c1c',ls='--',label='Original qd relation threshold')
    axes[2].axhline(5.518125,color='#b91c1c',ls='--',label='Original 1.25mg capacity proxy')
    for ax,label in zip(axes,('Original qd residual (rad/s)','F_L submitted closing in HOLD (rad/s)','Friction capacity proxy (N)')):
        ax.set_ylabel(label);ax.axvline(3504/960,color='#777',ls=':',label='First guard intervention');ax.legend(fontsize=8)
    axes[-1].set_xlabel('Native time (s)');fig.tight_layout();figure('guard_and_model',fig)
    matrix=copy.deepcopy(read(H/'full_requirements_v1/EVIDENCE_MATRIX_V31.json'));matrix.update(revision=32,updated_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),latest_actual_guard_diagnostic_evidence=decisions[105],fullSystem0_accepted=False)
    assert matrix['rows']==read(H/'full_requirements_v1/EVIDENCE_MATRIX_V31.json')['rows']
    write(R/'EVIDENCE_MATRIX_V32.json',matrix);q=H/'full_requirements_v1/EVIDENCE_MATRIX_V32.json';assert not q.exists();write(q,matrix)
    sources=[Path(__file__),P/'report_archive_utils_v1.py',P/'data_body_v1.txt',P/'VERIFICATION_CONTRACT_V1.json',H/'loaded_duration_report_delivery_v1/native_video_pts_v1.py',H/'prepare_loaded_actual_guard105_v1.py',H/'prepare_actual_guard_oracles105_v1.py',H/'verify_actual_guard105_preflight_v1.py',H/'audit_loaded_actual_guard_targets105_v1.py',H/'audit_loaded_actual_guard_decisions105_v1.py',H/'audit_loaded_actual_guard_window105_v1.py',H/'loaded_duration_prefix_custody_v1.py',H/'audit_loaded_native_capture105_v1.py',H/'audit_native_mimic_window_v6.py',H/'audit_native_mimic_window_v5.py',H/'audit_full_motor_effort_native_v4.py',H/'audit_load_only_prelift_intent_v1.py',H/'audit_native_camera_framing_v2.py',H/'LOADED_ACTUAL_GUARD105_PROSPECTIVE_PLAN_V1.json',H/'analyze_upper_contact_phases104_v1.py',H/'spike/native_mimic_long_duration_v1/bridge.cpp',H/'spike/native_mimic_long_duration_v1/test_boundary.py',H/'spike/native_mimic_long_duration_v1/CPU_BOUNDARY_VERIFICATION_V1.json']
    sources+=list((H/'feedback_actual_target_spike_v1').glob('*.py'))+list((H/'feedback_actual_target_spike_v1').glob('*.json'))
    sources+=[f for f in (H/'fourhand_native_probe_v105').iterdir() if f.suffix in ('.py','.usda')]
    source_manifest=[]
    with zipfile.ZipFile(R/'evidence/owned_method_source.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for f in dict.fromkeys(sources):
            name=str(f.relative_to(H));z.write(f,name);source_manifest.append(dict(original_path=str(f),archive_path=name,sha256=sha(f)))
        for a,asset in assets.items():
            f=Path(asset['original_URDF']);name=f'original_urdf/{a}/{f.name}';z.write(f,name);source_manifest.append(dict(original_path=str(f),archive_path=name,sha256=sha(f)))
    write(R/'METHOD_SOURCE_MANIFEST_V1.json',dict(source_files=source_manifest,installed_native_kernel_source_unavailable=True,SDK_and_registered_robot_assets_required_for_native_execution=True))
    for f in (H/'LOADED_ACTUAL_GUARD105_PROSPECTIVE_PLAN_V1.json',H/'fourhand_native_probe_v105/CPU_PREFLIGHT_VERIFICATION_V1.json'):
        shutil.copyfile(f,R/'evidence'/f.name)
    style=re.search(r'<style>(.*?)</style>',(W/'docs/safety_sustained_fourhand_20261012/index.html').read_text(),re.S).group(1)
    table=''.join(f'<tr><td>{v}</td><td>{"名义进度守卫" if v==104 else "实际提交目标守卫"}</td><td>{decisions[v]["physics_events"]}/8192</td><td>{decisions[v]["original_qd_error_rad_s"]:.8g}</td><td>{"通过" if decisions[v]["loaded_feedback_model_diagnostic_pass"] else "原模型失败"}</td><td>{decisions[v]["four_hand_close_s"]:.5f}s</td><td>未通过</td></tr>' for v in versions)
    video_html=''.join(f'<article class="video-card"><h3>{m["version"]} · {esc(m["view"])}</h3><video controls playsinline preload="metadata" poster="{m["poster"]}"><source src="{m["video"]}" type="video/mp4"></video><p>原生时戳0–{m["native_last_state_time_s"]:.4f}s；全部原帧保留。</p></article>' for m in media)
    links=''.join(f'<li><a href="{e["path"]}">105 全部原始分包 {e["part"]:02d} · {e["bytes"]/1024**2:.1f}MiB</a></li>' for e in archives)
    reqs=''.join(f'<tr><td>{esc(x.get("id",x.get("requirement_id","")))}</td><td>{esc(x.get("requirement",x.get("name",x.get("title",""))))}</td><td>{esc(x.get("status",""))}</td></tr>' for x in matrix['rows'])
    sections=[('summary','摘要与判定'),('questions','研究问题'),('method','系统与单变量协议'),('coverage','随机范围与统计分母'),('results','原生配对结果'),('guards','实际命令与力观测'),('qualitative','四视角原生视频'),('failures','保留失败与未覆盖分支'),('limits','九项验收与限制'),('data','复核数据与复现路径')]
    body=f'''<section id="summary"><h2>01 摘要与判定</h2><p>105完成8192个原生物理步（8.5333s），原URDF位置与速度关系、原物理门槛、全部50个独立电机努力和反馈目标审计通过。改变策略前的3488步、全部164字段逐字节与104一致；77个物理参数和13个初态字段与98一致。完整四手任务仍未通过。</p></section>
<section id="questions"><h2>02 研究问题</h2><p>104在HOLD标签下仍继续提交闭合目标，并在7.7s结束的窗口触发原速度关系失败。只让守卫目标以实际提交命令为起点，是否消除这条命令缺陷，并保持原模型约束？本研究仅检验这一已知初态，不能给出泛化安全结论。</p></section>
<section id="method"><h2>03 系统与单变量协议</h2><p>保持960Hz物理、60Hz控制、FIFO6、16次原生追加求解、8192事件容量和观察上限、0.10rad/s目标滤波速率，以及原质量、惯性、关节与接触门槛。HOLD保持上一实际提交目标；RELAX从该目标退回；JOINT_GUARD退回受保护组并保持另一组；SEEK保持原流程。不修改q/qd，不放宽1e−4原位置/速度关系门槛。</p><p>1次原生执行，运行完成后审计；原失败判据与全16步控制周期的保留规则不变。<a href="evidence/LOADED_ACTUAL_GUARD105_PROSPECTIVE_PLAN_V1.json">前瞻冻结协议</a> · <a href="evidence/105_PREFIX_PHYSICAL_CUSTODY_V1.json">全部前缀字段证据</a> · <a href="evidence/105_REGISTRATION_V1.json">完整登记与源SHA</a>。</p></section>
<section id="coverage"><h2>04 随机范围与统计分母</h2><p>1个已选择的开发初态、2种命令策略；新增随机物理任务0、正式独立留出0。15584个相关时间步不是15584个独立试验。手部单一夹持轨迹没有覆盖四臂的完整50维操作空间；不报告成功率置信区间。500个软件进度抽样与29312个配对命令回放用于命令不变量，不计入物理安全样本。学习System 0关闭。</p></section>
<section id="results"><h2>05 原生配对结果</h2><div class="table-wrap"><table><thead><tr><th>版本</th><th>策略</th><th>实际/计划步</th><th>最大qd残差 rad/s</th><th>模型诊断</th><th>四手连续接触</th><th>完整任务</th></tr></thead><tbody>{table}</tbody></table></div><figure><img src="figures/guard_and_model.png" alt="原URDF速度残差、实际HOLD提交闭合和承载代理曲线"><figcaption>同一初态的真实时轴；104完整失败尾段保留。命令停止不能证明实际关节立刻停止，承载代理不能替代抓握或力矩证书。</figcaption></figure><figure><img src="figures/four_hand_contact.png" alt="四手独立原生法向力"><figcaption>四条曲线分开列出；四个独立峰值不能证明四手同时稳定夹持。</figcaption></figure></section>
<section id="guards"><h2>06 实际命令与力观测</h2><p>104左前手3872个HOLD物理步中3211步继续提交闭合；105左前手4688个HOLD物理步中继续闭合0次。原生105未触发RELAX或JOINT_GUARD；其回退行为只通过软件回归与记录输入回放，不宣称物理分支验证完成。</p><p>守卫的6/8N阈值是60Hz反馈策略设置，不是物理力上限。全部960Hz物理步的峰值与控制采样力分别记录；原物理接触上限30N另行审计。<a href="ACTUAL_GUARD_SUMMARY_V1.json">命令与观测分母</a> · <a href="CONTACT_AND_PRELIFT_SUMMARY_V1.json">所有手部、预抬起和最终状态</a>。</p></section>
<section id="qualitative"><h2>07 四视角原生视频</h2><p>104与105各有俯视、正视、侧视、全景。104原有视频和失败帧保持不变；105为新原生相机帧。末帧仅显示约0.067s，不增加物理事件。</p><div class="video-grid">{video_html}</div><p><a href="MEDIA_TIMESTAMPS_AND_CUSTODY_V1.json">全部原帧SHA、实际时戳及视频PTS</a>。相机源点投影审核通过，不代表所有接触点无遮挡。</p></section>
<section id="failures"><h2>08 保留失败与未覆盖分支</h2><p>104的第7388步原速度关系违例和其后完整控制周期均保留。105消除了已观察到的HOLD提交滞后，但四手连续接触仍只有0.09375s，低于原0.25s；预抬起、实际抬升、搬运、放置、释放和退出未通过。上方两手在104仅拇指末节产生接触，末态均无有效载荷接触；几何原因尚未证实。</p><p>原生RELAX与JOINT_GUARD分支、完整四臂空间、新随机任务、感知不确定性故障及真实学习System 0的对照验收均未完成。<a href="evidence/104_UPPER_CONTACT_PHASE_DIAGNOSIS_V1.json">上方接触定位</a> · <a href="../safety_sustained_fourhand_20261012/">全部时长对照与失败报告</a>。</p></section>
<section id="limits"><h2>09 九项验收与限制</h2><p>原九项要求逐项状态保持不变。本次“原模型与物理诊断通过”不升级为完整安全验收。当前机器人配置仍是开发诊断配置，规范目标配置尚未联合通过；被动碰撞烹饪查询没有得到有效形状证书，代理间隙与已观测接触不能替代完整碰撞形状证明。</p><div class="table-wrap"><table><thead><tr><th>项</th><th>要求</th><th>原状态</th></tr></thead><tbody>{reqs}</tbody></table></div><p><a href="EVIDENCE_MATRIX_V32.json">原九项原文、状态与全部门槛</a>。后续先处理上方夹持位置与真实持续接触，再执行完整任务；固定合格模型和策略后才能进入全空间随机银行与学习System 0正式留出。</p></section>
<section id="data"><h2>10 复核数据与复现路径</h2><p><a href="PER_STEP_METRICS_V1.csv">15584步逐步指标CSV</a> · <a href="evidence/105_DECISION_V1.json">105独立终局判定</a> · <a href="evidence/105_CORE_ACTUAL_EXIT_RECEIPTS_V105.json">实际审计退出记录</a> · <a href="evidence/owned_method_source.zip">自有方法、独立审计、软件测试与原URDF代码包</a> · <a href="METHOD_SOURCE_MANIFEST_V1.json">方法源SHA映射</a>。</p><p>105完整原始输出分包下载，全部分包共同构成完整数据；<a href="RAW_ARCHIVE_MANIFEST_V1.json">每个原文件的SHA与大小</a>。104完整原始包沿用<a href="../safety_sustained_fourhand_20261012/RAW_ARCHIVE_MANIFEST_V1.json">已发布清单</a>，不重复复制。</p><ul>{links}</ul><p>方法包包含可读自有实现与原始数据核验入口。重跑原生实验仍需登记SDK及机器人资产；已安装原生求解内核源码未知，不保证不同SDK/设备逐字节复现。</p><p>报告组织参考<a href="https://anonymous-report-421.github.io/public-website/?lang=en&amp;view=">Anonymous embodied report</a>、<a href="https://robodojo-benchmark.com/report/gpt-6-astra-eval">RoboDojo report</a>、<a href="https://github.com/zjwzcx/Awesome-Astra-Embodied-AI">Awesome Astra Embodied AI</a>；未移用其结果或成功率。</p></section>'''
    nav=''.join(f'<a href="#{i}">{n:02d} {esc(t)}</a>' for n,(i,t) in enumerate(sections,1))
    page=f'''<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>SafeDuo · 实际夹持目标与原生对照</title><style>{style}</style></head><body><header class="masthead"><span class="brand">SAFEDUO / RESEARCH REPORT</span><a href="../../#scientific">返回实验主面板 ↗</a></header><div class="hero"><p class="eyebrow">SIMULATION · PAIRED CONTROLLER DIAGNOSTIC · 12 OCTOBER 2026</p><h1>实际夹持目标<br>与原生安全诊断</h1><p class="lead">修复HOLD提交滞后，在同一初态和原安全门槛下保留完整失败并进行配对验证。</p><div class="callout"><b>九项要求尚未全部达标。</b><p>原URDF位置/速度关系与原物理诊断通过8192步；四手稳定夹持和完整任务仍未通过。学习System 0关闭，正式留出0。</p></div><div class="actions"><a class="button primary" href="#results">原生配对结果</a><a class="button" href="#qualitative">八路原生视频</a><a class="button" href="#failures">失败与未覆盖分支</a><a class="button" href="#data">全部数据</a></div><div class="stats"><div><strong>8192步</strong><span>105实际完成 · 8.5333s</span></div><div><strong>0次</strong><span>4688个HOLD步继续提交闭合</span></div><div><strong>0.094s</strong><span>四手持续接触 · 原门槛0.25s</span></div><div><strong>0</strong><span>正式独立留出样本</span></div></div></div><main class="report"><aside class="toc"><b>ON THIS PAGE / 目录</b>{nav}</aside><article class="content">{body}</article></main><footer>SafeDuo · diagnostic evidence only · fullSystem0_accepted=false</footer></body></html>'''
    (R/'index.html').write_text(page)
    root=W/'index.html';old=root.read_text();needle='<div class="sci-note" id="sustainedFourhandEvidence">';assert old.count(needle)==1
    addition='<div class="sci-note" id="actualGuardEvidence"><b>最新科研报告：实际夹持目标与原生配对对照</b><p>修复HOLD实际提交滞后后，8192步原URDF位置/速度关系与物理诊断通过；配对失败、八路原生视频、全部原始分包可复核。四手持续接触仍仅0.094秒，完整任务未通过，System 0关闭，正式留出0。</p><a href="docs/safety_actual_guard_20261012/">查看配对结果、原始曲线与视频 →</a></div>\n'
    root.write_text(old.replace(needle,addition+needle));assert root.read_text().replace(addition,'',1)==old
    files=[dict(path=str(f.relative_to(W)),sha256=sha(f),bytes=f.stat().st_size) for f in sorted(R.rglob('*')) if f.is_file()];files.append(dict(path='index.html',sha256=sha(root),bytes=root.stat().st_size));assert all(f['bytes']<95*1024**2 for f in files)
    manifest=dict(files=files,base_commit=base,prior_root_sha256=hashlib.sha256(old.encode()).hexdigest(),root_addition_only=True,versions=versions,scientific_all9_pass=False,formal_holdout_count=0)
    write(P/'BUILD_MANIFEST_V1.json',manifest);write(R/'PUBLIC_MANIFEST_V1.json',dict(files=files,manifest_self_excluded=True,all9_pass=False))
    # Include the manifest in the outer byte gate, without a self-referential hash.
    manifest['files'].append(dict(path=str((R/'PUBLIC_MANIFEST_V1.json').relative_to(W)),sha256=sha(R/'PUBLIC_MANIFEST_V1.json'),bytes=(R/'PUBLIC_MANIFEST_V1.json').stat().st_size));write(P/'BUILD_MANIFEST_V1.json',manifest)
    print('P21_REPORT_BUILT',len(manifest['files']),'FILES',sum(x['bytes'] for x in manifest['files']),'BYTES;8_VIDEOS;ALL9_FALSE',flush=True)

if __name__=='__main__':main()
