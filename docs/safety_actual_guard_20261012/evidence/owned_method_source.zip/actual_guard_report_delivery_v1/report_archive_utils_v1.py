from pathlib import Path
import hashlib,json,zipfile,xml.etree.ElementTree as ET
import matplotlib.pyplot as plt
R=Path('/mnt/nas/data/lyf/double_hand/safeduo_dashboard_loaded_duration_20261012/docs/safety_actual_guard_20261012')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def archive_parts(raw, version):
    files = sorted(f for f in raw.rglob('*') if f.is_file())
    groups = []
    current = []
    size = 0
    for f in files:
        n = f.stat().st_size
        if n > 70 * 1024 ** 2:
            if current:
                groups.append(current)
                current, size = [], 0
            groups.append([f])
        else:
            if size + n > 70 * 1024 ** 2 and current:
                groups.append(current)
                current, size = [], 0
            current.append(f)
            size += n
    if current:
        groups.append(current)
    entries = []
    for i, group in enumerate(groups, 1):
        out = R / f'evidence/native_{version}_complete_raw_part{i:02d}.zip'
        with zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as z:
            for f in group:
                z.write(f, str(f.relative_to(raw)))
        assert out.stat().st_size < 95 * 1024 ** 2
        entries.append(dict(version=version, part=i, path=str(out.relative_to(R)), sha256=sha(out), bytes=out.stat().st_size,
                            original_files=[dict(path=str(f.relative_to(raw)), sha256=sha(f), bytes=f.stat().st_size) for f in group]))
    assert {f['path'] for e in entries for f in e['original_files']} == {str(f.relative_to(raw)) for f in files}
    return entries


def longest(time, mask):
    start = None
    maximum = 0.
    for t, flag in zip(time, mask):
        if flag:
            if start is None:
                start = float(t)
            maximum = max(maximum, float(t) - start)
        else:
            start = None
    return maximum


def figure(name, fig):
    fig.savefig(R / f'figures/{name}.png', dpi=170, bbox_inches='tight')
    svg = R / f'figures/{name}.svg'
    fig.savefig(svg, bbox_inches='tight')
    svg.write_text('\n'.join(line.rstrip() for line in svg.read_text().splitlines()) + '\n')
    ET.parse(svg)
    plt.close(fig)


