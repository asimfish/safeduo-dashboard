"""Compare complete prefix chunks, preserving scalar and ragged contact fields."""
from pathlib import Path
import hashlib
import json

import numpy as np


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def prefix_chunks(folder, physics_events):
    if not isinstance(physics_events, int) or isinstance(physics_events, bool) or physics_events <= 0 or physics_events % 32:
        raise ValueError('Prefix must contain a positive multiple of 32 physical events')
    folder = Path(folder)
    ledger = json.loads((folder / 'physics_chunks.json').read_text())
    expected_start = 0
    for row in ledger:
        if expected_start == physics_events:
            break
        if row['start'] != expected_start or row['stop'] != expected_start + 32:
            raise ValueError('Complete contiguous32-step prefix chunks are required; do not slice ragged packets')
        f = folder / row['path']
        if sha(f) != row['sha256']:
            raise ValueError('Physics chunk source hash mismatch')
        with np.load(f, allow_pickle=False) as z:
            if len(z.files) != 164 or len(set(z.files)) != 164:
                raise ValueError('Exactly164 original physical fields required')
            arrays = {k: z[k].copy() for k in z.files}
        if arrays['state_time_s'].shape != (32,):
            raise ValueError('Time-row count mismatch')
        if not np.array_equal(arrays['physics_event'], np.arange(expected_start, expected_start + 32)):
            raise ValueError('Physical event identities do not match the ledger')
        yield dict(start=row['start'], stop=row['stop'], source=str(f), sha256=row['sha256'], arrays=arrays)
        expected_start = row['stop']
    if expected_start != physics_events:
        raise ValueError('Requested prefix not fully captured')


def compare_prefix(candidate, baseline, physics_events):
    if not isinstance(physics_events, int) or isinstance(physics_events, bool) or physics_events <= 0 or physics_events % 32:
        raise ValueError('Prefix must contain a positive multiple of 32 physical events')
    a = prefix_chunks(candidate, physics_events)
    b = prefix_chunks(baseline, physics_events)
    rows = []
    sources = {}
    chunks = 0
    # Exhaust both iterators, so a missing final chunk cannot silently truncate zip.
    for _ in range(physics_events // 32):
        try:
            ca, cb = next(a), next(b)
        except StopIteration as e:
            raise ValueError('Requested prefix not fully captured') from e
        aa, bb = ca['arrays'], cb['arrays']
        if set(aa) != set(bb):
            raise ValueError('Physical field identities differ')
        for k in sorted(aa):
            equal = aa[k].shape == bb[k].shape and aa[k].dtype == bb[k].dtype and aa[k].tobytes() == bb[k].tobytes()
            rows.append(dict(start=ca['start'], stop=ca['stop'], field=k, byte_identical=equal,
                             candidate_shape=list(aa[k].shape), baseline_shape=list(bb[k].shape)))
        sources.update({c['source']: c['sha256'] for c in (ca, cb)})
        chunks += 1
    for iterator in (a, b):
        try:
            next(iterator)
        except StopIteration:
            pass
        else:
            raise ValueError('Unexpected prefix chunk')
    return dict(all_fields_byte_identical=all(r['byte_identical'] for r in rows), physics_events=physics_events,
                chunks=chunks, fields_per_chunk=164, field_comparisons=len(rows), rows=rows, source_sha256=sources)
