"""Independent original-XML command oracle, without importing candidate code."""
from pathlib import Path
import ast

H = Path(__file__).resolve().parent


def once(text, before, after):
    assert text.count(before) == 1, before
    return text.replace(before, after)


def main():
    target = H / 'audit_loaded_actual_guard_targets105_v1.py'
    feedback = H / 'audit_loaded_actual_guard_decisions105_v1.py'
    closure = H / 'audit_loaded_actual_guard_window105_v1.py'
    assert not any(f.exists() for f in (target, feedback, closure))
    oracle = '''def expected_guard_nominal(names,A,b,rootids,opened,far,progress_nominal,previous,mode,tg,fg,dt,relax):
    if mode == 'SEEK':return np.asarray(progress_nominal,dtype=np.float32)
    if mode == 'HOLD':return np.asarray(previous,dtype=np.float32)
    assert mode in ('RELAX','JOINT_GUARD')
    assert mode=='RELAX' or tg or fg
    thumb=np.array(['thumb' in names[i] for i in rootids])
    active=np.ones(len(rootids),dtype=bool) if mode=='RELAX' else np.where(thumb,tg,fg)
    old=np.asarray(previous,dtype=float)[rootids]
    op=np.asarray(opened,dtype=float)[rootids];close=np.asarray(far,dtype=float)[rootids]
    desired=old-np.where(active,relax*dt*(close-op),0.)
    bounded=np.minimum(np.maximum(desired,np.minimum(old,op)),np.maximum(old,op))
    return np.asarray(A@np.where(active,bounded,old)+b,dtype=np.float32)

'''
    text = (H / 'audit_loaded_feedback_targets100_v1.py').read_text()
    text = once(text, 'def main(version):', oracle + 'def main(version):')
    text = once(text, "['physics_event','phase','feedback_grip_finger_fraction','feedback_grip_thumb_fraction']",
                "['physics_event','phase','feedback_grip_finger_fraction','feedback_grip_thumb_fraction','feedback_grip_mode','feedback_grip_thumb_guard','feedback_grip_finger_guard']")
    text = once(text, 'thumb=np.array([\'thumb\' in n for n in hn]);max_rate=0.;max_binding=0.;max_relation=0.',
                "thumb=np.array(['thumb' in n for n in hn]);max_rate=0.;max_binding=0.;max_relation=0.;guard_stats={}")
    text = once(text, '            elif filtered:\n                expected=expected_target',
                """            elif filtered:
                mode=str(d['feedback_grip_mode'][e,ai])
                nominal=expected_guard_nominal(hn,A,b,rootids,opened,far,nominal,previous,mode,
                    bool(d['feedback_grip_thumb_guard'][e,ai]),bool(d['feedback_grip_finger_guard'][e,ai]),
                    reg['control_dt_s'],reg['feedback_grip_settings']['relax_rate'])
                expected=expected_target""")
    text = once(text, '            if filtered and e>=activation:\n                rate=',
                """            if filtered and e>=activation:
                mode=str(d['feedback_grip_mode'][e,ai])
                if mode!='SEEK':
                    delta=measured-previous;closing=float(np.maximum(delta*np.sign(far-opened),0).max())
                    assert closing<=1e-7,(a,e,mode,'guard submitted closing',closing)
                    if mode=='HOLD':assert abs(delta).max()<=1e-7,(a,e,'HOLD submitted movement')
                    st=guard_stats.setdefault(mode,dict(samples=0,actual_submitted_closing_samples=0,maximum_actual_closing_rad=0.))
                    st['samples']+=1;st['actual_submitted_closing_samples']+=int(closing>1e-7)
                    st['maximum_actual_closing_rad']=max(st['maximum_actual_closing_rad'],closing)
                rate=""")
    text = once(text, 'max_native_target_relation_error_rad=max_relation))',
                'max_native_target_relation_error_rad=max_relation,actual_guard_submitted_target_stats=guard_stats))')
    text = once(text, "report=dict(status='PASS_INDEPENDENT_ALL_MICROSTEP_COUPLED_NATIVE_TARGET_BINDING',",
                "report=dict(actual_guard_submitted_target_invariants=True,guard_output_does_not_prove_safe_stop=True,status='PASS_INDEPENDENT_ALL_MICROSTEP_COUPLED_NATIVE_TARGET_BINDING',")
    target.write_text(text)
    text = (H / 'audit_loaded_feedback_decisions100_v1.py').read_text()
    text = once(text, 'H=Path(__file__).resolve().parent',
                'from audit_loaded_actual_guard_targets105_v1 import matrix,expected_guard_nominal\nH=Path(__file__).resolve().parent')
    text = once(text, "refs=np.load(reg['coupled_reference_endpoints']);activation=", "assets=json.loads(Path(reg['coupled_assets']).read_text())['assets']\n    refs=np.load(reg['coupled_reference_endpoints']);activation=")
    text = once(text, "                nominal=data[arm+'_hand_nominal_position_target'][e]",
                """                hn=[str(names[i]) for i in hand]
                roots,A,b=matrix(hn,assets[arm]['original_URDF']);rootids=[hn.index(n) for n in roots]
                previous=data[arm+'_actual_full_position_target'][e-1,0,hand]
                targets=expected_guard_nominal(hn,A,b,rootids,openq,far,targets,previous,mode,tg,fg,dt,settings['relax_rate'])
                nominal=data[arm+'_hand_nominal_position_target'][e]""")
    text = once(text, "'nominal hand target not bound to progress'", "'guarded nominal target not bound to actual command and progress'")
    feedback.write_text(text)
    text = (H / 'audit_loaded_feedback_duration_v1.py').read_text()
    text = once(text, "out = p / 'LOADED_FEEDBACK_DURATION_DECISION_V1.json'", "out = p / 'LOADED_ACTUAL_GUARD_DECISION_V1.json'")
    text = once(text, "'CLOSED_ORIGINAL_FEEDBACK_DURATION_DIAGNOSTIC'", "'CLOSED_SINGLE_ACTUAL_TARGET_GUARD_COUNTERFACTUAL'")
    text = once(text, 'all_original_feedback_and_filtered_targets_audited=True,',
                "all_original_feedback_and_filtered_targets_audited=True, actual_guard_submitted_target_invariants=targets['actual_guard_submitted_target_invariants'],")
    text = once(text, "print('DURATION_CLOSED'", "print('ACTUAL_GUARD_CLOSED'")
    closure.write_text(text)
    for f in (target, feedback, closure):
        ast.parse(f.read_text())
        assert 'from actual_guard_nominal_v1' not in f.read_text()
    print('INDEPENDENT105_ORIGINAL_XML_GUARD_TARGETS_DECISIONS_CLOSURE_PREPARED', flush=True)


if __name__ == '__main__':
    main()
