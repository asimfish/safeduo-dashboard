"""Expected failing reproduction from immutable native104 submitted targets."""
from pathlib import Path
import json
import numpy as np

H = Path(__file__).resolve().parent.parent
P = H / 'fourhand_native_probe_v104'
reg = json.loads((P / 'REGISTRATION_V1.json').read_text())
raw = Path(json.loads((P / 'RESOURCE_EXECUTION_V1.json').read_text())['out'])
refs = np.load(reg['coupled_reference_endpoints'], allow_pickle=False)
entry = next(c for c in json.loads((raw / 'physics_chunks.json').read_text()) if c['start'] <= 3504 < c['stop'])
with np.load(raw / entry['path'], allow_pickle=False) as z:
    i = int(np.flatnonzero(z['physics_event'] == 3504)[0])
    assert i > 0 and str(z['feedback_grip_mode'][i, 0]) == 'HOLD'
    ids = refs['F_L_hand_indices']
    previous = z['F_L_actual_full_position_target'][i - 1, 0, ids]
    actual = z['F_L_actual_full_position_target'][i, 0, ids]
    direction = np.sign(refs['F_L_hand_far_q'] - refs['F_L_hand_open_q'])
    closing = float(np.maximum((actual - previous) * direction, 0).max())
    print('RED_NATIVE104_HOLD_ACTUAL_CLOSING_RAD', closing, flush=True)
    assert closing <= 1e-7, 'HOLD leaves an existing nominal-to-submitted backlog closing'
