"""Paired one-step command counterfactuals, with native104 inputs held fixed.

Recorded force/state/mode inputs do not become the physical state of the new
controller. This replay establishes a command invariant, not native safety.
"""
from pathlib import Path
import hashlib
import json
import sys
import numpy as np

P = Path(__file__).resolve().parent
H = P.parent
BASE = H / 'fourhand_native_probe_v104'
sys.path.insert(0, str(BASE))
sys.path.insert(0, str(H))
from actual_guard_nominal_v1 import actual_guard_nominal
from coupled_hand_filter_v1 import coupled_filtered_hand_targets
from audit_loaded_feedback_targets100_v1 import matrix

sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
read = lambda p: json.loads(Path(p).read_text())


def main():
    out = P / 'RECORDED_INPUT_COMMAND_REPLAY_V1.json'
    assert not out.exists()
    reg = read(BASE / 'REGISTRATION_V1.json')
    raw = Path(read(BASE / 'RESOURCE_EXECUTION_V1.json')['out'])
    params = np.load(raw / 'native_parameters.npz', allow_pickle=False)
    refs = np.load(reg['coupled_reference_endpoints'], allow_pickle=False)
    assets = read(reg['coupled_assets'])['assets']
    arms = ('F_L', 'F_R', 'U_L', 'U_R')
    keys = ['physics_event', 'feedback_grip_mode', 'feedback_grip_thumb_guard', 'feedback_grip_finger_guard']
    keys += [a + s for a in arms for s in ('_actual_full_position_target', '_hand_nominal_position_target')]
    chunks = read(raw / 'physics_chunks.json')
    parts = {k: [] for k in keys}
    sources = {}
    for c in chunks:
        f = raw / c['path']
        assert sha(f) == c['sha256']
        sources[str(f)] = c['sha256']
        with np.load(f, allow_pickle=False) as z:
            for k in keys:
                parts[k].append(z[k].copy())
    data = {k: np.concatenate(v) for k, v in parts.items()}
    assert np.array_equal(data['physics_event'], np.arange(7392))
    stats = {}
    for ai, a in enumerate(arms):
        allnames = params[a + '_joint_names'].tolist()
        names = assets[a]['hand_joint_names']
        ids = np.array([allnames.index(n) for n in names])
        hard = params[a + '_hard_limits'][0, ids]
        opened, far = refs[a + '_hand_open_q'], refs[a + '_hand_far_q']
        roots, A, b = matrix(names, assets[a]['original_URDF'])
        rootids = [names.index(n) for n in roots]
        direction = np.sign(far - opened)
        previous = data[a + '_actual_full_position_target'][:-1, 0, ids]
        modes = {}
        max_relation = max_rate = 0.
        paired_seek_equal = 0
        for e in range(64, 7392):
            old = previous[e - 1]
            nominal = data[a + '_hand_nominal_position_target'][e]
            mode = str(data['feedback_grip_mode'][e, ai])
            desired = actual_guard_nominal(names, nominal, old, opened, far, hard, assets[a]['relations'], mode,
                                          bool(data['feedback_grip_thumb_guard'][e, ai]),
                                          bool(data['feedback_grip_finger_guard'][e, ai]),
                                          reg['control_dt_s'], reg['feedback_grip_settings']['relax_rate'])
            kwargs = dict(max_target_rate_rad_s=reg['interior_hand_target_settings']['max_target_rate_rad_s'],
                          distal_lower_reserve_rad=reg['interior_hand_target_settings']['distal_lower_reserve_rad'])
            candidate = coupled_filtered_hand_targets(names, desired, old, hard, reg['physics_dt_s'], True,
                                                       assets[a]['relations'], **kwargs).astype(np.float32)
            delta = candidate - old
            closing = float(np.maximum(delta * direction, 0).max())
            relation = float(abs(A @ candidate[rootids] + b - candidate).max())
            rate = float(abs(delta).max() / reg['physics_dt_s'])
            assert relation < 1e-6 and abs(delta).max() <= kwargs['max_target_rate_rad_s'] * reg['physics_dt_s'] + 1e-6
            assert (candidate >= hard[:, 0] - 1e-6).all() and (candidate <= hard[:, 1] + 1e-6).all()
            max_relation, max_rate = max(max_relation, relation), max(max_rate, rate)
            if mode == 'SEEK':
                unchanged = coupled_filtered_hand_targets(names, nominal, old, hard, reg['physics_dt_s'], True,
                                                           assets[a]['relations'], **kwargs).astype(np.float32)
                np.testing.assert_array_equal(candidate, unchanged)
                paired_seek_equal += 1
            else:
                assert closing <= 1e-7, (a, e, mode, closing)
                if mode == 'HOLD':
                    assert abs(delta).max() <= 1e-7, (a, e, mode, delta)
                st = modes.setdefault(mode, dict(samples=0, original_closing_samples=0, new_closing_samples=0,
                                                new_opening_samples=0, max_candidate_closing_rad=0.))
                original = data[a + '_actual_full_position_target'][e, 0, ids] - old
                st['samples'] += 1
                st['original_closing_samples'] += int(np.maximum(original * direction, 0).max() > 1e-7)
                st['new_closing_samples'] += int(closing > 1e-7)
                st['new_opening_samples'] += int(np.maximum(-delta * direction, 0).max() > 1e-7)
                st['max_candidate_closing_rad'] = max(st['max_candidate_closing_rad'], closing)
        stats[a] = dict(paired_byte_equal_SEEK_microsteps=paired_seek_equal, guards=modes,
                        maximum_original_XML_target_relation_error_rad=max_relation,
                        maximum_actual_float32_target_rate_rad_s=max_rate)
    for f in [Path(__file__), P / 'actual_guard_nominal_v1.py', P / 'test_actual_guard_nominal_v1.py',
              P / 'PROSPECTIVE_PLAN_V1.json', BASE / 'REGISTRATION_V1.json', BASE / 'coupled_hand_filter_v1.py',
              BASE / 'coupled_hand_targets_v1.py', H / 'audit_loaded_feedback_targets100_v1.py',
              raw / 'native_parameters.npz', Path(reg['coupled_reference_endpoints']), Path(reg['coupled_assets'])]:
        sources[str(f)] = sha(f)
    result = dict(status='PASS_RECORDED_INPUT_COMMAND_INVARIANT_ONLY',recorded_native_events=7392,
                  paired_after_activation_commands=4 * (7392 - 64), hands=stats, physical_counterfactual_executions=0,
                  interpretation='Each candidate command uses its paired original submitted previous target and recorded original mode. No synthetic q/qd or force trajectory is treated as native evidence.',
                  new_random_cases=0, formal_holdout_count=0, fulltask_pass=False, fullSystem0_accepted=False,
                  source_sha256=sources)
    out.write_text(json.dumps(result, indent=2) + '\n')
    print(result['status'], result['paired_after_activation_commands'], json.dumps(stats), flush=True)


if __name__ == '__main__':
    main()
