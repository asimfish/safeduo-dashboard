"""Command regression tests; neither replay nor properties certify physics."""
import unittest
import numpy as np
from actual_guard_nominal_v1 import actual_guard_nominal
from coupled_hand_filter_v1 import coupled_filtered_hand_targets


class GuardTargetTests(unittest.TestCase):
    def setUp(self):
        self.names = ('index_joint', 'index_tip_joint', 'thumb_joint', 'thumb_tip_joint')
        self.relations = [dict(slave=self.names[1], master=self.names[0], urdf_multiplier=-.7, urdf_offset_rad=.6),
                          dict(slave=self.names[3], master=self.names[2], urdf_multiplier=.5, urdf_offset_rad=.1)]
        self.hard = np.array([[0., 1.], [-.1, .6], [0., 1.], [.1, .6]])
        self.opened = np.array([.1, .53, .9, .55])
        self.far = np.array([.9, -.03, .1, .15])
        self.previous = self.opened + .4 * (self.far - self.opened)
        self.nominal = self.opened + .8 * (self.far - self.opened)

    def target(self, mode, tg=False, fg=False, previous=None):
        old = self.previous if previous is None else previous
        desired = actual_guard_nominal(self.names, self.nominal, old, self.opened, self.far, self.hard,
                                       self.relations, mode, tg, fg, 1 / 60, .75)
        result = coupled_filtered_hand_targets(self.names, desired, old, self.hard, 1 / 960, True,
                                              self.relations, max_target_rate_rad_s=.1)
        return desired, result

    def test_seek_is_byte_identical_to_existing_filter(self):
        expected = coupled_filtered_hand_targets(self.names, self.nominal, self.previous, self.hard, 1 / 960,
                                                True, self.relations, max_target_rate_rad_s=.1)
        np.testing.assert_array_equal(self.target('SEEK')[1], expected)

    def test_hold_cancels_backlog_for_both_stroke_directions(self):
        _, result = self.target('HOLD')
        np.testing.assert_array_equal(result, self.previous)

    def test_relax_opens_immediately_despite_nominal_backlog(self):
        _, result = self.target('RELAX')
        self.assertTrue(((result - self.previous) * np.sign(self.far - self.opened) < 0).all())
        self.assertLessEqual(abs(result - self.previous).max(), .1 / 960 + 1e-12)
        self.assertAlmostEqual(result[1], -.7 * result[0] + .6)
        self.assertAlmostEqual(result[3], .5 * result[2] + .1)

    def test_thumb_guard_freezes_finger_target(self):
        _, result = self.target('JOINT_GUARD', tg=True)
        np.testing.assert_array_equal(result[:2], self.previous[:2])
        self.assertTrue(((result[2:] - self.previous[2:]) * np.sign(self.far[2:] - self.opened[2:]) < 0).all())

    def test_open_endpoint_cannot_be_crossed(self):
        _, result = self.target('RELAX', previous=self.opened)
        np.testing.assert_array_equal(result, self.opened)

    def test_invalid_guard_and_unknown_modes_fail(self):
        for mode in ('JOINT_GUARD', 'UNBOUND'):
            with self.assertRaises(ValueError):
                self.target(mode)

    def test_mixed_direction_properties_across_broad_command_fraction(self):
        rng = np.random.default_rng(20261012)
        for fraction in rng.uniform(0, 1, 500):
            old = self.opened + fraction * (self.far - self.opened)
            for mode in ('HOLD', 'RELAX', 'JOINT_GUARD'):
                _, result = self.target(mode, tg=True, fg=True, previous=old)
                self.assertLessEqual(np.maximum((result - old) * np.sign(self.far - self.opened), 0).max(), 1e-12)
                self.assertLessEqual(abs(result - old).max(), .1 / 960 + 1e-12)


if __name__ == '__main__':
    unittest.main()
