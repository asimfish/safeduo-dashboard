"""Encode every original RGB frame at its exact 960Hz native time coordinate."""
from pathlib import Path
import hashlib
import json
import subprocess


def encode(raw, selected, video, work):
    raw, video, work = Path(raw), Path(video), Path(work)
    work.mkdir(exist_ok=False)
    ticks = []
    for i, frame in enumerate(selected):
        f = raw / frame['path']
        assert hashlib.sha256(f.read_bytes()).hexdigest() == frame['sha256']
        tick = frame['control'] * 16
        assert abs(tick / 960 - frame['state_time_s']) <= 1e-12
        ticks.append(tick)
        (work / f'frame_{i:05d}.png').symlink_to(f)
    assert ticks[0] == 0 and all(b > a for a, b in zip(ticks, ticks[1:]))
    regular = len(ticks) if ticks[-1] % 64 == 0 else len(ticks) - 1
    assert ticks[:regular] == [64 * i for i in range(regular)]
    if regular < len(ticks):
        assert 0 < ticks[-1] - ticks[-2] < 64
    expression = f'setpts=if(lt(N\\,{regular})\\,64*N\\,{ticks[-1]})'
    argv = ['ffmpeg', '-hide_banner', '-loglevel', 'error', '-framerate', '960', '-i', str(work / 'frame_%05d.png'),
            '-vf', expression, '-vsync', 'vfr', '-r', '15', '-enc_time_base', '1:960', '-c:v', 'libx264',
            '-preset', 'fast', '-crf', '23', '-pix_fmt', 'yuv420p', '-video_track_timescale', '960', '-movflags', '+faststart', str(video)]
    subprocess.run(argv, check=True)
    frames = json.loads(subprocess.check_output(['ffprobe', '-v', 'error', '-select_streams', 'v:0',
        '-show_entries', 'frame=best_effort_timestamp_time', '-of', 'json', str(video)], text=True))
    measured = json.loads(subprocess.check_output(['ffprobe', '-v', 'error', '-select_streams', 'v:0',
        '-show_entries', 'packet=pts_time,duration_time:stream=time_base,duration,duration_ts:format=duration', '-of', 'json', str(video)], text=True))
    pts = [float(x['best_effort_timestamp_time']) for x in frames['frames']]
    expected = [tick / 960 for tick in ticks]
    assert len(pts) == len(expected) and max(abs(a - b) for a, b in zip(pts, expected)) <= 1e-6, (pts, expected)
    last = max(measured['packets'], key=lambda x: float(x['pts_time']))
    assert abs(float(last['duration_time']) - 1 / 15) <= 1e-6, last
    assert measured['streams'][0]['time_base'] == '1/960'
    assert abs(float(measured['streams'][0]['duration']) - expected[-1] - 1 / 15) <= 1e-6
    assert abs(float(measured['format']['duration']) - expected[-1] - 1 / 15) <= .001, measured['format']
    return dict(original_frame_count=len(selected), encoded_frame_count=len(pts), native_960Hz_ticks=ticks,
                measured_frame_pts_s=pts, frame_pts_match_native_to_one_microsecond=True,
                last_frame_display_duration_s=float(last['duration_time']), container_duration_s=float(measured['format']['duration']),
                video_stream_duration_s=float(measured['streams'][0]['duration']), container_duration_rounding_tolerance_s=.001,
                native_last_frame_time_s=expected[-1], ffmpeg_argv=argv)
