"""Prevent an inherited table-only CSS ID from sizing the whole mobile section."""
from pathlib import Path
import hashlib,json,shutil,zipfile
P=Path(__file__).resolve().parent
W=Path('/mnt/nas/data/lyf/double_hand/safeduo_dashboard_loaded_duration_20261012')
R=W/'docs/safety_actual_guard_20261012'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_text())
def write(p,v):Path(p).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def main():
    assert not (P/'BUILD_MANIFEST_V3.json').exists()
    old=read(P/'BUILD_MANIFEST_V2.json');snap=P/'layout_before_results_fix_v2';snap.mkdir()
    shutil.copyfile(R/'index.html',snap/'index.html');shutil.move(R/'PUBLIC_MANIFEST_V2.json',snap/'PUBLIC_MANIFEST_V2.json')
    s=(R/'index.html').read_text();assert s.count('id="results"')==1 and s.count('href="#results"')==2
    s=s.replace('id="results"','id="evaluation"').replace('href="#results"','href="#evaluation"')
    needle='<div class="scroll"><table>';assert s.count(needle)==2;s=s.replace(needle,'<div class="scroll"><table id="results">',1)
    s=s.replace('href="evidence/owned_method_source_v2.zip"','href="evidence/owned_method_source_v3.zip"').replace('href="METHOD_SOURCE_MANIFEST_V2.json"','href="METHOD_SOURCE_MANIFEST_V3.json"');(R/'index.html').write_text(s)
    current=read(R/'METHOD_SOURCE_MANIFEST_V2.json');current['source_files'].append(dict(original_path=str(Path(__file__)),archive_path='actual_guard_report_delivery_v1/postprocess_results_anchor_v2.py',sha256=sha(Path(__file__))))
    current['mobile_section_anchor_collision_corrected']=True
    with zipfile.ZipFile(R/'evidence/owned_method_source_v2.zip') as before,zipfile.ZipFile(R/'evidence/owned_method_source_v3.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6) as after:
        for entry in before.infolist():after.writestr(entry,before.read(entry.filename))
        after.write(Path(__file__),current['source_files'][-1]['archive_path'])
    write(R/'METHOD_SOURCE_MANIFEST_V3.json',current)
    for item in old['files']:
        if item['path'].endswith(('safety_actual_guard_20261012/index.html','PUBLIC_MANIFEST_V2.json')):continue
        assert sha(W/item['path'])==item['sha256']
    files=[dict(path=str(f.relative_to(W)),sha256=sha(f),bytes=f.stat().st_size) for f in sorted(R.rglob('*')) if f.is_file()];root=W/'index.html';files.append(dict(path='index.html',sha256=sha(root),bytes=root.stat().st_size))
    write(R/'PUBLIC_MANIFEST_V3.json',dict(files=files,manifest_self_excluded=True,all9_pass=False));files.append(dict(path=str((R/'PUBLIC_MANIFEST_V3.json').relative_to(W)),sha256=sha(R/'PUBLIC_MANIFEST_V3.json'),bytes=(R/'PUBLIC_MANIFEST_V3.json').stat().st_size));assert all(x['bytes']<95*1024**2 for x in files)
    write(P/'BUILD_MANIFEST_V3.json',dict(old,files=files,layout_revision=3,original_build_preserved=str(P/'BUILD_MANIFEST_V1.json')))
    print('P21_MOBILE_RESULTS_ANCHOR_FIXED;ALL_PRIOR_RAW_AND_METHOD_PACKAGES_UNCHANGED',len(files),flush=True)
if __name__=='__main__':main()
