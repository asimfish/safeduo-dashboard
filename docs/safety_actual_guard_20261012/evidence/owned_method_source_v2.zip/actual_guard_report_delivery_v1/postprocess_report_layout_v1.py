"""Match existing report CSS structure; preserve initial build and all raw data."""
from pathlib import Path
import hashlib,json,shutil,zipfile

P=Path(__file__).resolve().parent
W=Path('/mnt/nas/data/lyf/double_hand/safeduo_dashboard_loaded_duration_20261012')
R=W/'docs/safety_actual_guard_20261012'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_text())
def write(p,v):Path(p).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def once(s,a,b):
    assert s.count(a)==1,(a,s.count(a))
    return s.replace(a,b)

def main():
    assert not (P/'BUILD_MANIFEST_V2.json').exists()
    snap=P/'layout_before_fix_v1';snap.mkdir()
    shutil.copyfile(R/'index.html',snap/'index.html')
    shutil.move(R/'PUBLIC_MANIFEST_V1.json',snap/'PUBLIC_MANIFEST_V1.json')
    s=(R/'index.html').read_text()
    s=once(s,'<header class="masthead">','<header><div class="hero"><div class="topline">')
    s=once(s,'</header><div class="hero">','</div>')
    s=once(s,'</div><main class="report">','</div></header><div class="layout">')
    s=once(s,'<aside class="toc">','<nav class="toc" aria-label="报告目录">')
    s=once(s,'</aside><article class="content">','</nav><main>')
    s=once(s,'</article></main><footer>','</main></div><footer>')
    s=once(s,'class="lead"','class="subtitle"')
    s=once(s,'class="callout"','class="verdict"')
    s=once(s,'<b>九项要求尚未全部达标。</b>','<strong>九项要求尚未全部达标。</strong>')
    s=once(s,'<div class="stats"><div>','<div class="metrics"><div class="metric">')
    assert s.count('</div><div><strong>')==3
    s=s.replace('</div><div><strong>','</div><div class="metric"><strong>')
    s=s.replace('class="table-wrap"','class="scroll"')
    s=once(s,'href="evidence/owned_method_source.zip"','href="evidence/owned_method_source_v2.zip"')
    s=once(s,'href="METHOD_SOURCE_MANIFEST_V1.json"','href="METHOD_SOURCE_MANIFEST_V2.json"')
    (R/'index.html').write_text(s)
    previous=read(R/'METHOD_SOURCE_MANIFEST_V1.json');current=dict(previous)
    current['source_files']=[*previous['source_files'],dict(original_path=str(Path(__file__)),archive_path='actual_guard_report_delivery_v1/postprocess_report_layout_v1.py',sha256=sha(Path(__file__)))]
    current['html_layout_postprocessing_only']=True
    with zipfile.ZipFile(R/'evidence/owned_method_source.zip') as old,zipfile.ZipFile(R/'evidence/owned_method_source_v2.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6) as new:
        for item in old.infolist():new.writestr(item,old.read(item.filename))
        new.write(Path(__file__),current['source_files'][-1]['archive_path'])
    write(R/'METHOD_SOURCE_MANIFEST_V2.json',current)
    original=read(P/'BUILD_MANIFEST_V1.json')
    files=[dict(path=str(f.relative_to(W)),sha256=sha(f),bytes=f.stat().st_size) for f in sorted(R.rglob('*')) if f.is_file()]
    root=W/'index.html';files.append(dict(path='index.html',sha256=sha(root),bytes=root.stat().st_size))
    write(R/'PUBLIC_MANIFEST_V2.json',dict(files=files,manifest_self_excluded=True,all9_pass=False))
    files.append(dict(path=str((R/'PUBLIC_MANIFEST_V2.json').relative_to(W)),sha256=sha(R/'PUBLIC_MANIFEST_V2.json'),bytes=(R/'PUBLIC_MANIFEST_V2.json').stat().st_size))
    assert all(x['bytes']<95*1024**2 for x in files)
    write(P/'BUILD_MANIFEST_V2.json',dict(original,files=files,layout_revision=2,original_build_preserved=str(P/'BUILD_MANIFEST_V1.json')))
    print('P21_LAYOUT_MATCHED_EXISTING_CSS;ALL_RAW_UNCHANGED',len(files),'FILES',flush=True)

if __name__=='__main__':main()
