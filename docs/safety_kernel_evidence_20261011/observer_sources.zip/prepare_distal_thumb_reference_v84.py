"""Represent the original two thumb relations with the loaded distal joint as reference."""
from pathlib import Path
import ast,copy,datetime,hashlib,json,shutil
from audit_native_mimic_window_v8 import constraint_equivalence
H=Path(__file__).resolve().parent
read=lambda p:json.loads(Path(p).read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()

def main():
    base=H/'fourhand_native_probe_v82';p=H/'fourhand_native_probe_v84';assets=H/'coupled_hand_assets_v5'
    for v in [82,83]:
        assert read(H/f'fourhand_native_probe_v{v}/ACTUAL_COMPLETION_EXIT_V{v}.json')['actual_outer_exit']==0
        assert not read(H/f'fourhand_native_probe_v{v}/DISTRIBUTED_FORCE_VELOCITY_DIAGNOSTIC_DECISION_V1.json')['short_diagnostic_pass']
    assert not p.exists() and not assets.exists();p.mkdir();assets.mkdir()
    reg=copy.deepcopy(read(base/'REGISTRATION_V1.json'));meta=copy.deepcopy(read(reg['coupled_assets']))
    fl=meta['assets']['F_L'];r3=next(r for r in fl['relations'] if r['slave']=='left_thumb_3_joint');r4=next(r for r in fl['relations'] if r['slave']=='left_thumb_4_joint')
    a3,b3=r3['physx_multiplier'],r3['physx_offset_rad'];a4,b4=r4['physx_multiplier'],r4['physx_offset_rad']
    assert r3['physx_master']==r4['physx_master']=='left_thumb_2_joint' and a3>0 and a4>0
    pathprefix=r4['source_USD_joint_path'].rsplit('/',1)[0]
    # Preserve all original slave/master/multiplier/offset/motor and source asset fields.
    r4.update(physx_slave='left_thumb_2_joint',physx_master='left_thumb_4_joint',physx_multiplier=1/a4,
              physx_offset_rad=-b4/a4,physx_USD_joint_path=pathprefix+'/left_thumb_2_joint')
    r3.update(physx_master='left_thumb_4_joint',physx_multiplier=a3/a4,physx_offset_rad=b3-a3*b4/a4)
    layer=assets/'f_l_distal_thumb_reference_v1.usda'
    layer.write_text(f'''#usda 1.0
(
    defaultPrim = "Robot"
    subLayers = [@{fl['layer']}@]
)
over "Robot" {{
    over "f2_hand" {{
        over "joints" {{
            over "left_thumb_4_joint" (delete apiSchemas = ["PhysxMimicJointAPI:rotZ"]) {{}}
            over "left_thumb_2_joint" (prepend apiSchemas = ["PhysxMimicJointAPI:rotZ"]) {{
                float physxMimicJoint:rotZ:gearing = {-r4['physx_multiplier']:.17g}
                float physxMimicJoint:rotZ:offset = {-r4['physx_offset_rad']*180/3.141592653589793:.17g}
                rel physxMimicJoint:rotZ:referenceJoint = </Robot/f2_hand/joints/left_thumb_4_joint>
                uniform token physxMimicJoint:rotZ:referenceJointAxis = "rotZ"
            }}
            over "left_thumb_3_joint" {{
                float physxMimicJoint:rotZ:gearing = {-r3['physx_multiplier']:.17g}
                float physxMimicJoint:rotZ:offset = {-r3['physx_offset_rad']*180/3.141592653589793:.17g}
                rel physxMimicJoint:rotZ:referenceJoint = </Robot/f2_hand/joints/left_thumb_4_joint>
                uniform token physxMimicJoint:rotZ:referenceJointAxis = "rotZ"
            }}
        }}
    }}
}}
''')
    fl['layer']=str(layer);metafile=assets/'COUPLED_ASSETS_V1.json';metafile.write_text(json.dumps(meta,indent=2)+'\n')
    proofs={arm:constraint_equivalence(asset) for arm,asset in meta['assets'].items()}
    for f in base.iterdir():
        if f.suffix in ['.py','.usda']:shutil.copyfile(f,p/f.name)
    private=p/'private_kit_user_data';private.mkdir();prepared=p/'PRIVATE_KIT_USER_CONFIG_FROZEN_V1.json'
    shutil.copyfile(base/'PRIVATE_KIT_USER_CONFIG_FROZEN_V1.json',prepared);shutil.copyfile(prepared,private/'user.config.json')
    source=(base/'native_common_beam_v1.py').read_text()
    needle="suffix=r['source_USD_joint_path'].split('/',2)[2]";assert source.count(needle)==1
    source=source.replace(needle,"suffix=r.get('physx_USD_joint_path',r['source_USD_joint_path']).split('/',2)[2]")
    needle="records.append(dict(slave=r['slave'],master=r['physx_master'],original_URDF_master=r['master'],gearing=gear,offset_degrees=offset,prim=str(prim.GetPath()),reference=str(rel[0])))";assert source.count(needle)==1
    source=source.replace(needle,needle[:-2]+',native_axis=token))')
    needle="save(out/'native_mimic_identity.json',dict(relations=native_mimic,scope='Full-window coupled grasp development; independent load and task audits required'))";assert source.count(needle)==1
    source=source.replace(needle,"""actual_mimic_count=sum(prim.HasAPI(PhysxSchema.PhysxMimicJointAPI,axis) for prim in stage.Traverse(Usd.TraverseInstanceProxies()) if str(prim.GetPath()).startswith('/World/envs/env_0/') for axis in ['rotX','rotY','rotZ'])
        assert actual_mimic_count==24
        save(out/'native_mimic_identity.json',dict(relations=native_mimic,actual_applied_mimic_API_count=actual_mimic_count,scope='Equivalent distal reference; API count/rowspace are not native compliance or convergence proof'))""")
    ast.parse(source);(p/'native_common_beam_v1.py').write_text(source)
    launcher=H/'launch_fourhand_native_probe_v84.py';wrapper=H/'run_isolated_microstep_convergence_v84.py'
    for old,new in [(H/'launch_fourhand_native_probe_v82.py',launcher),(H/'run_isolated_microstep_convergence_v82.py',wrapper)]:
        assert not new.exists();text=old.read_text().replace('probe_v82','probe_v84').replace('PLAN_V82','PLAN_V84').replace('convergence-v82','convergence-v84');ast.parse(text);new.write_text(text)
    reg.update(attempt_version=84,scientific_candidate_version=84,numerical_baseline_version=82,registered_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),coupled_assets=str(metafile),
               change_scope='Equivalent numerical constraint reference graph for two F_L thumb rows: loaded distal joint4 is reference forjoint2 andjoint3. Original24 URDF relations, all6 original independent hand motor coordinates perhand, physical properties, full50controller, seed/tape/clock/model and physical thresholds unchanged. Exactly24 native mimic APIs, rank6 perhand; no duplicate rows/additional locks/compliance or actuators. DistributedforceTrue/32position/1velocity from82 fixed; private Kit settings only. Not same as failed73 inverse-only graph, which retainedjoint3 referencejoint2. Short64-event known-case diagnostic, not acceptance or random coverage.')
    reg['private_asset_settings']=dict(reg['private_asset_settings'],private_directory=str(private))
    for f in [*p.iterdir(),*assets.iterdir(),Path(__file__),launcher,wrapper,prepared,H/'audit_native_mimic_window_v9.py',H/'audit_native_mimic_window_v8.py']:
        if f.is_file():reg['source_sha256'][str(f)]=sha(f)
    (p/'REGISTRATION_V1.json').write_text(json.dumps(reg,indent=2)+'\n')
    plan=H/'DISTAL_THUMB_REFERENCE84_PROSPECTIVE_PLAN_V1.json';assert not plan.exists()
    plan.write_text(json.dumps(dict(frozen_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),baseline=82,candidate=84,
                original_constraint_rowspace_proofs=proofs,actual_API_inventory_must_equal24=True,actual_native_constraint_rank_per_hand=6,
                original_independent_hand_motors_per_hand=6,all77_native_parameter_arrays_and13seed_fields_must_byte_equal71=True,
                full50_controller_targets_clock_and_physical_parameters_unchanged=True,original_q_and_qd_tolerance=1e-4,
                maximum_physics_events=64,maximum_native_wall_seconds=600,
                additional_weak_contact=dict(F_L_normal_gt_N=.005,consecutive_events_ge=20),
                advance_only_if_complete64_original_model_original_physical_and_weak_contact=True,
                authored_frequency_or_damping_values_not_native_compliance_proof=True,no_duplicate_constraints_or_added_actuator=True,
                candidate79_never_launched=True,new_independent_random_cases=0,formal_holdout_count=0,fulltask_accepted=False,fullSystem0_accepted=False,
                source_sha256={str(f):sha(f) for f in [Path(__file__),metafile,layer,p/'REGISTRATION_V1.json',H/'audit_native_mimic_window_v9.py']}),indent=2)+'\n')
    print('FROZEN84_EQUIVALENT_DISTAL_THUMB_REFERENCE_RANK6_ORIGINAL24_HARD_MODEL_GATES',flush=True)

if __name__=='__main__':main()
