"""Exact original82 state custody before bounded interpretation of observed scalar bytes."""
from pathlib import Path
import datetime,json,math,struct
from audit_owned_kernel_trace81_v1 import compare,sha
H=Path(__file__).resolve().parent
read=lambda p:json.loads(Path(p).read_text())
def float_bits(scalar):return struct.unpack('<f',struct.pack('<I',scalar['raw_u32']))[0]

def main():
    p=H/'fourhand_native_probe_v86';target=p/'OWNED_KERNEL_PARAMETERS86_CLOSURE_V1.json';assert not target.exists()
    assert read(p/'ACTUAL_COMPLETION_EXIT_V86.json')['actual_outer_exit']==0
    assert all(r['actual_exit']==0 for r in read(p/'CORE_ACTUAL_EXIT_RECEIPTS_V86.json')['actual_outer_exits'].values())
    planfile=H/'OWNED_KERNEL_PARAMETERS86_PROSPECTIVE_PLAN_V1.json';plan=read(planfile)
    for f,d in plan['source_sha256'].items():assert sha(f)==d
    raw=[];chunks=[]
    for v in [82,86]:
        r=read(H/f'fourhand_native_probe_v{v}/RESOURCE_EXECUTION_V1.json');assert r['actual_exit']==r['actual_native_exit']==0
        root=Path(r['out']);raw.append(root);index=read(root/'physics_chunks.json');assert len(index)==1
        f=root/index[0]['path'];assert sha(f)==index[0]['sha256'];chunks.append(f)
    parity=dict(native_parameters=compare(raw[0]/'native_parameters.npz',raw[1]/'native_parameters.npz',77),
                seed=compare(raw[0]/'actual_initial_seed_binding.npz',raw[1]/'actual_initial_seed_binding.npz',13),
                recorded_physics=compare(chunks[0],chunks[1],164));pure=all(x['all_fields_byte_identical'] for x in parity.values())
    job=read(H/'fourhand_native_probe_v86_execution.json')['jobs'][0]
    assert job['actual_native_exit']==0 and job['native_owned_process_reaped_and_absent'];pid=job['actual_native_pid']
    log=p/'OWNED_KERNEL_ARGUMENTS_V1.jsonl';data=[json.loads(s) for s in log.read_text().splitlines()]
    assert not any(r['kind'] in ['unsupported_launch','subscribe_failed'] for r in data)
    layout={r['role']:r for r in data if r['kind']=='binary_parameter_layout'};assert set(layout)=={0,1}
    assert layout[0]['sizes']==[8,4,4,4,1,1] and len(layout[1]['sizes'])<=16
    entries=[r for r in data if r['kind']=='entry'];exits=[r for r in data if r['kind']=='exit'];assert len(entries)==len(exits)>0
    returns={(r['role'],r['correlation']):r for r in exits};assert len(returns)==len(exits)
    unique=set();per_event=[]
    for event in range(16):
        group=[r for r in entries if r['event']==event];assert group
        counts={str(role):sum(r['role']==role for r in group) for role in [0,1]};assert all(counts.values())
        mimic=[r for r in group if r['role']==0];values=[{s['index']:s for s in r['scalars']} for r in mimic]
        per_event.append(dict(event=event,named_kernel_counts=counts,
            source_compatible_mimic_arg4_u8_sequence=[s[4]['raw_u8'] for s in values],
            source_compatible_mimic_arg5_u8_sequence=[s[5]['raw_u8'] for s in values],
            source_compatible_mimic_arg2_float32_values=[float_bits(s[2]) for s in values],
            source_compatible_mimic_arg3_float32_values=[float_bits(s[3]) for s in values]))
    for r in entries:
        key=r['role'],r['correlation'];assert key not in unique;unique.add(key)
        assert r['pid']==pid and 0<=r['event']<16 and returns[key]['event']==r['event'] and returns[key]['actual_CUDA_status']==0
        sizes=layout[r['role']]['sizes'];expected={i for i,s in enumerate(sizes) if s!=8}
        assert {s['index'] for s in r['scalars']}==expected
        for scalar in r['scalars']:
            i=scalar['index'];assert scalar['size']==sizes[i]
            if scalar['size']==4:assert math.isfinite(float_bits(scalar))
    model=read(p/'INDEPENDENT_NATIVE_MIMIC_WINDOW_V6.json');observed=per_event[0]['source_compatible_mimic_arg2_float32_values'][0]
    result=dict(status='PASS_BOUNDED_OWNED_KERNEL_SCALARS_AND_BYTEWISE82_PURITY' if pure else 'REJECT_OBSERVER_PARITY_FAILED',
                utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),observation_replica=86,baseline=82,
                trace_inference_authorized=pure,parity=parity,physics_events=16,owned_native_pid=pid,
                actual_binary_parameter_layouts=list(layout.values()),per_event=per_event,all_entries_exits_correlated_successful=True,
                CPU_argument_data_only_no_GPU_pointer_values_or_descriptor_reads=True,
                original_model_pass=model['model_window_pass'],original_qd_error_rad_s=model['maximum_qd_residual_rad_s'],
                clock_hypothesis=dict(observed_mimic_arg2_float32=observed,registered_physics_dt_s=read(p/'REGISTRATION_V1.json')['physics_dt_s'],
                                      compatible_source_explanation='Arg2 has the published mimic dt signature; 32 times its observed float32 value matches1/960, whereas registration specifies0.001041625. SDK local set_physics_dt truncates1/dt tointegerHz. Direct runtime getter+USD integer-rate verification is required before claiming the actual clock is qualified.',
                                      direct_runtime_clock_binding_not_yet_verified=True),
                installed_binary_exact_source_commit_unknown=True,public_source_semantic_argument_names_are_hypotheses=True,
                internal_signature_public12_versus_observed_count=len(layout[1]['sizes']),new_scientific_candidate=False,
                new_independent_random_cases=0,formal_holdout_count=0,fulltask_qualified=False,all9_jointly_accepted=False,fullSystem0_accepted=False,
                source_sha256={str(f):sha(f) for f in [Path(__file__),planfile,log,p/'CORE_ACTUAL_EXIT_RECEIPTS_V86.json',*chunks]})
    target.write_text(json.dumps(result,indent=2)+'\n')
    print(result['status'],'layouts',[r['sizes'] for r in layout.values()],'counts',per_event[0]['named_kernel_counts'],flush=True)

if __name__=='__main__':main()
