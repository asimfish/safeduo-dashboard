// Observe two owned CUDA launches. Never call CUDA or mutate arguments in a callback.
#include <cuda.h>
#include <cupti.h>
#include <cstdio>
#include <cstring>
#include <cstdint>
#include <mutex>
#include <cmath>
#include <unistd.h>
namespace {
std::mutex gate;
CUpti_SubscriberHandle subscriber;
FILE* output=nullptr;
int event=-1;
bool subscribed=false;
CUfunction functions[2]={};
bool validated[2]={};
size_t sizes[2][16]={},offsets[2][16]={};
const char* names[2]={"artiSolveInternalTendonAndMimicJointConstraints1T","artiSolveInternalConstraintsTGS1T"};
const size_t expected_mimic[6]={8,4,4,4,1,1};
int counts[2]={0,0};
void CUPTIAPI callback(void*,CUpti_CallbackDomain domain,CUpti_CallbackId id,const void* data){
 if(domain!=CUPTI_CB_DOMAIN_DRIVER_API||id!=CUPTI_DRIVER_TRACE_CBID_cuLaunchKernel)return;
 const auto* info=static_cast<const CUpti_CallbackData*>(data);
 if(!info->symbolName||!info->functionParams)return;
 int role=-1;for(int i=0;i<2;++i)if(std::strcmp(info->symbolName,names[i])==0)role=i;
 if(role<0)return;
 const auto* args=static_cast<const cuLaunchKernel_params*>(info->functionParams);
 std::lock_guard<std::mutex> lock(gate);
 if(!functions[role])functions[role]=args->f;
 if(event<0||!output)return;
 if(functions[role]!=args->f||!validated[role]||!args->kernelParams){
  std::fprintf(output,"{\"kind\":\"unsupported_launch\",\"event\":%d,\"role\":%d}\n",event,role);return;
 }
 if(info->callbackSite==CUPTI_API_EXIT){
  int status=-1;if(info->functionReturnValue)std::memcpy(&status,info->functionReturnValue,sizeof(status));
  std::fprintf(output,"{\"kind\":\"exit\",\"event\":%d,\"role\":%d,\"correlation\":%u,\"actual_CUDA_status\":%d}\n",event,role,info->correlationId,status);return;
 }
 if(info->callbackSite!=CUPTI_API_ENTER)return;
 std::fprintf(output,"{\"kind\":\"entry\",\"pid\":%d,\"event\":%d,\"role\":%d,\"kernel\":\"%s\",\"correlation\":%u,\"context_uid\":%u,\"scalars\":[",int(getpid()),event,role,names[role],info->correlationId,info->contextUid);
 bool comma=false;
 for(int i=0;i<counts[role];++i){
  if(sizes[role][i]==8)continue; // Never read/dereference descriptors or print pointer values.
  if(comma){std::fputc(',',output);}
  comma=true;
  if(!args->kernelParams[i]){std::fprintf(output,"{\"index\":%d,\"missing\":true}",i);continue;}
  if(sizes[role][i]==1){uint8_t value;std::memcpy(&value,args->kernelParams[i],1);std::fprintf(output,"{\"index\":%d,\"size\":1,\"raw_u8\":%u}",i,unsigned(value));}
  else if(sizes[role][i]==2){uint16_t bits;std::memcpy(&bits,args->kernelParams[i],2);std::fprintf(output,"{\"index\":%d,\"size\":2,\"raw_u16\":%u}",i,unsigned(bits));}
  else {uint32_t bits;float value;std::memcpy(&bits,args->kernelParams[i],4);std::memcpy(&value,args->kernelParams[i],4);std::fprintf(output,"{\"index\":%d,\"size\":4,\"raw_u32\":%u",i,bits);if(std::isfinite(value)){std::fprintf(output,",\"IEEE32_bit_view\":%.9g",double(value));}std::fprintf(output,"}");}
 }
 std::fprintf(output,"]}\n");
}
}
extern "C" int safeduo_observer_start(const char* path){
 if(subscribed||output)return -1;
 output=std::fopen(path,"wx");if(!output)return -2;
 CUptiResult r=cuptiSubscribe(&subscriber,callback,nullptr);
 if(r!=CUPTI_SUCCESS){std::fprintf(output,"{\"kind\":\"subscribe_failed\",\"status\":%d}\n",int(r));std::fclose(output);output=nullptr;return -3;}
 subscribed=true;r=cuptiEnableCallback(1,subscriber,CUPTI_CB_DOMAIN_DRIVER_API,CUPTI_DRIVER_TRACE_CBID_cuLaunchKernel);
 return r==CUPTI_SUCCESS?0:-4;
}
extern "C" int safeduo_observer_prepare(){
 // Called by Python before its critical window, outside all CUPTI callbacks.
 std::lock_guard<std::mutex> lock(gate);
 for(int role=0;role<2;++role){
  if(!functions[role])return -10-role;
  for(int i=0;i<=16;++i){
   size_t offset=0,size=0;
   CUresult r=cuFuncGetParamInfo(functions[role],i,&offset,&size);
   if(r==CUDA_ERROR_INVALID_VALUE){counts[role]=i;break;}
   if(r!=CUDA_SUCCESS||i==16||(size!=1&&size!=2&&size!=4&&size!=8))return -20-role;
   sizes[role][i]=size;offsets[role][i]=offset;
  }
  if(counts[role]<1||counts[role]>16)return -30-role;
  if(role==0){if(counts[role]!=6)return -40;for(int i=0;i<6;++i)if(sizes[role][i]!=expected_mimic[i])return -41;}
  validated[role]=true;
  std::fprintf(output,"{\"kind\":\"binary_parameter_layout\",\"role\":%d,\"kernel\":\"%s\",\"sizes\":[",role,names[role]);
  for(int i=0;i<counts[role];++i)std::fprintf(output,"%s%zu",i?",":"",sizes[role][i]);
  std::fprintf(output,"],\"offsets\":[");for(int i=0;i<counts[role];++i)std::fprintf(output,"%s%zu",i?",":"",offsets[role][i]);std::fprintf(output,"]}\n");
 }
 std::fflush(output);return 0;
}
extern "C" int safeduo_observer_event(int value){std::lock_guard<std::mutex> lock(gate);event=value;return 0;}
extern "C" int safeduo_observer_stop(){
 if(!subscribed)return -1;
 CUptiResult r=cuptiUnsubscribe(subscriber);subscribed=false;
 std::lock_guard<std::mutex> lock(gate);event=-1;
 if(output){std::fflush(output);std::fclose(output);output=nullptr;}
 return r==CUPTI_SUCCESS?0:-2;
}
