"""Freeze the installed SDK's recommended 1/2-velocity comparison after the owned trace."""
from pathlib import Path
import ast,copy,datetime,hashlib,json,shutil
H=Path(__file__).resolve().parent
read=lambda p:json.loads(Path(p).read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()

def main():
    base=H/'fourhand_native_probe_v78';closed=read(H/'fourhand_native_probe_v81/OWNED_KERNEL_TRACE81_CLOSURE_V1.json')
    assert closed['trace_inference_authorized'] and not closed['original_model_pass']
    assert not read(base/'DISTRIBUTED_FORCE78_DIAGNOSTIC_DECISION_V1.json')['candidate79_authorized_by_predeclared_gate']
    sdk=Path('/home/liyufeng/safeduo_isaaclab/source/isaaclab/isaaclab/sim/simulation_context.py')
    assert 'number of velocity iterations (setting it to 1 or 2 rather than 0)' in sdk.read_text()
    target=H/'DISTRIBUTED_FORCE_VELOCITY82_83_PROSPECTIVE_PLAN_V1.json';assert not target.exists()
    cases={}
    for version,velocity in [(82,1),(83,2)]:
        p=H/f'fourhand_native_probe_v{version}';assert not p.exists();p.mkdir()
        for f in base.iterdir():
            if f.suffix in ['.py','.usda']:shutil.copyfile(f,p/f.name)
        private=p/'private_kit_user_data';private.mkdir()
        prepared=p/'PRIVATE_KIT_USER_CONFIG_FROZEN_V1.json'
        shutil.copyfile(H/'fourhand_native_probe_v81/PRIVATE_KIT_USER_CONFIG_FROZEN_V1.json',prepared)
        shutil.copyfile(prepared,private/'user.config.json')
        source=(base/'native_common_beam_v1.py').read_text()
        changes={
            'cfg.sim.physx.max_velocity_iteration_count=0':f'cfg.sim.physx.min_velocity_iteration_count={velocity}\n        cfg.sim.physx.max_velocity_iteration_count={velocity}',
            'solver_velocity_iteration_count=0':f'solver_velocity_iteration_count={velocity}',
            "values['min_velocity']<=0<=values['max_velocity']":f"values['min_velocity']<={velocity}<=values['max_velocity']",
            "caps[0]['min_velocity']==caps[0]['max_velocity']==0":f"caps[0]['min_velocity']==caps[0]['max_velocity']=={velocity}",
            'metadata_scene_velocity_cap=0':f'metadata_scene_velocity_cap={velocity}',
            '(pi,vi)==(32,0)':f'(pi,vi)==(32,{velocity})',
            'position_iterations=32,velocity_iterations=0':f'position_iterations=32,velocity_iterations={velocity}',
        }
        for old,new in changes.items():assert source.count(old)==1,old;source=source.replace(old,new)
        ast.parse(source);(p/'native_common_beam_v1.py').write_text(source)
        launcher=H/f'launch_fourhand_native_probe_v{version}.py';wrapper=H/f'run_isolated_microstep_convergence_v{version}.py'
        for old,new in [(H/'launch_fourhand_native_probe_v78.py',launcher),(H/'run_isolated_microstep_convergence_v78.py',wrapper)]:
            assert not new.exists();text=old.read_text().replace('probe_v78',f'probe_v{version}').replace('PLAN_V78',f'PLAN_V{version}').replace('convergence-v78',f'convergence-v{version}')
            if new==launcher:
                needle="        for binding in reg['private_driver_library_bindings']:";assert text.count(needle)==1
                shared=read(H/'fourhand_native_probe_v81/REGISTRATION_V1.json')['private_asset_settings']['shared_directory']
                text=text.replace(needle,"        prefix+=['--bind',str(P/'private_kit_user_data'),"+repr(shared)+']\n'+needle)
                if version==83:
                    needle="    reg=json.loads((P/'REGISTRATION_V1.json').read_text())";assert text.count(needle)==1
                    text=text.replace(needle,"    prior=json.loads((H/'fourhand_native_probe_v82/ACTUAL_COMPLETION_EXIT_V82.json').read_text());assert prior['actual_outer_exit']==0, 'Sequential owned case82 must be reaped'\n"+needle)
            ast.parse(text);new.write_text(text)
        reg=copy.deepcopy(read(base/'REGISTRATION_V1.json'))
        reg.update(attempt_version=version,scientific_candidate_version=version,numerical_baseline_version=78,
                   registered_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                   native_solver_profile=dict(position_iterations=32,velocity_iterations=velocity),native_scene_velocity_iteration_cap=velocity,
                   native_scene_velocity_iteration_minimum=velocity,
                   private_asset_settings=read(H/'fourhand_native_probe_v81/REGISTRATION_V1.json')['private_asset_settings'],
                   change_scope=f'Known-seed comparison versus78: effective velocity iteration setting0->{velocity}, implemented consistently in four original articulation roots and scene minimum/maximum. Distributed external force remainsTrue, position32 fixed, original full50 controller and all77 native parameters+13seed arrays/tape/clock/qANDqd1e-4/physical gates unchanged. Private Kit user directory isolates shared asset settings as81; no profiler and no shared settings write. Installed SDK specifically recommends1or2 velocity iterations with distributed forces. Not conditional position79, whose gate remainsFalse. Short64 maximum development, no new random/fulltask/formal/learnedSystem0 trial. Native metadata profile is verified; binary kernel execution count for this new candidate is not observed.')
        for f in [*p.iterdir(),prepared,Path(__file__),launcher,wrapper,sdk,H/'audit_short_contact_capture_v1.py',
                  H/'audit_native_mimic_window_v6.py',H/'audit_short_contact_target_tape_v1.py',H/'audit_full_motor_effort_native_v4.py']:
            if f.is_file():reg['source_sha256'][str(f)]=sha(f)
        (p/'REGISTRATION_V1.json').write_text(json.dumps(reg,indent=2)+'\n')
        cases[str(version)]=dict(velocity_iterations=velocity,position_iterations=32,distributed_external_forces=True,
                                  registration_sha256=sha(p/'REGISTRATION_V1.json'))
    target.write_text(json.dumps(dict(frozen_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),baseline=78,candidates=cases,
                                     original_native_arrays77_seed_fields13_must_byte_equal71=True,
                                     original_q_and_qd_tolerances=1e-4,all_original_physical_gates_unchanged=True,
                                     original_full50_controller_and_targets_unchanged=True,maximum_events_per_candidate=64,
                                     per_candidate_abort_after_complete_control_if_original_model_fails=True,
                                     additional_diagnostic_weak_contact=dict(F_L_normal_gt_N=.005,consecutive_events_ge=20),
                                     advancement_requires_complete64_model_physical_and_diagnostic_weak_contact=True,
                                     comparison_scientific_factor='Effective velocity-iteration setting0/1/2; consistent root and scene min/max authoring are declared together. Position32 and all physical parameters fixed.',
                                     both_cases_frozen_before_any_result=True,run83_only_after82_actual0_reaped=True,
                                     conditional79_gate_still_false_and79_never_launched=True,
                                     hardware_configuration_still_unqualified=True,formal_holdout_count=0,new_independent_random_cases=0,
                                     fulltask_accepted=False,fullSystem0_accepted=False,
                                     source_sha256={str(f):sha(f) for f in [Path(__file__),sdk,H/'fourhand_native_probe_v81/OWNED_KERNEL_TRACE81_CLOSURE_V1.json']}),indent=2)+'\n')
    print('FROZEN82_83_DISTRIBUTED_FORCE_VELOCITY1_2_ORIGINAL_GATES_AND_SEQUENTIAL_ONLY',flush=True)

if __name__=='__main__':main()
