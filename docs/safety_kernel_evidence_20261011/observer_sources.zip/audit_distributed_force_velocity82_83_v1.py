"""Apply the frozen 82/83 original-model and contact gate; retain every rejection."""
from pathlib import Path
import argparse,datetime,hashlib,json
import numpy as np
from audit_owned_kernel_trace81_v1 import compare
from audit_short_hand_pd_filter_decision_v1 import longest
H=Path(__file__).resolve().parent
read=lambda p:json.loads(Path(p).read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()

def main(version):
    assert version in [82,83];p=H/f'fourhand_native_probe_v{version}'
    target=p/'DISTRIBUTED_FORCE_VELOCITY_DIAGNOSTIC_DECISION_V1.json';assert not target.exists()
    planfile=H/'DISTRIBUTED_FORCE_VELOCITY82_83_PROSPECTIVE_PLAN_V1.json';plan=read(planfile)
    profile=plan['candidates'][str(version)];v=profile['velocity_iterations']
    regfile=p/'REGISTRATION_V1.json';assert sha(regfile)==profile['registration_sha256']
    for f,d in plan['source_sha256'].items():assert sha(f)==d
    reg=read(regfile)
    for f,d in reg['source_sha256'].items():assert sha(f)==d
    assert read(p/f'ACTUAL_COMPLETION_EXIT_V{version}.json')['actual_outer_exit']==0
    core=read(p/f'CORE_ACTUAL_EXIT_RECEIPTS_V{version}.json')
    assert all(x['actual_exit']==0 for x in core['actual_outer_exits'].values())
    capture=read(p/'INDEPENDENT_CAPTURE_AUDIT_V1.json');model=read(p/'INDEPENDENT_NATIVE_MIMIC_WINDOW_V6.json')
    assert capture['record_integrity_verified'] and capture['all_owned_native_children_reaped']
    raw=Path(read(p/'RESOURCE_EXECUTION_V1.json')['out']);baseline=Path(read(H/'fourhand_native_probe_v71/RESOURCE_EXECUTION_V1.json')['out'])
    native=compare(raw/'native_parameters.npz',baseline/'native_parameters.npz',77)
    seed=compare(raw/'actual_initial_seed_binding.npz',baseline/'actual_initial_seed_binding.npz',13)
    assert native['all_fields_byte_identical'] and seed['all_fields_byte_identical']
    roots=read(raw/'native_solver_roots.json');assert len(roots)==4 and all(x['position_iterations']==32 and x['velocity_iterations']==v for x in roots)
    scenes=read(raw/'native_scene_iteration_caps_v1.json')['scenes'];assert len(scenes)==1 and scenes[0]['min_velocity']==scenes[0]['max_velocity']==v
    assert read(raw/'native_scene_settings.json')['enable_external_forces_every_iteration'] is True
    execution=read(H/f'fourhand_native_probe_v{version}_execution.json');job=execution['jobs'][0]
    assert job['actual_exit']==job['actual_native_exit']==0 and job['native_owned_process_reaped_and_absent']
    supplementary=H/'PRIVATE_SETTINGS_BINDING82_83_PRELAUNCH_SUPPLEMENT_V1.json'
    binding=next(x for x in read(supplementary)['bindings'] if x['version']==version)
    argv=job['argv'];triplet=['--bind',binding['actual_private_directory'],binding['actual_shared_directory']]
    assert any(argv[i:i+3]==triplet for i in range(len(argv)-2))
    assert sha(p/'PRIVATE_KIT_USER_CONFIG_FROZEN_V1.json')==binding['frozen_config_sha256']
    pieces=[];files=[]
    for chunk in read(raw/'physics_chunks.json'):
        file=raw/chunk['path'];assert sha(file)==chunk['sha256'];files.append(file)
        with np.load(file,allow_pickle=False) as z:pieces.append(z['four_hand_normal_N'].copy())
    force=np.concatenate(pieces);n=len(force);assert n==capture['physics_events']==model['physics_events'] and 0<n<=64
    diagnostic=plan['additional_diagnostic_weak_contact'];duration=longest(force[:,0]>diagnostic['F_L_normal_gt_N'])
    assert model['predeclared_relation_tolerance']==plan['original_q_and_qd_tolerances']==1e-4
    checks=dict(complete64=n==64,original_q_AND_qd_model=model['model_window_pass'],original_physical=capture['physical_gates_pass'],
                additional_weak_contact_persistence=duration>=diagnostic['consecutive_events_ge'])
    result=dict(status='CLOSED_PREDECLARED_DISTRIBUTED_FORCE_VELOCITY_DIAGNOSTIC',version=version,baseline=78,
                utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),velocity_iterations_metadata=v,position_iterations_metadata=32,
                binary_execution_count_for_this_candidate_not_observed=True,physics_events=n,checks=checks,
                short_diagnostic_pass=all(checks.values()),eligible_for_further_loaded_qualification=all(checks.values()),
                original_q_error_rad=model['maximum_q_residual_rad'],original_qd_error_rad_s=model['maximum_qd_residual_rad_s'],
                maximum_F_L_normal_N=float(force[:,0].max()),diagnostic_F_L_longest_weak_contact_events=duration,
                all77_native_arrays_and13_seed_fields_byte_equal71=True,every_submitted_target_independently_verified=True,
                correct_actual_private_Kit_binding_verified=True,original_registration_ancestor_directory_metadata_corrected_by_prelaunch_supplement=True,
                candidate_adopted=False,fulltask_qualified=False,all9_jointly_accepted=False,new_independent_random_cases=0,formal_holdout_count=0,
                fullSystem0_accepted=False,source_sha256={str(f):sha(f) for f in [Path(__file__),planfile,regfile,supplementary,
                     p/f'CORE_ACTUAL_EXIT_RECEIPTS_V{version}.json',p/'INDEPENDENT_CAPTURE_AUDIT_V1.json',p/'INDEPENDENT_NATIVE_MIMIC_WINDOW_V6.json',*files]})
    target.write_text(json.dumps(result,indent=2)+'\n')
    print('CLOSED_VELOCITY_DIAGNOSTIC',version,checks,'qd',result['original_qd_error_rad_s'],'force',result['maximum_F_L_normal_N'],flush=True)

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('version',type=int);main(parser.parse_args().version)
