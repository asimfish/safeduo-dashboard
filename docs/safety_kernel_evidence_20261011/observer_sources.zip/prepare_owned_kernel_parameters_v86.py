"""Read kernel scalar arguments for an owned82 replica; preserve the physical trajectory."""
from pathlib import Path
import ast,copy,datetime,hashlib,json,shutil
H=Path(__file__).resolve().parent
read=lambda p:json.loads(Path(p).read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()

def main():
    base=H/'fourhand_native_probe_v82';p=H/'fourhand_native_probe_v86';assert not p.exists()
    assert read(base/'ACTUAL_COMPLETION_EXIT_V82.json')['actual_outer_exit']==0
    assert not read(base/'DISTRIBUTED_FORCE_VELOCITY_DIAGNOSTIC_DECISION_V1.json')['short_diagnostic_pass']
    previous=read(H/'fourhand_native_probe_v85/ACTUAL_INCOMPLETE_SETUP_EXIT_V85.json');assert previous['actual_outer_exit']==1 and previous['physics_events']==0
    library=H/'owned_kernel_argument_observer86.so';assert library.is_file()
    p.mkdir()
    for f in base.iterdir():
        if f.suffix in ['.py','.usda']:shutil.copyfile(f,p/f.name)
    private=p/'private_kit_user_data';private.mkdir();prepared=p/'PRIVATE_KIT_USER_CONFIG_FROZEN_V1.json'
    shutil.copyfile(base/'PRIVATE_KIT_USER_CONFIG_FROZEN_V1.json',prepared);shutil.copyfile(prepared,private/'user.config.json')
    source=(base/'native_common_beam_v1.py').read_text()
    needle='    env=None;observer=None;completed=0;';assert source.count(needle)==1
    source=source.replace(needle,'    kernel_observer=None\n'+needle)
    needle='        import isaaclab.sim as sim_utils';assert source.count(needle)==1
    source=source.replace(needle,"""        import ctypes
        kernel_observer=ctypes.CDLL(str(H/'owned_kernel_argument_observer86.so'))
        kernel_observer.safeduo_observer_start.argtypes=[ctypes.c_char_p]
        kernel_observer.safeduo_observer_start.restype=ctypes.c_int
        kernel_observer.safeduo_observer_event.argtypes=[ctypes.c_int]
        assert kernel_observer.safeduo_observer_start(str(P/'OWNED_KERNEL_ARGUMENTS_V1.jsonl').encode())==0, 'Owned callback subscription failed'
"""+needle)
    needle="        for step in range(reg['maximum_controls']):";assert source.count(needle)==1
    source=source.replace(needle,"        assert kernel_observer.safeduo_observer_prepare()==0, 'Actual binary parameter layouts not validated; do not read arguments'\n"+needle)
    needle='                env.sim.step(render=False);env.scene.update(cfg.sim.dt)';assert source.count(needle)==1
    source=source.replace(needle,"                assert kernel_observer.safeduo_observer_event(substeps*step+sub)==0\n"+needle+"\n                assert kernel_observer.safeduo_observer_event(-1)==0")
    needle='        flush();observer.close(completed)';assert source.count(needle)==1
    source=source.replace(needle,"        assert kernel_observer.safeduo_observer_stop()==0\n        kernel_observer=None\n"+needle)
    needle="        save(out/'fourhand_protocol.json',protocol)\n        if env is not None:env.close()";assert source.count(needle)==1
    source=source.replace(needle,"        if kernel_observer is not None:\n            kernel_observer.safeduo_observer_stop();kernel_observer=None\n"+needle)
    ast.parse(source);(p/'native_common_beam_v1.py').write_text(source)
    launcher=H/'launch_fourhand_native_probe_v86.py';wrapper=H/'run_isolated_microstep_convergence_v86.py'
    for old,new in [(H/'launch_fourhand_native_probe_v82.py',launcher),(H/'run_isolated_microstep_convergence_v82.py',wrapper)]:
        assert not new.exists();text=old.read_text().replace('probe_v82','probe_v86').replace('PLAN_V82','PLAN_V86').replace('convergence-v82','convergence-v86');ast.parse(text);new.write_text(text)
    reg=copy.deepcopy(read(base/'REGISTRATION_V1.json'))
    reg.update(attempt_version=86,scientific_candidate_version=82,numerical_baseline_version=82,registered_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
               owned_kernel_argument_observer=dict(library=str(library),callbacks='Only own cuLaunchKernel entry/exit, two whitelisted kernel names',
                                                   driver_queries='cuFuncGetParamInfo outside callbacks before critical physics; six mimic sizes and dynamically discovered internal sizes required',
                                                   raw_argument_sizes=[8,4,1],pointer_sized_arguments_never_read_or_dereferenced=True,
                                                   no_CUDA_API_calls_in_callback=True,no_launch_or_argument_changes=True),
               change_scope='Read-only own-process scalar-argument observer for closed82; no numerical candidate. Original native77 arrays/13seed/full164 physics fields must byte-equal82 before inference. Actual driver parameter-size metadata validates read bounds. Public-source semantic names remain a hypothesis; installed binary exact source commit is unknown. No callback dereference outside lifetime, no callback CUDA calls or launches, no GPU descriptor reads, no q/qd writes/projection or added forces. Original profile32position/1velocity/distributedforceTrue and every gate fixed. Private Kit settings only. Short known case, no new random/formal/fulltask/learnedSystem0 trial.')
    reg['private_asset_settings']=dict(reg['private_asset_settings'],private_directory=str(private))
    headers=Path('/home/liyufeng/miniforge3/envs/safeduo/lib/python3.11/site-packages/nvidia/cuda_cupti')
    extras=[H/'owned_kernel_argument_observer86.cpp',library,headers/'include/cupti.h',headers/'include/cupti_callbacks.h',headers/'include/generated_cuda_meta.h',headers/'lib/libcupti.so.12',Path('/usr/local/cuda-12.8/include/cuda.h')]
    for f in [*p.iterdir(),Path(__file__),launcher,wrapper,prepared,*extras]:
        if f.is_file():reg['source_sha256'][str(f)]=sha(f)
    (p/'REGISTRATION_V1.json').write_text(json.dumps(reg,indent=2)+'\n')
    plan=H/'OWNED_KERNEL_PARAMETERS86_PROSPECTIVE_PLAN_V1.json';assert not plan.exists()
    plan.write_text(json.dumps(dict(frozen_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),baseline=82,observation_replica=86,
                                   new_scientific_candidate=False,maximum_physics_events=64,maximum_native_wall_seconds=600,
                                   require_all77_native_arrays13_seed_fields164_physics_fields_byte_equal82=True,
                                   require_actual_driver_parameter_sizes_before_reading_values=True,
                                   require_all_named_kernel_entries_exits_correlated_and_successful_in_each_event=True,
                                   no_context_creation_no_kernel_launch_change_no_callback_CUDA_calls=True,
                                   public_source_argument_names_are_hypotheses_not_exact_source_identity=True,
                                   prior85_internal_signature_guess_rejected_before_physics=True,
                                   internal_argument_count_and_sizes_discovered_from_binary_without_source_guess=True,
                                   pointer_values_or_GPU_descriptors_not_recorded=True,
                                   original_q_AND_qd_tolerance=1e-4,all_original_physical_gates_unchanged=True,
                                   source_sha256={str(f):sha(f) for f in [Path(__file__),p/'REGISTRATION_V1.json',*extras]},
                                   fulltask_accepted=False,new_independent_random_cases=0,formal_holdout_count=0,fullSystem0_accepted=False),indent=2)+'\n')
    print('FROZEN86_OWNED_READONLY_KERNEL_SCALARS_BINARY_LAYOUT_AND_BYTEWISE82_PURITY_GATE',flush=True)

if __name__=='__main__':main()
