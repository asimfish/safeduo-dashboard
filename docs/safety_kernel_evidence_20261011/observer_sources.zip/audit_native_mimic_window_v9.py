"""Original 24 URDF q/qd oracle and equivalent native graph, without compliance inference."""
from pathlib import Path
import argparse,json,math
from audit_native_mimic_window_v8 import constraint_equivalence,sha
from audit_native_mimic_window_v5 import main as original_audit
H=Path(__file__).resolve().parent
read=lambda p:json.loads(Path(p).read_text())

def main(version):
    p=H/f'fourhand_native_probe_v{version}';target=p/'INDEPENDENT_NATIVE_MIMIC_WINDOW_V9.json'
    assert not target.exists() and not (p/'INDEPENDENT_NATIVE_MIMIC_WINDOW_V5.json').exists()
    reg=read(p/'REGISTRATION_V1.json')
    for f,d in reg['source_sha256'].items():assert sha(f)==d
    raw=Path(read(p/'RESOURCE_EXECUTION_V1.json')['out']);meta=read(reg['coupled_assets'])
    identity=read(raw/'native_mimic_identity.json');proof={};seen=set()
    for arm,asset in meta['assets'].items():
        rows={r['slave']:r for r in identity['relations'][arm]};assert len(rows)==6
        for r in asset['relations']:
            row=rows[r['slave']];actual_slave=r.get('physx_slave',r['slave']);prefix='/World/envs/env_0/'+arm+'/'
            assert row['prim'].startswith(prefix) and row['prim'].rsplit('/',1)[1]==actual_slave
            assert row['reference'].startswith(prefix) and row['reference'].rsplit('/',1)[1]==r['physx_master']
            assert abs(row['gearing']+r['physx_multiplier'])<=1e-6
            assert abs(row['offset_degrees']+math.degrees(r['physx_offset_rad']))<=1e-5
            key=(row['prim'],row['native_axis']);assert key not in seen;seen.add(key)
        proof[arm]=constraint_equivalence(asset,rows)
    assert len(seen)==24 and identity['actual_applied_mimic_API_count']==24
    original_audit(version);result=read(p/'INDEPENDENT_NATIVE_MIMIC_WINDOW_V5.json')
    result.update(status='CLOSED_ORIGINAL24_URDF_AND_EQUIVALENT_NATIVE_GRAPH_AUDIT',original_relation_oracle_unchanged=True,
                  native_constraint_rowspace_proofs=proof,no_missing_or_additional_native_mimic_APIs=True,
                  native_compliance_parameter_values_not_observed=True,authored_custom_compliance_attributes_not_a_native_hardness_proof=True,
                  scope='Native API inventory and gearing rowspace agree with original 6-coordinate model per hand within unchanged USD attribute encoding bounds. Original24 q AND qd1e-4 assessed separately at every recorded physics step. Do not infer installed solver compliance, convergence or safety from attribute names/counts alone.')
    result['source_SHA256'].update({str(Path(__file__)):sha(__file__),str(p/'INDEPENDENT_NATIVE_MIMIC_WINDOW_V5.json'):sha(p/'INDEPENDENT_NATIVE_MIMIC_WINDOW_V5.json')})
    target.write_text(json.dumps(result,indent=2)+'\n');print(result['status'],'model_pass',result['model_window_pass'],flush=True)

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('version',type=int);main(ap.parse_args().version)
