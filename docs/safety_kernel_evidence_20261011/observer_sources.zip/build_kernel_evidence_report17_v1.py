"""Deliver finite closed diagnostics, exact source custody and unchanged nine gates."""
from pathlib import Path
import copy,datetime,hashlib,html,json,shutil,sqlite3,subprocess,zipfile
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
H=Path(__file__).resolve().parent
P=H/'kernel_evidence_delivery_v1';W=Path('/home/liyufeng/safeduo-dashboard-kernel-evidence-20261011')
BASE='56c5d5845428eb05b5d6b8d2af313b540b4440d5';SLUG='docs/safety_kernel_evidence_20261011'
read=lambda p:json.loads(Path(p).read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
VERSIONS=[78,82,83,84]
LABELS={78:'逐位置步施加原外力，速度迭代0',82:'同外力方式，速度迭代1',83:'同外力方式，速度迭代2',84:'同82，将拇指末节设为共同参考'}

def main():
    assert not P.exists() and not (W/SLUG).exists()
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip()==BASE
    assert not subprocess.check_output(['git','status','--porcelain'],cwd=W)
    for v in [81,86]:assert read(H/f'fourhand_native_probe_v{v}/ACTUAL_COMPLETION_EXIT_V{v}.json')['actual_outer_exit']==0
    trace=read(H/'fourhand_native_probe_v81/OWNED_KERNEL_TRACE81_CLOSURE_V1.json');assert trace['trace_inference_authorized']
    args=read(H/'fourhand_native_probe_v86/OWNED_KERNEL_PARAMETERS86_CLOSURE_V1.json');assert args['trace_inference_authorized']
    P.mkdir();out=W/SLUG;out.mkdir();custody=[];rows=[]
    def deliver(source,relative):
        source=Path(source);destination=out/relative;destination.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,destination)
        custody.append(dict(source=str(source),public_path=destination.relative_to(W).as_posix(),bytes=source.stat().st_size,sha256=sha(source)))
    for version in VERSIONS+[81,86]:
        probe=H/f'fourhand_native_probe_v{version}';actual=read(probe/f'ACTUAL_COMPLETION_EXIT_V{version}.json');assert actual['actual_outer_exit']==0
        raw=Path(read(probe/'RESOURCE_EXECUTION_V1.json')['out']);capture=read(probe/'INDEPENDENT_CAPTURE_AUDIT_V1.json')
        model=read(probe/('INDEPENDENT_NATIVE_MIMIC_WINDOW_V9.json' if version==84 else 'INDEPENDENT_NATIVE_MIMIC_WINDOW_V6.json'))
        assert capture['record_integrity_verified'] and capture['all_owned_native_children_reaped']
        corefile=probe/f'CORE_ACTUAL_EXIT_RECEIPTS_V{version}.json'
        if version==84:corefile=probe/'CORE_ACTUAL_EXIT_RECEIPTS_V84_CORRECTED_V2.json'
        if version==78:
            for name in ['INDEPENDENT_CAPTURE_AUDIT_V1','INDEPENDENT_NATIVE_MIMIC_WINDOW_V6','INDEPENDENT_FULL_MOTOR_EFFORT_V4','INDEPENDENT_SHORT_CONTACT_TARGET_TAPE_V1']:
                assert read(probe/(name+'_ACTUAL_EXIT.json'))['actual_outer_exit']==0
        else:assert all(x['actual_exit']==0 and x['tool_chunk_id']!='PLACEHOLDER_PENDING' for x in read(corefile)['actual_outer_exits'].values())
        for f in sorted(raw.rglob('*')):
            if f.is_file():deliver(f,f'native_v{version}/raw/'+f.relative_to(raw).as_posix())
        for f in sorted(probe.iterdir()):
            if f.suffix in ['.json','.jsonl'] and 'KIT_USER_CONFIG' not in f.name and 'SHARED_CONFIG' not in f.name:
                deliver(f,f'native_v{version}/audit/'+f.name)
        archive=out/f'native_v{version}/source_archive.zip';members=[]
        with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED) as z:
            for f in sorted(probe.iterdir()):
                if f.suffix in ['.py','.usda']:
                    z.writestr(f.name,f.read_bytes());members.append(dict(name=f.name,bytes=f.stat().st_size,sha256=sha(f)))
        (archive.parent/'SOURCE_ARCHIVE_CUSTODY_V1.json').write_text(json.dumps(dict(archive_sha256=sha(archive),members=members,source_bytes_unchanged=True),indent=2)+'\n')
        forces=[]
        for piece in read(raw/'physics_chunks.json'):
            f=raw/piece['path'];assert sha(f)==piece['sha256']
            with np.load(f,allow_pickle=False) as z:forces.append(z['four_hand_normal_N'].copy())
        force=np.concatenate(forces);assert len(force)==capture['physics_events']==16 and not (force>.1).any()
        if version in VERSIONS:rows.append(dict(version=version,label=LABELS[version],physics_events=16,actual_outer_exit=0,
            original_q_error_rad=model['maximum_q_residual_rad'],original_qd_error_rad_s=model['maximum_qd_residual_rad_s'],
            original_model_pass=model['model_window_pass'],original_physical_pass=capture['physical_gates_pass'],
            peak_F_L_normal_N=float(force[:,0].max()),four_hand_grasp_window_s=capture['measured_stage_windows_s']['four_hand_close'],
            fulltask_pass=False,learned_System0_on=False))
    assert len(rows)==4 and all(not r['original_model_pass'] and not r['fulltask_pass'] and r['four_hand_grasp_window_s']==0 for r in rows)
    extras=['TGS_DISTRIBUTED_FORCE78_79_PROSPECTIVE_PLAN_V1.json','DISTRIBUTED_FORCE_VELOCITY82_83_PROSPECTIVE_PLAN_V1.json',
            'PRIVATE_SETTINGS_BINDING82_83_PRELAUNCH_SUPPLEMENT_V1.json','DISTAL_THUMB_REFERENCE84_PROSPECTIVE_PLAN_V1.json',
            'OWNED_KERNEL_TRACE80_PROSPECTIVE_PLAN_V1.json','PRIVATE_ASSET_KERNEL_TRACE81_PROSPECTIVE_PLAN_V1.json',
            'OWNED_KERNEL_PARAMETERS85_PROSPECTIVE_PLAN_V1.json','OWNED_KERNEL_PARAMETERS86_PROSPECTIVE_PLAN_V1.json',
            'fourhand_native_probe_v80/ACTUAL_INCOMPLETE_SETUP_EXIT_V80.json','fourhand_native_probe_v85/ACTUAL_INCOMPLETE_SETUP_EXIT_V85.json',
            'OWNED_ARGUMENT_OBSERVER85_COMPILE_FAILURE_V1.json','fourhand_native_probe_v85/OWNED_KERNEL_ARGUMENTS_V1.jsonl',
            'coupled_hand_assets_v5/COUPLED_ASSETS_V1.json','coupled_hand_assets_v5/f_l_distal_thumb_reference_v1.usda']
    for name in extras:deliver(H/name,'evidence/'+name.replace('/','__'))
    own_code=[H/f for f in ['prepare_distributed_force_velocity_pair82_83_v1.py','prepare_distal_thumb_reference_v84.py',
              'audit_distributed_force_velocity82_83_v1.py','audit_native_mimic_window_v9.py','audit_owned_kernel_trace81_v1.py',
              'prepare_owned_kernel_parameters_v85.py','prepare_owned_kernel_parameters_v86.py','owned_kernel_argument_observer85.cpp',
              'owned_kernel_argument_observer86.cpp','OWNED_ARGUMENT_OBSERVER85_COMPILE_FAILURE_SOURCE_V1.cpp','audit_owned_kernel_parameters86_v1.py',Path(__file__).name]]
    archive=out/'observer_sources.zip';members=[]
    with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED) as z:
        for f in own_code:z.writestr(f.name,f.read_bytes());members.append(dict(name=f.name,bytes=f.stat().st_size,sha256=sha(f)))
    (out/'OBSERVER_SOURCE_ARCHIVE_CUSTODY_V1.json').write_text(json.dumps(dict(archive_sha256=sha(archive),members=members),indent=2)+'\n')
    summary=dict(status='CLOSED_DIAGNOSTIC_FRONTIER_ORIGINAL_MODEL_AND_FULL_ACCEPTANCE_FAILED',created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                 rows=rows,new_candidate_records=4,new_candidate_physics_events=64,observer_replicas=[81,86],observer_physics_events=32,
                 cumulative_two_report_candidate_records=18,cumulative_two_report_candidate_physics_events=368,unique_known_initial_cases=1,
                 new_independent_native_random_cases=0,formal_holdout_count=0,learned_System0_tested=False,fullSystem0_accepted=False,
                 all9_jointly_accepted=False,canonical_profile_qualified=False,original_q_AND_qd_tolerance=1e-4,
                 physics_profile='Experimental2FR3/F2+2UR5/DFX; not canonical2FR3+2JAKA+4F2',
                 binary_source_commit_unknown=True,excluded=[dict(version=79,launched=False,reason='Frozen continuation gate false'),dict(version=80,physics_events=0,actual_outer_exit=1),dict(version=85,physics_events=0,actual_outer_exit=1)])
    (out/'SUMMARY_V1.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False)+'\n')
    matrix=copy.deepcopy(read(H/'full_requirements_v1/EVIDENCE_MATRIX_V26.json'))
    for row in matrix['rows']:
        row['joint_requirement_accepted']=False
        if row['id'] in ['grasp','cooperative_task','native_oracle','visual_delivery']:row['measured']=dict(prior_revision26=row['measured'],revision27=summary)
    matrix.update(revision=27,updated_utc=summary['created_utc'],every_required_row_jointly_accepted=False,fullSystem0_accepted=False,formal_holdout_acceptance_count=0,latest_development_frontier=summary,active_native_excluded=[])
    (out/'EVIDENCE_MATRIX_V27.json').write_text(json.dumps(matrix,indent=2,ensure_ascii=False)+'\n')
    local=H/'full_requirements_v1/EVIDENCE_MATRIX_V27.json';assert not local.exists();shutil.copyfile(out/'EVIDENCE_MATRIX_V27.json',local)
    render(out,rows,trace,args,matrix)
    root=W/'index.html';prior=root.read_text();needle='<div class="sci-note" id="thumbContactEvidence">';assert prior.count(needle)==1
    card='<div class="sci-note" id="kernelEvidence"><b>10-11 最新实际求解内核与对照：仍未达标</b><p>新增4条同初态短例、64个物理子步，原速度约束全部失败；两次观测复现逐字节保持原轨迹。内核顺序与实传参数证据、失败与九项缺口均保留。正式学习System 0验收0。</p><a href="docs/safety_kernel_evidence_20261011/">查看最新结果、实际内核证据与原始数据 →</a></div>\n'
    root.write_text(prior.replace(needle,card+needle));assert root.read_text().replace(card,'',1)==prior
    (out/'SOURCE_CUSTODY_V1.json').write_text(json.dumps(dict(source_entries=custody,source_bytes_unchanged=True,private_user_settings_not_published=True,fullSystem0_accepted=False),indent=2)+'\n')
    files=[dict(path=f.relative_to(W).as_posix(),bytes=f.stat().st_size,sha256=sha(f)) for f in sorted(out.rglob('*')) if f.is_file()]
    manifest=dict(base_commit=BASE,slug=SLUG,old_tracked_paths=13670,public_files=files,all9_jointly_accepted=False,formal_holdout_count=0,fullSystem0_accepted=False)
    (out/'PUBLIC_MANIFEST_V1.json').write_text(json.dumps(manifest,indent=2)+'\n');(P/'BUILD_MANIFEST_V1.json').write_text(json.dumps(manifest,indent=2)+'\n')
    print('BUILT17_FOUR_REJECTED_CASES64_EVENTS_TWO_OBSERVERS32_EVENTS',len(files)+1,flush=True)

def render(out,rows,trace,args,matrix):
    fig,axes=plt.subplots(1,2,figsize=(13,4.8),layout='constrained');x=np.arange(len(rows));labels=[str(r['version']) for r in rows]
    axes[0].bar(x,[r['original_qd_error_rad_s'] for r in rows],color='#b91c1c');axes[0].set_yscale('log')
    axes[0].axhline(1e-4,color='#172033',ls='--',label='Original qd gate: 1e-4 rad/s');axes[0].legend();axes[0].set_ylabel('Maximum qd residual (rad/s)');axes[0].set_title('All four candidates fail original qd gate')
    axes[1].bar(x,[r['peak_F_L_normal_N'] for r in rows],color='#2563eb');axes[1].axhline(.1,color='#172033',ls='--',label='Original per-hand contact minimum: 0.1 N');axes[1].legend();axes[1].set_ylabel('Peak F_L normal (N)');axes[1].set_title('Weak left-thumb contact; no qualified grasp')
    for ax in axes:ax.set_xticks(x,labels);ax.grid(axis='y',alpha=.2);ax.set_xlabel('Candidate version; one known initial case')
    fig.savefig(out/'candidate_comparison.png',dpi=150);fig.savefig(out/'candidate_comparison.svg');plt.close(fig)
    database=H/'fourhand_native_probe_v81/owned_native81_kernel_trace.sqlite';c=sqlite3.connect('file:'+str(database)+'?mode=ro',uri=True)
    start,end=c.execute("SELECT start,end FROM NVTX_EVENTS WHERE text='physics_event_0'").fetchone()
    records=list(c.execute('SELECT k.start,k.end,s.value FROM CUPTI_ACTIVITY_KIND_KERNEL k JOIN StringIds s ON s.id=k.shortName WHERE k.start>=? AND k.end<=? ORDER BY k.start',(start,end)));c.close()
    last=max(i for i,r in enumerate(records) if r[2]=='artiSolveInternalTendonAndMimicJointConstraints1T')
    tail=records[last:last+16];origin=tail[0][0];fig,ax=plt.subplots(figsize=(13,7),layout='constrained')
    for i,(a,b,name) in enumerate(tail):ax.barh(i,(b-a)/1000,left=(a-origin)/1000,color='#b45309' if 'Mimic' in name else '#2563eb')
    ax.set_yticks(range(len(tail)),[r[2] for r in tail],fontsize=9);ax.invert_yaxis();ax.set_xlabel('GPU microseconds since last named mimic kernel start');ax.set_title('Observed event0 kernel order; this does not prove failure cause');ax.grid(axis='x',alpha=.2)
    fig.savefig(out/'observed_kernel_order.png',dpi=150);fig.savefig(out/'observed_kernel_order.svg');plt.close(fig)
    for f in out.glob('*.svg'):f.write_text('\n'.join(s.rstrip() for s in f.read_text().splitlines())+'\n')
    rowhtml=''.join('<tr>'+''.join('<td>'+html.escape(str(v))+'</td>' for v in [r['version'],r['label'],r['physics_events'],f"{r['original_q_error_rad']:.9g}",f"{r['original_qd_error_rad_s']:.9g}",'未通过',f"{r['peak_F_L_normal_N']:.6f}",'未完成'])+'</tr>' for r in rows)
    matrixhtml=''.join(f"<tr><td>{html.escape(r['requirement'])}</td><td>{html.escape(r['gate'])}</td><td>联合未验收</td></tr>" for r in matrix['rows'])
    physical_arg=args['clock_hypothesis']['observed_mimic_arg2_float32'];layouts=args['actual_binary_parameter_layouts']
    downloads=''.join(f'<li><a href="native_v{v}/audit/REGISTRATION_V1.json">{v}预注册</a> · <a href="native_v{v}/raw/physics_chunks.json">全部原生物理数据索引</a> · <a href="native_v{v}/audit/INDEPENDENT_CAPTURE_AUDIT_V1.json">物理独立审计</a> · <a href="native_v{v}/source_archive.zip">冻结代码</a></li>' for v in VERSIONS+[81,86])
    page=f'''<!doctype html>
<html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>SafeDuo · 实际求解内核与最新对照</title>
<style>body{{font-family:system-ui,sans-serif;color:#172033;background:#f5f7fa;max-width:1200px;margin:auto;padding:24px;line-height:1.65}}a{{color:#1d4ed8}}h1{{font-size:clamp(22px,3vw,34px)}}section,.notice{{background:white;border:1px solid #d6dce7;border-radius:12px;padding:20px;margin:20px 0}}.notice{{border-left:6px solid #b91c1c}}.scroll{{overflow:auto}}table{{border-collapse:collapse;width:100%;font-size:14px}}td,th{{padding:9px;text-align:left;border-bottom:1px solid #d6dce7;vertical-align:top}}th{{background:#eef2f7}}img{{width:100%;height:auto}}pre{{white-space:pre-wrap;overflow-wrap:anywhere;background:#eef2f7;padding:12px}}@media(max-width:600px){{body{{padding:12px}}section,.notice{{padding:15px}}}}</style>
<p><a href="../../#scientific">← 主面板</a> · <a href="../safety_thumb_contact_20261011/">先前14条短例和静态四视图</a> · <a href="../safety_loaded_rate_20261011/">完整四路原生视频</a></p>
<h1>实际求解内核、速度迭代与拇指约束对照</h1>
<div class="notice"><b>九项要求尚未全部达标。真实四手夹持、完整任务和正式学习System 0验收均未完成。</b><p>新增4条候选短例、合计64个物理子步，全部未通过原始速度耦合约束；另有2次各16步的观测复现。候选和复现均来自同一个已知初态，没有新增独立随机案例，也没有正式留出实验。</p><p>本页与先前短例页合计18条候选记录、368个物理子步。数字是诊断记录数，不能当作独立实验样本量或操作空间覆盖证据。学习策略与System 0均关闭。</p></div>
<section><h2>最新对照结果</h2><p>原始24条传动关系每物理步均要求位置与速度残差≤0.0001。4条新候选的位置残差通过，速度残差仍失败。原物理上限审计通过，但这里仅有左拇指弱接触，各手&gt;0.1 N连续0.25 s的原夹持窗口为0，完整任务未通过。</p><img src="candidate_comparison.png" alt="4条最新候选的速度残差和左手弱接触，原验收线保持不变"><p><a href="candidate_comparison.svg">矢量图</a> · <a href="SUMMARY_V1.json">机器可读完整结果</a></p><div class="scroll"><table id="results"><thead><tr><th>版本</th><th>变化</th><th>物理步</th><th>位置残差rad</th><th>速度残差rad/s</th><th>原模型</th><th>左手峰值N</th><th>完整任务</th></tr></thead><tbody>{rowhtml}</tbody></table></div><p>84将两条拇指约束改为末端关节参考，启动前和原生观测均验证每手仍为6个独立坐标、共24条关系，没有增加锁死自由度的重复约束。其速度残差反而增大，已拒绝采用。</p></section>
<section><h2>观测如何保持原轨迹</h2><p>81仅记录CUDA/NVTX，77项原生参数、13项初态和164项物理记录与77逐字节一致；86仅观察本进程的两类内核标量，以上字段与82逐字节一致。两次复现都经过独立目标、力矩、物理和原模型审计，原模型仍失败。</p><p>81每物理步实际观察到32次mimic名称内核调用。86每步各观察到33次mimic和内部约束名称内核调用；每条CPU调用均有成功返回码。没有记录GPU指针值或读取GPU描述符，没有改变内核参数或发起额外内核。内核名称、数量、先后顺序并不证明每一条约束的执行质量或失败原因。</p><img src="observed_kernel_order.png" alt="原生事件0结束阶段的GPU内核顺序，mimic之后仍有其他内核"><p><a href="observed_kernel_order.svg">矢量时序图</a> · <a href="native_v81/audit/OWNED_KERNEL_TRACE81_CLOSURE_V1.json">逐调用关联与字节一致性</a> · <a href="native_v86/audit/OWNED_KERNEL_PARAMETERS86_CLOSURE_V1.json">参数记录和字节一致性</a> · <a href="native_v86/audit/OWNED_KERNEL_ARGUMENTS_V1.jsonl">全部标量原始记录</a></p></section>
<section><h2>实际参数布局与新的时钟核查</h2><p>驱动直接返回的mimic参数大小为{html.escape(str(layouts[0]['sizes']))}；内部约束参数大小为{html.escape(str(layouts[1]['sizes']))}。后者有15个参数，参考源码有12个，因此安装版的精确源码提交仍未知，不能直接套用其完整ABI或因果解释。</p><p>与参考mimic签名相容的第2号标量为{physical_arg:.12g}，32倍约为1/960；原注册物理步长为0.001041625。安装SDK设置时间步的源码会将1/dt截断为整数步频。这提示原登记时轴可能与物理时轴存在量化差异，直接运行时getter与USD步频联合校验尚待完成；此前同步声明需要补充这一验收。原始时间戳、视频和失败记录保持原字节。</p><p>原始标量字节是观测事实；将字段解释为时间步或迭代标志仍依据相容的参考签名，需要进一步核对。完整夹持、视觉感知、正式机器人配置、充分随机覆盖和真正学习System 0同输入安全对照仍未验收。</p></section>
<section><h2>失败、未启动记录与完整下载</h2><p>79未满足预注册的继续条件，始终未启动。80因共享资源路径缺失而初始化失败，物理步0；随后使用本任务局部Kit配置，保留共享配置。85在发现假定参数布局不符后被启动前校验拒绝，物理步0，未读取临界窗口参数。86改为查询真实布局后完成。编译器首次拒绝重复头文件及缩进问题，其源文件和退出码也保留，未产生模拟试验。</p><ul>{downloads}</ul><p><a href="observer_sources.zip">观测和独立审计源码</a> · <a href="SOURCE_CUSTODY_V1.json">原始字节来源</a> · <a href="PUBLIC_MANIFEST_V1.json">全量文件与哈希</a> · <a href="evidence/fourhand_native_probe_v80__ACTUAL_INCOMPLETE_SETUP_EXIT_V80.json">80失败</a> · <a href="evidence/fourhand_native_probe_v85__ACTUAL_INCOMPLETE_SETUP_EXIT_V85.json">85失败</a></p></section>
<section><h2>九项原要求联合验收</h2><div class="scroll"><table id="matrix"><thead><tr><th>要求</th><th>原门槛</th><th>状态</th></tr></thead><tbody>{matrixhtml}</tbody></table></div><p><a href="EVIDENCE_MATRIX_V27.json">证据矩阵27</a>：9项原要求及门槛逐项保持原值，联合验收为false，正式留出数量为0。</p></section>
</html>'''
    (out/'index.html').write_text(page)

if __name__=='__main__':main()
