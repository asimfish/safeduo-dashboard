"""Close only the owned trace: bytewise state parity and CPU-to-CUDA launch custody."""
from pathlib import Path
import datetime,hashlib,json,sqlite3
import numpy as np
H=Path(__file__).resolve().parent
read=lambda p:json.loads(Path(p).read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()

def compare(a,b,expected):
    differences=[]
    with np.load(a,allow_pickle=False) as x,np.load(b,allow_pickle=False) as y:
        assert set(x.files)==set(y.files) and len(x.files)==expected
        for key in sorted(x.files):
            u,v=x[key],y[key]
            if u.dtype!=v.dtype or u.shape!=v.shape or u.tobytes(order='C')!=v.tobytes(order='C'):
                differences.append(key)
    return dict(field_count=expected,all_fields_byte_identical=not differences,differing_fields=differences)

def main():
    p=H/'fourhand_native_probe_v81';target=p/'OWNED_KERNEL_TRACE81_CLOSURE_V1.json';assert not target.exists()
    assert read(p/'ACTUAL_COMPLETION_EXIT_V81.json')['actual_outer_exit']==0
    assert all(x['actual_exit']==0 for x in read(p/'CORE_ACTUAL_EXIT_RECEIPTS_V81.json')['actual_outer_exits'].values())
    assert read(p/'NSYS_EXPORT_ACTUAL_EXIT_V1.json')['actual_outer_exit']==0
    original=read(H/'PRIVATE_ASSET_KERNEL_TRACE81_PROSPECTIVE_PLAN_V1.json')
    for f,d in original['source_sha256'].items():assert sha(f)==d
    raw=[];chunks=[]
    for version in [77,81]:
        state=read(H/f'fourhand_native_probe_v{version}/RESOURCE_EXECUTION_V1.json')
        assert state['actual_exit']==state['actual_native_exit']==0
        root=Path(state['out']);raw.append(root);index=read(root/'physics_chunks.json');assert len(index)==1
        file=root/index[0]['path'];assert sha(file)==index[0]['sha256'];chunks.append(file)
    parity=dict(native_parameters=compare(raw[0]/'native_parameters.npz',raw[1]/'native_parameters.npz',77),
                initial_seed=compare(raw[0]/'actual_initial_seed_binding.npz',raw[1]/'actual_initial_seed_binding.npz',13),
                recorded_physics=compare(chunks[0],chunks[1],164))
    pure=all(x['all_fields_byte_identical'] for x in parity.values())
    protocol=read(raw[1]/'fourhand_protocol.json');n=protocol['physics_events'];assert protocol['status']=='complete' and n==16
    execution=read(H/'fourhand_native_probe_v81_execution.json');job=execution['jobs'][0]
    assert job['native_owned_process_reaped_and_absent'] and job['actual_native_exit']==0
    pid=job['actual_native_pid'];report=p/'owned_native81_kernel_trace.nsys-rep';database=p/'owned_native81_kernel_trace.sqlite'
    assert report.stat().st_size>0 and database.stat().st_size>0
    c=sqlite3.connect('file:'+str(database)+'?mode=ro',uri=True);c.row_factory=sqlite3.Row
    ranges=[dict(r) for r in c.execute("SELECT start,end,globalTid,text FROM NVTX_EVENTS WHERE text LIKE 'physics_event_%' ORDER BY start")]
    assert len(ranges)==n and [r['text'] for r in ranges]==['physics_event_'+str(i) for i in range(n)]
    assert all(r['start']<r['end'] and (r['globalTid']>>24)&0xffffff==pid for r in ranges)
    names=['artiSolveInternalConstraintsTGS1T','artiSolveInternalTendonAndMimicJointConstraints1T']
    events=[dict(event=i,CPU_range_start_ns=r['start'],CPU_range_end_ns=r['end'],observed_kernels={}) for i,r in enumerate(ranges)]
    all_observations=[]
    for name in names:
        kernels=[dict(r) for r in c.execute('SELECT k.*,s.value AS kernel_name FROM CUPTI_ACTIVITY_KIND_KERNEL k JOIN StringIds s ON s.id=k.shortName WHERE s.value=? ORDER BY k.start',(name,))]
        assert kernels and len({k['globalPid'] for k in kernels})==1
        counts=[0]*n
        for k in kernels:
            assert (k['globalPid']>>24)&0xffffff==pid
            launches=[dict(r) for r in c.execute('SELECT r.*,s.value AS API_name FROM CUPTI_ACTIVITY_KIND_RUNTIME r JOIN StringIds s ON s.id=r.nameId WHERE r.correlationId=? AND (r.globalTid>>24)=(?>>24)',(k['correlationId'],k['globalPid']))]
            assert len(launches)==1
            launch=launches[0];assert launch['returnValue']==0 and launch['API_name']=='cuLaunchKernel'
            owners=[i for i,r in enumerate(ranges) if r['start']<=launch['start']<=launch['end']<=r['end']]
            assert len(owners)==1;i=owners[0]
            assert ranges[i]['start']<=k['start']<=k['end']<=ranges[i]['end']
            assert k['graphNodeId'] is None and k['graphId'] is None
            counts[i]+=1
            all_observations.append(dict(event=i,kernel=name,correlationId=k['correlationId'],globalPid=k['globalPid'],
                                         CPU_API=launch['API_name'],CPU_globalTid=launch['globalTid'],CPU_start_ns=launch['start'],CPU_end_ns=launch['end'],
                                         GPU_start_ns=k['start'],GPU_end_ns=k['end'],deviceId=k['deviceId'],contextId=k['contextId']))
        assert sum(counts)==len(kernels)
        for event,count in zip(events,counts):event['observed_kernels'][name]=count
    c.close()
    full=read(p/'INDEPENDENT_NATIVE_MIMIC_WINDOW_V6.json')
    refs=[Path(__file__),H/'PRIVATE_ASSET_KERNEL_TRACE81_PROSPECTIVE_PLAN_V1.json',p/'CORE_ACTUAL_EXIT_RECEIPTS_V81.json',
          p/'ACTUAL_COMPLETION_EXIT_V81.json',p/'NSYS_EXPORT_ACTUAL_EXIT_V1.json',p/'INDEPENDENT_NATIVE_MIMIC_WINDOW_V6.json',report,database,*chunks]
    result=dict(status='PASS_BOUNDED_OWNED_TRACE_CUSTODY_AND_BITEXACT77_PARITY' if pure else 'REJECT_TRACE_INFERENCE_OBSERVER_STATE_PARITY_FAILED',
                utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),observation_replica=81,original=77,physics_events=n,
                original_native_PID=pid,parity=parity,trace_inference_authorized=pure,per_physics_event=events,
                all_launches=all_observations,original_model_pass=full['model_window_pass'],
                original_q_error_rad=full['maximum_q_residual_rad'],original_qd_error_rad_s=full['maximum_qd_residual_rad_s'],
                scope='Kernel names and counts with direct same-owned-process CPU CUDA API correlation inside each physics NVTX range. CUDA graph nodes were absent for these named kernels. No kernel argument values, no installed binary source commit proof, no new independent physical case, no attribution of per-row enforcement quality or proof of failure cause.',
                baseline_ground_USD_exact_source_byte_identity_not_proven=True,private_Kit_config_only=True,
                scientific_candidate_adopted=False,fulltask_qualified=False,new_independent_random_cases=0,formal_holdout_count=0,
                all9_jointly_accepted=False,fullSystem0_accepted=False,source_sha256={str(f):sha(f) for f in refs})
    target.write_text(json.dumps(result,indent=2)+'\n')
    print(result['status'],'physics',n,'per_event_counts',[x['observed_kernels'] for x in events],flush=True)

if __name__=='__main__':main()
