"""Complete the already built report using an attribute-order-independent card."""
from pathlib import Path
import csv,hashlib,json,re,zipfile
P=Path(__file__).resolve().parent
W=Path('/mnt/nas/data/lyf/double_hand/safeduo_dashboard_loaded_duration_20261012')
R=W/'docs/safety_motion_random_20261012'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_text())
def save(p,x):Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')

def main():
    assert read(P/'BUILD_ACTUAL_FAILURE_V1.json')['actual_exit']==1
    assert not (P/'BUILD_MANIFEST_V2.json').exists() and not (R/'PUBLIC_MANIFEST_V2.json').exists()
    root=W/'index.html';before=root.read_text();assert 'motionRandomEvidence' not in before
    matches=list(re.finditer(r'<div\b[^>]*\bid="actualGuardEvidence"[^>]*>',before))
    assert len(matches)==1
    (P/'root_index_before_v1.html').write_text(before)
    card='<div id="motionRandomEvidence" class="sci-note" style="margin-bottom:18px;border-left:4px solid #2459af"><strong>四臂动作与随机运动 · 最新原生评测</strong><p>四臂退离1条通过；随机原始指令与确定性防护均未通过。本页保留实际动作、超速与间隙失败；全面安全验收未完成。</p><a href="docs/safety_motion_random_20261012/">查看动作、随机范围与原生视频 →</a></div>\n  '
    i=matches[0].start();after=before[:i]+card+before[i:]
    assert after.replace(card,'',1)==before
    root.write_text(after)
    old=read(R/'METHOD_SOURCE_MANIFEST_V1.json');items=old['source_files'][:]
    for file in [Path(__file__),P/'BUILD_ACTUAL_FAILURE_V1.json']:
        items.append(dict(path=str(file),archive_path='report_delivery/'+file.name,sha256=sha(file),bytes=file.stat().st_size))
    with zipfile.ZipFile(R/'evidence/owned_method_source_v2.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for item in items:z.write(item['path'],item['archive_path'])
    save(R/'METHOD_SOURCE_MANIFEST_V2.json',dict(old,source_files=items,root_link_completion_source_included=True))
    page=R/'index.html';text=page.read_text().replace('METHOD_SOURCE_MANIFEST_V1.json','METHOD_SOURCE_MANIFEST_V2.json').replace('evidence/owned_method_source_v1.zip','evidence/owned_method_source_v2.zip')
    page.write_text(text)
    files=[dict(path=str(f.relative_to(W)),sha256=sha(f),bytes=f.stat().st_size) for f in sorted([*R.rglob('*'),root]) if f.is_file()]
    save(R/'PUBLIC_MANIFEST_V2.json',dict(files=[f for f in files if f['path']!='index.html'],all9_jointly_accepted=False))
    file=R/'PUBLIC_MANIFEST_V2.json';files.append(dict(path=str(file.relative_to(W)),sha256=sha(file),bytes=file.stat().st_size))
    with (R/'PER_STEP_MOTION_METRICS_V1.csv').open() as f:rows=sum(1 for _ in csv.reader(f))-1
    save(P/'BUILD_MANIFEST_V2.json',dict(base_commit='74d8327ddbb53451a1d7b88a31f37952c57ca4fe',slug=R.name,files=files,total_bytes=sum(f['bytes'] for f in files),versions=[106,107,108],csv_rows=rows,all9_jointly_accepted=False))
    print('BUILT_COMPLETE_MOTION_RANDOM_REPORT_V2',len(files),'files',rows,'native rows;12videos;rootonlynewcard',flush=True)

if __name__=='__main__':main()
