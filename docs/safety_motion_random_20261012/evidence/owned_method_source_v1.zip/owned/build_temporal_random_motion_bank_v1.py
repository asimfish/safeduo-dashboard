"""Reuse unconditioned full50 IID proposals as temporal command packets.

This is prospective experiment input, never native trajectory evidence.
"""
from pathlib import Path
import datetime, hashlib, json, xml.etree.ElementTree as ET
import numpy as np

H=Path(__file__).resolve().parent
M=H/'motion_safety_benchmark_v1'
ARMS=('F_L','F_R','U_L','U_R')
read=lambda p:json.loads(Path(p).read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()

def main():
    output=M/'TEMPORAL_RANDOM_MOTION_BANK_V1.npz'
    assert M.exists() and not output.exists()
    plan=M/'TEMPORAL_RANDOM_PROSPECTIVE_PLAN_V1.json'
    assert not plan.exists()
    source=H/'full_motor_operating_domain_v2/DEVELOPMENT_FULL50_PROPOSALS_V2.npz'
    domain=read(source.parent/'FULL_MOTOR_DOMAIN_V2.json')
    assert sha(source)==domain['proposal_SHA256']
    reg=read(H/'fourhand_native_probe_v105/REGISTRATION_V1.json')
    raw=Path(read(H/'fourhand_native_probe_v105/RESOURCE_EXECUTION_V1.json')['out'])
    meta=read(reg['coupled_assets'])
    prospective=dict(status='FROZEN_BEFORE_TEMPORAL_BANK_ASSEMBLY',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        episodes=128,initial_proposal_ids=list(range(128)),command_proposal_ids=[128,2176],
        command_blocks_each=16,controls_per_block=32,control_Hz=60,physics_Hz=960,
        maximum_physics_events_each=8192,original_FIFO_controls=6,
        source_bank_is_public_development_IID=True,no_geometric_or_outcome_selection=True,
        commanded_coordinates=50,arm_coordinates=26,hand_motor_coordinates=24,
        command_channels=['absolute_position_target','signed_velocity_request'],
        execution_must_declare_consumed_channel_and_keep_both_raw_and_submitted_commands=True,
        paired_methods=['Raw','deterministic_safety_baseline','actual_learned_System0_when_qualified'],
        same_initial_state_scene_commands_fault_timing_and_duration_between_methods=True,
        native_initial_geometry_admission_must_log_every_input_and_every_rejection=True,
        denominator_fields=['generated','initially_rejected','native_started','early_failure','complete','physical_pass','model_pass','motion_pass','task_pass'],
        do_not_accept_all_hold=dict(per_arm_maximum_actual_departure_rad=.1,per_mount_actual_path_m=.02),
        safety_fields=['all74_actual_hard_and_velocity','original24_q_AND_qd','all9021_proxy_gaps','all82_native_point_contacts','payload_force','object_motion','actual_stopping_distance_and_latency'],
        coverage_fields=['per_joint_normalized_span_and_bins','all1225_pairwise_4x4_cells','all4_mount_xyz_voxels_orientation_and_path','actual_speed_strata','actual_vs_requested_coverage','rejection_ratio'],
        required_additional_suites=['human_teleoperation_packet_replay','four_arm_opposed_and_crossing_motion','shared_payload_lift_carry_place_release','FIFO6_plus_packet_delay_and_drop_faults','object_pose_size_mass_friction_uncertainty'],
        native_admission_requires='106 original model AND physical AND actual four-arm motion pass; then full50 moving controller qualification and frozen canonical profile before formal acceptance',
        immutable_failure_records_required=True,formal_holdout_count=0,new_independent_random_draws=0,
        native_executed=0,fullSystem0_accepted=False,
        source_sha256={str(f):sha(f) for f in [Path(__file__),source,source.parent/'FULL_MOTOR_DOMAIN_V2.json',raw/'native_parameters.npz',Path(reg['coupled_assets'])]})
    plan.write_text(json.dumps(prospective,indent=2)+'\n')
    with np.load(source) as z:
        data={k:z[k].copy() for k in z.files}
    with np.load(raw/'native_parameters.npz') as z:
        params={k:z[k].copy() for k in z.files}
    state_ids=np.arange(128);command_ids=np.arange(128,2176).reshape(128,16)
    assert (data['proposal_stratum'][np.concatenate([state_ids,command_ids.ravel()])]=='pure_iid_position_velocity_target').all()
    bank=dict(initial_proposal_id=state_ids,command_proposal_id=command_ids,
        independent_initial_q=data['independent_q'][state_ids],independent_initial_qd=data['independent_qd'][state_ids],
        independent_requested_target=data['independent_target'][command_ids],
        independent_requested_velocity=data['independent_qd'][command_ids],
        independent_names=data['independent_names'],independent_lower_rad=data['independent_lower_rad'],
        independent_upper_rad=data['independent_upper_rad'],independent_speed_cap_rad_s=data['independent_speed_cap_rad_s'])
    relation_max=0.;velocity_max=0.;rows=[]
    for arm in ARMS:
        names=params[arm+'_joint_names'].tolist();limits=params[arm+'_hard_limits'][0];speed=params[arm+'_max_velocity'][0]
        q=data[arm+'_q'][state_ids];v=data[arm+'_qd'][state_ids];targets=data[arm+'_target'][command_ids];vel=data[arm+'_qd'][command_ids]
        assert q.shape==(128,len(names)) and targets.shape==(128,16,len(names))
        for values in [q,targets]:
            assert (values>=limits[:,0]-1e-12).all() and (values<=limits[:,1]+1e-12).all()
        for values in [v,vel]:assert (abs(values)<=speed+1e-12).all()
        for joint in ET.parse(meta['assets'][arm]['original_URDF']).findall('joint'):
            mimic=joint.find('mimic')
            if mimic is None or joint.get('name') not in names:continue
            si=names.index(joint.get('name'));mi=names.index(mimic.get('joint'))
            m=float(mimic.get('multiplier','1'));b=float(mimic.get('offset','0'))
            for values in [q,targets]:relation_max=max(relation_max,float(abs(values[...,si]-m*values[...,mi]-b).max()))
            for values in [v,vel]:velocity_max=max(velocity_max,float(abs(values[...,si]-m*values[...,mi]).max()))
        for suffix,value in [('_initial_q',q),('_initial_qd',v),('_requested_position_target',targets),('_requested_velocity',vel)]:bank[arm+suffix]=value
        rows.append(dict(arm=arm,coordinates=len(names),joint_names=names,original_URDF_sha256=sha(meta['assets'][arm]['original_URDF'])))
    assert relation_max<=1e-12 and velocity_max<=1e-12
    np.savez_compressed(output,**bank)
    lo,hi=bank['independent_lower_rad'],bank['independent_upper_rad']
    target=bank['independent_requested_target'].reshape(-1,50)
    units=(target-lo)/(hi-lo);bins=np.minimum(9,np.floor(units*10)).astype(int)
    occupied=[len(np.unique(bins[:,i])) for i in range(50)]
    cell=np.minimum(3,np.floor(units*4)).astype(int)
    counts=np.stack([np.bincount(4*cell[:,i]+cell[:,j],minlength=16) for i in range(50) for j in range(i+1,50)])
    assert counts.shape==(1225,16) and min(occupied)==10 and (counts>0).all()
    report=dict(status='PASS_TEMPORAL_INPUT_BANK_ORIGINAL74_RELATION_AND_LIMIT_BINDING_ONLY',
        episodes=128,command_blocks=2048,unselected_original_IID_ids=True,
        per_joint_requested_span_fraction=((target.max(0)-target.min(0))/(hi-lo)).tolist(),
        per_joint_requested_10bin_occupancy=occupied,all1225_requested_pair_4x4_cells_occupied=True,
        minimum_requested_pair_cell_samples=int(counts.min()),original_position_relation_max_rad=relation_max,
        original_velocity_relation_max_rad_s=velocity_max,rows=rows,
        requested_full50_volume_fraction_not_estimated=True,actual_motion_coverage_measured=False,
        safe_or_reachable_volume_not_measured=True,initial_geometry_admission_not_executed=True,
        human_teleoperation_not_executed=True,learned_System0_not_executed=True,
        native_executed=0,formal_holdout_count=0,new_independent_random_draws=0,fullSystem0_accepted=False,
        source_sha256={**prospective['source_sha256'],str(plan):sha(plan),str(output):sha(output)})
    (M/'TEMPORAL_RANDOM_INPUT_AUDIT_V1.json').write_text(json.dumps(report,indent=2)+'\n')
    print(report['status'],'128 episodes,2048 blocks;native0;formal0;paircell_min',int(counts.min()),flush=True)

if __name__=='__main__':main()
