"""Separate source prediction mismatch from command/actual state tracking."""
from pathlib import Path
import hashlib,json,sys
import numpy as np
import torch
from prepare_random_arm_pair107_108_v1 import proxy_gaps

H=Path(__file__).resolve().parent
M=H/'motion_safety_benchmark_v1'
ARMS=('F_L','F_R','U_L','U_R')
read=lambda p:json.loads(Path(p).read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()

def main():
    output=M/'RANDOM_MOTION_PAIR_CAUSAL_FRONTIER_V1.json';assert not output.exists()
    sys.path.insert(0,'/home/liyufeng/safeduo/src')
    from safeduo.delta.task_record_s9 import make_s9_provider
    torch.set_num_threads(1);provider=make_s9_provider(1,device='cpu',spheres='v7')
    reports=[];sources={}
    for v in [107,108]:
        p=H/f'fourhand_native_probe_v{v}';raw=Path(read(p/'RESOURCE_EXECUTION_V1.json')['out'])
        params=np.load(raw/'native_parameters.npz');parts=[]
        for c in read(raw/'physics_chunks.json'):
            f=raw/c['path'];assert sha(f)==c['sha256'];sources[str(f)]=sha(f)
            with np.load(f) as z:
                parts.append({k:z[k].copy() for k in z.files if k in ['physics_event','state_time_s','all9021_raw_geometry','all74_speed_exceedance_rad_s'] or any(k==a+s for a in ARMS for s in ['_native_q','_native_qd','_actual_full_position_target','_applied_target','_issued_target'])})
        d={k:np.concatenate([z[k] for z in parts]) for k in parts[0]}
        recorded=d['all9021_raw_geometry'][:,0]
        actual_arm={a:d[a+'_native_q'][:,0,params[a+'_controlled_indices']] for a in ARMS}
        submitted_arm={a:d[a+'_actual_full_position_target'][:,0,params[a+'_controlled_indices']] for a in ARMS}
        actual_prediction=proxy_gaps(provider,actual_arm);command_prediction=proxy_gaps(provider,submitted_arm)
        assert actual_prediction.shape==recorded.shape
        first=int(np.flatnonzero(recorded.min(-1)<0)[0]) if (recorded.min(-1)<0).any() else None
        maxspeed=0.;speed_worst=None;first_speed=None
        for a in ARMS:
            excess=np.maximum(abs(d[a+'_native_qd'][:,0])-params[a+'_max_velocity'][0],0)
            if excess.max()>maxspeed:
                e,j=np.unravel_index(excess.argmax(),excess.shape);maxspeed=float(excess[e,j]);speed_worst=dict(arm=a,joint=str(params[a+'_joint_names'][j]),event=int(e),actual_speed_rad_s=float(abs(d[a+'_native_qd'][e,0,j])),original_speed_limit_rad_s=float(params[a+'_max_velocity'][0,j]),exceedance_rad_s=maxspeed)
            hits=np.argwhere(excess>1e-5)
            if len(hits):
                e,j=map(int,hits[0])
                if first_speed is None or e<first_speed['event']:first_speed=dict(arm=a,joint=str(params[a+'_joint_names'][j]),event=e,time_s=float(d['state_time_s'][e]),actual_speed_rad_s=float(abs(d[a+'_native_qd'][e,0,j])),original_speed_limit_rad_s=float(params[a+'_max_velocity'][0,j]))
        mismatch=first is not None and actual_prediction[first].min()>=0
        summary=dict(version=v,events=len(recorded),maximum_native_speed_exceedance_rad_s=maxspeed,first_speed_violation=first_speed,worst_speed_violation=speed_worst,
            source_prediction_at_actual_q_minimum_m=float(actual_prediction.min()),source_prediction_at_submitted_target_minimum_m=float(command_prediction.min()),
            native_recorded_proxy_minimum_m=float(recorded.min()),same_state_source_vs_runtime_maximum_pair_gap_difference_m=float(abs(actual_prediction-recorded).max()),
            first_native_proxy_failure=None if first is None else dict(event=first,time_s=float(d['state_time_s'][first]),recorded_minimum_m=float(recorded[first].min()),
                source_at_same_actual_arm_q_minimum_m=float(actual_prediction[first].min()),source_at_same_submitted_arm_target_minimum_m=float(command_prediction[first].min()),
                critical_pair_index=int(recorded[first].argmin()),source_value_at_that_pair=float(actual_prediction[first,recorded[first].argmin()])),
            same_actual_arm_state_source_predictor_misses_runtime_proxy_failure=bool(mismatch),
            pure_delay_explanation_insufficient=bool(mismatch),
            source_hand_model_is_open_fixed_geometry=True,current_native_hands_are_articulated_held_close=True,
            precise_hand_body_frame_or_shape_root_cause_not_yet_proven=True,
            no_native_collision_or_hardware_unsafe_claim_from_negative_proxy_alone=True)
        reports.append(summary)
    result=dict(status='CLOSED_RECORDED_RANDOM_MOTION_FAILURE_DIAGNOSIS',rows=reports,
        next_required_intervention='Bind source prediction to all actual articulated hand/body transforms and revalidate against recorded moving native data before another safety claim; then include real queued target and actual velocity/stopping reserve.',
        native_reruns=0,threshold_changes=0,formal_holdout_count=0,fullSystem0_accepted=False,
        source_sha256={**sources,str(Path(__file__)):sha(__file__),str(H/'prepare_random_arm_pair107_108_v1.py'):sha(H/'prepare_random_arm_pair107_108_v1.py')})
    output.write_text(json.dumps(result,indent=2)+'\n')
    print('RANDOM_PAIR_FAILURE_FRONTIER',json.dumps(reports),flush=True)

if __name__=='__main__':main()
