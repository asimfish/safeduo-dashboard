"""Report actual movement separately from random input and safety acceptance."""
from pathlib import Path
import csv, datetime, hashlib, html, json, re, shutil, subprocess, sys, zipfile
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

P=Path(__file__).resolve().parent;H=P.parent;M=H/'motion_safety_benchmark_v1'
W=Path('/mnt/nas/data/lyf/double_hand/safeduo_dashboard_loaded_duration_20261012')
SLUG='safety_motion_random_20261012';R=W/'docs'/SLUG
read=lambda p:json.loads(Path(p).read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
esc=lambda x:html.escape(str(x))
def save(p,x):Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')

def main():
    assert not R.exists() and not (P/'BUILD_MANIFEST_V1.json').exists()
    base=subprocess.check_output(['git','-c','core.filemode=false','rev-parse','HEAD'],cwd=W,text=True).strip()
    assert base=='74d8327ddbb53451a1d7b88a31f37952c57ca4fe'
    sys.path.insert(0,str(H/'loaded_duration_report_delivery_v1'))
    from native_video_pts_v1 import encode
    sys.path.insert(0,str(H/'actual_guard_report_delivery_v1'))
    import report_archive_utils_v1 as utils
    utils.R=R
    versions=[106,107,108];curves={};results={};media=[];archives=[];csvrows=[]
    for sub in ['media','figures','evidence']:(R/sub).mkdir(parents=True,exist_ok=False)
    for v in versions:
        q=H/f'fourhand_native_probe_v{v}';r=read(q/'REGISTRATION_V1.json');resource=read(q/'RESOURCE_EXECUTION_V1.json')
        assert read(q/f'ACTUAL_COMPLETION_EXIT_V{v}.json')['actual_outer_exit']==0
        assert resource['actual_exit']==resource['actual_native_exit']==0 and resource['native_owned_process_reaped_and_absent']
        assert all(z['actual_exit']==0 for z in read(q/f'CORE_ACTUAL_EXIT_RECEIPTS_V{v}.json')['actual_outer_exits'].values())
        results[v]=read(q/'INDEPENDENT_OPERATIONAL_MOTION_V1.json');raw=Path(resource['out'])
        results[v]['physical_metrics']=read(q/'INDEPENDENT_CAPTURE_AUDIT_V1.json')
        results[v]['original_URDF']=read(q/'INDEPENDENT_NATIVE_MIMIC_WINDOW_V6.json')
        results[v]['native_camera']=read(q/'INDEPENDENT_CAMERA_FRAMING_V2.json')
        results[v]['method']='四臂退离动作' if v==106 else '随机原始指令' if v==107 else '随机确定性防护'
        archives.extend(utils.archive_parts(raw,v))
        for f in q.iterdir():
            if f.is_file() and f.suffix=='.json':shutil.copyfile(f,R/'evidence'/f'{v}_{f.name}')
        params=np.load(raw/'native_parameters.npz');chunks=[];initial=np.load(raw/'actual_initial_seed_binding.npz')
        for c in read(raw/'physics_chunks.json'):
            f=raw/c['path'];assert sha(f)==c['sha256']
            with np.load(f) as z:
                part={'time':z['state_time_s'].copy(),'event':z['physics_event'].copy(),
                    'geometry':z['all9021_raw_geometry'].min((1,2)),
                    'unintended':z['unintended_peak_normal_N'].copy(),
                    'hard':z['all74_hard_violation_rad'].copy(),'speed':z['all74_speed_exceedance_rad_s'].copy(),
                    'hand_force':z['four_hand_normal_N'].max(-1),
                    'q_relation':np.max(np.stack([abs(z[a+'_mimic_position_residual_rad']).max(-1) for a in ['F_L','F_R','U_L','U_R']]),axis=0),
                    'qd_relation':np.max(np.stack([abs(z[a+'_mimic_velocity_residual_rad_s']).max(-1) for a in ['F_L','F_R','U_L','U_R']]),axis=0)}
                for a in ['F_L','F_R','U_L','U_R']:
                    ids=params[a+'_controlled_indices'];names=params[a+'_body_names'].tolist()
                    body=('left_hand_base' if a.endswith('L') else 'right_hand_base') if a.startswith('F') else 'wrist_3_link'
                    part[a+'_q_departure']=abs(z[a+'_native_q'][:,0,ids]-params[a+'_initial_q'][0,ids]).max(-1)
                    part[a+'_command_departure']=abs(z[a+'_applied_target'][:,0]-initial[a+'_target'][0,ids]).max(-1)
                    part[a+'_mount_xyz']=z[a+'_body_position_local'][:,0,names.index(body)]
                chunks.append(part)
        d=curves[v]={k:np.concatenate([z[k] for z in chunks]) for k in chunks[0]}
        for j in range(len(d['time'])):
            csvrows.append([v,int(d['event'][j]),d['time'][j],d['geometry'][j],d['unintended'][j],d['hard'][j],d['speed'][j],d['hand_force'][j],d['q_relation'][j],d['qd_relation'][j],
                *[d[a+'_q_departure'][j] for a in ['F_L','F_R','U_L','U_R']],*[x for a in ['F_L','F_R','U_L','U_R'] for x in d[a+'_mount_xyz'][j]]])
        frames=read(raw/'camera_frames.json')
        for view in ['overview','top','front','side']:
            selected=sorted([f for f in frames if f['view']==view],key=lambda f:f['state_time_s'])
            assert abs(selected[-1]['state_time_s']-results[v]['actual_duration_s'])<1e-12
            poster=R/f'media/{v}_{view}_last.png';video=R/f'media/{v}_{view}.mp4'
            shutil.copyfile(raw/selected[-1]['path'],poster)
            encoded=encode(raw,selected,video,P/f'encoded_source_{v}_{view}')
            media.append(dict(version=v,view=view,video=str(video.relative_to(R)),poster=str(poster.relative_to(R)),
                original_frames=selected,exact_frame_pts=encoded,native_last_state_time_s=results[v]['actual_duration_s'],
                final_frame_display_hold_s=1/15,video_sha256=sha(video),poster_sha256=sha(poster)))
    for f in M.iterdir():
        if f.is_file() and f.suffix in ['.json','.npz'] and not f.name.startswith('PROGRESS_HANDOFF'):shutil.copyfile(f,R/'evidence'/f.name)
    save(R/'RAW_ARCHIVE_MANIFEST_V1.json',dict(archives=archives,all_parts_required=True))
    save(R/'MEDIA_TIMESTAMPS_AND_CUSTODY_V1.json',dict(videos=media,source='Unmodified native camera frames and actual state time; no interpolated motion.'))
    save(R/'MOTION_RESULTS_V1.json',dict(versions=results,independent_initial_states=1,paired_random_sequences=1,
        synthetic_operator=True,human_teleoperation_tested=False,actual_learned_System0_tested=False,formal_holdout_count=0,all9_jointly_accepted=False))
    with (R/'PER_STEP_MOTION_METRICS_V1.csv').open('w',newline='') as f:
        writer=csv.writer(f,lineterminator='\n');writer.writerow(['version','physics_event','native_time_s','minimum_proxy_gap_m','unintended_normal_N','hard_violation_rad','speed_exceedance_rad_s','maximum_hand_payload_normal_N','original_q_relation_residual_rad','original_qd_relation_residual_rad_s',
            *[a+'_actual_departure_rad' for a in ['F_L','F_R','U_L','U_R']],*[a+'_mount_'+axis+'_m' for a in ['F_L','F_R','U_L','U_R'] for axis in ['x','y','z']]]);writer.writerows(csvrows)
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'axes.grid':True,'grid.alpha':.2,'svg.hashsalt':'safeduo-motion-safety'})
    colors={106:'#2459af',107:'#a6443c',108:'#197b7e'}
    fig,axes=plt.subplots(2,2,figsize=(11,7))
    for ax,a in zip(axes.flat,['F_L','F_R','U_L','U_R']):
        for v in versions:ax.plot(curves[v]['time'],curves[v][a+'_q_departure'],color=colors[v],label=f'native{v}')
        ax.axhline(.1,color='#777',linestyle='--',label='movement admission')
        ax.set_title(a+' actual arm movement');ax.set_xlabel('Native time (s)');ax.set_ylabel('Max departure (rad)')
    axes[0,0].legend(fontsize=8);fig.tight_layout();utils.figure('actual_arm_movement',fig)
    fig,axes=plt.subplots(2,2,figsize=(11,7))
    for ax,k,label,limit in [(axes[0,0],'geometry','Source proxy minimum gap (m)',0),(axes[0,1],'unintended','Unintended native force (N)',.1),(axes[1,0],'hard','Native hard-limit violation (rad)',1e-5),(axes[1,1],'speed','Native speed exceedance (rad/s)',1e-5)]:
        for v in versions:ax.plot(curves[v]['time'],curves[v][k],color=colors[v],label=f'native{v}')
        ax.axhline(limit,color='#777',linestyle='--');ax.set_title(label);ax.set_xlabel('Native time (s)')
        if k!='geometry':ax.set_yscale('symlog',linthresh=max(limit/10,1e-7))
    axes[0,0].legend(fontsize=8);fig.tight_layout();utils.figure('actual_safety_metrics',fig)
    random=read(M/'TEMPORAL_RANDOM_INPUT_AUDIT_V1.json')
    fig,ax=plt.subplots(figsize=(12,4));ax.bar(np.arange(50),random['per_joint_requested_span_fraction'],color='#7691b3',label='Requested position span: software input')
    ax.set_ylim(0,1.08);ax.set_xlabel('Independent motor coordinate (26 arm +24 hand)');ax.set_ylabel('Fraction of original joint range');ax.legend();fig.tight_layout();utils.figure('requested_scope_only',fig)
    matrix=read(H/'full_requirements_v1/EVIDENCE_MATRIX_V32.json');assert not matrix['fullSystem0_accepted']
    save(R/'EVIDENCE_MATRIX_V32.json',matrix)
    sources=[]
    method_files=[Path(__file__),Path(utils.__file__),H/'loaded_duration_report_delivery_v1/native_video_pts_v1.py',
        H/'prepare_motion_safety106_v1.py',H/'build_temporal_random_motion_bank_v1.py',H/'prepare_random_arm_pair107_108_v1.py',
        H/'audit_native_mimic_window_v5.py',H/'audit_native_mimic_window_v6.py',H/'audit_full_motor_effort_native_v4.py',
        H/'analyze_random_motion_pair_frontier_v1.py',H/'analyze_random_motion_pair_frontier_v2.py',
        H/'microstep_contract_v1.py',H/'spike/native_mimic_long_duration_v1/bridge.cpp']
    for v in versions:
        q=H/f'fourhand_native_probe_v{v}'
        method_files += [q/'native_common_beam_v1.py',H/f'audit_motion_capture{v}_v1.py',H/f'audit_motion_coverage{v}_v1.py',H/f'launch_native_clock_admission_v{v}.py']
    assets=read(read(H/'fourhand_native_probe_v106/REGISTRATION_V1.json')['coupled_assets'])['assets']
    method_files += [Path(z['original_URDF']) for z in assets.values()]
    for f in method_files:
        assert f.exists(),f
        archive_path=('owned/'+str(f.relative_to(H))) if f.is_relative_to(H) else 'original_URDF/'+f.name
        sources.append(dict(path=str(f),archive_path=archive_path,sha256=sha(f),bytes=f.stat().st_size))
    with zipfile.ZipFile(R/'evidence/owned_method_source_v1.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for item in sources:z.write(item['path'],item['archive_path'])
    save(R/'METHOD_SOURCE_MANIFEST_V1.json',dict(source_files=sources,original_SDK_binary_source_commit_unverified=True,
        external_SDK_assets_private_driver_libraries_not_packaged=True,source_integrity_is_not_native_shape_certificate=True))
    old=read(M/'REPORT_COVERAGE_GAP_AUDIT_V1.json');prior=(W/'docs/safety_actual_guard_20261012/index.html').read_text();css=re.search(r'<style>(.*?)</style>',prior,re.S).group(1)
    section_ids=['question','system','protocol','denominator','evaluation','intervention','qualitative','coverage','limits','data']
    titles=['研究问题与当前结论','运动输入与执行链路','预注册与原始门槛','实验分母与失败保留','实际动作与物理结果','随机指令干预效果','原生多视角视频','随机范围：输入与实际执行','尚未满足的验收要求','完整数据与复现来源']
    sections=[]
    def section(i,body):sections.append(f'<section id="{section_ids[i]}"><h2><span class="number">{i+1:02d}</span>{titles[i]}</h2>{body}</section>')
    section(0,'<p>最新夹持报告中全部26个机械臂关节的指令跨度为零，只验证闭合与 HOLD。它不能说明遥操运动或大范围随机动作安全。</p><p>本页增加真实四臂退离及一条随机指令的原生配对对照，分别显示实际移动、危险指标和干预代价。当前仍不能宣称所有遥操动作安全。</p>')
    section(1,'<div class="flow"><div>合成操作指令<br><span>退离轨迹 / 未筛选随机目标</span></div><div>原始或确定性防护<br><span>随机对照只有26维机械臂输入</span></div><div>六帧指令队列<br><span>60 Hz 输入 →960 Hz 物理</span></div><div>实际关节与原生接触<br><span>全部74关节、82点接触视图</span></div></div><p>原始质量、惯量、关节约束与全部50个独立电机的力矩控制保持不变；四手保持捕获时的目标。确定性防护只限制指令速率、关节范围并检查源模型间隙，实际学习版 System 0 尚未接入本次测试。</p><p>本轮为实验资产2FR3/F2＋2UR5/DFX，目标2FR3＋2JAKA＋4RH56F2硬件配置尚未完成资格验证。四臂退离动作不等于四手共同抓取、搬运和释放任务完成。</p>')
    section(2,'<p>执行前固定轨迹、随机输入、方法、失败中止和验收项。原始24条 URDF 关系的 q 与 q̇ 残差均须≤10⁻⁴，全部74关节硬限位和速度超限≤10⁻⁵；全部9021个代理间隙须≥0，非预期原生接触≤0.1 N，单手物体法向力≤30 N。</p><p>另加实际动作门槛：每臂最大关节变化≥0.1 rad、手端路径≥2 cm，防止全部 HOLD 获得运动验收。代理几何通过不等于原生碰撞形状证书。</p>')
    denominator='<div class="scroll"><table><thead><tr><th>证据层</th><th>样本 / 执行</th><th>可支持的结论</th></tr></thead><tbody>'
    for x,y,z in [('全50维时序输入银行','128条输入、2048指令块；完整物理银行执行0','输入覆盖与原始关节关系检查'),('四臂退离基线','1条开发轨迹','这条退离动作的原生结果'),('随机配对','1条随机序列 ×2方法，独立初态1','这个输入上的干预与失败比较'),('真人遥操 / 学习版System0 / 正式留出','均0','尚无验收证据')]:denominator+=f'<tr><td>{esc(x)}</td><td>{esc(y)}</td><td>{esc(z)}</td></tr>'
    section(3,denominator+'</tbody></table></div><p>8192个物理微步不能当作8192次独立实验；截停与失败全部保留。这一随机开发样本不支持成功率置信区间或整体安全概率。</p>')
    table='<div class="scroll"><table id="results"><thead><tr><th>方法</th><th>实际时长 / 完成</th><th>原始物理</th><th>原始q / q̇关系</th><th>四臂动作</th><th>完整运动诊断</th></tr></thead><tbody>'
    for v,d in results.items():
        numerical=d['original_URDF']['maximum_q_residual_rad']<=1e-4 and d['original_URDF']['maximum_qd_residual_rad_s']<=1e-4
        vals=[d['method'],f"{d['actual_duration_s']:.3f}s / {d['completed_controls']}/256",'通过' if d['original_physical_pass'] else '失败','通过' if numerical else '失败','通过' if d['all4_actual_motion_admission_pass'] else '不足','通过' if d['operational_motion_diagnostic_pass'] else '失败']
        table+='<tr>'+''.join('<td>'+esc(x)+'</td>' for x in vals)+'</tr>'
    section(4,table+'</tbody></table></div><figure><img src="figures/actual_arm_movement.png" alt="各臂实际关节变化，实测时间轴"><figcaption>实测 q 的变化；虚线是本次动作门槛。未执行的轨迹尾部没有填充。</figcaption></figure><figure><img src="figures/actual_safety_metrics.png" alt="真实间隙、接触、限位与速度指标"><figcaption>全部原生已记录样本，包括首个失败和该完整控制周期。间隙仍为代理模型；接触力来自原生点数据。</figcaption></figure>')
    guard=read(M/'RANDOM_ARM_COMMAND_PREPARATION_V1.json')
    frontier=read(M/'RANDOM_MOTION_PAIR_CAUSAL_FRONTIER_V2.json')
    raw_failure=frontier['rows'][0]['worst_speed_violation'];guard_failure=frontier['rows'][1]['first_native_proxy_failure']
    section(5,f'<p>两方法共用原始目标序列和物理初态。不干预时，{esc(raw_failure["arm"]+"/"+raw_failure["joint"])}实际速度达{raw_failure["actual_speed_rad_s"]:.3f} rad/s，超过原始{raw_failure["original_speed_limit_rad_s"]:.2f} rad/s上限。确定性防护避免了该超速，但在{guard_failure["time_s"]:.3f}秒触发代理间隙门槛，仍未通过。</p><p>失败时，提交目标的源模型间隙仍为正，而把同一个预测器输入换成实际关节状态即可重现负间隙，和运行态关键间隙差不到0.21微米。这说明指令状态的筛查没有保证实际状态安全；需补实际状态、速度、延迟队列与跟踪及制动余量，不能只提高软件筛查样本数。</p><p>预计算的256个控制时刻中有{guard["guarded_alpha_zero_controls"]}个生成零新增位移指令，其中多数未实际执行；完整计划不是执行证据。停止危险意图可以是正确干预，但仍需独立展示可行空间中的有效动作。负代理间隙本身不等于原生碰撞或硬件碰撞证据。</p>')
    body=''
    for v in versions:
        d=results[v];body+=f'<h3>{esc(d["method"])} · native{v} · {d["actual_duration_s"]:.3f}秒</h3>'
        if not d['full_window_complete']:body+='<p class="note warning">原始门槛触发后已中止；视频只展示实际执行前缀，未补出计划动作。</p>'
        body+='<div class="views">'
        for item in [x for x in media if x['version']==v]:
            label={'overview':'全景','top':'俯视','front':'正视','side':'侧视'}[item['view']]
            body+=f'<figure><video controls playsinline preload="metadata" poster="{item["poster"]}" src="{item["video"]}"></video><figcaption>{label} · 原生画面与时间戳 · <a href="{item["video"]}">下载视频</a></figcaption></figure>'
        body+='</div>'
    section(6,body)
    section(7,'<figure><img src="figures/requested_scope_only.png" alt="全50维请求范围，仅输入银行，非实际安全覆盖"><figcaption>128条未筛选输入的请求跨度覆盖全部50维原始范围；10个边际分箱及1225对关节的4×4输入格均有样本。该图没有代表实际安全覆盖。</figcaption></figure><p>当前原生随机对照只执行26个机械臂维度的一条序列，24个手部独立电机未随机动作。四手协同搬运、广泛可操作空间和全50维实际覆盖均待补齐。实际每关节跨度、手端路径和空间跨度逐项保存在结果JSON。</p>')
    oldcounts=old['old_motion_experiments']['multirow_hold_fallback']
    section(8,f'<p>旧的128条筛选后运动开发样本中，安全回退仍有{oldcounts["primary_failures"]}条物理主门槛失败，且不能代表全50维随机空间。本轮不覆盖真人操作记录、四手共同搬运完成、学习版System0、物体与感知不确定性、制动距离和正式留出验收。</p><p class="note warning">全部九项联合验收仍未通过。全面安全结论必须同时具备实际动作、全程安全、任务完成和冻结协议后的独立测试，不能只统计没有碰撞的静止窗口。</p><p><a href="EVIDENCE_MATRIX_V32.json">原始九项验收矩阵</a> · <a href="../safety_actual_guard_20261012/">前一版闭合与HOLD诊断</a></p>')
    links=['MOTION_RESULTS_V1.json','PER_STEP_MOTION_METRICS_V1.csv','MEDIA_TIMESTAMPS_AND_CUSTODY_V1.json','RAW_ARCHIVE_MANIFEST_V1.json','METHOD_SOURCE_MANIFEST_V1.json','evidence/owned_method_source_v1.zip','evidence/REPORT_COVERAGE_GAP_AUDIT_V1.json','evidence/OPERATIONAL_MOTION_PROSPECTIVE_PLAN_V1.json','evidence/TEMPORAL_RANDOM_PROSPECTIVE_PLAN_V1.json','evidence/TEMPORAL_RANDOM_INPUT_AUDIT_V1.json','evidence/TEMPORAL_RANDOM_MOTION_BANK_V1.npz','evidence/RANDOM_ARM_PAIR107_108_PROSPECTIVE_PLAN_V1.json','evidence/RANDOM_MOTION_PAIR_CAUSAL_FRONTIER_V2.json']
    body='<ul>'+''.join(f'<li><a href="{x}">{esc(x)}</a></li>' for x in links)+'</ul><details><summary>全部原生捕获分卷（无删样本）</summary><ul>'
    body+=''.join(f'<li><a href="{x["path"]}">native{x["version"]}分卷{x["part"]} · {x["bytes"]/1024**2:.1f} MiB</a></li>' for x in archives)+'</ul></details><p>方法源码与原始URDF已提供；外部模拟器SDK、完整资源和驱动库需要原有环境。活动原生碰撞形状身份及SDK二进制来源尚未认证，不声称仅凭源码包即可复现所有原生内部行为。</p>'
    section(9,body)
    page=f'<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>SafeDuo · 四臂动作与随机运动安全评测</title><style>{css}</style></head><body><header><div class="hero"><div class="topline"><span class="brand">SAFEDUO / EXPERIMENT REPORT</span><a href="../../#scientific">返回主面板</a></div><p class="eyebrow">Operational motion · paired random input · acceptance gaps</p><h1>四臂动作与随机运动：原生安全评测</h1><p class="subtitle">从真实执行的动作出发，分别检查运动、安全与覆盖，保留失败和证据缺口。</p><div class="verdict"><p><strong>当前结论：尚不能证明所有遥操动作安全，全面随机安全验收未完成。</strong></p><p>此前机械臂指令跨度为零；本页补充实际四臂退离和一条随机配对。真人遥操、学习版System0及正式留出测试均未执行。</p></div><div class="actions"><a class="button primary" href="#qualitative">看真实动作与失败视频</a><a class="button" href="#evaluation">安全与动作结果</a><a class="button" href="#coverage">随机范围与缺口</a></div><div class="metrics"><div class="metric"><strong>3次</strong><span>原生开发执行，含随机配对</span></div><div class="metric"><strong>1条</strong><span>随机序列，独立初态1</span></div><div class="metric"><strong>128条</strong><span>全50维输入银行，完整物理银行执行0</span></div><div class="metric"><strong>未达标</strong><span>原始九项全面安全联合验收</span></div></div></div></header><div class="layout"><nav class="toc"><b>REPORT CONTENTS</b>'+''.join(f'<a href="#{i}">{j+1:02d} {esc(t)}</a>' for j,(i,t) in enumerate(zip(section_ids,titles)))+'</nav><main>'+''.join(sections)+'</main></div><footer>SafeDuo · 全部结果来自原始记录；合成操作者不是人类遥操，确定性防护不是学习版System0验收。</footer></body></html>'
    (R/'index.html').write_text(page+'\n')
    root=W/'index.html';before=root.read_text();assert 'motionRandomEvidence' not in before
    marker='<div id="actualGuardEvidence"';assert before.count(marker)==1
    pos=before.index(marker);card=f'<div id="motionRandomEvidence" class="sci-note" style="margin-bottom:18px;border-left:4px solid #2459af"><strong>四臂动作与随机运动 · 最新原生评测</strong><p>真实四臂退离和随机指令配对；记录实际动作、危险干预与失败。尚不能证明全部遥操安全，正式留出与学习版System0仍未测。</p><a href="docs/{SLUG}/">查看动作、随机范围与原生视频 →</a></div>\n  '
    (P/'root_index_before_v1.html').write_text(before);root.write_text(before[:pos]+card+before[pos:])
    owned=sorted([*R.rglob('*'),root]);files=[]
    for f in owned:
        if f.is_file():files.append(dict(path=str(f.relative_to(W)),sha256=sha(f),bytes=f.stat().st_size))
    save(R/'PUBLIC_MANIFEST_V1.json',dict(files=[f for f in files if f['path']!='index.html'],all9_jointly_accepted=False))
    files.append(dict(path=str((R/'PUBLIC_MANIFEST_V1.json').relative_to(W)),sha256=sha(R/'PUBLIC_MANIFEST_V1.json'),bytes=(R/'PUBLIC_MANIFEST_V1.json').stat().st_size))
    save(P/'BUILD_MANIFEST_V1.json',dict(base_commit=base,slug=SLUG,files=files,total_bytes=sum(f['bytes'] for f in files),versions=versions,csv_rows=len(csvrows),all9_jointly_accepted=False))
    print('BUILT_MOTION_RANDOM_REPORT',len(files),'files',len(csvrows),'raw microstep rows;12 original native videos;all9false',flush=True)

if __name__=='__main__':main()
