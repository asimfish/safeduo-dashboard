"""Movement and physical qualification are separate predicates; no no-op pass."""
from pathlib import Path
import hashlib, json
import numpy as np

H=Path(__file__).resolve().parent
P=H/'fourhand_native_probe_v106'
ARMS=('F_L','F_R','U_L','U_R')
read=lambda p:json.loads(Path(p).read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()

def main():
    output=P/'INDEPENDENT_OPERATIONAL_MOTION_V1.json';assert not output.exists()
    r=read(P/'REGISTRATION_V1.json');raw=Path(read(P/'RESOURCE_EXECUTION_V1.json')['out'])
    baseline=Path(read(H/'fourhand_native_probe_v105/RESOURCE_EXECUTION_V1.json')['out'])
    protocol=read(raw/'fourhand_protocol.json');physical=read(P/'INDEPENDENT_CAPTURE_AUDIT_V1.json')
    model=read(P/'INDEPENDENT_NATIVE_MIMIC_WINDOW_V6.json')
    params=np.load(raw/'native_parameters.npz');oldparams=np.load(baseline/'native_parameters.npz')
    assert set(params.files)==set(oldparams.files) and len(params.files)==77
    for k in params.files:np.testing.assert_array_equal(params[k],oldparams[k])
    with np.load(raw/'actual_initial_seed_binding.npz') as seed,np.load(baseline/'actual_initial_seed_binding.npz') as old:
        assert len(seed.files)==13 and set(seed.files)==set(old.files)
        for k in seed.files:np.testing.assert_array_equal(seed[k],old[k])
    sources={};parts=[]
    for c in read(raw/'physics_chunks.json'):
        f=raw/c['path'];assert sha(f)==c['sha256'];sources[str(f)]=sha(f)
        with np.load(f) as z:
            parts.append({k:z[k].copy() for k in z.files if k in ['physics_event','state_time_s','motion_family'] or any(k==a+s for a in ARMS for s in ['_native_q','_native_qd','_body_position_local','_issued_target','_applied_target'])})
    data={k:np.concatenate([part[k] for part in parts]) for k in parts[0]}
    oldchunks=read(baseline/'physics_chunks.json');newchunks=read(raw/'physics_chunks.json')
    prefix=0
    for new,old in zip(newchunks,oldchunks):
        if old['stop']>64:break
        assert new['start']==old['start'] and new['stop']==old['stop']
        with np.load(raw/new['path']) as a,np.load(baseline/old['path']) as b:
            assert set(a.files)==set(b.files)|{'motion_family'}
            for k in b.files:
                assert a[k].dtype==b[k].dtype and a[k].shape==b[k].shape and a[k].tobytes()==b[k].tobytes(),(new['start'],k)
        prefix=old['stop']
    assert prefix==min(64,protocol['physics_events'])
    rows=[];coverage_ok=True
    for a in ARMS:
        ids=params[a+'_controlled_indices'];q=data[a+'_native_q'][:,0,ids];v=data[a+'_native_qd'][:,0,ids]
        origin=params[a+'_initial_q'][0,ids]
        names=params[a+'_body_names'].tolist()
        mount=('left_hand_base' if a.endswith('L') else 'right_hand_base') if a.startswith('F') else 'wrist_3_link'
        body=data[a+'_body_position_local'][:,0,names.index(mount)]
        departure=float(abs(q-origin).max());path=float(np.linalg.norm(np.diff(body,axis=0),axis=-1).sum())
        arm_ok=departure>=.1 and path>=.02;coverage_ok=coverage_ok and arm_ok
        rows.append(dict(arm=a,hand_mount=mount,events=len(q),maximum_actual_departure_rad=departure,
            actual_joint_path_rad=float(abs(np.diff(q.astype(float),axis=0)).sum()),
            per_joint_actual_span_rad=np.ptp(np.concatenate([origin[None],q]),axis=0).tolist(),
            per_joint_URDF_range_coverage_fraction=(np.ptp(np.concatenate([origin[None],q]),axis=0)/(params[a+'_hard_limits'][0,ids,1]-params[a+'_hard_limits'][0,ids,0])).tolist(),
            maximum_actual_speed_rad_s=float(abs(v).max()),hand_mount_path_m=path,
            hand_mount_xyz_span_m=np.ptp(body,axis=0).tolist(),actual_motion_admission_pass=arm_ok))
    complete=protocol['completed_controls']==r['maximum_controls']
    accepted=bool(complete and physical['physical_gates_pass'] and model['model_window_pass'] and coverage_ok)
    result=dict(status='CLOSED_OPERATIONAL_MOTION_DIAGNOSTIC',candidate=106,baseline=105,
        physics_events=protocol['physics_events'],completed_controls=protocol['completed_controls'],
        actual_duration_s=protocol['physics_events']*r['physics_dt_s'],full_window_complete=complete,
        rows=rows,all4_actual_motion_admission_pass=bool(coverage_ok),
        original_model_pass=model['model_window_pass'],original_physical_pass=physical['physical_gates_pass'],
        operational_motion_diagnostic_pass=accepted,random_followup_admitted=accepted,
        model_qualification_failure=protocol.get('model_qualification_failure'),unsafe_events=protocol['unsafe_events'],
        common_prefix_physical_fields_verified_events=prefix,all77_physics_and13_initial_seed_fields_byte_equal105=True,
        denominator=dict(operational_development_trajectories=1,new_random_native_trajectories=0,formal_holdout_trajectories=0),
        no_op_acceptance_prevented=True,human_teleoperation_tested=False,learned_System0_active=False,
        fullSystem0_accepted=False,all9_jointly_accepted=False,
        source_sha256={**sources,**{str(f):sha(f) for f in [Path(__file__),P/'REGISTRATION_V1.json',raw/'fourhand_protocol.json',P/'INDEPENDENT_CAPTURE_AUDIT_V1.json',P/'INDEPENDENT_NATIVE_MIMIC_WINDOW_V6.json']}})
    output.write_text(json.dumps(result,indent=2)+'\n')
    print('OPERATIONAL_MOTION106',accepted,'model',model['model_window_pass'],'physical',physical['physical_gates_pass'],'motion',coverage_ok,json.dumps(rows),flush=True)

if __name__=='__main__':main()
