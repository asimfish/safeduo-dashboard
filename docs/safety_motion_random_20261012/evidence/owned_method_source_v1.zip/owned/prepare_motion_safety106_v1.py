"""Freeze an operational four-arm retreat before interpreting random safety."""
from pathlib import Path
import ast, copy, datetime, hashlib, json, shutil
import numpy as np

H = Path(__file__).resolve().parent
B = H / 'fourhand_native_probe_v105'
P = H / 'fourhand_native_probe_v106'
M = H / 'motion_safety_benchmark_v1'
ARMS = ('F_L', 'F_R', 'U_L', 'U_R')
read = lambda p: json.loads(Path(p).read_text())
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()

def replace_once(text, before, after):
    assert text.count(before) == 1, before
    return text.replace(before, after)

def main():
    assert not P.exists() and not M.exists()
    reg = copy.deepcopy(read(B / 'REGISTRATION_V1.json'))
    assert read(B / 'LOADED_ACTUAL_GUARD_DECISION_V1.json')['all9_jointly_accepted'] is False
    for f, digest in reg['source_sha256'].items():
        assert sha(f) == digest, f
    M.mkdir(); P.mkdir()
    controls = 256
    raw = Path(read(B / 'RESOURCE_EXECUTION_V1.json')['out'])
    with np.load(raw / 'native_parameters.npz') as z:
        params = {k: z[k] for k in z.files}
    with np.load(reg['contact_reproducer']['fixture']) as z:
        seed = {k: z[k] for k in z.files}
    with np.load(reg['path']) as z:
        path = {k: z[k] for k in z.files}
    # Reverse the final 100 samples of the previously audited approach path.
    # This is a visible operational retreat, not a random or grasp success trial.
    u = np.linspace(0., 1., controls - 6 - 4)
    source_indices = 433. - 99. * (.5 - .5 * np.cos(np.pi * u))
    bank = {}; rows = []
    for arm in ARMS:
        ids = params[arm + '_controlled_indices'].ravel().astype(int)
        initial = seed[arm + '_actual_full_position_target_seed'][0, ids]
        q = path['q_' + arm]
        target = np.stack([np.interp(source_indices, np.arange(len(q)), q[:, j]) for j in range(len(ids))], axis=-1)
        # Preserve the distinct captured target and avoid a start-command jump.
        target += (initial - q[-1])[None] * (1. - u[:, None])
        target = np.concatenate([np.repeat(initial[None],4,axis=0), target, np.repeat(target[-1:], 6, axis=0)]).astype(np.float32)
        np.testing.assert_array_equal(target[0], initial)
        hard = params[arm + '_hard_limits'][0, ids]
        assert (target >= hard[:, 0]).all() and (target <= hard[:, 1]).all()
        rate = abs(np.diff(target.astype(float), axis=0)) / reg['control_dt_s']
        assert rate.max() < .5
        assert abs(np.diff(target.astype(float), axis=0)).max() < .015
        bank[arm + '_issued_target'] = target
        rows.append(dict(arm=arm, command_endpoint_departure_rad=float(abs(target[-1] - initial).max()),
                         command_path_rad=float(abs(np.diff(target.astype(float), axis=0)).sum()),
                         maximum_command_rate_rad_s=float(rate.max())))
    np.savez_compressed(M / 'RETREAT_COMMAND_BANK_V1.npz', **bank)
    for f in B.iterdir():
        if f.suffix in ('.py', '.usda') or f.name == 'PRIVATE_KIT_USER_CONFIG_FROZEN_V1.json':
            shutil.copyfile(f, P / f.name)
    shutil.copytree(B / 'private_kit_user_data', P / 'private_kit_user_data')
    worker = P / 'native_common_beam_v1.py'
    text = worker.read_text()
    text = replace_once(text, "        capture(0)\n        for step in range(reg['maximum_controls']):",
        "        with np.load(reg['motion_test']['command_bank'],allow_pickle=False) as z:motion_bank={k:z[k] for k in z.files}\n        capture(0)\n        for step in range(reg['maximum_controls']):")
    text = replace_once(text, "            issued={a:initial[a].clone() for a in ARMS};applied={a:initial[a].clone() for a in ARMS};u=1.",
        "            issued={a:torch.as_tensor(motion_bank[a+'_issued_target'][step],device=env.device,dtype=initial[a].dtype)[None] for a in ARMS}\n            pending.append({a:issued[a].clone() for a in ARMS});applied=pending.popleft();u=1.")
    text = replace_once(text, "                        full=repro[a+'_actual_full_position_target_tape'][tape_index]",
        "                        full=repro[a+'_actual_full_position_target_tape'][tape_index].copy()\n                        full[0,parameters[a+'_controlled_indices']]=array(applied[a])[0]")
    text = replace_once(text, "                hard_peak=0.;speed_peak=0.;data=dict(physics_event=np.asarray(event),", 
        "                hard_peak=0.;speed_peak=0.;data=dict(motion_family=np.asarray('FOUR_ARM_RETREAT'),physics_event=np.asarray(event),")
    text = replace_once(text, "        protocol.update(task_status=('ORIGINAL_MODEL_QUALIFICATION_FAILED' if model_qualification_failure is not None else 'ORIGINAL_FEEDBACK_CLOSE_WINDOW_COMPLETE') if not unsafe else protocol['task_status'],",
        "        protocol.update(task_status=('ORIGINAL_MODEL_QUALIFICATION_FAILED' if model_qualification_failure is not None else 'OPERATIONAL_RETREAT_WINDOW_COMPLETE') if not unsafe else protocol['task_status'],")
    text = replace_once(text, "        protocol.update(method='LOADED_NATIVE60_FOUR_HAND_FEEDBACK_AFTER_PURE64_PREFIX',target_producer='Exact64-step held prefix; then original four-hand force/joint feedback with original per-microstep target filter',initial_state_source_event=11271)",
        "        protocol.update(method='OPERATIONAL_FOUR_ARM_RETREAT_WITH_FIFO6',target_producer='Frozen reversed approach commands at60Hz through real FIFO6; original full50 motor effort controller; hands hold recorded seed tape',initial_state_source_event=11271,synthetic_operator=True,human_teleoperation_tested=False,random_test=False)")
    ast.parse(text); worker.write_text(text)
    capture = H / 'audit_motion_capture106_v1.py'
    text = (H / 'audit_loaded_native_capture105_v1.py').read_text()
    text = replace_once(text, "assert version == 105 and reg['contact_reproducer']['maximum_physics_events']==8192 and reg['maximum_controls']==512",
        "assert version == 106 and reg['contact_reproducer']['maximum_physics_events']==4096 and reg['maximum_controls']==256")
    capture.write_text(text)
    launcher = H / 'launch_native_clock_admission_v106.py'
    text = (H / 'launch_native_clock_admission_v105.py').read_text()
    text = text.replace('v105', 'v106').replace('V105', 'V106').replace('NATIVE105', 'NATIVE106')
    text = text.replace("argv[argv.index('--timeout-seconds')+1]='1800'", "argv[argv.index('--timeout-seconds')+1]='1200'")
    text = text.replace("job['max_wall_seconds']=1800", "job['max_wall_seconds']=1200")
    launcher.write_text(text)
    reg.update(attempt_version=106, scientific_candidate_version=106, maximum_controls=controls,
        expected_maximum_physics_events=4096, feedback_activation_control=controls + 1,
        registered_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        independent_capture_auditor=str(capture),
        change_scope='Operational four-arm motion through FIFO6; hands held at recorded tape; native physics, all50 effort controller, original q/qd/physical/task thresholds and16 native passes unchanged. Not random, learnedSystem0, canonical or hardware acceptance.',
        motion_test=dict(command_bank=str(M / 'RETREAT_COMMAND_BANK_V1.npz'),
            source_path_interval=[433, 334], synthetic_operator=True,
            hands='Hold captured native seed target tape; no feedback closure or grasp success claim',
            actual_motion_admission=dict(each_arm_max_departure_rad_at_least=.1,each_hand_mount_path_m_at_least=.02),
            first64_physical_fields_byte_identical105_required=True),
        private_asset_settings=dict(reg['private_asset_settings'],private_directory=str(P / 'private_kit_user_data')))
    reg['contact_reproducer'] = dict(reg['contact_reproducer'], maximum_physics_events=4096,
        no_task_or_new_random_input=True, target_after_tape='Hold hand tape only; controlled arm commands use registered operational FIFO6')
    # Remove stale hand-feedback and duration acceptance descriptions from this new protocol.
    for key in ['duration_prefix_baseline_version','duration_prefix_required_events','actual_target_guard_policy','loaded_only_qualification']:
        reg.pop(key, None)
    reg['first64_physical_prefix_baseline'] = 105
    sources = {}
    for file in reg['source_sha256']:
        old = Path(file)
        if old.is_relative_to(B):
            new = P / old.relative_to(B)
        elif old == H / 'launch_native_clock_admission_v105.py':
            new = launcher
        elif old == H / 'audit_loaded_native_capture105_v1.py':
            new = capture
        else:
            new = old
        if not new.exists():
            new.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(old,new)
        sources[str(new)] = sha(new)
    for f in [Path(__file__), M / 'RETREAT_COMMAND_BANK_V1.npz', H / 'audit_motion_coverage106_v1.py']:
        sources[str(f)] = sha(f)
    reg['source_sha256'] = sources
    (P / 'REGISTRATION_V1.json').write_text(json.dumps(reg,indent=2)+'\n')
    plan = dict(status='FROZEN_BEFORE_NATIVE', utc=reg['registered_utc'], baseline=105, candidate=106,
        maximum_native_executions=1, maximum_controls=256, maximum_physics_events=4096, maximum_native_wall_s=1200,
        operator_command_rows=rows, original_physical_and_model_gates_unchanged=True,
        original_q_AND_qd_tolerance=1e-4, original_native_960Hz_control_60Hz_and_FIFO6=True,
        no_kernel_or_physics_parameter_change=True, all77_physics_and13_seed_arrays_equal105_required=True,
        first64_common_fields_byte_equal105_required=True,
        rejection='Any original model or physical gate failure, or insufficient actual four-arm movement, rejects the operational motion diagnostic. All failed samples retained; no native failure rerun.',
        random_followup='Broad random motion is gated on a physically qualified moving controller, not stationary105. No random or teleoperation safety acceptance from this one development trajectory.',
        formal_holdout_count=0, new_random_cases=0, learned_System0_active=False, fullSystem0_accepted=False,
        source_sha256={str(f):sha(f) for f in [Path(__file__), P / 'REGISTRATION_V1.json',capture,launcher,H / 'audit_motion_coverage106_v1.py']})
    (M / 'OPERATIONAL_MOTION_PROSPECTIVE_PLAN_V1.json').write_text(json.dumps(plan,indent=2)+'\n')
    print('FROZEN_OPERATIONAL106', json.dumps(rows), flush=True)

if __name__ == '__main__': main()
