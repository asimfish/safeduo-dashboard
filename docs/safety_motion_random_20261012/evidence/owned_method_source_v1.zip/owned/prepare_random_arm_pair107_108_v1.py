"""Predeclare one unselected random packet sequence, Raw versus command guard.

The guard is a deterministic source-proxy diagnostic, not learned System0.
It holds the captured hand commands; only26 arm joints are executed here.
"""
from pathlib import Path
import ast, copy, datetime, hashlib, json, shutil, sys
import numpy as np
import torch

H=Path(__file__).resolve().parent
M=H/'motion_safety_benchmark_v1'
B=H/'fourhand_native_probe_v106'
ARMS=('F_L','F_R','U_L','U_R')
read=lambda p:json.loads(Path(p).read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()

def proxy_gaps(provider, q):
    centers=provider.fk_all({a:torch.tensor(q[a],dtype=torch.float32) for a in ARMS})['centers']
    m=provider.sph;r=m.radii;pieces=[]
    for pairs in [m.pairs_cross,m.pairs_self]:
        pieces.append((centers[:,pairs[:,0]]-centers[:,pairs[:,1]]).norm(dim=-1)-r[pairs[:,0]]-r[pairs[:,1]])
    tc=torch.tensor(provider.layout.table_centers);th=torch.tensor(provider.layout.table_half_extents)
    sph,tab=m.pairs_table[:,0],m.pairs_table[:,1]
    box=(centers[:,sph]-tc[tab]).abs()-th[tab]
    pieces.append(box.clamp_min(0).norm(dim=-1)+box.amax(-1).clamp_max(0)-r[sph])
    gaps=torch.cat(pieces,-1).numpy();assert gaps.shape[-1]==9021 and np.isfinite(gaps).all()
    return gaps

def main():
    planfile=M/'RANDOM_ARM_PAIR107_108_PROSPECTIVE_PLAN_V1.json';assert not planfile.exists()
    for v in [107,108]:assert not (H/f'fourhand_native_probe_v{v}').exists()
    reg=read(B/'REGISTRATION_V1.json')
    for f,d in reg['source_sha256'].items():assert sha(f)==d,f
    bankfile=M/'TEMPORAL_RANDOM_MOTION_BANK_V1.npz';input_audit=read(M/'TEMPORAL_RANDOM_INPUT_AUDIT_V1.json')
    assert input_audit['native_executed']==0 and input_audit['unselected_original_IID_ids']
    prospective=dict(status='FROZEN_BEFORE_RANDOM_PAIR_COMMAND_SELECTION_AND_NATIVE',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        candidates=[107,108],episode_index=0,requested_block_proposal_ids=list(range(128,136)),
        maximum_controls=256,maximum_physics_events=4096,maximum_native_wall_s_each=1200,
        first4_controls_common_seed_hold=True,original_FIFO6_and_960Hz_60Hz=True,
        paired_methods=['Raw absolute arm target','deterministic rate/limit/source-proxy command guard'],
        guarded_arm_command_rate_rad_s=.25,guarded_arm_command_limit_reserve_rad=.03,
        source_proxy_check='All9021 open-hand source proxy gaps at9 points along each guarded command segment; alpha candidates1,.5,.25,.125,.0625,0; require every gap>=0.',
        physical_states_velocities_contacts_and_delayed_commands_are_not_predicted=True,
        guard_is_not_physical_stopping_or_collision_certificate=True,
        raw_mode_is_simulation_only=True,original_full50_effort_and_original_model_physical_gates_unchanged=True,
        each_candidate_max_native_executions=1,early_failure_samples_retained=True,
        execution_condition='106 complete and original model/physical/actual movement admission pass',
        scope=dict(executed_arm_dimensions=26,executed_hand_motor_random_dimensions=0,captured_hand_targets_held=True,
                   independent_initial_states=1,random_command_sequences=1,broader_full50_128_bank_native_executed=0),
        new_independent_random_draws=0,formal_holdout_count=0,learned_System0_active=False,fullSystem0_accepted=False,
        source_sha256={str(f):sha(f) for f in [Path(__file__),bankfile,M/'TEMPORAL_RANDOM_INPUT_AUDIT_V1.json',B/'REGISTRATION_V1.json']})
    planfile.write_text(json.dumps(prospective,indent=2)+'\n')
    torch.set_num_threads(1);sys.path.insert(0,'/home/liyufeng/safeduo/src')
    from safeduo.delta.task_record_s9 import make_s9_provider
    provider=make_s9_provider(1,device='cpu',spheres='v7')
    raw=Path(read(H/'fourhand_native_probe_v105/RESOURCE_EXECUTION_V1.json')['out'])
    params=np.load(raw/'native_parameters.npz');seeds=np.load(reg['contact_reproducer']['fixture']);bank=np.load(bankfile)
    initial={};requests={};guarded={};direct={};limits={}
    for a in ARMS:
        ids=params[a+'_controlled_indices'].ravel().astype(int)
        initial[a]=seeds[a+'_actual_full_position_target_seed'][0,ids].copy()
        limits[a]=params[a+'_hard_limits'][0,ids].copy()
        req=np.concatenate([np.repeat(initial[a][None],4,axis=0),np.repeat(bank[a+'_requested_position_target'][0][:,ids],32,axis=0)],axis=0)[:256]
        assert req.shape==(256,len(ids));requests[a]=req.astype(np.float32)
        guarded[a]=[];direct[a]=requests[a]
    last=copy.deepcopy(initial);alphas=[];minimums=[]
    for step in range(256):
        if step<4:
            chosen=copy.deepcopy(initial);alpha=1.;minimum=float(proxy_gaps(provider,{a:last[a][None] for a in ARMS}).min())
        else:
            capped={a:np.clip(last[a]+np.clip(requests[a][step]-last[a],-.25/60,.25/60),limits[a][:,0]+.03,limits[a][:,1]-.03) for a in ARMS}
            chosen=copy.deepcopy(last);alpha=0.;minimum=float('nan')
            for fraction in [1.,.5,.25,.125,.0625,0.]:
                candidate={a:last[a]+fraction*(capped[a]-last[a]) for a in ARMS}
                path={a:last[a][None]+np.linspace(0,1,9)[:,None]*(candidate[a]-last[a])[None] for a in ARMS}
                minimum=float(proxy_gaps(provider,path).min())
                if minimum>=0:
                    chosen=candidate;alpha=fraction;break
            # An infeasible stationary source proxy is logged, never relabelled safe.
        for a in ARMS:guarded[a].append(chosen[a].astype(np.float32))
        last={a:guarded[a][-1].copy() for a in ARMS};alphas.append(alpha);minimums.append(minimum)
    np.savez_compressed(M/'RANDOM_ARM_GUARD_COMMAND_DIAGNOSTICS_V1.npz',alpha=np.asarray(alphas),source_proxy_minimum_m=np.asarray(minimums))
    for v,targets in [(107,direct),(108,guarded)]:
        p=H/f'fourhand_native_probe_v{v}';p.mkdir()
        commandbank=M/f'RANDOM_ARM_COMMAND_BANK_{v}_V1.npz'
        np.savez_compressed(commandbank,**{a+'_issued_target':np.asarray(targets[a],dtype=np.float32) for a in ARMS},
            **{a+'_raw_requested_target':requests[a] for a in ARMS})
        for f in B.iterdir():
            if f.suffix in ('.py','.usda') or f.name=='PRIVATE_KIT_USER_CONFIG_FROZEN_V1.json':shutil.copyfile(f,p/f.name)
        shutil.copytree(B/'private_kit_user_data',p/'private_kit_user_data')
        worker=p/'native_common_beam_v1.py';text=worker.read_text().replace("np.asarray('FOUR_ARM_RETREAT')", "np.asarray('RANDOM_ARM_RAW' if reg['attempt_version']==107 else 'RANDOM_ARM_COMMAND_GUARD')")
        text=text.replace('OPERATIONAL_FOUR_ARM_RETREAT_WITH_FIFO6','SYNTHETIC_RANDOM26_ARM_WITH_FIFO6')
        text=text.replace('Frozen reversed approach commands at60Hz through real FIFO6; original full50 motor effort controller; hands hold recorded seed tape',
                          'Frozen unselected random26 arm targets or deterministic source-proxy guarded commands through real FIFO6; original full50 effort controller; held hand tape; not learnedSystem0')
        before="data[a+'_native_q']=q;data[a+'_native_qd']=qd;data[a+'_issued_target']=array(issued[a]);"
        assert text.count(before)==1
        text=text.replace(before,"data[a+'_raw_requested_arm_target']=motion_bank[a+'_raw_requested_target'][step];"+before)
        ast.parse(text);worker.write_text(text)
        launcher=H/f'launch_native_clock_admission_v{v}.py'
        text=(H/'launch_native_clock_admission_v106.py').read_text().replace('v106',f'v{v}').replace('V106',f'V{v}').replace('NATIVE106',f'NATIVE{v}')
        before="    assert not (P/'RESOURCE_EXECUTION_V1.json').exists()"
        after=before+"\n    assert read(H/'fourhand_native_probe_v106/INDEPENDENT_OPERATIONAL_MOTION_V1.json')['operational_motion_diagnostic_pass'], 'Random motion not admitted by moving-controller qualification'"
        assert text.count(before)==1;text=text.replace(before,after);launcher.write_text(text)
        capture=H/f'audit_motion_capture{v}_v1.py';text=(H/'audit_motion_capture106_v1.py').read_text().replace('assert version == 106',f'assert version == {v}')
        # Raw command discontinuity is measured as a failure, not a custody error.
        before="        assert np.max(abs(np.diff(np.concatenate([initial_command[a][:,ix][None],issued[0::substeps]],axis=0),axis=0)))<=.015+1e-6"
        assert text.count(before)==1
        text=text.replace(before,"        if version==108:\n    "+before)
        capture.write_text(text);ast.parse(text)
        new=copy.deepcopy(reg)
        new.update(attempt_version=v,scientific_candidate_version=v,registered_utc=prospective['utc'],independent_capture_auditor=str(capture),
            change_scope=f'Candidate{v}: one unselected random26 arm goal stream through FIFO6 with held hand commands; Raw versus deterministic source-proxy command guard. Not full50 random native coverage, learnedSystem0, human teleoperation or formal acceptance.',
            motion_test=dict(reg['motion_test'],command_bank=str(commandbank),random_episode=0,paired_versions=[107,108],
                            guard_mode='none' if v==107 else 'deterministic_source_proxy_command_filter',actual_learned_System0_active=False),
            private_asset_settings=dict(reg['private_asset_settings'],private_directory=str(p/'private_kit_user_data')))
        sources={}
        for file in reg['source_sha256']:
            old=Path(file)
            if old.is_relative_to(B):dest=p/old.relative_to(B)
            elif old==H/'launch_native_clock_admission_v106.py':dest=launcher
            elif old==H/'audit_motion_capture106_v1.py':dest=capture
            else:dest=old
            sources[str(dest)]=sha(dest)
        for f in [Path(__file__),commandbank,planfile,bankfile,M/'RANDOM_ARM_GUARD_COMMAND_DIAGNOSTICS_V1.npz']:
            sources[str(f)]=sha(f)
        new['source_sha256']=sources;(p/'REGISTRATION_V1.json').write_text(json.dumps(new,indent=2)+'\n')
    report=dict(status='FROZEN_RANDOM_ARM_PAIR_COMMANDS_NATIVE_UNTESTED',selected_episode=0,original_source_proposal_ids=list(range(128,136)),
        full50_bank_native_executed=0,random_arm_pair_native_executed=0,
        guarded_source_proxy_minimum_m=float(np.min(minimums)),guarded_alpha_zero_controls=int((np.asarray(alphas)==0).sum()),
        per_arm_guarded_requested_departure_rad={a:float(abs(np.asarray(guarded[a])-initial[a]).max()) for a in ARMS},
        source_proxy_not_actual_native_shapes=True,no_physical_stopping_or_safety_certificate=True,
        original_physics_native_boundary_unchanged=True,formal_holdout_count=0,fullSystem0_accepted=False)
    (M/'RANDOM_ARM_COMMAND_PREPARATION_V1.json').write_text(json.dumps(report,indent=2)+'\n')
    print(report['status'],json.dumps(report),flush=True)

if __name__=='__main__':main()
