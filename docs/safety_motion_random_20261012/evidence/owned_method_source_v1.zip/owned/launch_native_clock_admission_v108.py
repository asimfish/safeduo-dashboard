"""Finite rescheduling of proven prelaunch rejection; at most one native child."""
from pathlib import Path
import copy,datetime,hashlib,json,os,subprocess,sys,time
H=Path(__file__).resolve().parent
P=H/'fourhand_native_probe_v108'
read=lambda p:json.loads(Path(p).read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()

def save(record):
    path=P/'RESOURCE_EXECUTION_V1.json';tmp=path.with_suffix('.tmp')
    tmp.write_text(json.dumps(record,indent=2)+'\n');tmp.replace(path)

def prelaunch_only(receipt,log,out,supervisor_receipt):
    jobs=receipt.get('jobs',[])
    if len(jobs)!=1:return False
    j=jobs[0]
    untouched=(j.get('actual_exit')==3 and j.get('resource_abort') is None
        and j.get('actual_native_pid') is None and not j.get('native_candidate_processes_including_owned_forks')
        and not j.get('cross_GPU_owned_contexts') and not out.exists()
        and all(x['owned_GPU_MiB']==0 for x in j['resource_samples']))
    if not untouched:return False
    text=log.read_text().strip()
    if not supervisor_receipt.exists():return text=='GPU_JOB_FAIL: requested GPU is not admissible'
    inner=read(supervisor_receipt)
    return (text=='' and inner['status']=='FAIL' and not inner['assigned_gpu_observed']
        and not inner['cross_gpu_observed']
        and inner['error']=='selected GPU exceeded its admission budget after lease acquisition')

def main():
    assert not (P/'RESOURCE_EXECUTION_V1.json').exists()
    assert read(H/'fourhand_native_probe_v106/INDEPENDENT_OPERATIONAL_MOTION_V1.json')['operational_motion_diagnostic_pass'], 'Random motion not admitted by moving-controller qualification'
    sys.path.insert(0,'/home/liyufeng/safeduo/tools')
    from isaac_gpu_job import query_gpu_samples,select_device,_lease_available,GpuJobError
    qualified=read(H/'fourhand_native_probe_v91/NATIVE_CLOCK91_DIAGNOSTIC_DECISION_V1.json')
    assert qualified['native_clock_qualified'] and qualified['unchanged_native_physical_parameter_arrays']==75
    assert read(H/'fourhand_native_probe_v92/OWNED_NATIVE_SWEEP92_PURITY_V1.json')['disabled_boundary_bytewise_pure']
    assert read(H/'fourhand_native_probe_v93/NATIVE_SWEEP93_DIAGNOSTIC_DECISION_V1.json')['eligible_for_further_loaded_qualification']
    assert read(H/'fourhand_native_probe_v98/LOADED_NATIVE98_DIAGNOSTIC_DECISION_V1.json')['long_known_state_model_diagnostic_pass']
    reg=read(P/'REGISTRATION_V1.json')
    env=dict(os.environ,LD_LIBRARY_PATH=reg['scoped_driver_library_path'])
    os.environ['LD_LIBRARY_PATH']=reg['scoped_driver_library_path']
    deadline=time.monotonic()+900
    record=dict(status='waiting_resource',started_utc=now(),max_wait_seconds=900,
        native_launches=0,finite_supervisor_attempts=0,samples=[],prelaunch_rejections=[],
        maximum_owned_GPU_MiB=7680,runtime_floor_free_MiB=4096,initial_free_MiB=12288,
        utilization_ceiling_percent=80,scientific_acceptance=False,fullSystem0_accepted=False)
    save(record);consecutive=0
    try:
        while time.monotonic()<deadline:
            samples=query_gpu_samples()
            try:
                selected=select_device(samples,requested='cuda:1',policy='shared',required_free_mib=12288,
                    max_utilization_percent=80,lease_available=lambda i,p:_lease_available(H/'gpu_private_driver_runtime_v1/leases',i,p))
            except GpuJobError:selected=None
            consecutive=consecutive+1 if selected==1 else 0
            record['samples'].append(dict(utc=now(),selected_gpu=selected,consecutive=consecutive,
                GPUs=[dict(index=s.index,free_MiB=s.memory_free_mib,utilization_percent=s.utilization_percent) for s in samples]))
            save(record)
            if consecutive<2:time.sleep(20);continue
            for f,d in reg['source_sha256'].items():assert sha(f)==d,f
            index=record['finite_supervisor_attempts'];assert index<6,'six prelaunch rejections retained; scheduling stopped'
            tag=f'fourhand_native_probe_v108_dispatch{index}'
            plan=copy.deepcopy(read(H/'FOURHAND_NATIVE_PROBE_PLAN_V88.json'))
            plan.update(tag=tag,gpu_index=1,sources={**reg['source_sha256'],str(P/'REGISTRATION_V1.json'):sha(P/'REGISTRATION_V1.json')})
            root=Path('/mnt/nas/data/lyf/double_hand/safety_physical_qualified_random_20261009_1613/strong_random_recipe_v1')/tag
            root.mkdir(exist_ok=False);out=root/'native_case23';job=plan['jobs'][0]
            old_out=job['out'];job['out']=str(out)
            jobid=f'fourhand-microstep-convergence-v108-dispatch{index}'
            argv=[]
            for value in job['argv']:
                if value==old_out:value=str(out)
                else:value=value.replace('fourhand_native_probe_v88','fourhand_native_probe_v108')
                if value=='fourhand-microstep-convergence-v88':value=jobid
                argv.append(value)
            argv[argv.index('--timeout-seconds')+1]='1200'
            job['max_wall_seconds']=1200
            job['argv']=argv
            job['env']['LD_PRELOAD']=reg['native_sweep_spike']['library']
            assert argv[argv.index('--out')+1]==job['out'],'native output argv must match frozen plan output'
            supervisor_receipt=H/'gpu_private_driver_runtime_v1/jobs'/jobid/'receipt.json'
            job['gpu_supervisor_receipt']=str(supervisor_receipt)
            planpath=H/f'FOURHAND_NATIVE_PROBE_PLAN_V108_DISPATCH{index}.json';assert not planpath.exists()
            planpath.write_text(json.dumps(plan,indent=2)+'\n')
            record.update(status='running_finite_supervisor',finite_supervisor_attempts=index+1,
                gpu_index=1,launch_utc=now(),plan_sha256=sha(planpath));save(record)
            with (P/f'finite_dispatch{index}.log').open('xb') as log:
                child=subprocess.Popen(['/usr/bin/python3','-B',str(H/'execute_physical_plan_v4.py'),str(planpath)],
                    cwd=P,env=env,stdout=log,stderr=subprocess.STDOUT)
                record['finite_supervisor_pid']=child.pid;save(record);actual=child.wait()
            receiptpath=H/(tag+'_execution.json');receipt=read(receiptpath)
            logpath=H/(tag+'_common_beam_case23.log')
            if actual and prelaunch_only(receipt,logpath,out,supervisor_receipt):
                record['prelaunch_rejections'].append(dict(dispatch=index,finite_actual_exit=actual,
                    GPU_prelaunch_exit=3,native_launches=0,receipt=str(receiptpath),receipt_sha256=sha(receiptpath),
                    log_sha256=sha(logpath),utc=now()))
                record.update(status='waiting_resource',actual_last_finite_exit=actual);save(record)
                consecutive=0;time.sleep(20);continue
            j=receipt.get('jobs',[{}])[0]
            launched=bool(j.get('actual_native_pid') is not None or j.get('native_candidate_processes_including_owned_forks') or out.exists())
            record.update(actual_exit=actual,native_launches=int(launched),actual_native_exit=j.get('actual_native_exit'),
                actual_native_pid=j.get('actual_native_pid'),native_owned_process_reaped_and_absent=j.get('native_owned_process_reaped_and_absent'),out=str(out))
            save(record)
            assert actual==0,'non-prelaunch execution failure retained; never rescheduled'
            assert receipt['status']=='complete' and len(receipt['jobs'])==1
            j=receipt['jobs'][0];assert j['actual_exit']==j['actual_native_exit']==0 and j['native_owned_process_reaped_and_absent']
            record.update(native_launches=1,actual_native_exit=0,out=str(out));save(record)
            protocol=read(out/'fourhand_protocol.json');assert protocol['status']=='complete'
            assert protocol['physics_events']==reg['physics_substeps_per_control']*protocol['completed_controls']>0
            assert read(out/'point_contact_receipts.json')['physics_events']==protocol['physics_events']
            # These are custody-bound aliases; immutable dispatch originals stay intact.
            aliases=[]
            for original,alias in [(receiptpath,H/'fourhand_native_probe_v108_execution.json'),(planpath,H/'FOURHAND_NATIVE_PROBE_PLAN_V108.json')]:
                assert not alias.exists();alias.write_bytes(original.read_bytes())
                aliases.append(dict(original=str(original),alias=str(alias),sha256=sha(alias)))
            (P/'SUCCESSFUL_DISPATCH_ALIAS_CUSTODY_V1.json').write_text(json.dumps(dict(aliases=aliases),indent=2)+'\n')
            record.update(status='complete_native_probe_closed_independent_audit_pending',out=str(out),native_launches=1,
                task_status=protocol['task_status'],actual_native_exit=0,protocol_sha256=sha(out/'fourhand_protocol.json'),
                scientific_acceptance=False,independent_audit_complete=False,fullSystem0_accepted=False)
            print('ACTUAL_WAIT_NATIVE108',actual,protocol['task_status'],protocol['physics_events'],flush=True)
            return
        raise TimeoutError('finite900-second resource wait expired; no qualification')
    except BaseException as e:
        record.update(status='failed',error=repr(e));raise
    finally:
        record['closed_utc']=now();save(record)

if __name__=='__main__':main()
