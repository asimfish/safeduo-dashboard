"""Extend only the event ledger; preserve frozen16-pass convergence behavior."""
from pathlib import Path
import hashlib
import json
import shutil

H = Path(__file__).resolve().parent
OLD = H / 'spike/native_mimic_feedback_sweep16_v1'
P = H / 'spike/native_mimic_long_duration_v1'
assert not P.exists()
P.mkdir()
for name in ['bridge.cpp', 'native_boundary.py', 'fake_driver.cpp', 'test_boundary.py']:
    shutil.copyfile(OLD / name, P / name)
bridge = (P / 'bridge.cpp').read_text()
assert bridge.count('2048') == 5
(P / 'bridge.cpp').write_text(bridge.replace('2048', '8192'))
tests = (P / 'test_boundary.py').read_text()
assert tests.count('2048') == 2
(P / 'test_boundary.py').write_text(tests.replace('2048', '8192').replace('CPU_ONLY13_BOUNDARY_CASES', 'CPU_ONLY14_BOUNDARY_CASES'))
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
record = dict(status='PREPARED_CAPACITY_ONLY8192_SPIKE_NO_NATIVE_CLAIM',
              changed_bridge_literals=5, event_ledger_capacity_before=2048, event_ledger_capacity_after=8192,
              extra_pass_count_unchanged=16, retained_CPU_scenarios=14,
              old_source_sha256={str(OLD / n): sha(OLD / n) for n in ['bridge.cpp', 'test_boundary.py', 'fake_driver.cpp', 'native_boundary.py']},
              new_source_sha256={str(P / n): sha(P / n) for n in ['bridge.cpp', 'test_boundary.py', 'fake_driver.cpp', 'native_boundary.py']})
(P / 'CAPACITY_ONLY_SOURCE_DIFF_V1.json').write_text(json.dumps(record, indent=2) + '\n')
print('PREPARED8192_CAPACITY_ONLY_SPIKE;16_PASSES_AND_ALL_BOUNDARY_SEMANTICS_UNCHANGED')
