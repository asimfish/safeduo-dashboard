"""Freeze one duration-only extension: identical feedback102, 2048 events."""
from pathlib import Path
import copy
import datetime
import hashlib
import json
import shutil

H = Path(__file__).resolve().parent
OLD = H / 'fourhand_native_probe_v102'
P = H / 'fourhand_native_probe_v103'
read = lambda p: json.loads(Path(p).read_text())
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()


def main():
    assert not P.exists()
    closed = read(OLD / 'LOADED_FEEDBACK_DIAGNOSTIC_DECISION_V2.json')
    assert closed['loaded_feedback_model_diagnostic_pass'] and closed['physics_events'] == 1024
    reg = copy.deepcopy(read(OLD / 'REGISTRATION_V1.json'))
    for f, d in reg['source_sha256'].items():
        assert sha(f) == d, f
    assert reg['native_sweep_spike']['event_ledger_capacity'] == 2048
    assert reg['native_sweep_spike']['extra_pass_count'] == 16
    assert reg['interior_hand_target_settings']['max_target_rate_rad_s'] == .1
    P.mkdir()
    for f in OLD.iterdir():
        if f.suffix in ['.py', '.usda'] or f.name == 'PRIVATE_KIT_USER_CONFIG_FROZEN_V1.json':
            shutil.copyfile(f, P / f.name)
    shutil.copytree(OLD / 'private_kit_user_data', P / 'private_kit_user_data')
    launcher = H / 'launch_native_clock_admission_v103.py'
    assert not launcher.exists()
    launcher.write_text((H / 'launch_native_clock_admission_v102.py').read_text().replace('v102', 'v103').replace('V102', 'V103').replace('NATIVE102', 'NATIVE103'))
    capture = H / 'audit_loaded_native_capture103_v1.py'
    assert not capture.exists()
    src = (H / 'audit_loaded_native_capture94_v1.py').read_text()
    old_assert = "assert reg['contact_reproducer']['maximum_physics_events']==1024 and reg['maximum_controls']==64"
    assert src.count(old_assert) == 1
    src = src.replace('declared1024-step known contact replay', 'declared2048-step duration-only known contact replay').replace(old_assert,
                      "assert version == 103 and reg['contact_reproducer']['maximum_physics_events']==2048 and reg['maximum_controls']==128")
    capture.write_text(src)
    reg.update(attempt_version=103, scientific_candidate_version=103, registered_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
               maximum_controls=128, expected_maximum_physics_events=2048,
               first64_physical_prefix_baseline=102, duration_prefix_baseline_version=102, duration_prefix_required_events=1024,
               change_scope='Duration-only extension of102 from1024 to2048 physical events. Same byte-identical worker, 16 native passes,0.10rad/s target rate, initial state, all77 physics/13 seed fields and original model/physical/prelift limits. First1024 all164 fields must match102. No lift, formal acceptance or new random case.')
    reg['contact_reproducer'] = dict(reg['contact_reproducer'], maximum_physics_events=2048)
    reg['private_asset_settings'] = dict(reg['private_asset_settings'], private_directory=str(P / 'private_kit_user_data'))
    sources = {}
    for f in reg['source_sha256']:
        out = Path(f.replace('fourhand_native_probe_v102', 'fourhand_native_probe_v103').replace('launch_native_clock_admission_v102', 'launch_native_clock_admission_v103'))
        if not out.exists():
            assert Path(f).is_relative_to(OLD), f
            out.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(f, out)
        sources[str(out)] = sha(out)
    for f in [Path(__file__), capture, H / 'loaded_duration_prefix_custody_v1.py', H / 'test_loaded_duration_prefix_custody_v1.py',
              H / 'audit_loaded_feedback_duration_v1.py', OLD / 'LOADED_FEEDBACK_DIAGNOSTIC_DECISION_V2.json', OLD / 'CORE_ACTUAL_EXIT_RECEIPTS_V102_V2.json']:
        sources[str(f)] = sha(f)
    assert sha(P / 'native_common_beam_v1.py') == sha(OLD / 'native_common_beam_v1.py')
    reg['source_sha256'] = sources
    (P / 'REGISTRATION_V1.json').write_text(json.dumps(reg, indent=2) + '\n')
    plan = dict(candidate=103, baseline=102, registered_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                only_changed_scientific_setting='maximum_duration1024->2048physics_events', maximum_native_executions=1,
                maximum_native_wall_s=600, maximum_scheduler_wait_s=900, maximum_physics_events=2048,
                native_event_ledger_capacity=2048, first1024_all164_physical_fields_identical102_required=True,
                all77_parameters_and13_seed_fields_identical98_required=True, original_q_AND_qd_tolerance=1e-4,
                all_original_physical_and_task_gates_unchanged=True, original_actual_hand_speed_prelift_limit_rad_s=.05,
                force_thresholds_N=dict(hold=6, resume=4, relax=8, maximum_intended=30, unintended=.1),
                formal_holdout_count=0, new_independent_random_cases=0, fullSystem0_accepted=False,
                abort='Retain every sample; original model/physical failure stops after the full16-microstep control period. Never rerun a native failure.',
                source_sha256={str(f): sha(f) for f in [Path(__file__), P / 'REGISTRATION_V1.json', launcher, capture,
                               H / 'loaded_duration_prefix_custody_v1.py', H / 'audit_loaded_feedback_duration_v1.py']})
    out = H / 'LOADED_FEEDBACK103_DURATION_PROSPECTIVE_PLAN_V1.json'
    assert not out.exists()
    out.write_text(json.dumps(plan, indent=2) + '\n')
    print('FROZEN103_DURATION_ONLY2048; WORKER102_IDENTICAL; ALL_ORIGINAL_THRESHOLDS_UNCHANGED', flush=True)


if __name__ == '__main__':
    main()
