"""Report closed duration experiments, including retained failures and full denominators."""
from pathlib import Path
import copy
import csv
import datetime
import hashlib
import html
import json
import re
import shutil
import subprocess
import zipfile
import xml.etree.ElementTree as ET

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
from native_video_pts_v1 import encode

P = Path(__file__).resolve().parent
H = P.parent
W = Path('/mnt/nas/data/lyf/double_hand/safeduo_dashboard_loaded_duration_20261012')
SLUG = 'safety_sustained_fourhand_20261012'
R = W / 'docs' / SLUG
read = lambda p: json.loads(Path(p).read_text())
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
esc = lambda x: html.escape(str(x))


def write(path, value):
    Path(path).write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')


def archive_parts(raw, version):
    files = sorted(f for f in raw.rglob('*') if f.is_file())
    groups = []
    current = []
    size = 0
    for f in files:
        n = f.stat().st_size
        if n > 70 * 1024 ** 2:
            if current:
                groups.append(current)
                current, size = [], 0
            groups.append([f])
        else:
            if size + n > 70 * 1024 ** 2 and current:
                groups.append(current)
                current, size = [], 0
            current.append(f)
            size += n
    if current:
        groups.append(current)
    entries = []
    for i, group in enumerate(groups, 1):
        out = R / f'evidence/native_{version}_complete_raw_part{i:02d}.zip'
        with zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as z:
            for f in group:
                z.write(f, str(f.relative_to(raw)))
        assert out.stat().st_size < 95 * 1024 ** 2
        entries.append(dict(version=version, part=i, path=str(out.relative_to(R)), sha256=sha(out), bytes=out.stat().st_size,
                            original_files=[dict(path=str(f.relative_to(raw)), sha256=sha(f), bytes=f.stat().st_size) for f in group]))
    assert {f['path'] for e in entries for f in e['original_files']} == {str(f.relative_to(raw)) for f in files}
    return entries


def longest(time, mask):
    start = None
    maximum = 0.
    for t, flag in zip(time, mask):
        if flag:
            if start is None:
                start = float(t)
            maximum = max(maximum, float(t) - start)
        else:
            start = None
    return maximum


def figure(name, fig):
    fig.savefig(R / f'figures/{name}.png', dpi=170, bbox_inches='tight')
    svg = R / f'figures/{name}.svg'
    fig.savefig(svg, bbox_inches='tight')
    svg.write_text('\n'.join(line.rstrip() for line in svg.read_text().splitlines()) + '\n')
    ET.parse(svg)
    plt.close(fig)


def main():
    assert not R.exists() and not (P / 'BUILD_MANIFEST_V1.json').exists()
    versions = [102, 103, 104]
    decisions, roots, regs = {}, {}, {}
    for v in versions:
        p = H / f'fourhand_native_probe_v{v}'
        assert read(p / f'ACTUAL_COMPLETION_EXIT_V{v}.json')['actual_outer_exit'] == 0
        core = p / f'CORE_ACTUAL_EXIT_RECEIPTS_V{v}.json'
        if v == 102:
            core = p / 'CORE_ACTUAL_EXIT_RECEIPTS_V102_V2.json'
        assert all(x['actual_exit'] == 0 for x in read(core)['actual_outer_exits'].values())
        decision = p / ('LOADED_FEEDBACK_DIAGNOSTIC_DECISION_V2.json' if v == 102 else 'LOADED_FEEDBACK_DURATION_DECISION_V1.json')
        decisions[v] = read(decision)
        roots[v] = Path(read(p / 'RESOURCE_EXECUTION_V1.json')['out'])
        regs[v] = read(p / 'REGISTRATION_V1.json')
    assert decisions[103]['loaded_feedback_model_diagnostic_pass'] and decisions[103]['physics_events'] == 2048
    R.mkdir()
    for name in ['evidence', 'media', 'figures']:
        (R / name).mkdir()
    css = re.search(r'<style>(.*?)</style>', (W / 'docs/safety_loaded_feedback_20261012/index.html').read_text(), re.S).group(1)
    curves, media, archives, rows, state_summary = {}, [], [], [], []
    assets = read(regs[103]['coupled_assets'])['assets']
    for v in versions:
        p, raw = H / f'fourhand_native_probe_v{v}', roots[v]
        if v > 102:
            archives.extend(archive_parts(raw, v))
        for name in ['REGISTRATION_V1.json', 'RESOURCE_EXECUTION_V1.json', f'ACTUAL_COMPLETION_EXIT_V{v}.json',
                     f'CORE_ACTUAL_EXIT_RECEIPTS_V{v}.json', f'CORE_ACTUAL_EXIT_RECEIPTS_V{v}_V2.json',
                     'INDEPENDENT_CAPTURE_AUDIT_V1.json', 'INDEPENDENT_NATIVE_MIMIC_WINDOW_V6.json', 'INDEPENDENT_FULL_MOTOR_EFFORT_V4.json',
                     'INDEPENDENT_LOADED_FEEDBACK_TARGETS100_V1.json', 'INDEPENDENT_LOADED_FEEDBACK_DECISIONS100_V1.json',
                     'INDEPENDENT_CAMERA_FRAMING_V2.json', 'CAMERA_FRAMING_ACTUAL_EXIT_V1.json',
                     'INDEPENDENT_LOAD_ONLY_PRELIFT_INTENT_V1.json', 'PRELIFT_INTENT_ACTUAL_EXIT_V1.json',
                     'LOADED104_CAUSAL_FRONTIER_V2.json', 'CAUSAL_FRONTIER_ACTUAL_EXIT_V2.json',
                     'PREFIX_PHYSICAL_CUSTODY_V1.json', 'DURATION_DECISION_ACTUAL_EXIT_V1.json', 'CPU_PREFLIGHT_ACTUAL_EXIT_V1.json']:
            if (p / name).exists():
                shutil.copyfile(p / name, R / f'evidence/{v}_{name}')
        write(R / f'evidence/{v}_DECISION_V1.json', decisions[v])
        with np.load(raw / 'native_parameters.npz', allow_pickle=False) as params:
            relations = []
            for a, asset in assets.items():
                names = params[a + '_joint_names'].tolist()
                for j in ET.parse(asset['original_URDF']).findall('joint'):
                    m = j.find('mimic')
                    if m is not None and j.get('name') in asset['hand_joint_names']:
                        relations.append((a, names.index(j.get('name')), names.index(m.get('joint')), float(m.get('multiplier', '1')), float(m.get('offset', '0'))))
            assert len(relations) == 24
            pieces = []
            for ch in read(raw / 'physics_chunks.json'):
                f = raw / ch['path']
                assert sha(f) == ch['sha256']
                with np.load(f, allow_pickle=False) as z:
                    qe, ve = [], []
                    for a, si, mi, m, o in relations:
                        qe.append(abs(z[a + '_native_q'][:, 0, si] - m * z[a + '_native_q'][:, 0, mi] - o))
                        ve.append(abs(z[a + '_native_qd'][:, 0, si] - m * z[a + '_native_qd'][:, 0, mi]))
                    pieces.append(np.column_stack([z['physics_event'], z['state_time_s'], np.max(qe, axis=0), np.max(ve, axis=0),
                        z['four_hand_normal_N'], z['prelift_friction_capacity_proxy_N'], z['prelift_weight_reserve_N'],
                        z['prelift_max_hand_speed_rad_s'], z['prelift_native_hand_min_margin_rad'], z['prelift_ready']]))
        data = curves[v] = np.concatenate(pieces)
        n = len(data)
        assert n == decisions[v]['physics_events']
        assert abs(float(data[:, 3].max()) - decisions[v]['original_qd_error_rad_s']) < 1e-12
        rows.extend([[v, *row.tolist()] for row in data])
        state_summary.append(dict(version=v, observed_events=n, planned_events=regs[v]['contact_reproducer']['maximum_physics_events'],
            per_hand_peak_normal_N=data[:, 4:8].max(axis=0).tolist(), per_hand_last_normal_N=data[-1, 4:8].tolist(),
            per_hand_contact_samples_above_point1_N=(data[:, 4:8] > .1).sum(axis=0).tolist(),
            per_hand_longest_contact_s=[longest(data[:, 1], data[:, k] > .1) for k in range(4, 8)],
            all_four_contact_samples=int((data[:, 4:8].min(axis=1) > .1).sum()),
            all_four_longest_contact_s=longest(data[:, 1], data[:, 4:8].min(axis=1) > .1),
            prelift_ready_samples=int(data[:, 12].sum()), prelift_ready_longest_s=longest(data[:, 1], data[:, 12].astype(bool)),
            capacity_peak_N=float(data[:, 8].max()), capacity_last_N=float(data[-1, 8]),
            final_hand_speed_rad_s=float(data[-1, 10]), final_joint_margin_rad=float(data[-1, 11]),
            independent_initial_states=1, new_random_cases=0, formal_holdout_count=0))
        frames = read(raw / 'camera_frames.json')
        for view in ['top', 'front', 'side', 'overview']:
            selected = sorted((x for x in frames if x['view'] == view), key=lambda x: x['state_time_s'])
            assert selected[0]['state_time_s'] == 0 and abs(selected[-1]['state_time_s'] - n / 960) <= 1e-12
            for f in selected:
                assert sha(raw / f['path']) == f['sha256']
            poster, video = R / f'media/{v}_{view}_last.png', R / f'media/{v}_{view}.mp4'
            shutil.copyfile(raw / selected[-1]['path'], poster)
            encoded = encode(raw, selected, video, P / f'encoded_source_{v}_{view}')
            media.append(dict(version=v, view=view, video=str(video.relative_to(R)), poster=str(poster.relative_to(R)),
                original_frames=selected, native_first_state_time_s=0, native_last_state_time_s=n / 960,
                final_frame_display_hold_s=1 / 15, exact_frame_pts=encoded, video_sha256=sha(video), poster_sha256=sha(poster)))
    header = ['version', 'physics_event', 'native_state_time_s', 'q_residual_max_rad', 'qd_residual_max_rad_s',
              'F_L_normal_N', 'F_R_normal_N', 'U_L_normal_N', 'U_R_normal_N', 'capacity_proxy_N', 'required_weight_reserve_N',
              'max_hand_speed_rad_s', 'min_joint_margin_rad', 'prelift_ready']
    with (R / 'PER_STEP_METRICS_V1.csv').open('w', newline='') as f:
        writer = csv.writer(f, lineterminator='\n')
        writer.writerow(header)
        writer.writerows(rows)
    write(R / 'CONTACT_AND_PRELIFT_SUMMARY_V1.json', dict(rows=state_summary, independent_states=1, success_rate_CI=None,
        reason_no_CI='One chosen development state and temporally dependent events do not define independent trials.'))
    write(R / 'RAW_ARCHIVE_MANIFEST_V1.json', dict(archives=archives, all_parts_required=True,
        baseline102_full_raw='../safety_loaded_feedback_20261012/evidence/native_102_complete_raw.zip'))
    write(R / 'MEDIA_TIMESTAMPS_AND_CUSTODY_V1.json', dict(videos=media, source='Original native RGB and recorded time stamps; final display hold adds no physical events.'))
    plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 10, 'axes.spines.top': False, 'axes.spines.right': False,
                         'axes.grid': True, 'grid.alpha': .2, 'svg.hashsalt': 'safeduo-sustained-fourhand'})
    colors = {102: '#718096', 103: '#157f82', 104: '#bb5c32'}
    fig, axes = plt.subplots(2, 2, figsize=(12, 7), sharex=True)
    for i, ax in enumerate(axes.flat):
        for v in versions:
            ax.plot(curves[v][:, 1], curves[v][:, 4 + i], color=colors[v], label=str(v), linewidth=1)
        ax.axhline(.1, color='#b91c1c', linestyle='--', label='Contact threshold 0.1N')
        ax.set_title(['F_L', 'F_R', 'U_L', 'U_R'][i])
        ax.set_ylabel('Native normal force (N)')
        ax.set_xlabel('Native time (s)')
    axes[0, 0].legend(fontsize=8)
    fig.tight_layout()
    figure('four_hand_contact', fig)
    fig, axes = plt.subplots(3, 1, figsize=(12, 9), sharex=True)
    for v in versions:
        d = curves[v]
        axes[0].plot(d[:, 1], d[:, 3], color=colors[v], label=str(v), linewidth=.9)
        axes[1].plot(d[:, 1], d[:, 8], color=colors[v], label=str(v), linewidth=.9)
        axes[2].plot(d[:, 1], d[:, 10], color=colors[v], label=str(v), linewidth=.9)
    axes[0].axhline(1e-4, color='#b91c1c', linestyle='--', label='Original qd limit')
    axes[1].axhline(5.518125, color='#b91c1c', linestyle='--', label='Original 1.25mg proxy requirement')
    axes[2].axhline(.05, color='#b91c1c', linestyle='--', label='Original prelift hand-speed limit')
    for ax, label in zip(axes, ['Original URDF qd residual (rad/s)', 'Friction capacity proxy (N)', 'Maximum actual hand speed (rad/s)']):
        ax.set_ylabel(label)
        ax.legend(fontsize=8)
    axes[-1].set_xlabel('Native time (s)')
    fig.tight_layout()
    figure('model_and_prelift', fig)
    matrix = copy.deepcopy(read(H / 'full_requirements_v1/EVIDENCE_MATRIX_V30.json'))
    matrix.update(revision=31, updated_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  latest_duration_development_evidence=decisions[104], fullSystem0_accepted=False,
                  latest_development_frontier='Duration-only loading; stable four-hand contact, prelift and fulltask require original independent acceptance.')
    assert matrix['rows'] == read(H / 'full_requirements_v1/EVIDENCE_MATRIX_V30.json')['rows']
    write(R / 'EVIDENCE_MATRIX_V31.json', matrix)
    matrix_path = H / 'full_requirements_v1/EVIDENCE_MATRIX_V31.json'
    assert not matrix_path.exists()
    write(matrix_path, matrix)
    source_files = [Path(__file__), P / 'native_video_pts_v1.py', P / 'test_native_video_pts_v1.py',
                    P / 'MEDIA_PTS_PROBE_V3/RESULT_V1.json', P / 'MEDIA_PTS_PROBE_V3/ACTUAL_EXIT_V1.json',
                    H / 'prepare_loaded_feedback103_v1.py', H / 'prepare_loaded_feedback104_v1.py',
                    H / 'prepare_long_duration_capacity_spike_v1.py', H / 'loaded_duration_prefix_custody_v1.py',
                    H / 'test_loaded_duration_prefix_custody_v1.py', H / 'audit_loaded_feedback_duration_v1.py',
                    H / 'audit_load_only_prelift_intent_v1.py', H / 'audit_native_camera_framing_v2.py',
                    H / 'audit_native_mimic_window_v6.py', H / 'audit_native_mimic_window_v5.py',
                    H / 'audit_full_motor_effort_native_v4.py', H / 'audit_owned_kernel_trace81_v1.py',
                    H / 'analyze_loaded104_frontier_v2.py',
                    H / 'audit_loaded_native_capture103_v1.py', H / 'audit_loaded_native_capture104_v1.py',
                    H / 'audit_loaded_feedback_decisions100_v1.py', H / 'audit_loaded_feedback_targets100_v1.py',
                    H / 'spike/native_mimic_long_duration_v1/bridge.cpp', H / 'spike/native_mimic_long_duration_v1/test_boundary.py',
                    H / 'spike/native_mimic_long_duration_v1/fake_driver.cpp', H / 'spike/native_mimic_long_duration_v1/native_boundary.py',
                    H / 'spike/native_mimic_long_duration_v1/CPU_BOUNDARY_VERIFICATION_V1.json',
                    Path('/home/liyufeng/safeduo/docs/adr/20261012-native-mimic-long-duration.md')]
    source_files.extend(Path(asset['original_URDF']) for asset in assets.values())
    source_files.extend(f for f in (H / 'fourhand_native_probe_v104').iterdir() if f.suffix in ['.py', '.usda'])
    source_files = list(dict.fromkeys(source_files))
    urdf_names = {Path(asset['original_URDF']): 'original_urdf/' + arm + '/' + Path(asset['original_URDF']).name for arm, asset in assets.items()}
    source_rows = []
    with zipfile.ZipFile(R / 'evidence/owned_method_source.zip', 'w', zipfile.ZIP_DEFLATED) as z:
        for f in source_files:
            name = str(f.relative_to(H)) if f.is_relative_to(H) else ('adr/' + f.name if f.suffix == '.md' else urdf_names[f])
            z.write(f, name)
            source_rows.append(dict(archive_path=name, source=str(f), sha256=sha(f)))
    write(R / 'METHOD_SOURCE_MANIFEST_V1.json', dict(source_files=source_rows, installed_native_kernel_source_unknown=True))
    for v in [103, 104]:
        shutil.copyfile(H / f'LOADED_FEEDBACK{v}_DURATION_PROSPECTIVE_PLAN_V1.json', R / f'evidence/{v}_PROSPECTIVE_PLAN_V1.json')
    toc = [('abstract', '摘要与当前判定'), ('questions', '研究问题'), ('setup', '系统与预先登记协议'),
           ('random', '随机范围与统计分母'), ('evaluation', '结果与抬升前门槛'), ('qualitative', '原生四视图视频'),
           ('failures', '失败与守卫响应'), ('limits', '结论边界'), ('acceptance', '九项完整验收'), ('reproduce', '数据与复现')]
    sections = []
    def section(i, body):
        identifier, title = toc[i - 1]
        sections.append(f'<section id="{identifier}"><h2><span class="number">{i:02d}</span>{title}</h2>{body}</section>')
    latest = decisions[104]
    frontier = read(H / 'fourhand_native_probe_v104/LOADED104_CAUSAL_FRONTIER_V2.json')
    section(1, '<p>延长同一开发初态的真实反馈夹持，检验此前短窗口结论能否保持。103完成2048步，原模型、物理、50电机与反馈审计通过，前1024步全部164字段复现102。104的实际完成长度、完整失败判定和四手持续接触列于下表。</p><p>本轮仍只有1个独立初态；正式留出0、新随机输入0，学习System 0关闭。诊断通过不能代替完整任务或安全泛化验收。</p>')
    section(2, '<ol><li>延长持续加载后，原24条URDF位置和速度约束及物理门槛是否仍成立？</li><li>另外两只手的短暂接触能否形成四手同时各&gt;0.1N连续0.25s？</li><li>力增加是否同时满足承载余量、低速、关节余量和稳定窗口？</li><li>HOLD/RELAX守卫的实际提交目标与物理响应是否一致？守卫标签本身不证明安全停止。</li></ol>')
    section(3, '<p>2 FR3/F2 + 2 UR5/DFX开发配置，26臂关节、48手关节、50独立电机；原生960Hz、控制60Hz、臂目标FIFO6=0.1s。梁0.04×0.70×0.08m、0.45kg；物理质量、惯量、摩擦与硬限位不变。使用原生对象真值，未验证视觉闭环。</p><p>102/103/104使用逐字节相同的反馈工作程序、16次追加求解和0.10rad/s逐物理步目标过滤。最大观测步数分别1024、2048、8192。104仅扩大记录容量2048→8192，原生ABI、配对、参数复制、返回和q/qd状态处理不变，14项CPU边界检查通过。原模型q与qd各≤10⁻⁴；全74关节超限/超速≤10⁻⁵，9021几何代理≥0，意外接触≤0.1N，手梁接触≤30N/手。没有运行中物体移动或绑定，也没有q/qd投影。</p><p>103要求前1024步复现102，104要求前2048步复现103，全部164物理字段包含标量与完整不等长接触数据。所有77物理参数和13初态字段分别核对98。原模型或物理失败保留样本，完整控制周期结束后停止；不能补写为完整通过。</p>')
    section(4, '<p>这是同一策略的三个观测时长对照，独立开发初态=1；不是3个随机样本或3种独立策略。新随机输入=0，正式独立留出=0。物理步具有时间依赖，不能当作独立安全成功次数，未报告IID成功率置信区间。</p><p>既有40000软件提案（32000 IID、4000边界、4000混合）、1225对和64分层，不能证明50维安全体积。历史128输入开发集不能替代冻结合格配置与策略后的两套新正式种子、每方法至少128次完整任务。<a href="../safety_loaded_feedback_20261012/#random">已有覆盖范围与缺口</a></p>')
    table = '<div class="scroll"><table><thead><tr><th>时长对照</th><th>实际/计划步</th><th>最大q / qd残差</th><th>原诊断门槛</th><th>四手连续窗口</th><th>完整任务</th></tr></thead><tbody>'
    for v in versions:
        d = decisions[v]
        table += f'<tr><td>{v} · {len(curves[v])/960:.4f}s</td><td>{len(curves[v])}/{regs[v]["contact_reproducer"]["maximum_physics_events"]}</td><td>{d["original_q_error_rad"]:.3g}rad / {d["original_qd_error_rad_s"]:.6g}rad/s</td><td>{"通过" if d["loaded_feedback_model_diagnostic_pass"] else "未通过"}</td><td>{d["four_hand_close_s"]:.6f}s</td><td>未通过</td></tr>'
    table += '</tbody></table></div>'
    contact = '<h3>四手各自接触与持续观测</h3><div class="scroll"><table><thead><tr><th>记录</th><th>手</th><th>峰值 / 末步力 N</th><th>超过0.1N的物理步</th><th>最长连续观测 s</th></tr></thead><tbody>'
    for summary in state_summary:
        for i, arm in enumerate(['F_L', 'F_R', 'U_L', 'U_R']):
            contact += f'<tr><td>{summary["version"]}</td><td>{arm}</td><td>{summary["per_hand_peak_normal_N"][i]:.4f} / {summary["per_hand_last_normal_N"][i]:.4f}</td><td>{summary["per_hand_contact_samples_above_point1_N"][i]}</td><td>{summary["per_hand_longest_contact_s"][i]:.6f}</td></tr>'
    contact += '</tbody></table></div><h3>抬升前必要条件</h3><div class="scroll"><table><thead><tr><th>记录</th><th>承载代理峰值 / 末步 N</th><th>末步手速度 rad/s</th><th>末步余量 rad</th><th>就绪条件最长观测 s</th></tr></thead><tbody>'
    for summary in state_summary:
        contact += f'<tr><td>{summary["version"]}</td><td>{summary["capacity_peak_N"]:.4f} / {summary["capacity_last_N"]:.4f}</td><td>{summary["final_hand_speed_rad_s"]:.6f}</td><td>{summary["final_joint_margin_rad"]:.6f}</td><td>{summary["prelift_ready_longest_s"]:.6f}</td></tr>'
    contact += '</tbody></table></div>'
    section(5, table + contact + '<figure><img src="figures/four_hand_contact.png" alt="四只手各自原生接触法向力与0.1N原门槛"><figcaption>单手峰值与四手同时持续接触分开验收。原始逐步数据包含全部四手。</figcaption></figure><figure><img src="figures/model_and_prelift.png" alt="原URDF速度误差、承载代理和实际手速度及原门槛"><figcaption>μΣN≥1.25mg=5.518125N只是必要承载代理，仍需手速度≤0.05rad/s、余量≥0.02rad、无守卫及稳定窗；不能取代真实100mm/2s抬升。</figcaption></figure><p><a href="PER_STEP_METRICS_V1.csv">全部逐步CSV</a> · <a href="CONTACT_AND_PRELIFT_SUMMARY_V1.json">各手接触与抬升前摘要</a> · <a href="figures/four_hand_contact.svg">四手矢量图</a> · <a href="figures/model_and_prelift.svg">模型与承载矢量图</a></p>')
    videos = ''
    for v in versions:
        videos += f'<h3>{v} · 实际记录 {len(curves[v])/960:.4f}s</h3><div class="video-grid">'
        for item in [x for x in media if x['version'] == v]:
            title = {'top': '俯视', 'front': '正视', 'side': '侧视', 'overview': '全景'}[item['view']]
            videos += f'<figure><video controls preload="metadata" playsinline poster="{item["poster"]}"><source src="{item["video"]}" type="video/mp4"></video><figcaption>{title} · 原生时戳0–{item["native_last_state_time_s"]:.4f}s</figcaption></figure>'
        videos += '</div>'
    section(6, videos + '<p>全部原生相机帧、实际时戳与SHA绑定；失败结束帧保留。末帧显示另有约0.067s停留，不增加物理步数。视频外观不能证明抓取成功。<a href="MEDIA_TIMESTAMPS_AND_CUSTODY_V1.json">原帧与媒体对应清单</a></p>')
    modes = '<div class="scroll"><table><thead><tr><th>记录</th><th>手</th><th>SEEK</th><th>HOLD</th><th>RELAX</th><th>JOINT_GUARD</th></tr></thead><tbody>'
    for v in versions:
        for arm, c in decisions[v]['feedback_mode_counts'].items():
            modes += f'<tr><td>{v}</td><td>{arm}</td>' + ''.join(f'<td>{c[k]}</td>' for k in ['SEEK', 'HOLD', 'RELAX', 'JOINT_GUARD']) + '</tr>'
    modes += '</tbody></table></div>'
    failure = frontier['first_original_relation_violation']
    guard_table = '<div class="scroll"><table><thead><tr><th>手与模式</th><th>实际目标仍闭合的物理步 / 模式步</th><th>最高实际闭合目标速率 rad/s</th><th>首次模式时的名义/提交目标差 rad</th></tr></thead><tbody>'
    for arm, hand in frontier['hand_observations'].items():
        for mode, observation in hand['guard_target_motion'].items():
            guard_table += f'<tr><td>{arm} · {mode}</td><td>{observation["actual_target_closing_samples"]}/{observation["samples"]}</td><td>{observation["maximum_actual_closing_rate_rad_s"]:.6f}</td><td>{observation["nominal_to_actual_target_gap_at_first_event_rad"]:.6f}</td></tr>'
    guard_table += '</tbody></table></div>'
    failure_text = f'<p>104计划8192步，在第{failure["event"]}步（{failure["time_s"]:.6f}s）{esc(failure["arm"])}的{esc(failure["slave"])}首次超过原速度关系门槛；当时模式为{esc(failure["mode"])}。整个16步控制周期保留，到7392步停止。完整独立审计最大残差{latest["original_qd_error_rad_s"]:.8g}rad/s&gt;10⁻⁴，因此原模型判定失败；物理门槛通过并不能抵消此失败。</p>'
    section(7, failure_text + modes + '<p>103四手同时超过0.1N仅有2个孤立样本，最长连续窗口0s。104虽增加至0.09375s，仍低于0.25s；抬升前意图为0，实际抬升为0。</p>' + guard_table + '<p>HOLD冻结名义进度时，实际提交目标仍以约0.10rad/s继续闭合；RELAX也捕获到仍闭合的区间。这是实际命令观测，不单独证明物理越界或原生速度关系失败的原因。另两手末步已接近名义目标、运动趋于稳定，但对梁法向力均为0；仅延长时间无法解释或修复此时的接触缺失。</p><p>下一步分别检验：HOLD是否应锚定实际提交目标、RELAX是否应立即撤回；另外两手的操作端点与布局是否留住接触；加载下原生速度关系是否需要不同收敛处理。每个假设独立对照，保留原模型和物理阈值。<a href="evidence/104_LOADED104_CAUSAL_FRONTIER_V2.json">原始观测、失败关系与可证伪方案</a></p>')
    section(8, '<p>本报告只覆盖已知接触初态的持续反馈诊断。四手完整抬升、搬运、放置、释放和退回尚未通过；正式2 FR3 + 2 JAKA + 4 RH56F2配置尚未合格。9021点为几何代理，连续扫掠与原生烹饪网格仍未认证；真实视觉感知、硬件与学习System 0均未认证。</p><p>安装的原生求解器源提交未知，只绑定实际ABI、调用返回、原生状态及独立原URDF审计。所有新结果不增加正式随机分母，不改变原九项验收要求。</p>')
    acceptance = '<div class="scroll"><table><thead><tr><th>要求</th><th>原门槛</th><th>状态</th><th>未完成项</th></tr></thead><tbody>'
    for row in matrix['rows']:
        acceptance += '<tr><td>' + esc(row['id']) + ' · ' + esc(row['requirement']) + '</td><td>' + esc(row['gate']) + '</td><td>' + esc(row['status']) + '</td><td>' + esc(row['missing']) + '</td></tr>'
    section(9, acceptance + '</tbody></table></div><p><a href="EVIDENCE_MATRIX_V31.json">原九项门槛与证据矩阵</a>；九项尚未共同达标。</p>')
    downloads = '<ul><li><a href="../safety_loaded_feedback_20261012/evidence/native_102_complete_raw.zip">102完整原始数据</a></li>'
    for entry in archives:
        downloads += f'<li><a href="{entry["path"]}">{entry["version"]}完整原始数据 · 第{entry["part"]}包</a>（{entry["bytes"]/1024**2:.1f}MiB）</li>'
    downloads += '</ul>'
    section(10, downloads + '<p>同一运行的全部ZIP分包共同组成完整原始记录，解压到同一目录；原始文件没有切割、筛选或舍弃。<a href="RAW_ARCHIVE_MANIFEST_V1.json">逐文件归档与哈希清单</a> · <a href="evidence/owned_method_source.zip">实验、审计和CPU边界源码</a> · <a href="METHOD_SOURCE_MANIFEST_V1.json">源码哈希</a> · <a href="PUBLIC_MANIFEST_V1.json">当前网页文件清单</a></p><p>先核验原文件、参数和初态，再按原URDF复算24关系、82点接触、9021几何、74关节、50电机和真实反馈命令。<a href="../safety_loaded_feedback_20261012/">前版完整方法对照与失败</a>。报告组织参考<a href="https://anonymous-report-421.github.io/public-website/?lang=en&amp;view=">具身任务报告</a>、<a href="https://robodojo-benchmark.com/report/gpt-6-astra-eval">RoboDojo</a>及<a href="https://github.com/zjwzcx/Awesome-Astra-Embodied-AI">具身AI资料</a>，外部报告数据不作为本项目结果。</p>')
    nav = ''.join(f'<a href="#{key}">{i:02d} {esc(title)}</a>' for i, (key, title) in enumerate(toc, 1))
    page = f'<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>SafeDuo 持续加载与四手夹持报告</title><style>{css}</style></head><body><header><div class="hero"><div class="topline"><span class="brand">SAFEDUO / RESEARCH REPORT</span><a href="../../#scientific">返回实验主面板 ↗</a></div><p class="eyebrow">Simulation · Duration controls · 12 October 2026</p><h1>持续加载<br>与四手稳定夹持</h1><p class="subtitle">相同策略与原安全门槛下，延长真实加载窗口，逐手检验接触、承载和稳定性。</p><p class="meta">原生960Hz / 控制60Hz / FIFO6 · 16次追加求解 · 0.10rad/s目标速率</p><div class="verdict"><strong>九项要求尚未全部达标。</strong><p>2048步诊断通过；最新更长窗口的实际完成、失败和抬升前条件独立列示。完整任务未通过，学习System 0关闭，正式留出0。</p></div><div class="actions"><a class="button primary" href="#evaluation">实测结果</a><a class="button" href="#qualitative">四视图视频</a><a class="button" href="#failures">守卫与失败</a><a class="button" href="#reproduce">完整数据</a></div><div class="metrics"><div class="metric"><strong>{len(curves[104])}步</strong><span>最新实际观测 · 计划8192步</span></div><div class="metric"><strong>1个初态</strong><span>相同策略 · 三个时长对照</span></div><div class="metric"><strong>{latest["four_hand_close_s"]:.3f}s</strong><span>四手同时接触 · 原门槛0.25s</span></div><div class="metric"><strong>0</strong><span>正式独立留出样本</span></div></div></div></header><div class="layout"><nav class="toc" aria-label="报告目录"><b>ON THIS PAGE / 目录</b>{nav}</nav><main>{"".join(sections)}</main></div><footer>SafeDuo · 2026-10-12 · 持续反馈开发诊断；完整System 0验收仍未通过。</footer></body></html>'
    (R / 'index.html').write_text(page)
    root = W / 'index.html'
    before = root.read_text()
    needle = '<div class="sci-note" id="loadedFeedbackEvidence">'
    assert before.count(needle) == 1 and 'id="sustainedFourhandEvidence"' not in before
    card = f'<div class="sci-note" id="sustainedFourhandEvidence"><b>最新科研报告：持续加载与四手稳定夹持</b><p>2048步原模型与物理诊断通过；新增最长8192步时长对照，记录实际完成长度、四手接触、承载余量和守卫响应。12路原生视频、全部原始分包和失败可复核。完整任务仍未通过，System 0关闭，正式留出0。</p><a href="docs/{SLUG}/">查看最新报告、四手曲线与视频 →</a></div>\n'
    root.write_text(before.replace(needle, card + needle))
    manifest = [dict(path=str(f.relative_to(W)), sha256=sha(f), bytes=f.stat().st_size) for f in sorted(R.rglob('*')) if f.is_file()]
    write(R / 'PUBLIC_MANIFEST_V1.json', dict(files=manifest, manifest_self_excluded=True, fullSystem0_accepted=False))
    manifest.extend(dict(path=str(f.relative_to(W)), sha256=sha(f), bytes=f.stat().st_size) for f in [R / 'PUBLIC_MANIFEST_V1.json', root])
    write(P / 'BUILD_MANIFEST_V1.json', dict(files=manifest, base_commit=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=W, text=True).strip(),
        prior_root_sha256=hashlib.sha256(before.encode()).hexdigest(), root_addition_only=True, versions=versions, scientific_all9_pass=False, formal_holdout_count=0))
    print('BUILT_DURATION_REPORT', len(manifest), 'FILES;', len(media), 'NATIVE_VIDEOS;ALL9_FALSE_FORMAL0', flush=True)


if __name__ == '__main__':
    main()
