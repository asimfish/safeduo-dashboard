"""Real installed FFmpeg: retain regular frames and an early-failure partial interval."""
from pathlib import Path
import json

from native_video_pts_v1 import encode

P = Path(__file__).resolve().parent
H = P.parent
output = P / 'MEDIA_PTS_PROBE_V3'
output.mkdir(exist_ok=False)
records = []
for version in [100, 103]:
    raw = Path(json.loads((H / f'fourhand_native_probe_v{version}/RESOURCE_EXECUTION_V1.json').read_text())['out'])
    frames = [x for x in json.loads((raw / 'camera_frames.json').read_text()) if x['view'] == 'overview']
    if version == 103:
        frames = frames[:4]
    record = encode(raw, frames, output / f'{version}.mp4', output / f'source_{version}')
    record['version'] = version
    records.append(record)
(output / 'RESULT_V1.json').write_text(json.dumps(dict(status='PASS_REGULAR_AND_PARTIAL_INTERVAL_NATIVE_PTS', records=records), indent=2) + '\n')
print('PASS_NATIVE_PTS_REGULAR_AND_PARTIAL_INTERVAL_ALL_ORIGINAL_FRAMES', [(r['version'], r['measured_frame_pts_s']) for r in records])
