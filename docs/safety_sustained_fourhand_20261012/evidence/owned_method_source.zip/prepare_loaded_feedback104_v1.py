"""Duration-only8192 with a capacity-only bridge; original feedback103 retained."""
from pathlib import Path
import copy
import datetime
import hashlib
import json
import shutil

H = Path(__file__).resolve().parent
OLD = H / 'fourhand_native_probe_v103'
P = H / 'fourhand_native_probe_v104'
S = H / 'spike/native_mimic_long_duration_v1'
read = lambda p: json.loads(Path(p).read_text())
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()


def main():
    assert not P.exists()
    decision = read(OLD / 'LOADED_FEEDBACK_DURATION_DECISION_V1.json')
    assert decision['loaded_feedback_model_diagnostic_pass'] and decision['physics_events'] == 2048
    cpu = read(S / 'CPU_BOUNDARY_VERIFICATION_V1.json')
    assert cpu['actual_exit'] == 0 and cpu['CPU_boundary_scenarios'] == 14
    for f, d in cpu['source_sha256'].items():
        assert sha(f) == d, f
    reg = copy.deepcopy(read(OLD / 'REGISTRATION_V1.json'))
    for f, d in reg['source_sha256'].items():
        assert sha(f) == d, f
    P.mkdir()
    for f in OLD.iterdir():
        if f.suffix in ['.py', '.usda'] or f.name == 'PRIVATE_KIT_USER_CONFIG_FROZEN_V1.json':
            shutil.copyfile(f, P / f.name)
    shutil.copytree(OLD / 'private_kit_user_data', P / 'private_kit_user_data')
    launcher = H / 'launch_native_clock_admission_v104.py'
    assert not launcher.exists()
    text = (H / 'launch_native_clock_admission_v103.py').read_text().replace('v103', 'v104').replace('V103', 'V104').replace('NATIVE103', 'NATIVE104')
    needle = "            job['argv']=argv"
    assert text.count(needle) == 1
    text = text.replace(needle, "            argv[argv.index('--timeout-seconds')+1]='1800'\n            job['max_wall_seconds']=1800\n" + needle)
    launcher.write_text(text)
    capture = H / 'audit_loaded_native_capture104_v1.py'
    assert not capture.exists()
    text = (H / 'audit_loaded_native_capture103_v1.py').read_text()
    old_assert = "assert version == 103 and reg['contact_reproducer']['maximum_physics_events']==2048 and reg['maximum_controls']==128"
    assert text.count(old_assert) == 1
    capture.write_text(text.replace('declared2048-step duration-only', 'declared8192-step duration-only').replace(old_assert,
                      "assert version == 104 and reg['contact_reproducer']['maximum_physics_events']==8192 and reg['maximum_controls']==512"))
    reg.update(attempt_version=104, scientific_candidate_version=104, registered_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
               maximum_controls=512, expected_maximum_physics_events=8192, first64_physical_prefix_baseline=103,
               duration_prefix_baseline_version=103, duration_prefix_required_events=2048,
               change_scope='Duration-only2048->8192events and capacity-only bridge2048->8192. Same worker103,16 native passes,0.10rad/s target rate, initial state,77 physics/13 seed fields, original q AND qd/physical/prelift thresholds. First2048all164 physical fields must match103. Execution-only cap1800s from measured337.69s/2048; no lift, formal acceptance or new random case.')
    reg['contact_reproducer'] = dict(reg['contact_reproducer'], maximum_physics_events=8192)
    reg['native_sweep_spike'] = dict(reg['native_sweep_spike'], library=str(S / 'bridge.so'), event_ledger_capacity=8192)
    reg['private_asset_settings'] = dict(reg['private_asset_settings'], private_directory=str(P / 'private_kit_user_data'))
    sources = {}
    for f in reg['source_sha256']:
        out = Path(f.replace('fourhand_native_probe_v103', 'fourhand_native_probe_v104').replace('launch_native_clock_admission_v103', 'launch_native_clock_admission_v104').replace('audit_loaded_native_capture103_v1.py', 'audit_loaded_native_capture104_v1.py'))
        if not out.exists():
            assert Path(f).is_relative_to(OLD), f
            out.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(f, out)
        sources[str(out)] = sha(out)
    for f in [Path(__file__), S / 'CPU_BOUNDARY_VERIFICATION_V1.json', H / 'prepare_long_duration_capacity_spike_v1.py',
              OLD / 'LOADED_FEEDBACK_DURATION_DECISION_V1.json', OLD / 'PREFIX_PHYSICAL_CUSTODY_V1.json',
              OLD / 'CORE_ACTUAL_EXIT_RECEIPTS_V103.json', Path('/home/liyufeng/safeduo/docs/adr/20261012-native-mimic-long-duration.md')]:
        sources[str(f)] = sha(f)
    sources.update(cpu['source_sha256'])
    assert sha(P / 'native_common_beam_v1.py') == sha(OLD / 'native_common_beam_v1.py')
    reg['source_sha256'] = sources
    (P / 'REGISTRATION_V1.json').write_text(json.dumps(reg, indent=2) + '\n')
    plan = dict(candidate=104, baseline=103, registered_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                only_changed_scientific_setting='maximum_observation_duration2048->8192physics_events',
                execution_capacity_only_change='event_ledger2048->8192;16 passes and all boundary semantics unchanged',
                maximum_native_executions=1, maximum_native_wall_s=1800, maximum_scheduler_wait_s=900,
                runtime_cap_rationale='Observed103 launch-to-close337.690802s for2048;4x=1350.763208s,1800s allows33.26% slack.',
                maximum_physics_events=8192, native_event_ledger_capacity=8192, physics_Hz=960,
                first2048_all164_physical_fields_identical103_required=True, all77_parameters_and13_seed_fields_identical98_required=True,
                original_q_AND_qd_tolerance=1e-4, all_original_physical_and_task_gates_unchanged=True,
                original_actual_hand_speed_prelift_limit_rad_s=.05, formal_holdout_count=0, new_independent_random_cases=0,
                fullSystem0_accepted=False, no_lift_enabled=True,
                abort='Keep original failure abort after complete16-step control period; all failed samples retained; no native failure rerun.',
                source_sha256={str(f): sha(f) for f in [Path(__file__), P / 'REGISTRATION_V1.json', launcher, capture,
                               S / 'CPU_BOUNDARY_VERIFICATION_V1.json', H / 'audit_loaded_feedback_duration_v1.py']})
    q = H / 'LOADED_FEEDBACK104_DURATION_PROSPECTIVE_PLAN_V1.json'
    assert not q.exists()
    q.write_text(json.dumps(plan, indent=2) + '\n')
    print('FROZEN104_DURATION8192;CAPACITY_ONLY8192;WORKER103_IDENTICAL;ORIGINAL_MODEL_AND_PHYSICAL_GATES_UNCHANGED', flush=True)


if __name__ == '__main__':
    main()
