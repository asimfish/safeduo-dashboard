"""Duration comparisons must catch corruption after the former 64-step prefix."""
from pathlib import Path
import json
import tempfile
import unittest

import numpy as np

from loaded_duration_prefix_custody_v1 import compare_prefix, sha
from loaded_prefix_custody_v2 import compare_first64


class DurationPrefix(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.a = Path(self.temp.name) / 'candidate'
        self.b = Path(self.temp.name) / 'baseline'
        self.write(self.a)
        self.write(self.b)

    def tearDown(self):
        self.temp.cleanup()

    def write(self, p, change=None, count=32):
        p.mkdir(exist_ok=True)
        ledger = []
        for start in range(0, count * 32, 32):
            z = dict(state_time_s=(np.arange(start, start + 32) + 1) / 960,
                     physics_event=np.arange(start, start + 32), schema=np.asarray('ragged-v1'),
                     points=np.arange(352 * 3, dtype=np.float64).reshape(352, 3),
                     offsets=np.arange(33, dtype=np.int64) * 11)
            z.update({f'field_{i}': np.arange(32, dtype=np.float32) for i in range(159)})
            if start == 992 and change:
                change(z)
            f = p / f'physics_{start:05d}_{start + 32:05d}.npz'
            np.savez(f, **z)
            ledger.append(dict(start=start, stop=start + 32, path=f.name, sha256=sha(f)))
        (p / 'physics_chunks.json').write_text(json.dumps(ledger))

    def test_all1024_events_and164_complete_fields(self):
        r = compare_prefix(self.a, self.b, 1024)
        self.assertTrue(r['all_fields_byte_identical'])
        self.assertEqual(r['field_comparisons'], 5248)
        self.assertEqual(r['chunks'], 32)

    def test_late_ragged_point_beyond_time_row_count(self):
        self.write(self.a, lambda z: z['points'].__setitem__((200, 2), -12345))
        self.assertTrue(compare_first64(self.a, self.b)['all_fields_byte_identical'])
        r = compare_prefix(self.a, self.b, 1024)
        self.assertEqual([(x['start'], x['field']) for x in r['rows'] if not x['byte_identical']], [(992, 'points')])

    def test_terminal_offset_scalar_and_dtype_changes(self):
        for field, change in [('offsets', lambda z: z['offsets'].__setitem__(32, 11111)),
                              ('schema', lambda z: z.__setitem__('schema', np.asarray('changed'))),
                              ('field_0', lambda z: z.__setitem__('field_0', z['field_0'].astype(np.float64)))]:
            with self.subTest(field=field):
                self.write(self.a, change)
                r = compare_prefix(self.a, self.b, 1024)
                self.assertEqual([x['field'] for x in r['rows'] if not x['byte_identical']], [field])

    def test_missing_final_chunk_is_rejected(self):
        self.write(self.a, count=31)
        with self.assertRaisesRegex(ValueError, 'not fully captured'):
            compare_prefix(self.a, self.b, 1024)

    def test_corrupt_hash_is_rejected(self):
        f = self.a / 'physics_00992_01024.npz'
        f.write_bytes(f.read_bytes() + b'corrupted')
        with self.assertRaisesRegex(ValueError, 'hash mismatch'):
            compare_prefix(self.a, self.b, 1024)

    def test_ledger_event_and_schema_mismatch_are_rejected(self):
        for pattern, change in [('event identities', lambda z: z['physics_event'].__setitem__(31, 1024)),
                                ('Exactly164', lambda z: z.pop('field_0'))]:
            with self.subTest(pattern=pattern):
                self.write(self.a, change)
                with self.assertRaisesRegex(ValueError, pattern):
                    compare_prefix(self.a, self.b, 1024)
        self.write(self.a)
        path = self.a / 'physics_chunks.json'
        ledger = json.loads(path.read_text())
        ledger[-1]['start'] = 991
        path.write_text(json.dumps(ledger))
        with self.assertRaisesRegex(ValueError, 'contiguous'):
            compare_prefix(self.a, self.b, 1024)

    def test_partial_or_invalid_requested_prefix_rejected(self):
        for n in (0, -32, 1000, True, 1024.0):
            with self.subTest(n=n), self.assertRaisesRegex(ValueError, 'positive multiple'):
                compare_prefix(self.a, self.b, n)


if __name__ == '__main__':
    unittest.main()
