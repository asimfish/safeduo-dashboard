"""Separate observed control/geometry gaps from unknown native solver root cause."""
from pathlib import Path
import hashlib
import json
import xml.etree.ElementTree as ET

import numpy as np

H = Path(__file__).resolve().parent
P = H / 'fourhand_native_probe_v104'
read = lambda p: json.loads(Path(p).read_text())
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()


def main():
    out = P / 'LOADED104_CAUSAL_FRONTIER_V2.json'
    assert not out.exists()
    assert not read(P / 'INDEPENDENT_NATIVE_MIMIC_WINDOW_V6.json')['model_window_pass']
    assert read(P / 'INDEPENDENT_LOADED_FEEDBACK_TARGETS100_V1.json')['status'] == 'PASS_INDEPENDENT_ALL_MICROSTEP_COUPLED_NATIVE_TARGET_BINDING'
    raw = Path(read(P / 'RESOURCE_EXECUTION_V1.json')['out'])
    reg = read(P / 'REGISTRATION_V1.json')
    params = np.load(raw / 'native_parameters.npz', allow_pickle=False)
    refs = np.load(reg['coupled_reference_endpoints'], allow_pickle=False)
    assets = read(reg['coupled_assets'])['assets']
    relations = []
    for a, asset in assets.items():
        names = params[a + '_joint_names'].tolist()
        for j in ET.parse(asset['original_URDF']).findall('joint'):
            m = j.find('mimic')
            if m is not None and j.get('name') in asset['hand_joint_names']:
                relations.append((a, j.get('name'), m.get('joint'), names.index(j.get('name')), names.index(m.get('joint')), float(m.get('multiplier', '1')), float(m.get('offset', '0'))))
    assert len(relations) == 24
    keys = ['physics_event', 'state_time_s', 'four_hand_normal_N', 'feedback_grip_mode', 'feedback_grip_finger_fraction',
            'feedback_grip_thumb_fraction', 'prelift_ready', 'prelift_friction_capacity_proxy_N', 'prelift_weight_reserve_N', 'prelift_max_hand_speed_rad_s']
    keys += [a + suffix for a in assets for suffix in ['_native_q', '_native_qd', '_actual_full_position_target', '_hand_nominal_position_target']]
    pieces = {k: [] for k in keys}
    sources = {}
    for ch in read(raw / 'physics_chunks.json'):
        f = raw / ch['path']
        assert sha(f) == ch['sha256']
        sources[str(f)] = sha(f)
        with np.load(f, allow_pickle=False) as z:
            for k in keys:
                pieces[k].append(z[k].copy())
    d = {k: np.concatenate(v) for k, v in pieces.items()}
    violations = []
    for a, slave, master, si, mi, m, o in relations:
        q = d[a + '_native_q'][:, 0]
        v = d[a + '_native_qd'][:, 0]
        qe, ve = abs(q[:, si] - m * q[:, mi] - o), abs(v[:, si] - m * v[:, mi])
        for i in np.flatnonzero((qe > 1e-4) | (ve > 1e-4)):
            violations.append(dict(event=int(d['physics_event'][i]), time_s=float(d['state_time_s'][i]), arm=a, slave=slave, master=master,
                q_residual_rad=float(qe[i]), qd_residual_rad_s=float(ve[i]), slave_qd=float(v[i, si]), master_qd=float(v[i, mi]),
                actual_four_hand_normal_N=d['four_hand_normal_N'][i].tolist(), mode=str(d['feedback_grip_mode'][i, list(assets).index(a)])))
    violations.sort(key=lambda x: (x['event'], x['arm'], x['slave']))
    assert violations and violations[0]['event'] == read(raw / 'fourhand_protocol.json')['model_qualification_failure']['event']
    hands = {}
    for ai, a in enumerate(['F_L', 'F_R', 'U_L', 'U_R']):
        ids = refs[a + '_hand_indices']
        actual = d[a + '_actual_full_position_target'][:, 0, ids]
        initial = np.load(raw / 'actual_initial_seed_binding.npz', allow_pickle=False)[a + '_target'][0, ids]
        delta = np.diff(np.concatenate([initial[None], actual]), axis=0)
        direction = np.sign(refs[a + '_hand_far_q'] - refs[a + '_hand_open_q'])
        positive_closing = np.maximum(delta * direction, 0).max(axis=1)
        stats = {}
        for mode in ['HOLD', 'RELAX', 'JOINT_GUARD']:
            mask = d['feedback_grip_mode'][:, ai] == mode
            if mask.any():
                first = int(np.flatnonzero(mask)[0])
                stats[mode] = dict(samples=int(mask.sum()), actual_target_closing_samples=int((positive_closing[mask] > 1e-7).sum()),
                    maximum_actual_closing_rate_rad_s=float(positive_closing[mask].max() * 960),
                    first_event=int(d['physics_event'][first]), first_time_s=float(d['state_time_s'][first]),
                    nominal_to_actual_target_gap_at_first_event_rad=float(abs(d[a + '_hand_nominal_position_target'][first] - actual[first]).max()))
        hands[a] = dict(guard_target_motion=stats,
            final_nominal_to_actual_target_gap_rad=float(abs(d[a + '_hand_nominal_position_target'][-1] - actual[-1]).max()),
            final_actual_target_to_native_q_gap_rad=float(abs(actual[-1] - d[a + '_native_q'][-1, 0, ids]).max()),
            final_maximum_actual_hand_speed_rad_s=float(abs(d[a + '_native_qd'][-1, 0, ids]).max()),
            final_payload_normal_N=float(d['four_hand_normal_N'][-1, ai]),
            final_finger_fraction=float(d['feedback_grip_finger_fraction'][-1, ai]), final_thumb_fraction=float(d['feedback_grip_thumb_fraction'][-1, ai]))
    result = dict(status='DIAGNOSED_OBSERVABLE_GAPS_NATIVE_SOLVER_ROOT_CAUSE_UNRESOLVED', first_original_relation_violation=violations[0],
        all_original_relation_violations=violations, hand_observations=hands,
        current_scientific_verdict='REJECT_ORIGINAL_MODEL_AND_FULL_FOURHAND_TASK',
        falsified_explanation='Insufficient observation time alone does not explain final upper-hand contact loss: targets are reached and hands settle, yet both payload normals are zero.',
        hypotheses=[dict(candidate='HOLD/RELAX command lag', evidence='Measured actual submitted closing continues during guard modes; this is not by itself proof of force-gate failure.',
                         counterfactual='Freeze actual submitted command on HOLD and anchor RELAX to that command, preserving rate/URDF/physical limits; compare same state and common pre-intervention prefix.'),
                    dict(candidate='Upper operational grasp geometry or endpoint choice', evidence='Upper targets are reached and upper motion settles; final payload normals are zero.',
                         counterfactual='Locate contact-loss phase/fraction and native body/source hull geometry; change one upper grasp pose or operational endpoint only under unchanged full geometric/contact/model gates.'),
                    dict(candidate='Loaded native velocity convergence', evidence='Right-thumb3 and4 original qd relations exceed1e-4 in captured final control, despite independently verified actuation/targets.',
                         counterfactual='Distinguish command-motion sensitivity from numerical convergence using frozen paired inputs; do not project q/qd or weaken tolerance.')],
        unsafe_sole_inferences_rejected=['Native audit execution exit0 means model pass', 'A HOLD label proves physical stopping', 'All4 force peaks prove simultaneous stable contact', 'Settled upper hands imply payload grip'],
        fullSystem0_accepted=False, fulltask_pass=False, formal_holdout_count=0, new_random_cases=0,
        source_sha256={**sources, **{str(f): sha(f) for f in [Path(__file__), P / 'REGISTRATION_V1.json', P / 'INDEPENDENT_NATIVE_MIMIC_WINDOW_V6.json',
            P / 'INDEPENDENT_LOADED_FEEDBACK_TARGETS100_V1.json', P / 'INDEPENDENT_LOADED_FEEDBACK_DECISIONS100_V1.json', raw / 'fourhand_protocol.json']}})
    out.write_text(json.dumps(result, indent=2) + '\n')
    print('LOADED104_FIRST_FAILURE', violations[0], 'HOLD_TARGET_MOTION', {a: hands[a]['guard_target_motion'] for a in hands}, flush=True)


if __name__ == '__main__':
    main()
