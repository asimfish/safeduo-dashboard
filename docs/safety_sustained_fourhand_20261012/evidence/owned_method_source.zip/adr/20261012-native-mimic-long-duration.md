# ADR: Duration-only qualification of sustained four-hand contact

Native103 closes2048 events at original16 extra mimic passes and0.10rad/s
targets. The original24 URDF q AND qd relations, physical limits, independent
50-motor/target/feedback audits and clock qualify; all164 fields in the first1024
events match102 byte for byte. The fourhand simultaneous contact window is0s.
Peak individual forces are not continuous four-hand contact or preload capacity.

The former2048-entry event ledger cannot observe longer tests. The second and
last bounded spike in the moving-contact iteration changes only five ledger
capacity literals2048 to8192. No change to16 passes, solver pairing, opaque CPU
argument bytes, native ABI, stream/context/session matching, return handling,
actuation or tensor state. Source and binary of the previous spike stay frozen.

Retain all14 CPU forwarding/failure scenarios, extend the genuine event-capacity
test to8192 and reject event8192. Compile with warnings as errors. Freeze a fresh
104 registration before execution: same scientific worker, seed, all77 native
parameters, original thresholds and current feedback. Change only observation
horizon2048 to8192 events (8.5333s), and require first2048all164 physical fields
byte-identical103. This horizon exceeds the earlier measured nominal target lag
at0.10rad/s, but is no prediction of physical grip or task success.

Run at most one supervised GPU1 native child. Resource admission remains
12288MiB/80%, maximum owned7680MiB, runtime free4096MiB.103 took337.69s for2048;
four times this is1350.76s. An execution-only1800s cap allows about33% slack;
resource wait remains bounded900s. Original model and physical failures stop
after the current complete16-step control period, with all failing samples
retained and no native failure rerun. First2048 bytes and original q/qd gates
must independently qualify; CPU acceptance is never native safety acceptance.

Predeclared observations: all4 contact>0.1N continuously0.25s; original prelift
conditions including capacity>=1.25mg, hand speed<=0.05rad/s, joint margin>=0.02rad
and no guards. Record all HOLD/RELAX/JOINT_GUARD decisions and actual target motion
to detect delayed physical response. No lifting is enabled. Formal holdout and
new random cases remain0, learned System0 remains off, canonical profile and
full task remain unqualified. If this second spike fails, reassess the evidence
and architecture before further changes to native boundaries.
