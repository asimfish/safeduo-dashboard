"""Finite periodic Python stack diagnostics; no physical actions or GPU imports."""
import datetime,faulthandler,json,os,time
from pathlib import Path
BASE=Path('/mnt/nas/data/lyf/double_hand/safety_verified_fallback_20261010_0352/astra_full74_native_constraint_mechanism_v6_stateapi')
class PhaseTrace:
    def __init__(self,root):
        root=Path(root).resolve()
        if not root.is_relative_to(BASE):raise ValueError('NAS diagnostics only')
        self.root=root/'native_initialization_diagnostics_v4';self.root.mkdir(exist_ok=False)
        self.events=(self.root/'phases.jsonl').open('x');self.stacks=(self.root/'python_stacks.log').open('x');self.closed=False
        self.phase('DIAGNOSTICS_READY');faulthandler.dump_traceback_later(60,repeat=True,file=self.stacks,exit=False)
    def phase(self,name):
        if self.closed:raise ValueError('closed diagnostics')
        self.events.write(json.dumps(dict(phase=name,pid=os.getpid(),utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
            monotonic_seconds=time.monotonic(),process_cpu_seconds=time.process_time(),diagnostic_only=True))+'\n')
        self.events.flush();os.fsync(self.events.fileno())
    def close(self):
        if self.closed:return
        try:self.phase('DIAGNOSTICS_CLOSED_BEFORE_APP_SHUTDOWN')
        finally:
            faulthandler.cancel_dump_traceback_later()
            try:self.stacks.flush();os.fsync(self.stacks.fileno())
            finally:self.events.close();self.stacks.close();self.closed=True
