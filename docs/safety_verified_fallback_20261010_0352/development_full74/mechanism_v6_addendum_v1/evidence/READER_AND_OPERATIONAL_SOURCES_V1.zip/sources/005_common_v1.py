"""Operational CPU candidate; no imports from the native SDK or source mutations."""
import datetime, hashlib, json, os, resource, sys, types
from pathlib import Path

HERE=Path(__file__).resolve().parent
H=Path('/home/liyufeng/safeduo/artifacts/safety_verified_fallback_20261010_0352')
R=Path('/mnt/nas/data/lyf/double_hand/safety_verified_fallback_20261010_0352')
CLOCK=H/'astra/full74_admissible_pilot_clock_v3'
READER=CLOCK/'reader'
OUTPUT=R/'astra_full74_admissible_pilot_clock_reader_v3'
PREP=R/'parent_full74_clock3_reader_operations_v1'
CPU=R/'astra_full74_clock3_reader_operations_CPU_v1'
PY='/home/liyufeng/miniforge3/envs/safeduo/bin/python'
GRAPH=dict(path=str(CLOCK/'PACKAGE_SOURCE_GRAPH_V1.json'),sha256='8803a4f10f883a119eecdae46637ec39c74c6c8aa99ed8f5da9037788c659d88')
BUNDLE=dict(path=str(R/'parent_full74_admissible_pilot_clock_v3/campaign_v3/EXECUTION_BUNDLE_V3.json'),sha256='80224f1fc1515758ad45252136b40def18fe3f6c06227eeb92c326ba2a439f7b')
OUTER=R/'parent_full74_admissible_pilot_v1/executions/native_pilot3'
RUN=R/'astra_full74_admissible_pilot_v1/serial_run3'
STARTS=(64,512,672,1120)
COHORT=dict(path=str(R/'astra_full74_per_state_development_v4/cohort_v1/PROPOSALS.json'),sha256='bdc14bb135aa5b4801cae941110284aebecdad1f0a4b39d71f40e05622d47d8c')
CORE=dict(path=str(H/'astra/owned_discovery_race_v1/runtime_core_discovery_v1.py'),sha256='82c5ed80a8e1e4f875e2314fc7c2fa465916269311102dfc1549088504260626')
PIDFD=dict(path=str(H/'astra/full74_screen/parent_supervision_v1/pidfd_compat_v1.py'),sha256='e8256a5a7c105bdcee57a301052e6bc702ae71fd7734cbda6c3648885f143302')

def need(value,why):
    if not value:raise ValueError(why)
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda:f.read(1024**2),b''):h.update(b)
    return h.hexdigest()
def ref(path):return dict(path=str(path),sha256=sha(path))
def raw(r,limit=32*1024**2):
    need(set(r)=={'path','sha256'},'exact path/SHA reference')
    p=Path(r['path']);need(p.is_absolute() and '..' not in p.parts and (p.is_relative_to(H) or p.is_relative_to(R)),'bound local path')
    with p.open('rb') as f:b=f.read(limit+1)
    need(len(b)<=limit and hashlib.sha256(b).hexdigest()==r['sha256'],'bounded same-buffer SHA '+str(p))
    return b
def read(r):
    def unique(items):
        result={}
        for k,v in items:need(k not in result,'duplicate JSON key');result[k]=v
        return result
    def reject(value):raise ValueError('nonfinite JSON '+value)
    return json.loads(raw(r),object_pairs_hook=unique,parse_constant=reject)
def write(path,value):
    with Path(path).open('x') as f:
        json.dump(value,f,indent=2,allow_nan=False);f.write('\n');f.flush();os.fsync(f.fileno())
    return ref(path)
def name(value):
    need(isinstance(value,str) and value and value.replace('_','').isalnum(),'new simple output name');return value
def environment(tmp):
    e=dict(os.environ,CUDA_VISIBLE_DEVICES='',PYTHONDONTWRITEBYTECODE='1',TMPDIR=str(tmp))
    for k in ('OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS','NUMEXPR_NUM_THREADS','VECLIB_MAXIMUM_THREADS','BLIS_NUM_THREADS'):e[k]='1'
    return e
def cpu_limits():
    need(sys.dont_write_bytecode and os.environ.get('PYTHONDONTWRITEBYTECODE')=='1' and os.environ.get('CUDA_VISIBLE_DEVICES')=='' and all(os.environ.get(k)=='1' for k in ('OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS')),'-B CPU threads1 required')
    resource.setrlimit(resource.RLIMIT_AS,(1024**3,1024**3));resource.setrlimit(resource.RLIMIT_CORE,(0,0))
def source_files():
    own=read(ref(HERE/'SOURCE_GRAPH_V1.json'))['files']
    for p,d in own.items():raw(dict(path=p,sha256=d),1024**2)
    return own
def module(r,name_):
    b=raw(r,1024**2);need(name_ not in sys.modules,'clean module name '+name_)
    m=types.ModuleType(name_);m.__file__=r['path'];sys.modules[name_]=m
    exec(compile(b,r['path'],'exec'),m.__dict__);return m
def core():
    if '_clock3_reader_owned_core' in sys.modules:return sys.modules['_clock3_reader_owned_core']
    module(PIDFD,'pidfd_compat_v1')
    return module(CORE,'_clock3_reader_owned_core')
def absent(rows):
    need(bool(rows),'owned identities required')
    for row in rows:
        need(type(row['pid']) is int and type(row['startticks']) is int and row['startticks']>0,'typed PID/startticks')
        try:now=core().proc_identity(row['pid'])
        except (FileNotFoundError,ProcessLookupError):continue
        need(now['startticks']!=row['startticks'],'recorded identity still exists')
def closed_wait(w,expected,schema,backend=None):
    need(w['schema']==schema and (backend is None or w['backend']==backend),'wait domain')
    for k in ('child_pid','waited_pid','raw_wait_status','actual_wait_exit'):need(type(w[k]) is int,'terminal integer '+k)
    need(w['waitpid_observed'] is True and w['child_pid']==w['waited_pid']>0 and os.waitstatus_to_exitcode(w['raw_wait_status'])==w['actual_wait_exit']==expected and w['wait_mechanism']=='os.wait4(owned_pid, WNOHANG)','real wait4 terminal agreement')
    need(w['resource_abort'] is None and w.get('error') is None and not w['signals'] and all(x['live'] is False for x in w['owned_identities']),'clean closed owned wait')
    own=[x for x in w['owned_identities'] if x['pid']==w['child_pid']]
    need(len(own)==1 and own[0]['enrollment']['kind']=='direct_fork_handshake' and own[0]['enrollment']['parent_pid']==own[0]['ppid'],'fork ownership')
    absent(w['owned_identities'])
    for k in ('log','outer_monitor'):need(sha(w[k])==w[k+'_sha256'],'closed wait '+k)
    return own[0]
def binding(seed,refs):
    need(type(seed) is int and 0<=seed<4,'seed')
    return dict(schema='astra.full74.admissible_pilot.reader_binding.v1',cpu_test_only=False,seed_index=seed,**refs)
