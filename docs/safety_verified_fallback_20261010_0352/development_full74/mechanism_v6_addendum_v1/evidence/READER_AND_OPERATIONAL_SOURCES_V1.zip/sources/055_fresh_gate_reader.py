"""Independent persisted pre-App grant oracle; imports no producer implementation."""
import hashlib,json,math
def need(v,why):
    if not v:raise ValueError(why)
def canonical(v):return hashlib.sha256(json.dumps(v,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
def ident(x):return {k:x[k] for k in ('pid','startticks')}
def interval(start,end,label):
    need(all(type(x)in(int,float) and math.isfinite(x) for x in (start,end)) and 0<=end-start<=30,'independent30 '+label)
def resources(o,q):
    r=q['resource'];g=q['gpu_binding']
    need(o['gpu_index']==g['physical_index'] and o['gpu_uuid']==g['physical_uuid'],'physical sample')
    conditions=[o['GPU_free_MiB']>=r['min_initial_free_MiB'],o['owned_GPU_MiB']<=r['max_owned_process_MiB'],o['host_available_MiB']>=r['min_initial_host_available_MiB'],o['owned_RSS_MiB']<=r['max_owned_host_RSS_MiB'],o['SSD_free_bytes']>=r['min_SSD_free_bytes']+q['SSD_operational_reserve_bytes'],o['NAS_free_bytes']>=q['min_NAS_free_bytes']]
    need(all(conditions),'original full initial resources +4GiB')
def predicates(d):
    q,g,r,v,pre,root,parent,ctx=(d[k] for k in ('request','grant','ready','consumption','pre','root','parent','context'))
    need(g['schema']=='astra.pre_app.resource_grant.v1' and g['parent_authorized'] is True and g['cpu_test_only'] is False and g['freshness_seconds']==q['freshness_seconds']==30,'real grant type')
    need(r['schema']=='astra.pre_app.ready.v1' and r['app_created'] is False and r['context_digest']==g['context_digest']==canonical(ctx) and g['ready_digest']==canonical(r),'bound ready nonce')
    need(all(g[k]==ctx[k] for k in ('request','review','source_graph','dispatch_permit','gpu_binding')),'exact grant authority')
    need(g['child_identity']==r['child_identity']==ident(root) and g['parent_identity']==r['parent_identity']==ident(parent) and root['ppid']==parent['pid'],'actual child/root ownership')
    need(g['issuer_is_main_thread'] is True and type(g['issuer_thread_id'])is int,'parent main-thread issuer')
    lease=g['serial_lease'];need(lease['owner_pid']==parent['pid'] and lease['owner_startticks']==parent['startticks'] and lease['kernel_lock']==d['dispatch']['serial_lease']['kernel_lock'],'continuous recorded original lease')
    validation=r['validation_receipt'];need(validation['status']=='COMPLETE_VALIDATION_AND_APP_CONFIG_NO_APP' and validation['request']==ctx['request'] and validation['review']==ctx['review'] and validation['source_graph']==ctx['source_graph'],'validation before READY')
    need(v['status']=='FRESH_RESOURCE_GATE_CONSUMED_BEFORE_APP_NOT_NATIVE_PASS' and v['evidence']['grant']==g and v['evidence']['ready_digest']==canonical(r),'consumed exact grant')
    need(pre['grant']==g and pre['ready_digest']==canonical(r) and pre['child_observation']==v['evidence']['child_observation'],'persisted child sample')
    for suffix in ('unix_s','monotonic_s'):
        now=v['consumed_'+suffix];start=g['sample_started_'+suffix];end=g['sample_finished_'+suffix]
        need(r['ready_'+suffix]<=start<=end<=now,'sample follows READY/config')
        interval(start,now,'parent '+suffix);interval(pre['child_sample_started_'+suffix],now,'child '+suffix)
    need(q['max_wall_seconds']==1200 and v['consumed_monotonic_s']<g['guardian_deadline_monotonic_s'] and v['consumed_monotonic_s']<d['dispatch']['dispatch_monotonic_s']+1200,'original bounded guardian deadline')
    for o in (g['parent_observation'],pre['child_observation']):resources(o,q)
    need(ident(pre['child_observation']['owned_identity'])==ident(root) and pre['child_observation']['ownership_scope']=='SELF_PID_ONLY','actual child resource readback')
    need(g['parent_observation']['ownership']=='FORK_ROOT_AND_PROVEN_DESCENDANTS_ONLY' and any(ident(x)==ident(root) for x in g['parent_observation']['owned_identities']),'actual parent owned enrollment sample')
    return dict(parent_age_s=v['consumed_monotonic_s']-g['sample_started_monotonic_s'],child_age_s=v['consumed_monotonic_s']-pre['child_sample_started_monotonic_s'],native_pass=False)
def audit_fresh(e,root,entry,q,record,wait,parent):
    from pathlib import Path
    folder=Path(root)/'app_boundary_v4'
    def packet(name):
        cp=folder/(name+'.COMMIT.json');co=e.js(cp);br=co['body'];need(br['path']==str(folder/(name+'.json')),'fixed packet path')
        return e.js(br['path'],br['sha256']),dict(body=br,commit=dict(path=str(cp),sha256=e.hash(cp))),co
    r,rr,rc=packet('READY');g,gr,gc=packet('GRANT');pre,pr,pc=packet('PRECONSUMPTION')
    p=entry['pre_app_proof_v4'];v=p['boundary_v4'];argv=wait['argv']
    dispatchref=dict(path=str(Path(root)/'LIVE_PERMIT_V4.json'),sha256=argv[argv.index('--permit-sha256')+1]);dispatch=e.js(dispatchref['path'],dispatchref['sha256'])
    ctx=dict(request=record['request'],review=record['review'],source_graph=q['pre_app_freshness_graph'],dispatch_permit=dispatchref,gpu_binding=q['gpu_binding'],resource=q['resource'],SSD_operational_reserve_bytes=q['SSD_operational_reserve_bytes'],min_NAS_free_bytes=q['min_NAS_free_bytes'])
    own=next(x for x in wait['owned_identities'] if x['pid']==wait['child_pid'])
    need(ident(dispatch['parent_identity'])==ident(parent),'actual parent receipt versus dispatch identity')
    need(p['request_sha256']==record['request']['sha256'] and p['permit_sha256']==dispatchref['sha256'] and p['gpu_binding']==q['gpu_binding'] and ident(p['child_identity'])==ident(own),'exact ENTRY proof')
    for refs,actual in [(p['ready_packet'],rr),(g['ready_packet'],rr),(pre['ready_packet'],rr),(p['grant_packet'],gr),(pre['grant_packet'],gr),(v['persisted_evidence'],pr)]:need(all(refs[k]==actual[k] for k in ('body','commit')),'exact committed packet references')
    phases=[e.js(ref['path'],ref['sha256']) for ref in entry['pre_app_phase_refs']]
    need(phases and phases[-1]['phase']=='VALIDATION_AND_APP_CONFIG_COMPLETE' and r['validation_receipt']['actual_phase_refs']==entry['pre_app_phase_refs'],'actual phase inventory')
    need(all(x['pid']==own['pid'] for x in phases) and all(a['monotonic_s']<=b['monotonic_s'] for a,b in zip(phases,phases[1:])) and phases[-1]['monotonic_s']<=r['ready_monotonic_s'],'real phase ordering')
    for co in (rc,gc,pc):
        need(co['body_write_started'][1]<=co['body_write_finished'][1]<=v['consumed_monotonic_s'],'persisted before consumption')
    return predicates(dict(request=q,grant=g,ready=r,consumption=v,pre=pre,root=own,parent=parent,context=ctx,dispatch=dispatch))
