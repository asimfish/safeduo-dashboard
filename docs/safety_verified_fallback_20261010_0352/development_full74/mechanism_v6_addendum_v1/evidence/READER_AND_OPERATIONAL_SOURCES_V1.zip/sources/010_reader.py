"""Closure-gated full74 development reader. No observer, launcher or polling mode."""
import argparse
import json
import os
from pathlib import Path
import traceback
from evidence_io import (ARMS,H,R,HERE,SCREEN,NATIVE,OUTPUT,Evidence,require,contained,
    cpu_limits,write_new,exact,parse_json)


class PendingNative(RuntimeError):
    pass


# Historical V2/V3 parity seam retained for the byte-identical 46-test baseline.
# Execution authority is exclusively EXECUTION_ENTRY, separately tested for V7.
LIFECYCLE_ENTRY=H/'native_lifecycle_repair_v1/native_short_entry_v3.py'
from operational_v9 import (EXECUTION_ENTRY,execution_sources,thread_settings,thread_cpu_binding,root_cpu_binding,
    diagnostics_cpu_binding,attempt_binding,outer_completion)
from root_restore_reader import protocol_binding,audit_roots


def identity_anchor(w,anchors):
    own=next(x for x in w['owned_identities'] if x['pid']==w['child_pid'])
    known=anchors.get('actual_native_identity')
    if known is not None:
        require({k:own[k] for k in ('pid','startticks')}==known,'parent-confirmed native PID/startticks')
    return own


def parent_wait(e,root,wait_sha,request_sha):
    path=root/'PARENT_NATIVE_WAIT.json'
    if not path.is_file():
        raise PendingNative('actual PARENT_NATIVE_WAIT.json absent; native data not opened')
    w=e.js(path,wait_sha)
    require(w['schema']=='astra.full74.parent_native_wait.v1' and w['backend']=='isaac_physx_native','actual parent native wait schema/backend')
    for key in ('child_pid','waited_pid','raw_wait_status','actual_wait_exit'):
        require(type(w[key]) is int,'terminal native wait integer '+key)
    require(w['waitpid_observed'] is True and w['child_pid']==w['waited_pid']>0,'native child wait identity')
    require(w['raw_wait_status']==0 and w['actual_wait_exit']==0 and os.WIFEXITED(w['raw_wait_status']) and os.WEXITSTATUS(w['raw_wait_status'])==0,'native actual exit not zero')
    require(w['resource_abort'] is None and w['error'] is None and w['signals']==[],'native aborted/errored/signalled')
    require(w['wait_mechanism']=='os.wait4(owned_pid, WNOHANG)' and w['started_utc'] and w['closed_utc'],'actual wait4 terminal provenance')
    own=[i for i in w['owned_identities'] if i['pid']==w['child_pid']]
    require(len(own)==1,'exact owned root')
    own=own[0]
    require(type(own['startticks']) is int and own['startticks']>0 and own['pgid']==own['sid']==own['pid'],'native PID/startticks/session identity')
    require(own['enrollment']['kind']=='direct_fork_handshake' and own['enrollment']['parent_pid']==own['ppid']>0,'parent fork enrollment')
    require(own['live'] is False,'native root still live in terminal evidence')
    require(all(i['live'] is False for i in w['owned_identities']),'owned descendants not closed')
    for key in ('log','outer_monitor','request','native_receipt','entry_receipt','parent_review_path','parent_prelaunch_gate','fresh_recheck'):
        digest_key='parent_review_sha256' if key=='parent_review_path' else key+'_sha256'
        if key!='parent_review_path': contained(w[key],root)
        e.hash(w[key],w[digest_key])
    require(Path(w['native_receipt'])==root/'native/NATIVE_RECEIPT.json' and Path(w['entry_receipt'])==root/'native/NATIVE_SHORT_ENTRY_RECEIPT_V1.json','cross-attempt receipt')
    require(w['request_sha256']==request_sha,'external request SHA binding')
    # A hash-bound event log is evidence of wait/enrollment, never a liveness heuristic.
    events=[];resource_samples=0
    with Path(w['outer_monitor']).open('rb') as f:
        for line in iter(lambda:f.readline(4*1024**2+1),b''):
            require(len(line)<=4*1024**2,'monitor event bound')
            row=parse_json(line)
            if row.get('event') in ('OWNED_ENROLLED','ACTUAL_WAIT'):events.append(row)
            if row.get('event')=='RESOURCE':
                require(row['failed']==[],'parent resource sample failed')
                obs=row['observation'];resource_samples+=1
                require(obs['GPU_free_MiB']>=2500 and obs['owned_GPU_MiB']<=12500 and obs['host_available_MiB']>=12000 and obs['owned_RSS_MiB']<=46000 and obs['SSD_free_bytes']>=15*1024**3 and obs['NAS_free_bytes']>=32*1024**3,'original runtime resource threshold')
            require(len(events)<=2,'duplicate parent terminal/enrollment events')
    require(resource_samples>0,'actual outer native resource samples missing')
    enrolled=[v for v in events if v['event']=='OWNED_ENROLLED']; waited=[v for v in events if v['event']=='ACTUAL_WAIT']
    require(len(enrolled)==len(waited)==1,'monitor enrollment/actual wait events')
    require(enrolled[0]['argv']==w['argv'],'monitor executable argv')
    first=[v for v in enrolled[0]['identities'] if v['pid']==own['pid']]
    require(len(first)==1 and all(first[0][k]==own[k] for k in ('pid','ppid','startticks','pgid','sid','enrollment')),'monitor PID/startticks provenance')
    last=waited[0]
    require(all(last[k]==w[k] for k in ('child_pid','waited_pid','raw_wait_status','actual_wait_exit','resource_abort','signals')),'wait4 event/receipt disagreement')
    require(last['identities']==w['owned_identities'],'terminal ownership event disagreement')
    return w


def inputs(e,w,root,anchors):
    import numpy as np
    from science import NAMESPACE,SEEDS,parameters_layout
    e.verify(anchors['files'])
    b=e.js(SCREEN/'INPUT_BINDING_V1.json')
    require(len(b['files'])==509 and len(b['original500_sources'])==500,'509/500 denominator')
    require(all(b['files'][p]==h for p,h in b['original500_sources'].items()),'frozen500 binding')
    e.verify(b['files'])
    req=e.js(w['request'],w['request_sha256'])
    schema=e.js(SCREEN/'NATIVE_SHORT_READER_SCHEMA_V3.json')
    require(req['schema']=='astra.full74.native_execution_request.v1' and req['parent_frozen'] is True and req['single_Kit_process_at_a_time'] is True,'native frozen request')
    require(req['purpose']=='DEVELOPMENT_ONLY' and req['mode']=='camera-short' and req['maximum_batches']==1 and req['prefix_microsteps']==12,'only first32 short development')
    require(req['cohort_subset']==schema['cohort_subset'] and req['out']==str(root/'native'),'fixed IDs0..31 root binding')
    require(req['input_binding_sha256']==e.hash(SCREEN/'INPUT_BINDING_V1.json'),'input binding SHA')
    require(req['resource']==b['original_resource'],'original resource thresholds')
    expected_sources=execution_sources(schema,anchors)
    require(req['runner_sources']==expected_sources,'source variant drift: only pinned lifecycle entry may be added')
    protocol_binding(e,req,anchors,w['started_utc'])
    e.verify(req['runner_sources'])
    review=e.js(w['parent_review_path'],w['parent_review_sha256'])
    require(review['attempt_root']==str(root) and review['execute_authorized'] is True,'parent actual attempt review')
    before=e.js(root/'SOURCE_BINDING_BEFORE.json');after=e.js(root/'SOURCE_BINDING_AFTER.json')
    require(w['source_binding']==before,'parent wait/source binding before')
    for source in (before,after):
        source_binding(e,source,b,req,review)
    for key in ('original500_sources','all_input_sources','native_sources','runtime_sources'):
        require(before[key]==after[key],'parent source binding changed '+key)
    e.verify(w['prerequisite_sources'])
    require(req['parent_serialization_receipts']==w['prerequisite_sources'],'request prerequisite receipt chain')
    closure=e.js(root/'PARENT_PRODUCT_CLOSURE.json')
    require(closure['status']=='PRODUCER_SHORT_CLOSURE_ONLY_INDEPENDENT_READER_REQUIRED' and closure['native_wait']==str(root/'PARENT_NATIVE_WAIT.json') and closure['native_wait_sha256']==e.hash(root/'PARENT_NATIVE_WAIT.json'),'parent product closure')
    argv=w['argv']; require(argv[1]=='-B' and argv[2]==str(EXECUTION_ENTRY) and '--execute-native-short' in argv,'native lifecycle entry argv')
    for option,value in [('--request',w['request']),('--request-sha256',w['request_sha256']),('--proposal-start','0'),('--proposal-count','32'),('--prefix-microsteps','12')]:
        require(argv.count(option)==1 and argv[argv.index(option)+1]==value,'native argv binding '+option)
    gate=req['parent_prelaunch_gate'];require(gate['path']==w['parent_prelaunch_gate'] and gate['sha256']==w['parent_prelaunch_gate_sha256'],'prelaunch binding')
    p=contained(req['proposals_manifest'],R/'astra_full74_screen_development_v1')
    proposals=e.js(p,req['proposals_sha256']); reg=proposals['registration']
    require(reg==e.js(p.parent/'IDENTITY.json',proposals['identity_sha256']),'proposal registration')
    require(reg['namespace']==NAMESPACE and reg['purpose']=='DEVELOPMENT_ONLY' and reg['seeds']==SEEDS,'development seeds namespace')
    require(reg['proposals']==8192 and reg['per_seed']==2048 and reg['lanes']==32 and reg['prefix_microsteps']==12,'full ledger denominator')
    require(reg['selected']==reg['native_completed']==reg['formal_holdout']==0 and reg['policy_outcomes_used'] is False and reg['fresh_proposal_directory_opened'] is False,'unselected origin')
    require(reg['parameter_sha256']==b['files'][b['parameter_path']],'proposal parameter SHA')
    e.verify(proposals['files'],p.parent)
    params=e.npz(b['parameter_path']); layout=parameters_layout(params)
    for name in ('hard','soft','bounds','vmax','controlled','names'):exact(e.npy(p.parent/(name+'.npy')),layout[name],'proposal '+name)
    q=e.npy(p.parent/'q74.npy',(8192,74),'float32'); qd=e.npy(p.parent/'qd74.npy',(8192,74),'float32')
    require(np.isfinite(q).all() and np.isfinite(qd).all() and np.all(q>=layout['bounds'][:,0]) and np.all(q<=layout['bounds'][:,1]) and np.all(np.abs(qd)<=layout['vmax']),'entire proposal support')
    exact(e.npy(p.parent/'proposal_id.npy',(8192,),'int64'),np.tile(np.arange(2048,dtype=np.int64),4),'proposal IDs')
    exact(e.npy(p.parent/'seed_index.npy',(8192,),'uint8'),np.repeat(np.arange(4,dtype=np.uint8),2048),'four seed rows')
    exact(e.npy(p.parent/'family.npy',(8192,),'uint8'),np.tile(np.arange(2048,dtype=np.uint8)%4,4),'proposal families')
    return req,b,schema,params,layout,q[:32].copy(),qd[:32].copy()


def source_binding(e,source,binding,req,review):
    """V8 keeps flattened original4; request adds explicit entry/worker extras."""
    extras=e.js(HERE/'anchors.json')['execution_extras']
    old_science={k:v for k,v in req['runner_sources'].items() if k not in extras}
    require(source['original500_sources']==binding['original500_sources'] and source['all_input_sources']==binding['files'] and source['native_sources']==old_science,'parent flattened source binding')
    require(source['runtime_sources']==review['runtime_source_sha256'] and source['science_entry_sources_unchanged'] is True and source['process_groups_are_telemetry_not_ownership'] is True,'parent V5 runtime binding')
    e.verify(source['runtime_sources'])
    e.hash(review['runtime_CPU_report'],review['runtime_CPU_report_sha256'])
    require(source['runtime_CPU_report_sha256']==review['runtime_CPU_report_sha256'],'runtime CPU source receipt')
    if str(EXECUTION_ENTRY) in req['runner_sources']:
        proof=e.js(review['lifecycle_CPU_report'],review['lifecycle_CPU_report_sha256'])
        require(proof['status']=='PASS_CPU_SHUTDOWN_DURABILITY_ONLY','lifecycle CPU closure')
        e.verify(proof['source_sha256']);e.verify(proof['artifacts'])
        thread_cpu_binding(e,review,e.js(HERE/'anchors.json'))
        root_cpu_binding(e,review,e.js(HERE/'anchors.json'))
        diagnostics_cpu_binding(e,review,e.js(HERE/'anchors.json'))


def entry_lifecycle(e,out,entry):
    if (out/'APP_CLOSE_ERROR_V3.json').exists():
        e.hash(out/'APP_CLOSE_ERROR_V3.json')
        raise ValueError('APP_CLOSE_ERROR_V3.json denies native closure even with exit0')
    before=e.js(out/'NATIVE_SHORT_ENTRY_BEFORE_CLOSE_V3.json')
    require(entry['status']==before['status']=='complete' and not entry.get('cleanup_errors') and not before.get('error'),'early failed/receipt-only lifecycle entry')
    phase='BEFORE_ENV_AND_APP_CLOSE_REQUIRES_PARENT_ACTUAL_WAIT'
    require(before['receipt_phase']==entry['receipt_phase']==phase,'actual pinned V3 receipt phase')
    # Current V3 deliberately writes the final filename after env.close while
    # retaining its pre-close phase text. Do not invent a POST phase or app result.
    require(before==entry,'successful durable-before and post-env/pre-app receipts disagree')
    require((out/'NATIVE_RECEIPT.json').is_file() and (out/'all_proposal_status.npy').is_file() and
            (out/'batch_00000/native_fields/CLOSED.json').is_file() and
            (out/'batch_00000/initial_camera_receipts.json').is_file() and
            (out/'batch_00000/final_camera_receipts.json').is_file(),'exit0/entry-only cannot replace native state ledger and camera products')


def products(e,w,req,schema,params,layout,q,qd):
    import numpy as np
    out=Path(req['out']); batch=out/'batch_00000'
    receipt=e.js(w['native_receipt']); entry=e.js(w['entry_receipt'])
    entry_lifecycle(e,out,entry)
    thread_settings(entry)
    require(receipt['schema']=='astra.full74.native_screen_receipt.v1' and receipt['status']=='complete' and receipt['backend']=='isaac_physx_native','complete native receipt')
    require(entry['schema']=='astra.full74.native_short_entry.v1' and entry['status']=='complete' and entry['native_started'] is True and entry['native_launch_attempted'] is True and not entry.get('cleanup_errors'),'native entry closure')
    require(entry['request']==w['request'] and entry['request_sha256']==w['request_sha256'] and entry['native_receipt']==w['native_receipt'] and entry['native_receipt_sha256']==w['native_receipt_sha256'],'entry/request/receipt chain')
    require(entry['entry_sha256']==req['runner_sources'][str(EXECUTION_ENTRY)] and entry['subset']==req['cohort_subset'],'entry source/subset')
    require(Path(entry['geometry_identity']['path'])==out/'NATIVE_GEOMETRY_IDENTITY_V1.json','cross-attempt native geometry identity')
    require(receipt['runner_sources']==req['runner_sources'] and receipt['input_binding_sha256']==req['input_binding_sha256'] and receipt['proposals_sha256']==req['proposals_sha256'],'native source/request binding')
    require(receipt['mode']=='camera-short' and receipt['completed_batches']==1 and receipt['actual_prefix_microsteps']==12 and receipt['camera_all32_initial_final_qualified'] is True and receipt['native27_checks_unchanged'] is True,'complete12 camera receipt')
    require(receipt['safety_acceptance'] is False and receipt['selected_count']==receipt['formal_holdout_count']==0 and receipt['CONTACT']=='UNKNOWN' and receipt['ACTUAL_DRIVE_TORQUE']=='UNKNOWN' and receipt['TERMINAL_SET']=='UNKNOWN' and receipt['certified_error_bound'] is False,'unknown/scope preserved')
    for key in ('camera_closure','camera_cleanup'):
        require(receipt[key]['status']=='closed' and receipt[key]['errors']==[],'camera overlay closure')
    e.verify(receipt['artifacts'],out)
    for rel in schema['required_top_files']+schema['required_batch_files']:
        require(contained(out/rel,out).is_file(),'missing product '+rel)
    extra={str(out/n) for n in ('NATIVE_RECEIPT.json','NATIVE_SHORT_ENTRY_RECEIPT_V1.json','NATIVE_SHORT_ENTRY_BEFORE_CLOSE_V3.json','PARAMETER_READBACK_BEFORE_V1.npz','PARAMETER_READBACK_AFTER_V1.npz','NATIVE_GEOMETRY_IDENTITY_V1.json')}
    require({str(p) for p in out.rglob('*') if p.is_file()}==set(receipt['artifacts'])|extra,'unbound/orphan native product files')
    expected={k for k in params if not k.endswith('_full_initial_position_target') and k!='initial_strata'}
    for label in ('before','after'):
        ref=entry['parameter_readbacks'][label]
        require(Path(ref['path'])==out/('PARAMETER_READBACK_'+label.upper()+'_V1.npz'),'parameter path')
        actual=e.npz(ref['path'],ref['sha256']);require(set(actual)==expected,'parameter getter inventory')
        for k in actual:exact(actual[k],params[k],'parameter '+label+' '+k)
    exact(e.npy(batch/'proposal_ids.npy',(32,),'int64'),np.arange(32,dtype=np.int64),'fixed attempted proposal IDs')
    exact(e.npy(batch/'requested_q74.npy',(32,74),'float32'),q,'requested q');exact(e.npy(batch/'requested_qd74.npy',(32,74),'float32'),qd,'requested qd')
    exact(e.npy(batch/'fixed_prefix_targets_6x32x74.npy',(6,32,74),'float32'),np.repeat(q[None],6,axis=0),'all6 fixed controls')
    for micro in range(1,13):exact(e.npy(batch/f'applied_target74_micro_{micro:03d}.npy',(32,74),'float32'),q,'actual applied target micro'+str(micro))
    closed=e.js(batch/'native_fields/CLOSED.json');require(closed['filled']==13,'13 completed rows')
    e.verify(closed['files'],batch/'native_fields')
    require(set(closed['files'])=={str(batch/'native_fields'/(k+'.npy')) for k in schema['native_fields']},'closed native field inventory')
    for i in range(13):require(e.js(batch/'native_fields'/f'row_{i:03d}_complete.json')=={'row':i},'completed row identity')
    fields={k:e.npy(batch/'native_fields'/(k+'.npy'),v['shape'],v['dtype']) for k,v in schema['native_fields'].items()}
    exact(fields['q74'][0],q,'initial q bitwise');exact(fields['qd74'][0],qd,'initial qd bitwise');exact(fields['target74'][0],q,'initial target bitwise')
    exact(fields['micro'],np.arange(13,dtype=np.int64),'all micro indices')
    exact(fields['macro_step'],np.array([-1]+[(i-1)//2 for i in range(1,13)],np.int64),'six macro indices')
    exact(fields['substep'],np.array([-1]+[(i-1)%2 for i in range(1,13)],np.int64),'two substeps')
    exact(fields['point_fresh'],np.array([False]+[True]*12),'fresh contacts after actual step')
    exact(fields['initial_point_freshness_unknown'],np.array([True]+[False]*12),'initial contact UNKNOWN')
    exact(fields['simulation_step'],fields['simulation_step'][0]+np.arange(13,dtype=np.int64),'actual consecutive native steps')
    times=fields['simulation_time_s']; require(np.isfinite(times).all() and np.all(np.abs(times-times[0]-np.arange(13)*.008333)<1e-8),'native clock differs from fixed producer contract .008333')
    return out,batch,receipt,entry,fields


def contact_identity(e,batch,binding,body):
    identity=e.js(batch/'native_contact_identity.json');old=e.js(binding['contact_identity_path'])
    require(identity['environment_count']==32 and identity['physics_dt_s']==.008333 and identity['partners_env0']==old['partners_env0'],'native contact identity/time')
    require(identity['inventory']==old['inventory'] and len(identity['partners_env0'])==85,'all original contact partners/owners')
    require([v['arm'] for v in identity['views']]==list(ARMS),'native four contact views order')
    owners=[[] for _ in range(32)]
    for view,ref in zip(identity['views'],old['views']):
        for key in ('arm','sensors','filters','env_ids','capacity'):require(view[key]==ref[key],'contact identity '+key)
        require(view['capacity']==262144 and len(view['sensors'])==32*len(body[view['arm']]),'contact view denominator')
        for path,lane,filters in zip(view['sensors'],view['env_ids'],view['filters']):
            require(filters==[p.replace('/env_0/',f'/env_{lane}/') for p in identity['partners_env0']],'same native partner order')
            owners[lane].append(path)
    require(all(len(v)==len(set(v))==82 for v in owners),'exact82 owners per lane')
    return identity


def contacts(e,batch,fields,identity):
    import numpy as np
    from science import scalar_contacts
    point_counts=[]
    for micro in range(13):
        root=batch/f'points_{micro:03d}';c=e.js(root/'CLOSED.json')
        require(c['micro']==micro and c['fresh'] is (micro>0),'point closure freshness')
        e.verify(c['files'],root)
        require(set(c['files'])=={str(p) for p in root.glob('*.npy')},'unbound point file')
        statekeys=set(fields)-{'scalar82','violations'}
        perarm={'counts','starts','point_indices','sensor_indices','partner_indices','normal_forces','points','normals','separations','partner_abs_normal_sum_N'}
        require({Path(p).stem for p in c['files']}==statekeys|{a+'_'+k for a in ARMS for k in perarm},'point file inventory')
        for key in statekeys:exact(e.npy(root/(key+'.npy')),np.asarray(fields[key][micro]),'point/native row '+key)
        by_lane=[[] for _ in range(32)];total=0
        for view in identity['views']:
            a=view['arm']; arrays={k:e.npy(root/(a+'_'+k+'.npy')) for k in perarm}
            require(arrays['counts'].shape==(len(view['sensors']),85),'sensor/partner matrix')
            sums=scalar_contacts(arrays['counts'],arrays['starts'],arrays,arrays['normal_forces']);n=len(arrays['point_indices']);total+=n
            for key,width in [('points',3),('normals',3),('separations',1)]:
                require(arrays[key].shape==(n,width) and arrays[key].dtype in (np.float32,np.float64) and np.isfinite(arrays[key]).all(),'nonfinite/malformed owned point '+key)
            exact(sums,arrays['partner_abs_normal_sum_N'],'independent float64 sum(abs(force))')
            for sensor,lane in enumerate(view['env_ids']):by_lane[lane].append(sums[sensor].max())
        exact(np.asarray(by_lane,np.float64),fields['scalar82'][micro],'all82 scalar native owners')
        point_counts.append(total)
    return dict(valid_owned_points_by_row=point_counts,force_units='N; original dt=.008333, no rescaling',fresh_rows=list(range(1,13)),initial_contact='UNKNOWN')


def cameras(e,batch,fields,layout,body,identity):
    import numpy as np
    from camera_adapter import CameraAudit,micro_native,supplement
    from camera_oracle import audit_group
    audit=CameraAudit(batch,e,body,identity,layout)
    sources={'source_sha256':H/'astra/next_mechanism/qualified_views_v7.py','inherited_hand_views_sha256':H/'astra/next_mechanism/hand_views_v3.py','frozen_native_hold_source_sha256':H/'astra/adaptation32/hand_views_v2.py'}
    asset=e.js(H/'astra/next_mechanism/CAMERA_PALM_USD_IDENTITIES_V1.json');e.verify(asset['source_files_sha256'])
    result=[];origins=None;statepaths=set()
    for kind,micro,step in [('initial',0,-1),('final',12,5)]:
        r=e.js(batch/(kind+'_camera_receipts.json'))
        require(r['qualified'] is True and len(r['receipts'])==32 and [x['env_id'] for x in r['receipts']]==list(range(32)),'all32 '+kind+' camera groups')
        for rec in r['receipts']:
            ref=dict(path=rec['state'],sha256=rec['sha256']);state=parse_json(audit.ref(ref));slot=rec['env_id']
            require(ref['path'] not in statepaths,'duplicate camera state');statepaths.add(ref['path'])
            baseline=audit.snapshot(state['native_before_all64'])
            if origins is None:origins=baseline['environment_origins'].copy()
            exact(baseline['environment_origins'],origins,'all camera group origins')
            external=micro_native(fields,micro,layout,origins)
            del external['environment_origins']  # No origin field exists in native_fields.
            group=audit_group(audit,ref,expected_native_fields=external,expected_event=(kind,slot,step,None),expected_sources=sources,asset_manifest=asset)
            inventory=audit.load_inventory(state['native_path_mapping'])
            group.update(path=ref['path'],supplement_v3=supplement(group,inventory,slot))
            result.append(group)
    require(len(result)==64,'complete64 camera groups')
    return dict(groups=result,held_snapshots_checked=audit.snapshots,all64_v7_qualified=True,
        externally_bound_native_fields=26,held_native_fields=27,origin_scope='all27 raw held snapshots, stable across groups; no independent origin-grid reconstruction',
        supplement_v3_all64_sufficient=all(g['supplement_v3']['observed_coverage_sufficient'] for g in result),
        alarms_in_this_screen='no alarm-triggered camera captures; numeric violations remain retained',
        whole_prototype_acceptance=False),origins


def geometry_evidence(e,entry,binding,fields,origins):
    import numpy as np
    import yaml
    from science import geometry
    original=e.js(binding['geometry_identity_path']);ref=entry['geometry_identity'];actual=e.js(ref['path'],ref['sha256'])
    require(set(actual)==set(original)-{'scope'} and all(actual[k]==original[k] for k in actual),'global9021 identity including sphere/tip rows')
    # Read the frozen YAML inheritance chain as data; no environment factory imports.
    repo=Path('/home/liyufeng/safeduo');config=repo/'src/safeduo/configs';seen=set()
    def merge(a,b):
        for k,v in b.items():
            if isinstance(v,dict) and isinstance(a.get(k),dict):merge(a[k],v)
            else:a[k]=v
        return a
    def cfg(name):
        path=contained(config/name,config); require(path not in seen and len(seen)<40,'YAML inheritance cycle');seen.add(path)
        require(str(path) in binding['files'],'unbound configuration')
        doc=yaml.safe_load(e.raw(path));parent=doc.pop('extends',None)
        return merge(cfg(parent) if parent else {},doc)
    configdoc=cfg('duo_env_a31_pending_guard.yaml');layoutpath=contained(repo/configdoc['scene']['layout_yaml'],repo)
    require(str(layoutpath) in binding['files'],'unbound table layout')
    tables=yaml.safe_load(e.raw(layoutpath))['tables'];sx,sy,_=tables['params']['table_size'];th=float(tables['params']['table_top_thickness'])
    centers=np.array([(*tables[k]['center_xy'],tables[k]['top_z']-th/2) for k in ('table_F','table_U')],np.float32)
    half=np.repeat(np.array([[sx/2,sy/2,th/2]],np.float32),2,axis=0)
    errors=[];sign_disagreements=[];skipped=[]
    for i in range(13):
        row={k:v[i] for k,v in fields.items()}
        if not all(np.isfinite(row[a+'_link_xyzw']).all() for a in ARMS):skipped.append(i);continue
        reconstructed,_=geometry(row,actual,centers,half,origins)
        raw=fields['raw9021'][i];finite=np.isfinite(raw)
        error=np.abs(reconstructed[finite]-raw[finite]);errors.append(float(error.max()) if error.size else None)
        require(not error.size or error.max()<=5e-5,'recorded9021 geometry differs from native pose reconstruction')
        sign_disagreements.append(int(np.count_nonzero(((reconstructed<0)!=(raw<0))&finite)))
    return dict(rows=9021,robot_rows=8745,table_rows=276,identity_exact=True,
        sphere_names=actual['sphere_names'],tip_sphere_indices=[i for i,n in enumerate(actual['sphere_names']) if 'tip' in n.lower()],
        max_abs_float64_reconstruction_error_by_finite_row=errors,sign_disagreement_counts=sign_disagreements,
        skipped_nonfinite_pose_rows=skipped,diagnostic_tolerance_m=5e-5,
        predicate='all original raw9021 < 0 with zero epsilon; exemptions never remove a row',
        global_error_bound='UNKNOWN',physical_geometry_certificate=False)


def run(args):
    import numpy as np
    from science import flags,classify,counts,REASONS,STATES
    e=Evidence();report=dict(schema='astra.full74.independent_reader.v1',status='FAILED_CLOSED_DATA',
        native_pass=False,safety_acceptance=False,stage_pass=False,selected_count=0,formal_holdout_count=0,
        CONTACT='UNKNOWN',ACTUAL_DRIVE_TORQUE='UNKNOWN',TERMINAL_SET='UNKNOWN',GLOBAL_ERROR_BOUND='UNKNOWN',
        initial_contact_freshness='UNKNOWN',certified_error_bound=False,errors=[])
    code=2
    try:
        anchors=e.js(HERE/'anchors.json');root=Path(args.attempt_root).absolute()
        require(str(root)==anchors['actual_attempt_root'],'actual parent-confirmed attempt root required; CPU fixtures cannot become native')
        contained(root,NATIVE)
        w=parent_wait(e,root,args.parent_wait_sha256,args.request_sha256)
        identity_anchor(w,anchors)
        attempt_binding(w,anchors)
        outer=outer_completion(e,anchors,w,args.outer_execution_sha256)
        report['outer_completion']=dict(path=anchors['outer_execution_path'],sha256=args.outer_execution_sha256,
            pid=outer['pid'],actual_exit=outer['actual_exit'])
        report['native_closure']=dict(path=str(root/'PARENT_NATIVE_WAIT.json'),sha256=args.parent_wait_sha256,
            child_pid=w['child_pid'],owned_identities=w['owned_identities'],raw_wait_status=w['raw_wait_status'])
        req,b,schema,params,layout,q,qd=inputs(e,w,root,anchors)
        out,batch,receipt,entry,fields=products(e,w,req,schema,params,layout,q,qd)
        report['V9_operational_binding']=dict(entry=str(EXECUTION_ENTRY),entry_sha256=entry['entry_sha256'],
            CPU_thread_settings_after_app_launch=thread_settings(entry),limit_cpu_threads=1,
            limit_basis='SHA-pinned V4 config override; actual post-launch OMP/MKL/OPENBLAS strings verified')
        initial=e.npz(b['initial_path'])
        protocol=protocol_binding(e,req,anchors,w['started_utc'])
        restore_path=batch/'ROOT_RESTORE_EQUIVALENCE_V1.json'
        require(str(restore_path) in receipt['artifacts'],'unbound root restoration report')
        restore=e.js(restore_path,receipt['artifacts'][str(restore_path)])
        report['root_restore_equivalence']=audit_roots(fields,initial,protocol,restore)
        body=e.npz(Path(b['parameter_path']).parent/'body_identity.npz')
        identity=contact_identity(e,batch,b,body)
        report['contacts']=contacts(e,batch,fields,identity)
        computed=np.stack([flags({k:v[i] for k,v in fields.items()},layout,q,i>0) for i in range(13)])
        exact(computed,fields['violations'],'independent seven reason masks')
        report['observed_reason_counts']={r:int(computed[:,:,j].sum()) for j,r in enumerate(REASONS)}
        report['reason_mask_13x32x7']=computed.tolist()
        report['camera'],origins=cameras(e,batch,fields,layout,body,identity)
        report['geometry']=geometry_evidence(e,entry,b,fields,origins)
        status=classify(computed,native_closed=True,v7_camera=True)
        ledger=e.npy(out/'all_proposal_status.npy',(8192,),'uint8')
        exact(ledger[:32],status,'actual attempted ledger');exact(ledger[32:],np.zeros(8160,np.uint8),'retained unused8160')
        ls=e.js(out/'ledger_schema.json');require(ls['states']=={str(i):v for i,v in enumerate(STATES)} and ls['selected_count']==0 and ls['never_drop_unused'] is True and ls['proposals_manifest']==req['proposals_manifest'],'ledger contract')
        closed=e.js(batch/'BATCH_CLOSED.json')
        require(closed['complete'] is True and closed['backend']=='isaac_physx_native' and closed['actual_microsteps']==12 and closed['initial_q_qd_target74_bitwise'] is True and closed['camera_qualified'] is True and closed['no_selection'] is True and closed['safety_acceptance'] is False,'batch closure')
        require(closed['reasons']==list(REASONS) and closed['status_counts']==counts(status) and receipt['proposal_status_counts']==counts(ledger),'producer/independent status counts disagree')
        report.update(status='CLOSED_INDEPENDENT_DEVELOPMENT_DATA_ONLY',batch_status_counts=counts(status),proposal_status_counts=counts(ledger),
            proposal_status_8192=ledger.tolist(),attempted_ids=list(range(32)),unused_count=8160,
            prefix_eligible_count=int(np.count_nonzero(status==3)),zero_eligible_is_valid_data=True,
            prefix_eligibility_is_safety_proof=False,whole_prototype_goals='task tracking, pause/resume, FIFO, global error bounds and holdout remain outside this input screen')
        code=0
    except PendingNative as exc:
        report['status']='PENDING_ACTUAL_NATIVE_CLOSURE';report['errors'].append(str(exc));code=3
    except Exception as exc:
        report['errors'].append(dict(type=type(exc).__name__,message=str(exc),traceback=traceback.format_exc()))
    try:e.recheck()
    except Exception as exc:
        report['status']='FAILED_EVIDENCE_MUTATION';report['errors'].append(str(exc));code=2
    report['input_read_ledger']=e.ledger
    report['CPU_limits']=dict(address_space_bytes=1024**3,threads=1,bytecode=False)
    write_new(args.output,report);print(json.dumps(dict(status=report['status'],errors=len(report['errors']),native_pass=False)),flush=True)
    return code


def main():
    cpu_limits()
    p=argparse.ArgumentParser(description=__doc__,allow_abbrev=False)
    p.add_argument('--attempt-root',required=True);p.add_argument('--parent-wait-sha256',required=True)
    p.add_argument('--request-sha256',required=True);p.add_argument('--output',required=True)
    p.add_argument('--outer-execution-sha256',required=True)
    a=p.parse_args();contained(a.output,OUTPUT)
    require(all(len(x)==64 and all(c in '0123456789abcdef' for c in x) for x in (a.parent_wait_sha256,a.request_sha256,a.outer_execution_sha256)),'explicit external SHA bindings required')
    return run(a)


if __name__=='__main__':
    raise SystemExit(main())
