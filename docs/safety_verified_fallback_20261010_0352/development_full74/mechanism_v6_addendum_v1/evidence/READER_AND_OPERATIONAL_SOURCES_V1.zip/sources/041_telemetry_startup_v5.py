"""Process-local telemetry startup exclusion; no SDK import, signal or user-config write."""
from mechanism_bootstrap_v1 import require as need
ARGS=('--/app/extensions/excluded/0=omni.kit.telemetry','--/structuredLog/enable=false','--/telemetry/enableAnonymousData=false')
def configure(config):
 args=config.setdefault('extra_args',[])
 need(type(args) is list and not any(str(v).startswith(('--/app/extensions/excluded','--/structuredLog/enable','--/telemetry/enableAnonymousData')) for v in args),'no conflicting telemetry/exclusion override')
 args.extend(ARGS)
def capture(settings,extension_manager,environment):
 value=dict(schema='astra.constraint.mechanism.telemetry_startup_readback.v5',excluded=settings.get('/app/extensions/excluded'),structured_log_enabled=settings.get('/structuredLog/enable'),anonymous_data_enabled=settings.get('/telemetry/enableAnonymousData'),enabled_extension_id=extension_manager.get_enabled_extension_id('omni.kit.telemetry'),disable_anonymous_environment=environment.get('OMNI_TELEMETRY_DISABLE_ANONYMOUS_DATA'),native_wait_waiver=False)
 need(value['excluded']==['omni.kit.telemetry'] and value['structured_log_enabled'] is False and value['anonymous_data_enabled'] is False and (value['enabled_extension_id'] is None or value['enabled_extension_id']=='') and value['disable_anonymous_environment']=='1','actual startup exclusion and settings required')
 return value
