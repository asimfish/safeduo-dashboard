"""Frozen data-only reader interface; no native launch or native math changes.

Independent reviewer must recompute the retained tree/readback and provide
the matching review. This adapter validates the resulting provenance chain;
it does not manufacture that independent review or a calibration input.
"""
import io,json
from pathlib import Path
import numpy as np
import mechanism_bootstrap_v1 as b
from frame_schema_v4 import need,model_from_registry
from native_frame_export_v4 import IDENTITIES

def replay_export(receipt_ref,layout,body_names):
    r=b.document(receipt_ref);need(r['schema']=='astra.full74.frame_export_receipt.v4' and r['backend']=='isaac_physx_native' and r['synthetic'] is False,'actual exporter schema')
    need(r['identities']==IDENTITIES and r['capture_stage']=='BEFORE_EXPERIMENT_STATE_WRITE' and r['observational_readback_byte_equal'] is True and r['physics_steps_during_capture']==0,'source identities/prewrite observation')
    need(r['source_graph']==b.ref(Path(__file__).parent/'SOURCE_GRAPH_V4.json') and r['model'] is not None and r['native_frame_evidence'] is not None and r['model_errors']==[],'matching source-bound model-ready export')
    artifacts=r['source_artifacts'];need(len(artifacts)==4,'registry, two real readbacks and retained all32 coupling inventory')
    registry=b.document(artifacts[0]);archives=[]
    for ref in artifacts[1:3]:
        with np.load(io.BytesIO(b.raw_ref(ref)),allow_pickle=False) as z:archives.append({k:z[k] for k in z.files})
    before,after=archives;need(before.keys()==after.keys() and all(before[k].dtype==after[k].dtype and before[k].shape==after[k].shape and before[k].tobytes()==after[k].tobytes() for k in before),'all saved native fields unchanged')
    inventory=b.document(artifacts[3]);need(inventory['schema']=='astra.native.constraint_inventory.v2','actual coupling inventory retained, never inferred absent')
    model,_=model_from_registry(registry,before,layout,body_names);need(model==b.document(r['model']),'recompute recorded frames, not copied producer flags')
    evidence=b.document(r['native_frame_evidence']);need(evidence['source_artifacts']==artifacts and evidence['model']==r['model'] and evidence['source_graph']==r['source_graph'] and evidence['request_sha256']==r['request_sha256'],'matching evidence/model/raw chain')
    return r,model
def binding_after_actual_closure(receipt_ref,native_wait_ref,entry_ref,frame_export_review_ref):
    r=b.document(receipt_ref);w=b.document(native_wait_ref);entry=b.document(entry_ref);review=b.document(frame_export_review_ref)
    need(w['schema']=='astra.full74.parent_native_wait.v1' and w['backend']=='isaac_physx_native','actual native wait domain')
    # Exact closed core82c5 uses resource_abort/error/signals. Its shared closed
    # wait verifier also checks wait4 status, fork enrollment, absence and logs.
    import hashlib,types
    support_path=b.H/'astra/full74_clock3_reader_operations_v1/common_v1.py'
    support_raw=b.raw_ref(dict(path=str(support_path),sha256='4f8f6f698e1e62c2ecea0c9177f05e6962d677d1b652eccfce44b9b2442e33ca'))
    support=types.ModuleType('_frame_export_closed_wait_v4');support.__file__=str(support_path)
    exec(compile(support_raw,str(support_path),'exec'),support.__dict__)
    support.closed_wait(w,0,'astra.full74.parent_native_wait.v1','isaac_physx_native')
    need(entry['request_sha256']==r['request_sha256'] and entry['measurement_bytes_verified'] is True and entry['cleanup_errors']==[] and entry['actual_gpu_identity'],'actual measurement ENTRY/device evidence')
    need(entry['producer']['observational_frame_export']==receipt_ref and r['model'] is not None and r['native_frame_evidence'] is not None and r['model_errors']==[],'ENTRY points to exact frame export')
    need(review['status'] in ('PASS','COND_PASS') and review['blocking_findings']==[] and review['source_graph']==r['source_graph'] and review['frame_export_receipt']==receipt_ref and review['native_wait']==native_wait_ref and review['entry']==entry_ref and review['independent_tree_readback_recomputed'] is True and review['native_frame_evidence']==r['native_frame_evidence'] and review['model']==r['model'],'distinct closed frame review required')
    # Directly consumable by immutable contract_v2.model_inputs. The required
    # all128 point0 calibration_input is a SEPARATE independent data export;
    # the mechanism's 32 A/B states are never substituted for A128.
    return dict(schema='astra.full8192.native_frame_binding.v2',synthetic=False,**IDENTITIES,model=r['model'],native_frame_evidence=r['native_frame_evidence'],frame_export_review=frame_export_review_ref)
