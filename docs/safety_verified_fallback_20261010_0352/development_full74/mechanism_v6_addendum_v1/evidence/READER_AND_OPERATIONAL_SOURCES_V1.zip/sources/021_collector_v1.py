"""32 cases in the parent's existing App: diagnostic only, no policy/bank."""
import json,os,time,traceback,xml.etree.ElementTree as ET
from pathlib import Path
import numpy as np
from constraint_model_v1 import need,affine_relations,ordered,paired_inputs,coverage,residual
from native_inventory_v1 import inventory

def urdf_relations(request,layout,binding):
    """DFX hints ONLY for U_L/U_R. Never transplant DFX ratios to FR3/F2."""
    result=[];names=layout['names'].tolist()
    for arm,ref in request['urdf_sources'].items():
        need(arm in ('U_L','U_R'),'no cross-asset URDF assumption')
        raw=binding.raw_ref(ref)
        for joint in ET.fromstring(raw).findall('joint'):
            mimic=joint.find('mimic')
            if mimic is None:continue
            c,p=arm+'/'+joint.attrib['name'],arm+'/'+mimic.attrib['joint']
            need(c in names and p in names and joint.attrib['type']=='revolute','mapped URDF revolute DOF')
            result.append(dict(child=names.index(c),parent=names.index(p),multiplier=float(mimic.get('multiplier','1')),
                offset=float(mimic.get('offset','0')),authority='URDF_KINEMATIC_HINT_NOT_NATIVE_CONSTRAINT',source=ref))
    need(len(result)==12,'two DFX hands six relations each');return ordered(result)

def run(env,request,request_sha,out,resource_probe,b,old):
    """No launch/guardian/cleanup here. Caller MUST use measurement lifecycle V2."""
    frozen=old.frozen;out=Path(out);out.mkdir(parents=True,exist_ok=False)
    receipt=dict(schema='astra.constraint.mechanism.producer.v1',status='FAILED',request_sha256=request_sha,
        registered_cases=32,latent_proposals=16,actual_micro_ids=[],physics_steps=0,policy_actions=0,
        camera_status='NOT_TESTED_DIAGNOSTIC_ONLY',eligibility=False,bank_count=0,hidden_solver_state_restored=False,
        CONTACT='UNKNOWN',ACTUAL_DRIVE_TORQUE='UNKNOWN',PASSIVE_CONSTRAINT_IMPULSE='UNKNOWN',TERMINAL_SET='UNKNOWN',
        certified_error_bound=False,reachable_from_safe_initial_state='UNKNOWN')
    before=None;clock=None;stream=None;error=None;started=time.monotonic();flags=[];allq=[];allqd=[]
    def guard():
        need(time.monotonic()-started<1200,'mechanism original external1200 deadline')
        from mechanism_gpu_binding_v4 import observation
        observation(request['gpu_binding'],resource_probe(),initial=False)
    def measure():return dict(parameters=old.native_parameter_readback(env),geometry=frozen.geometry_identity(env))
    def save(label,v):
        with (out/f'PARAMETERS_{label}.npz').open('xb') as f:np.savez_compressed(f,**v['parameters']);f.flush();os.fsync(f.fileno())
        b.json_new(out/f'GEOMETRY_{label}.json',v['geometry'])
        return {k:b.ref(out/p) for k,p in [('parameters',f'PARAMETERS_{label}.npz'),('geometry',f'GEOMETRY_{label}.json')]}
    try:
        guard();params=old.load_parameters();layout=old.intervals(params);frozen.check_parameters(env,params)
        before=measure();receipt['measurements_before']=save('BEFORE',before)
        geometry=json.loads(Path(old.INPUT_BINDING['geometry_identity_path']).read_bytes())
        need(all(before['geometry'][k]==geometry[k] for k in before['geometry']),'exact original9021 geometry')
        inv=inventory(env,layout,frozen.array);b.json_new(out/'CONSTRAINTS_BEFORE.json',inv)
        from native_frame_export_v4 import export_before_write
        receipt['observational_frame_export']=export_before_write(env,layout,params,out,request_sha,b,old,guard)
        native_relations=affine_relations(inv['mimic_relations'],layout['names'].tolist(),layout['controlled'])
        # No automatic switch of intervention according to outcomes/native findings.
        if request['intervention']=='LIVE_USD_AFFINE_HAND_MIMIC':
            need(not inv['unsupported'] and bool(native_relations),'no supported native affine relations; experiment not executable')
            relations=native_relations
        else:
            need(request['intervention']=='URDF_DFX_HAND_COHERENCE_HYPOTHESIS','fixed intervention mode')
            need(not inv['unsupported'] and not native_relations,'unexpected live coupling: do not silently reinterpret URDF experiment')
            relations=urdf_relations(request,layout,b)
        receipt.update(intervention=request['intervention'],native_mimic_schema_count=len(native_relations),
            native_constraint_consistency_claim=False,relations=relations)
        manifest=b.document(request['cohort']);root=Path(request['cohort']['path']).parent
        need(manifest['purpose']=='DEVELOPMENT_ONLY' and len(manifest['files'])==3,'original development manifest')
        # Recheck only the three actual proposal inputs, never redraw.
        old.verify_files(manifest['files']);ids=request['proposal_ids']
        q=np.load(root/'q74.npy',mmap_mode='r',allow_pickle=False);qd=np.load(root/'qd74.npy',mmap_mode='r',allow_pickle=False)
        families=np.load(root/'family.npy',mmap_mode='r',allow_pickle=False)
        need(q.shape==qd.shape==(8192,74) and q.dtype==qd.dtype==np.float32,'original8192 shapes')
        need(np.array_equal(families[ids],np.asarray(ids)%4),'original source families')
        rawq,rawv=q[ids].copy(),qd[ids].copy()
        x,y,cq,cv,cases=paired_inputs(rawq,rawv,ids,relations,layout,request['intervention'])
        for name,a in [('latent_q74',rawq),('latent_qd74',rawv),('candidate_q74',cq),('candidate_qd74',cv),('requested_q74',x),('requested_qd74',y),('held_target74',x),('original_task_goal74',np.concatenate([params[a+'_full_initial_position_target'] for a in old.ARMS],1))]:old.npy_new(out/(name+'.npy'),a)
        b.json_new(out/'CASES.json',cases);b.json_new(out/'DISTRIBUTION.json',dict(latent=coverage(rawq,rawv,layout),written=coverage(x,y,layout),constructible=sum(c['constructible'] for c in cases),denominator=16,sentinel_ids=[92,93,94,95],prospective_ids=list(range(96,108)),not_new_draws=True))
        with np.load(old.INPUT_BINDING['initial_path'],allow_pickle=False) as z:roots={a:(z[a+'_root'],z[a+'_root_velocity']) for a in old.ARMS}
        old.restore_all32(env,x,y,roots,params)
        from native_all_body_contacts_v2 import NativeContacts
        observer=NativeContacts(env,out);frozen.validate_owner_identity(observer,json.loads(Path(old.INPUT_BINDING['contact_identity_path']).read_bytes()))
        stream=old.NpyStream(out/'native_fields',13)
        origins=frozen.array(env.scene.env_origins);old.npy_new(out/'environment_origins_before.npy',origins)
        for micro in range(13):
            guard()
            if micro:
                env.scene.write_data_to_sim()
                target=np.concatenate([frozen.array(env._arms[a].root_physx_view.get_dof_position_targets()) for a in old.ARMS],1)
                old.npy_new(out/f'applied_target74_micro_{micro:03d}.npy',target);need(frozen.exact(target,x),'all74 same assigned target')
                clock.before(micro);env.sim.step(render=False);env.scene.update(env.cfg.sim.dt)
            row=frozen.capture_row(env,observer,out,micro);row['violations']=old.numeric_checks(row,layout,x,micro>0)
            stream.append(row);receipt['actual_micro_ids'].append(micro)
            if not micro:
                exact=old.bitwise_lanes(row['q74'],x)&old.bitwise_lanes(row['qd74'],y)&old.bitwise_lanes(row['target74'],x)
                root_ok,rreport=old.root_admission(row,roots);b.json_new(out/'ROOT_ADMISSION.json',rreport)
                need(exact.all() and root_ok.all(),'native initial full74/root readback differs')
                clock=old.ClockSession(env,out,request['source_files']);clock.start(row)
            else:clock.commit(micro,row);receipt['physics_steps']=micro
            flags.append(row['violations']);allq.append(row['q74'].copy());allqd.append(row['qd74'].copy())
            b.json_new(out/f'PROGRESS_{micro:03d}.json',dict(committed_micro=micro,clock_validated=True,native_step=int(row['simulation_step']),native_time=float(row['simulation_time_s'])))
        need(frozen.exact(origins,frozen.array(env.scene.env_origins)),'all32 origins held')
        old.npy_new(out/'environment_origins_after.npy',frozen.array(env.scene.env_origins))
        inv_after=inventory(env,layout,frozen.array);b.json_new(out/'CONSTRAINTS_AFTER.json',inv_after);need(inv_after==inv,'constraint/drive configuration changed')
        from summarize_v1 import summarize
        b.json_new(out/'DESCRIPTIVE_PAIRED_OUTCOMES.json',summarize(cases,np.asarray(flags),np.asarray(allq),np.asarray(allqd),layout,relations))
        stream.close();receipt['status']='MECHANISM_COLLECTION_COMPLETE_PENDING_WAIT_AND_INDEPENDENT_AUDIT'
    except BaseException as exc:
        error=exc;receipt.update(status='FAILED',error=type(exc).__name__+':'+str(exc),traceback=traceback.format_exc())
    finally:
        try:
            if clock is not None:clock.close()
        except BaseException as exc:receipt['clock_close_error']=str(exc);error=error or exc
        try:
            need(before is not None,'before measurement missing');after=measure();receipt['measurements_after']=save('AFTER',after)
            old.verify_measurement(before,after);frozen.check_parameters(env,params);receipt['measurement_bytes_verified']=True
        except BaseException as exc:receipt['measurement_error']=str(exc);error=error or exc
        if error is not None:receipt['status']='FAILED'
        if stream is not None:
            for a in stream.arrays.values():a.flush();a._mmap.close()
            stream.arrays.clear()
        receipt['elapsed_s']=time.monotonic()-started;receipt['artifacts']={str(p):b.sha(p) for p in out.rglob('*') if p.is_file()}
        b.json_new(out/'MECHANISM_RECEIPT_V1.json',receipt)
    if error is not None:raise error
    return receipt
