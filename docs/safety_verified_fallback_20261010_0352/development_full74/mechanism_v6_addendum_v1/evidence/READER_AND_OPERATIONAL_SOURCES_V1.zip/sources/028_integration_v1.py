"""Existing-parent-App integration using closed lifecycle V2, no nested guardian."""
import os,traceback
import mechanism_bootstrap_v1 as b
from collector_v1 import run
OLD=None
def create_environment_in_existing_app(device):return OLD.create_environment_in_existing_app(device)
def run_in_existing_parent_app(app,env_factory,*,request_path,request_sha256,review_path,review_sha256,
        resource_probe,write_entry,write_app_error,gpu_permit_path,gpu_permit_sha256,pre_app_proof,native_torch,kit_settings,kit_log_path):
    env=None;error=None;lifecycle=None;state=dict(status='failed',cleanup_errors=[],request_sha256=request_sha256)
    try:
        q,out=b.request_pair(request_path,request_sha256,review_path,review_sha256,native=True)
        lifecycle=OLD.verified_module(OLD.LIFECYCLE,q['source_files'][str(OLD.LIFECYCLE)])
        from runtime_mechanism_v1 import load_runtime
        from mechanism_gpu_binding_v4 import runtime_identity,observation
        core=load_runtime(q);permit=b.bounded_json(gpu_permit_path,gpu_permit_sha256)
        b.require(permit['request_sha256']==request_sha256 and permit['gpu_binding']==q['gpu_binding'] and
            pre_app_proof['request_sha256']==request_sha256 and pre_app_proof['permit_sha256']==gpu_permit_sha256 and
            core.same_identity(core.proc_identity(os.getpid()),pre_app_proof['child_identity']),'same owned pre-App proof')
        observation(q['gpu_binding'],pre_app_proof['fresh_prelaunch_observation'],initial=True)
        state['actual_gpu_identity']=runtime_identity(q['gpu_binding'],native_torch,kit_settings,kit_log_path)
        env=env_factory();state['producer']=run(env,q,request_sha256,out,resource_probe,b,OLD)
        state['measurement_bytes_verified']=True;state['status']='mechanism_complete_pending_actual_wait_and_independent_audit'
    except BaseException as exc:error=exc;state.update(status='failed',error=str(exc),traceback=traceback.format_exc())
    finally:
        if lifecycle is not None:lifecycle.close_environment_and_app(state,env,app,write_entry,write_app_error)
        else:
            try:
                try:
                    if env is not None:env.close()
                finally:write_entry(state)
            finally:
                if app is not None:app.close()
    if error is not None:raise error
    return state
