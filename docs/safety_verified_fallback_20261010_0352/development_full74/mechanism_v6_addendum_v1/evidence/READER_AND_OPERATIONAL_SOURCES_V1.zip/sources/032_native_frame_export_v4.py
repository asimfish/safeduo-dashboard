"""Observation in the parent's existing live App, before experiment writes.

No App launch, render, state write, physics step, root restoration or sampler.
The exact registry/readback survives an unsupported FK tree. MODEL_ONLY is a
separate consumer and cannot mint native/physical/camera/bank acceptance.
"""
import hashlib,io,json,math,os,time
from pathlib import Path
import numpy as np
from frame_schema_v4 import ARMS,need,topology,model_from_registry

R=Path('/mnt/nas/data/lyf/double_hand/safety_verified_fallback_20261010_0352')
IDENTITIES={
    'cohort':dict(path=str(R/'astra_full74_per_state_development_v4/cohort_v1/PROPOSALS.json'),sha256='bdc14bb135aa5b4801cae941110284aebecdad1f0a4b39d71f40e05622d47d8c'),
    'parameter':dict(path=str(R/'shard_raw_v1/batch0_shard0_raw/resolved_native_parameters.npz'),sha256='13ef2ceee82aa9aa8a435be85124e7dc8559ba7189c167eb1e0d5eda966e9273'),
    'geometry':dict(path=str(R/'shard_raw_v1/batch0_shard0_raw/full_row_identity.json'),sha256='5bcc551590ce7a6696ce0d23e2d09e4d15ccdfe50f3ca7a106b2be8130633d4b'),
    'body_identity':dict(path=str(R/'shard_raw_v1/batch0_shard0_raw/body_identity.npz'),sha256='3770ceb1e4e5cc23a8f56cf6a48ffeb7e03f98a90ef923f0e6848df39d1f2b5a')}
def value(v):
    if v is None or isinstance(v,(str,bool,int)):return v
    if isinstance(v,float):
        return v if math.isfinite(v) else {'nonfinite_float':str(v)}
    try:return [value(x) for x in v]
    except TypeError:return str(v)
def quat(q):return [float(q.GetReal()),*[float(x) for x in q.GetImaginary()]]
def attribute(a,quaternion=False):
    need(bool(a),'missing resolved schema attribute')
    v=a.Get();need(v is not None,'unresolved schema value '+a.GetName())
    return (quat(v) if quaternion else value(v)),dict(name=a.GetName(),type=str(a.GetTypeName()),authored=bool(a.HasAuthoredValueOpinion()),property_stack=[dict(layer=p.layer.identifier,path=str(p.path)) for p in a.GetPropertyStack()])
def readback(env,array):
    fields={'env_origins':array(env.scene.env_origins).copy(),
        'table_centers_world_no_env_origin':array(env._sph._tables[0]).copy(),
        'table_half_extents':array(env._sph._tables[1]).copy(),
        'simulation_step':np.asarray(int(env.sim.current_time_step_index),np.int64),
        'simulation_time_s':np.asarray(float(env.sim.current_time),np.float64)}
    qs=[];vs=[];ts=[]
    for arm in ARMS:
        view=env._arms[arm].root_physx_view
        qs.append(array(view.get_dof_positions()).copy());vs.append(array(view.get_dof_velocities()).copy());ts.append(array(view.get_dof_position_targets()).copy())
        for suffix,getter in [('root_xyzw','get_root_transforms'),('root_velocity','get_root_velocities'),('link_xyzw','get_link_transforms'),('hard_limits','get_dof_limits')]:fields[arm+'_'+suffix]=array(getattr(view,getter)()).copy()
    fields.update(q74=np.concatenate(qs,1),qd74=np.concatenate(vs,1),target74=np.concatenate(ts,1))
    return fields
def capture_registry(env,guard):
    from pxr import Usd,UsdPhysics,UsdGeom
    stage=env.sim.stage;units=float(UsdGeom.GetStageMetersPerUnit(stage));up=str(UsdGeom.GetStageUpAxis(stage))
    lanes=[dict(lane=i,arms={}) for i in range(32)];prefixes={};errors=[];xforms=UsdGeom.XformCache(Usd.TimeCode.Default())
    for arm in ARMS:
        art=env._arms[arm];view=art.root_physx_view
        dofs=[[str(p) for p in row] for row in view.dof_paths];links=[[str(p) for p in row] for row in view.link_paths]
        for lane in range(32):
            try:
                path=str(view.prim_paths[lane]);prefix=path.split('/env_'+str(lane)+'/',1)[0]+'/env_'+str(lane)+'/'+path.split('/env_'+str(lane)+'/',1)[1].split('/')[0]+'/'
                if prefix in prefixes:errors.append(dict(lane=lane,arm=arm,error='duplicate articulation prefix'))
                prefixes.setdefault(prefix,[]).append((lane,arm))
                body_usd=[]
                for body_path in links[lane]:
                    try:
                        prim=stage.GetPrimAtPath(body_path);need(bool(prim),'native body path absent from live USD')
                        matrix=xforms.GetLocalToWorldTransform(prim)
                        body_usd.append([[float(matrix[i][j]) for j in range(4)] for i in range(4)])
                    except Exception as exc:
                        errors.append(dict(lane=lane,arm=arm,path=body_path,error=type(exc).__name__+': '+str(exc)[:4096]));body_usd.append(None)
                lanes[lane]['arms'][arm]=dict(prim_path=path,dof_paths=dofs[lane],link_paths=links[lane],joint_names=list(art.joint_names),body_names=list(art.body_names),link_parent_indices=None,fixed_base=None,native_metatype='RAW_SEPARATE_NOT_INTERPRETED',body_USD_world_row_vectors=body_usd,joints=[])
            except Exception as exc:errors.append(dict(lane=lane,arm=arm,error=type(exc).__name__+': '+str(exc)[:4096]))
    traversed=0
    for prim in Usd.PrimRange.Stage(stage,Usd.TraverseInstanceProxies()):
        traversed+=1
        if traversed%4096==0:guard()
        if not prim.IsA(UsdPhysics.Joint):continue
        path=str(prim.GetPath());matched=[v for k,values in prefixes.items() if path.startswith(k) for v in values]
        if not matched:continue
        if len(matched)!=1:
            errors.append(dict(path=path,error='ambiguous registered arm prefix'));continue
        lane,arm=matched[0];j=UsdPhysics.Joint(prim)
        record=dict(path=path,name=prim.GetName(),type=prim.GetTypeName(),schemas=list(prim.GetAppliedSchemas()),body0=[str(x) for x in j.GetBody0Rel().GetTargets()],body1=[str(x) for x in j.GetBody1Rel().GetTargets()],attribute_sources={})
        for name,getter,is_quat in [('localPos0',j.GetLocalPos0Attr,False),('localPos1',j.GetLocalPos1Attr,False),('localRot0',j.GetLocalRot0Attr,True),('localRot1',j.GetLocalRot1Attr,True),('enabled',j.GetJointEnabledAttr,False)]:
            try:record[name],record['attribute_sources'][name]=attribute(getter(),is_quat)
            except Exception as exc:
                record[name]=None;errors.append(dict(path=path,attribute=name,error=type(exc).__name__+': '+str(exc)[:4096]))
        record.update(axis=None,lower_limit=None,upper_limit=None)
        typed=UsdPhysics.RevoluteJoint(prim) if prim.IsA(UsdPhysics.RevoluteJoint) else UsdPhysics.PrismaticJoint(prim) if prim.IsA(UsdPhysics.PrismaticJoint) else None
        if typed is not None:
            for name,getter in [('axis',typed.GetAxisAttr),('lower_limit',typed.GetLowerLimitAttr),('upper_limit',typed.GetUpperLimitAttr)]:
                try:record[name],record['attribute_sources'][name]=attribute(getter())
                except Exception as exc:
                    record[name]=None;errors.append(dict(path=path,attribute=name,error=type(exc).__name__+': '+str(exc)[:4096]))
        lanes[lane]['arms'][arm]['joints'].append(record)
    for lane in lanes:
        for a in lane['arms'].values():a['joints'].sort(key=lambda j:j['path'])
    return dict(schema='astra.full74.live_joint_registry.v4',backend='isaac_physx_native',synthetic=False,capture_stage='BEFORE_EXPERIMENT_STATE_WRITE',stage_identifier=stage.GetRootLayer().identifier,used_layers=[l.identifier for l in stage.GetUsedLayers()],instance_proxies_traversed=True,getter_provider='installed omni.physics.tensors107.3.26 ArticulationView; get_link_transforms actor/link frame XYZW (not COM/visual)',native_positive_q='USD single-axis joint axis and native dof_paths recorded; no q_offset/q_gain fit. Candidate FK still requires independent64/64 empirical replay.',matrix_convention='column-vector homogeneous4x4, translation in last column; parent_A @ Motion(native_q) @ inverse(child_B)',
        capture_errors=errors,units=dict(meters_per_unit=value(units),up_axis=up,native_position='m',native_revolute_angle='rad',USD_revolute_limits='degree',USD_prismatic_limits='stage_distance_units',quaternion_USD='wxyz',quaternion_native='xyzw',USD_body_matrix='Gf row-vector world; retain rows, transpose once for MODEL scale/shear diagnostic, never substitute for native link pose'),lanes=lanes)
def export_before_write(env,layout,params,out,request_sha,b,old,guard):
    from native_metatype_raw_v5 import capture_metatypes,project_registry
    root=Path(out)/'native_frame_export_v4';root.mkdir(exist_ok=False);guard();before=readback(env,old.frozen.array)
    def save_readback(label,data):
        with (root/f'PREWRITE_NATIVE_READBACK_{label}.npz').open('xb') as f:np.savez_compressed(f,**data);f.flush();os.fsync(f.fileno())
    save_readback('BEFORE',before)
    guard_error=None
    def protected_guard():
        nonlocal guard_error
        try:guard()
        except Exception as exc:guard_error=exc;raise
    # Durable ALL32 typed raw metadata exists before a mapping assertion or
    # USD registry interpretation. Missing/rootless maps remain raw evidence.
    raw_meta=capture_metatypes(env,protected_guard)
    b.json_new(root/'RAW_NATIVE_METATYPE_V5.json',raw_meta)
    capture_error=None
    try:raw_registry=capture_registry(env,protected_guard)
    except Exception as exc:
        if exc is guard_error:raise
        capture_error=type(exc).__name__+': '+str(exc)[:4096]
        raw_registry=dict(schema='astra.full74.live_joint_registry.v4',capture_errors=[capture_error],capture_stage='BEFORE_EXPERIMENT_STATE_WRITE',lanes=[])
    b.json_new(root/'RAW_LIVE_JOINT_REGISTRY_V5.json',raw_registry)
    guard();after=readback(env,old.frozen.array);save_readback('AFTER',after)
    # State/resource/storage failures are still fatal. ONLY interpretation of
    # already-retained observational data can be MODEL_NOT_READY and continue.
    need(before.keys()==after.keys() and all(old.frozen.exact(before[k],after[k]) for k in before),'observational exporter changed native readback/clock')
    need(all(before[k].dtype==np.float32 and before[k].shape==(32,74) and np.isfinite(before[k]).all() for k in ('q74','qd74','target74')),'complete native74 prewrite state')
    for arm in ARMS:need(old.frozen.exact(before[arm+'_hard_limits'],params[arm+'_hard_limits']),'original native all32 limits')
    raw_refs=[b.ref(root/'RAW_LIVE_JOINT_REGISTRY_V5.json'),b.ref(root/'PREWRITE_NATIVE_READBACK_BEFORE.npz'),b.ref(root/'PREWRITE_NATIVE_READBACK_AFTER.npz'),b.ref(Path(out)/'CONSTRAINTS_BEFORE.json')]
    diagnostics=[b.ref(root/'RAW_NATIVE_METATYPE_V5.json'),raw_refs[0]]
    need(all(Path(r['path']).stat().st_size<=16*1024**2 for r in raw_refs+diagnostics),'consumer16MiB per source artifact ceiling')
    # Unsupported FK structures do not change the registered A/B experiment.
    # The complete raw observation remains retained with explicit model denial.
    result=dict(schema='astra.full74.frame_export_receipt.v4',status='RECORDED_LIVE_FRAME_SOURCE_MODEL_PENDING',request_sha256=request_sha,capture_stage='BEFORE_EXPERIMENT_STATE_WRITE',backend='isaac_physx_native',synthetic=False,source_graph=b.ref(Path(__file__).parent/'SOURCE_GRAPH_V4.json'),source_artifacts=raw_refs,identities=IDENTITIES,model=None,native_frame_evidence=None,model_errors=[],raw_diagnostic_artifacts=diagnostics,unsupported_model_continues_original_AB=True,observational_readback_byte_equal=True,physics_steps_during_capture=0,render_calls=0,source_frame_kind='LIVE_COMPOSED_USD_PLUS_NATIVE_PHYSX_IDENTITY_AND_READBACK',calibration='NOT_TESTED',native_admission=False,bank_count=0,CONTACT='UNKNOWN',ACTUAL_DRIVE_TORQUE='UNKNOWN',TERMINAL_SET='UNKNOWN')
    try:
        need(capture_error is None,'raw USD capture error: '+str(capture_error))
        registry=project_registry(raw_registry,raw_meta)
        b.json_new(root/'LIVE_JOINT_REGISTRY_V4.json',registry);raw_refs[0]=b.ref(root/'LIVE_JOINT_REGISTRY_V4.json')
        body_bytes=b.raw_ref(IDENTITIES['body_identity'])
        with np.load(io.BytesIO(body_bytes),allow_pickle=False) as z:body={a:z[a] for a in ARMS}
        topology(registry);model,root_comparison=model_from_registry(registry,before,layout,body)
        b.json_new(root/'FK_FRAME_MODEL_V2.json',model);model_ref=b.ref(root/'FK_FRAME_MODEL_V2.json')
        evidence=dict(schema='astra.full74.recorded_native_frame_evidence.v2',status='PROVISIONAL_PREWRITE_REQUIRES_ACTUAL_WAIT_ENTRY_AND_DISTINCT_REVIEW',native_wait='PENDING_AT_CAPTURE',backend='isaac_physx_native',synthetic=False,all32_topology_verified=True,joint_frames_are_actual_native_or_USD=True,coordinates='ALL74_INDEPENDENT_NO_MIMIC_PROJECTION',model=model_ref,geometry=IDENTITIES['geometry'],parameter=IDENTITIES['parameter'],body_identity=IDENTITIES['body_identity'],source_artifacts=raw_refs,source_graph=result['source_graph'],request_sha256=request_sha,root_comparison=root_comparison,model_only=True,native_admission=False,calibration='NOT_TESTED',root_rotation_conversion='retained raw xyzw; matrix from quaternion divided by recorded norm, norm error<=8float32eps')
        b.json_new(root/'RECORDED_NATIVE_FRAME_EVIDENCE_V2.json',evidence);result.update(status='RECORDED_LIVE_FRAME_TREE_PENDING_INDEPENDENT_REVIEW_AND_64_64_CALIBRATION',model=model_ref,native_frame_evidence=b.ref(root/'RECORDED_NATIVE_FRAME_EVIDENCE_V2.json'))
    except (ValueError,KeyError,TypeError,AttributeError,IndexError,NotImplementedError) as exc:result.update(status='MODEL_NOT_READY',model_errors=[type(exc).__name__+': '+str(exc)])
    guard();b.json_new(root/'FRAME_EXPORT_RECEIPT_V4.json',result)
    return b.ref(root/'FRAME_EXPORT_RECEIPT_V4.json')
