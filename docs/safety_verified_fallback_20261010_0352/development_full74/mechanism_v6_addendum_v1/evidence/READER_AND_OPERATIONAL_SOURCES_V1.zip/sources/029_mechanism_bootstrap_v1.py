"""Separate request authority. Closed V4 modules are loaded, never monkeypatched."""
import hashlib,json,os,sys,types
from pathlib import Path
HERE=Path(__file__).resolve().parent
H=HERE.parents[1];R=Path('/mnt/nas/data/lyf/double_hand/safety_verified_fallback_20261010_0352')
BASE=R/'astra_full74_native_constraint_mechanism_v6_stateapi';UP=H/'astra/full74_admissible_pilot_fresh_resume_v4'
UP_SHA='62140cc4ce5c03903ecdcf05239ab0caf03adafe45a1bb2db52ee9887fb60595'
RUNTIME_REF=dict(path=str(R/'parent_full74_admissible_pilot_fresh_resume_v4/campaign_v4/FROZEN_SEED_1_REQUEST_V4.json'),sha256='c58428921c897fa3509e663a278524c4d029655a65e3b47af84d0fbc18e62422')
COHORT=dict(path=str(R/'astra_full74_per_state_development_v4/cohort_v1/PROPOSALS.json'),sha256='bdc14bb135aa5b4801cae941110284aebecdad1f0a4b39d71f40e05622d47d8c')
def require(v,s):
    if not v:raise ValueError(s)
def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for x in iter(lambda:f.read(1024**2),b''):h.update(x)
    return h.hexdigest()
def ref(p):return dict(path=str(p),sha256=sha(p))
def raw_ref(r):
    with Path(r['path']).open('rb') as f:v=f.read(16*1024**2+1)
    require(len(v)<=16*1024**2 and hashlib.sha256(v).hexdigest()==r['sha256'],'same buffer SHA/size');return v
def document(r):
    def unique(items):
        d={}
        for k,v in items:require(k not in d,'duplicate JSON key');d[k]=v
        return d
    return json.loads(raw_ref(r),object_pairs_hook=unique)
def bounded_json(p,d):return document(dict(path=str(p),sha256=d))
bound_json=bounded_json
def json_new(p,v):
    with Path(p).open('x') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n');f.flush();os.fsync(f.fileno())
def assert_threads():
    require(sys.dont_write_bytecode and all(os.environ.get(k)=='1' for k in ('PYTHONDONTWRITEBYTECODE','OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS')),'-B/threads1')
def graph():return document(ref(HERE/'SOURCE_GRAPH_V4.json'))['files']
def request_pair(path,digest,review_path,review_digest,*,native):
    q=bounded_json(path,digest);r=bounded_json(review_path,review_digest);g=graph()
    require(r['request_sha256']==digest and r['status']=='REVIEWED' and r['source_graph']==ref(HERE/'SOURCE_GRAPH_V4.json'),'explicit new parent review graph')
    require(q['schema']=='astra.constraint.mechanism.request.v1' and q['source_files']==g,'separate mechanism graph')
    require(q['cohort']==COHORT and q['seed_index']==0 and q['proposal_ids']==list(range(92,108)),'exact16 existing source proposals, no redraw')
    require(q['cases']==32 and q['prefix_microsteps']==12 and q['max_wall_seconds']==1200 and q['policy_actions']==0,'fixed finite experiment')
    require(q['camera_schedule']=='NOT_TESTED_DIAGNOSTIC_ONLY' and q['bank_allowed'] is False and q['formal_holdout'] is False,'no bank/camera promotion')
    require(q['intervention'] in ('LIVE_USD_AFFINE_HAND_MIMIC','URDF_DFX_HAND_COHERENCE_HYPOTHESIS'),'predeclared intervention')
    require(q['runtime_reference']==RUNTIME_REF and q['freshness_seconds']==30 and q['freshness_protocol']=='OWNED_READY_PARENT_RENEWAL_APP_BOUNDARY_V4','unchanged parent core/fresh gate')
    base=document(RUNTIME_REF)
    for k in ('resource','SSD_operational_reserve_bytes','min_NAS_free_bytes'):require(q[k]==base[k],'original resource/GPU binding '+k)
    require(q['pre_app_freshness_graph']==ref(HERE/'SOURCE_GRAPH_V4.json'),'current delta fresh source authority')
    original=document(dict(path=str(R/'parent_native_constraint_mechanism_v2/FROZEN_REQUEST_V2.json'),sha256='049f34253437e642dc43adceccfb36921cf41042baa53e87cd7fb350e02bf645'))
    operational={'gpu_binding','source_files','pre_app_freshness_graph','attempt_root','out','parent_frozen','draft_only','cpu_test_only'}
    require(set(q)==set(original) and all(q[k]==original[k] for k in original if k not in operational),'V2 frozen scientific fields and resource floors unchanged')
    expected_gpu=dict(physical_index=0,physical_uuid='GPU-b129224c-c735-a03f-de6c-185d2a2724b1',CUDA_VISIBLE_DEVICES='0',logical_device='cuda:0',physics_gpu_logical=0,renderer_kit_index=0,renderer_uuid_prefix='b129224c',renderer_pci_bus_hex='41',multi_GPU=False)
    require(type(q['gpu_binding']) is dict and set(q['gpu_binding'])==set(expected_gpu) and all(type(q['gpu_binding'][k]) is type(v) and q['gpu_binding'][k]==v for k,v in expected_gpu.items()),'exact GPU0 physical UUID/PCI/renderer/logical binding')
    expected_urdf=json.loads((HERE/'PLAN_V2.json').read_bytes())['urdf_sources'];require(q['urdf_sources']==expected_urdf,'fixed corresponding U DFX source hints')
    if native:
        require(q['parent_frozen'] is True and q['draft_only'] is False and r['parent_execute_authorized'] is True,'parent review/freeze required')
        require(q['cpu_test_only'] is False and r['cpu_test_only'] is False,'CPU fixture cannot authorize native')
        independent=document(r['independent_review'])
        require(independent['source_graph']==ref(HERE/'SOURCE_GRAPH_V4.json') and independent['status'] in ('PASS','COND_PASS') and independent['blocking_findings']==[],'independent exact-source review')
    for p,d in g.items():
        if native or Path(p).is_relative_to(HERE):require(sha(p)==d,'source bytes '+p)
    root=Path(q['attempt_root']);out=Path(q['out'])
    require(root==BASE/'native_attempt1' and root.resolve()==root and out==root/'native' and not out.exists(),'exclusive new NAS attempt')
    return q,out
def _load_upstream(g):
    if 'source_import_v3' not in sys.modules:
        p=UP/'producer/source_import_v3.py';raw=raw_ref(dict(path=str(p),sha256=g[str(p)]));m=types.ModuleType('source_import_v3');m.__file__=str(p);sys.modules[m.__name__]=m;exec(compile(raw,str(p),'exec'),m.__dict__)
    from source_import_v3 import module_from_buffer
    m=module_from_buffer('_mechanism_closed_entry_import',UP/'producer/entry_import_v3.py',g[str(UP/'producer/entry_import_v3.py')])
    return m.load_runner(g)
def bootstrap(args,*,native):
    q,out=request_pair(args.request,args.request_sha256,args.review,args.review_sha256,native=native)
    up=document(dict(path=str(UP/'PACKAGE_SOURCE_GRAPH_V1.json'),sha256=UP_SHA))['files']
    require(all(q['source_files'][p]==d for p,d in up.items()),'all856 inherited bytes preserved')
    old=_load_upstream(q['source_files'])
    from source_import_v3 import module_from_buffer
    for name in ['telemetry_startup_v5','mechanism_gpu_binding_v4','frame_schema_v4','native_metatype_raw_v5','native_frame_export_v4','constraint_model_v1','native_inventory_v1','summarize_v1','collector_v1','runtime_mechanism_v1','fresh_exchange_mechanism_v1','integration_v1']:
        p=HERE/(name+'.py');module_from_buffer(name,p,q['source_files'][str(p)])
    runner=sys.modules['integration_v1']
    runner.OLD=old
    return sys.modules[__name__],runner,q,out
def __getattr__(name):
    # New facade delegates immutable science helpers, never alters their globals.
    if name.startswith('__'):raise AttributeError(name)
    import bindings_v1
    return getattr(bindings_v1,name)
def child_environment(root,*,native,gpu_binding=None):
    require(Path(root).is_relative_to(BASE),'mechanism NAS only')
    if native:
        from mechanism_gpu_binding_v4 import validate
        validate(gpu_binding)
    e=dict(os.environ,OMNI_TELEMETRY_DISABLE_ANONYMOUS_DATA='1',PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1',PXR_WORK_THREAD_LIMIT='1',
        OMNI_KIT_ACCEPT_EULA='YES',PRIVACY_CONSENT='Y',CUDA_DEVICE_ORDER='PCI_BUS_ID',PYTHONPATH='/home/liyufeng/safeduo/src',CUDA_VISIBLE_DEVICES=gpu_binding['CUDA_VISIBLE_DEVICES'] if native else '')
    e.pop('ACCEPT_EULA',None)
    for k,v in [('TMPDIR','tmp'),('TMP','tmp'),('TEMP','tmp'),('XDG_CACHE_HOME','cache'),('XDG_CONFIG_HOME','config'),('XDG_DATA_HOME','data'),('CUDA_CACHE_PATH','cache/cuda'),('TORCH_HOME','cache/torch'),('WARP_CACHE_PATH','cache/warp')]:e[k]=str(Path(root)/v)
    return e
