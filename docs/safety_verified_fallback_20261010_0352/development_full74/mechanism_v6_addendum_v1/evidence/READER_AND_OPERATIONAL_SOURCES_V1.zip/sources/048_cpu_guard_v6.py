"""Reviewed PIDfd CPU guardian; RAW requires actual parent authority and closure."""
import argparse,hashlib,json,sys,types
from pathlib import Path
HERE=Path(__file__).resolve().parent;H=HERE.parents[1]
p=H/'astra/full74_clock3_reader_operations_v1/common_v1.py';raw=p.read_bytes()
assert hashlib.sha256(raw).hexdigest()=='4f8f6f698e1e62c2ecea0c9177f05e6962d677d1b652eccfce44b9b2442e33ca'
c=types.ModuleType('_mechanism_v6_reader_guard');c.__file__=str(p);exec(compile(raw,str(p),'exec'),c.__dict__);c.cpu_limits()

def main():
    p=argparse.ArgumentParser(allow_abbrev=False);p.add_argument('--name',required=True);p.add_argument('--source-graph-sha256',required=True)
    g=p.add_mutually_exclusive_group(required=True);g.add_argument('--cpu-tests',action='store_true');g.add_argument('--check-cpu',action='store_true');g.add_argument('--audit-closed',action='store_true')
    p.add_argument('--binding');p.add_argument('--binding-sha256');a=p.parse_args()
    graph_ref=dict(path=str(HERE/'PACKAGE_SOURCE_GRAPH_V1.json'),sha256=a.source_graph_sha256)
    graph=c.read(graph_ref);before=dict(graph['files']);before[graph_ref['path']]=graph_ref['sha256']
    for path,digest in before.items():
        if Path(path).is_relative_to(c.H) or Path(path).is_relative_to(c.R):c.raw(dict(path=path,sha256=digest),2*1024**2)
        else:
            c.need(path in graph['sdk_clock_sources'],'only three exact SDK clock sources outside H/R')
            with Path(path).open('rb') as f:buf=f.read(2*1024**2+1)
            c.need(len(buf)<=2*1024**2 and hashlib.sha256(buf).hexdigest()==digest,'bounded exact SDK clock source')
    budget=120;script=HERE/'reader/read_mechanism_v1.py';args=['--check-cpu']
    root=c.R/'astra_full74_native_constraint_reader_v6_release2'/c.name(a.name)
    if a.cpu_tests:
        c.need(not a.binding and not a.binding_sha256,'synthetic tests do not take native binding')
        script=HERE/'reader/test_reader_v6.py';args=[str(root/'fixtures')]
    elif a.check_cpu:c.need(not a.binding and not a.binding_sha256,'CPU source check only')
    else:
        c.need(a.binding and a.binding_sha256,'actual parent binding required')
        b=c.read(dict(path=a.binding,sha256=a.binding_sha256));auth=c.read(b['reader_authority'])
        c.need(b['future_placeholder'] is False and auth['status'] in ('PARENT_AUTHORIZED_CLOSED_MECHANISM_RAW_READ','SESSION_AUTHORIZED_CLOSED_MECHANISM_RAW_READ') and auth['reader_graph']==graph_ref and auth['max_wall_seconds']==1200 and auth['address_space_bytes']==1024**3,'specific actual CPU read authority')
        budget=1200;args=['--audit-closed','--binding',a.binding,'--binding-sha256',a.binding_sha256,'--out',str(root/'raw')]
    root.mkdir(parents=True,exist_ok=False);w=None;error=None
    try:
        w=c.core().bounded_child([c.PY,'-B',str(script),*args],c.environment(root),root/'worker',backend='CPU_ONLY_MECHANISM_V6_INDEPENDENT_READER',max_wall=budget,cpu_limit=True,monitor=None)
        c.closed_wait(w,0,'astra.full74.owned_cpu_wait.v1','CPU_ONLY_MECHANISM_V6_INDEPENDENT_READER')
    except BaseException as exc:error=type(exc).__name__+': '+str(exc)
    finally:
        after={p:c.sha(p) for p in before};unchanged=after==before
        c.write(root/'DELIVERY_V1.json',dict(actual_wait=c.ref(root/'worker/ACTUAL_WAIT.json') if (root/'worker/ACTUAL_WAIT.json').is_file() else None,error=error,source_before=before,source_after=after,sources_unchanged=unchanged,
            raw_report=c.ref(root/'raw/INDEPENDENT_MECHANISM_RAW_V1.json') if (root/'raw/INDEPENDENT_MECHANISM_RAW_V1.json').is_file() else None,CPU_only=True,AS_bytes=1024**3,max_wall_seconds=budget,threads=1,native_launches=0,wrapper_exit_requires_external_actual_wait=True))
        print(json.dumps(dict(output=str(root),source_unchanged=unchanged,error=error)),flush=True)
    return 0 if error is None and unchanged else 2
if __name__=='__main__':raise SystemExit(main())
