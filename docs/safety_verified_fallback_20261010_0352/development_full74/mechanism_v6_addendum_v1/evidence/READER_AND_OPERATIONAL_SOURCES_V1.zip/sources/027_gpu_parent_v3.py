"""Explicit resource, PhysX, renderer and CUDA identity for physical GPU0."""
PHYSICAL_GPU = 0
EXPECTED_UUID = 'GPU-b129224c-c735-a03f-de6c-185d2a2724b1'
CUDA_DEVICE = 'cuda:0'
VISIBLE_DEVICES = '0'

def configure_single_gpu(config):
    if config.get('active_gpu') != 0 or config.get('physics_gpu') != 0:
        raise ValueError('AppLauncher must begin on remapped logical CUDA0')
    config['active_gpu'] = PHYSICAL_GPU
    config['physics_gpu'] = 0
    config['multi_gpu'] = False
    config['max_gpu_count'] = 1

def actual_cuda_identity(torch_module, device):
    if device != CUDA_DEVICE:
        raise ValueError('fixed remapped CUDA device0 required')
    properties = torch_module.cuda.get_device_properties(device)
    observed = str(properties.uuid)
    if observed.lower().removeprefix('gpu-') != EXPECTED_UUID.lower().removeprefix('gpu-'):
        raise ValueError('actual CUDA UUID differs from monitored physical GPU0')
    return dict(physical_gpu_index=PHYSICAL_GPU, cuda_device=device,
                expected_uuid=EXPECTED_UUID, actual_cuda_uuid=observed,
                cuda_visible_devices=VISIBLE_DEVICES, multi_gpu=False,
                active_renderer_gpu=PHYSICAL_GPU, physics_logical_gpu=0)

def kit_table_identity(raw):
    import hashlib
    text = raw.decode('utf-8', errors='strict')
    lines = text.splitlines()
    begin = next((i for i, line in enumerate(lines) if line.startswith('| GPU | Name')), None)
    if begin is None:
        raise ValueError('actual Kit GPU foundation table missing')
    rows = []
    selected = []
    for i in range(begin + 1, min(begin + 40, len(lines))):
        parts = [s.strip() for s in lines[i].split('|')]
        if len(parts) < 9 or not parts[1].isdecimal():
            continue
        if i + 2 >= len(lines):
            raise ValueError('truncated actual GPU table')
        uuid_parts = [s.strip() for s in lines[i+1].split('|')]
        bus_parts = [s.strip() for s in lines[i+2].split('|')]
        row = dict(renderer_index=int(parts[1]), active=parts[3],
                   uuid_prefix=uuid_parts[7].removesuffix('..').lower(),
                   pci_bus_hex=bus_parts[6].lower())
        rows.append(row)
        if row['active'].startswith('Yes:'):
            selected.append(row)
    if len(rows) != 2 or len(selected) != 1:
        raise ValueError('exactly one active renderer among actual two GPU rows required')
    active = selected[0]
    if (active['renderer_index'] != PHYSICAL_GPU or active['uuid_prefix'] != 'b129224c' or
            active['pci_bus_hex'] != '41'):
        raise ValueError('renderer index/UUID prefix/PCI bus differs from selected physical GPU0')
    table = '\n'.join(lines[begin:begin+16])
    return dict(active_renderer=active, actual_rows=rows, actual_table=table,
                actual_table_sha256=hashlib.sha256(table.encode()).hexdigest())

def actual_kit_identity(settings, log_path):
    from pathlib import Path
    expected = {'/renderer/activeGpu': 0, '/physics/cudaDevice': 0,
                '/renderer/multiGpu/enabled': False}
    observed = {key:settings.get(key) for key in expected}
    if observed != expected:
        raise ValueError('actual Kit render/physics/multiGPU settings mismatch')
    with Path(log_path).open('rb') as stream:
        raw = stream.read(16*1024**2 + 1)
    if len(raw) > 16*1024**2:
        raise ValueError('startup Kit log exceeds GPU identity bound')
    return dict(actual_settings=observed, **kit_table_identity(raw))
