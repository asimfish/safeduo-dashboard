"""PIDfd wrappers for this Conda build; no numerical-PID signal fallback.

Linux x86_64 syscall IDs are from the inspected local UAPI header
/usr/include/x86_64-linux-gnu/asm/unistd_64.h (424,434), SHA-bound in package.
Unsupported architecture/kernel fails closed. Loading this module sends nothing.
"""
import ctypes
import os
import signal


def _call(number, *args):
    if os.name != 'posix' or os.uname().sysname != 'Linux' or os.uname().machine != 'x86_64':
        raise RuntimeError('pidfd syscall fallback requires reviewed Linux x86_64')
    libc = ctypes.CDLL(None, use_errno=True)
    libc.syscall.restype = ctypes.c_long
    result = libc.syscall(ctypes.c_long(number), *args)
    if result < 0:
        error = ctypes.get_errno()
        raise OSError(error, os.strerror(error))
    return int(result)


def open_pidfd(pid):
    if hasattr(os, 'pidfd_open'):
        return os.pidfd_open(pid)
    return _call(434, ctypes.c_int(pid), ctypes.c_uint(0))


def send_pidfd_signal(fd, sig):
    if hasattr(signal, 'pidfd_send_signal'):
        return signal.pidfd_send_signal(fd, sig)
    return _call(424, ctypes.c_int(fd), ctypes.c_int(sig), ctypes.c_void_p(), ctypes.c_uint(0))


def require_pidfd_supported():
    fd = open_pidfd(os.getpid())
    os.close(fd)
