"""Unchanged direct fork/wait4 observer around the new finite CPU guardian."""
import argparse,hashlib,json,os,resource,sys,types
from pathlib import Path
HERE=Path(__file__).resolve().parent;H=HERE.parents[1];R=Path('/mnt/nas/data/lyf/double_hand/safety_verified_fallback_20261010_0352')
PY='/home/liyufeng/miniforge3/envs/safeduo/bin/python'
def main():
    p=argparse.ArgumentParser(allow_abbrev=False);p.add_argument('--name',required=True);p.add_argument('--source-graph-sha256',required=True)
    g=p.add_mutually_exclusive_group(required=True);g.add_argument('--cpu-tests',action='store_true');g.add_argument('--check-cpu',action='store_true');g.add_argument('--audit-closed',action='store_true')
    p.add_argument('--binding');p.add_argument('--binding-sha256');a=p.parse_args()
    assert sys.dont_write_bytecode and os.environ.get('CUDA_VISIBLE_DEVICES')=='' and all(os.environ.get(k)=='1' for k in ('PYTHONDONTWRITEBYTECODE','OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS'))
    resource.setrlimit(resource.RLIMIT_AS,(1024**3,1024**3));resource.setrlimit(resource.RLIMIT_CORE,(0,0))
    data=(HERE/'PACKAGE_SOURCE_GRAPH_V1.json').read_bytes();assert hashlib.sha256(data).hexdigest()==a.source_graph_sha256
    graph=json.loads(data)
    for path,digest in graph['files'].items():
        assert hashlib.sha256(Path(path).read_bytes()).hexdigest()==digest
    assert a.name and a.name.replace('_','').isalnum()
    argv=[PY,'-B',str(HERE/'cpu_guard_v6.py'),'--name',a.name,'--source-graph-sha256',a.source_graph_sha256]
    argv+=['--cpu-tests' if a.cpu_tests else '--check-cpu' if a.check_cpu else '--audit-closed']
    if a.binding:argv+=['--binding',a.binding]
    if a.binding_sha256:argv+=['--binding-sha256',a.binding_sha256]
    ref=graph['direct_observer'];path=Path(ref['path']);data=path.read_bytes();assert hashlib.sha256(data).hexdigest()==ref['sha256']
    m=types.ModuleType('_mechanism_v6_actual_reader_observer');m.__file__=str(path);exec(compile(data,str(path),'exec'),m.__dict__)
    root=R/'astra_full74_native_constraint_reader_v6_release2'/'external'/a.name
    w=m.observe(argv,root)
    assert w['waitpid_observed'] and w['owned_identities'] and all(row['live'] is False for row in w['owned_identities'])
    print(json.dumps(dict(actual_outer_exit=w['actual_wait_exit'],wait=m.ref(root/'ACTUAL_WAIT.json'))),flush=True)
    return w['actual_wait_exit'] if w['actual_wait_exit']>=0 else 128-w['actual_wait_exit']
if __name__=='__main__':raise SystemExit(main())
