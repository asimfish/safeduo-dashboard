"""Runtime read-only inventory. No setters, solver edits or passive-DOF guess."""
import numpy as np
import json,hashlib,re,math
from constraint_model_v1 import need

# A typed gear/rack joint has NO obligation to carry a Mimic/Tendon API.
# Closed V1 omitted this distinction. Unknown enabled joint types/API coupling
# are retained and denied; no projection is guessed from their attributes.
ORDINARY_JOINT_TYPES=frozenset(('PhysicsFixedJoint','PhysicsRevoluteJoint',
    'PhysicsPrismaticJoint','PhysicsSphericalJoint','PhysicsDistanceJoint'))
ORDINARY_PHYSICS_APIS=frozenset(('PhysicsArticulationRootAPI','PhysxArticulationAPI',
    'PhysicsDriveAPI','PhysxJointAPI','PhysicsLimitAPI','PhysxLimitAPI'))
COUPLING_WORDS=('tendon','mimic','gear','rack','coupling','constraint')
STATE_API='PhysicsJointStateAPI:angular'
STATE_ATTRIBUTES=('state:angular:physics:position','state:angular:physics:velocity')

def classify(kind,schemas,attributes,attribute_types=None):
    joint='Joint' in kind
    enabled=attributes.get('physics:jointEnabled')
    active_state='ENABLED' if enabled is True else 'DISABLED' if enabled is False else 'UNKNOWN'
    reasons=[]
    if joint and kind not in ORDINARY_JOINT_TYPES:reasons.append('unsupported typed joint: '+kind)
    if 'Constraint' in kind:reasons.append('unsupported typed constraint: '+kind)
    for schema in schemas:
        api=schema.split(':')[0]
        if api=='PhysicsJointStateAPI':
            # Installed107.3 multipleApply state schema: only the exact revolute
            # angular instance is validated here. Never broaden its API prefix.
            typed=attribute_types or {}
            state_keys={k for k in attributes if k.startswith('state:')}
            valid=(schema==STATE_API and kind=='PhysicsRevoluteJoint' and
                state_keys==set(STATE_ATTRIBUTES) and
                all(typed.get(k)=='float' and type(attributes.get(k)) is float and
                    math.isfinite(attributes[k]) for k in STATE_ATTRIBUTES))
            if not valid:reasons.append('unsupported or unvalidated joint state schema/type/attributes: '+schema)
            continue
        if api=='PhysxMimicJointAPI':
            reasons.append('live mimic outside fixed URDF hypothesis: '+schema)
            continue # fixed URDF hypothesis cannot adopt actual native mimic
        if any(t in schema.lower() for t in COUPLING_WORDS):reasons.append('unsupported applied coupling: '+schema)
        elif api.startswith(('Physics','Physx')) and joint and api not in ORDINARY_PHYSICS_APIS:
            reasons.append('unrecognized physics joint API: '+schema)
    # Disabled exotic joints are retained, never treated as an active relation.
    # Unknown enabled state is not evidence that a coupling is disabled.
    denied=bool(reasons) and active_state!='DISABLED'
    if joint and enabled is not True and enabled is not False:
        reasons.append('joint enabled state missing/nonboolean');denied=True
    return dict(joint_enabled=enabled,active_state=active_state,unsupported_reasons=reasons,
        deny_before_state_writes=denied)

def scalar(v):
    if v is None or isinstance(v,(str,int,float,bool)):return v
    try:return [scalar(x) for x in v]
    except TypeError:return str(v)

def inventory(env,layout,array):
    from pxr import Usd
    stage=env.sim.stage;records=[];relations=[];joint_map={};unsupported=[];lane_registry={i:[] for i in range(32)}
    for prim in Usd.PrimRange.Stage(stage,Usd.TraverseInstanceProxies()):
        path=str(prim.GetPath())
        match=re.search(r'/env_(\d+)/',path)
        if not match or int(match.group(1)) not in lane_registry:continue
        lane=int(match.group(1));schemas=list(prim.GetAppliedSchemas());kind=prim.GetTypeName()
        relevant='Joint' in kind or 'Constraint' in kind or any(any(t in x.lower() for t in COUPLING_WORDS) for x in schemas)
        if relevant:
            normalize=lambda x:re.sub(r'/env_\d+/', '/env_N/',str(x))
            attributes={a.GetName():scalar(a.Get()) for a in prim.GetAttributes()}
            attribute_types={a.GetName():str(a.GetTypeName()) for a in prim.GetAttributes() if a.GetName().startswith('state:')}
            relationships={r.GetName():[str(x) for x in r.GetTargets()] for r in prim.GetRelationships()}
            state=classify(kind,schemas,attributes,attribute_types)
            exotic=bool(state['unsupported_reasons'])
            lane_registry[lane].append(dict(path=normalize(path),type=kind,schemas=schemas,classification=state,
                state_attribute_types=attribute_types,
                attributes={k:v for k,v in attributes.items() if exotic or any(t in k.lower() for t in ('mimic','tendon','jointenabled'))},
                relationships={k:[normalize(x) for x in v] for k,v in relationships.items() if exotic or any(t in k.lower() for t in ('mimic','tendon'))}))
            if state['deny_before_state_writes'] and lane==0:
                unsupported.append(dict(path=path,type=kind,schemas=schemas,classification=state,attributes=attributes,relationships=relationships,
                    reason='unsupported or unknown active native joint/coupling; no inferred projection'))
        if lane!=0:continue
        if 'Joint' in prim.GetTypeName():joint_map[path]=prim
    for arm,(lo,hi) in layout['slices'].items():
        art=env._arms[arm];v=art.root_physx_view
        paths=list(v.prim_paths);need(len(paths)==32,'all32 articulation paths')
        root=paths[0].split('/env_0/',1)[1].split('/')[0];prefix='/World/envs/env_0/'+root+'/'
        for path,prim in joint_map.items():
            if not path.startswith(prefix):continue
            name=arm+'/'+prim.GetName();schemas=list(prim.GetAppliedSchemas())
            attrs={a.GetName():scalar(a.Get()) for a in prim.GetAttributes() if any(x in a.GetName().lower() for x in ('mimic','tendon','drive:','physics:joint','physics:axis'))}
            rels={r.GetName():[str(x) for x in r.GetTargets()] for r in prim.GetRelationships() if any(x in r.GetName().lower() for x in ('mimic','tendon','body'))}
            records.append(dict(arm=arm,path=path,joint_name=name,type=prim.GetTypeName(),schemas=schemas,attributes=attrs,relationships=rels))
            for schema in schemas:
                if 'Tendon' in schema:unsupported.append(dict(path=path,schema=schema,reason='tendon is compliant/multi-DOF; no guessed affine projection'))
                if schema.startswith('PhysxMimicJointAPI:'):
                    axis=schema.split(':')[-1];base='physxMimicJoint:'+axis+':'
                    targets=rels.get(base+'referenceJoint',[]);need(len(targets)==1,'exact mimic reference')
                    reference=stage.GetPrimAtPath(targets[0]);need(bool(reference),'missing native reference prim')
                    relations.append(dict(child=name,parent=arm+'/'+reference.GetName(),type=prim.GetTypeName(),reference_type=reference.GetTypeName(),
                        same_articulation=targets[0].startswith(prefix),enabled=prim.GetAttribute('physics:jointEnabled').Get() is True,
                        gearing=attrs[base+'gearing'],offset_degrees=attrs[base+'offset'],path=path,axis=axis))
    for v in lane_registry.values():v.sort(key=lambda x:x['path'])
    need(bool(lane_registry[0]) and all(v==lane_registry[0] for v in lane_registry.values()),'all32 actual USD coupling topology must match')
    getter={};passive={}
    for arm in layout['slices']:
        v=env._arms[arm].root_physx_view;getter[arm]=dict(dof_paths=scalar(v.dof_paths),prim_paths=scalar(v.prim_paths))
        for kind in ('fixed','spatial'):
            count=int(getattr(v,'max_'+kind+'_tendons'));getter[arm][kind+'_count']=count
            if count:
                unsupported.append(dict(arm=arm,kind=kind,count=count,reason='native tendon requires separate constitutive model'))
                suffixes=('stiffnesses','dampings','limit_stiffnesses','offsets')+(('limits','rest_lengths') if kind=='fixed' else ())
                for suffix in suffixes:getter[arm][kind+'_'+suffix]=array(getattr(v,'get_'+kind+'_tendon_'+suffix)()).tolist()
        k=array(v.get_dof_stiffnesses());d=array(v.get_dof_dampings());f=array(v.get_dof_max_forces())
        passive[arm]=dict(joint_names=list(env._arms[arm].joint_names),stiffness=k.tolist(),damping=d.tolist(),force_cap=f.tolist(),
            no_PD_coefficients=((k==0)&(d==0)).tolist(),zero_drive_cap=(f==0).tolist(),
            passive_DOF_proven=False,actual_drive_torque='UNKNOWN')
    return dict(schema='astra.native.constraint_inventory.v2',stage_scope='LIVE_ALL32_TOPOLOGY_EQUAL_PLUS_ALL32_TENSOR_GETTERS',
        registry_policy='TYPED_JOINT_AND_APPLIED_COUPLING_EXPLICIT_SUPPORT_BEFORE_STATE_WRITES',
        instance_proxies_traversed=True,ordinary_joint_types=sorted(ORDINARY_JOINT_TYPES),
        normalized_all32_registry=lane_registry,
        records=records,mimic_relations=relations,tendon_getters=getter,unsupported=unsupported,drive_configuration=passive,
        eDRIVE_LIMITS_ARE_FORCES='UNKNOWN_NO_NATIVE_FLAG_GETTER_BOUND',
        compiled_mimic_impulses='UNKNOWN',passive_constraint_impulses='UNKNOWN')
