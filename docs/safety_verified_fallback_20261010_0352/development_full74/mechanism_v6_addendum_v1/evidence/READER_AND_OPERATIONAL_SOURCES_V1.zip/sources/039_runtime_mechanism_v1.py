"""Reuse reviewed native core82c5; only one guardian, stricter1200s call budget."""
import mechanism_bootstrap_v1 as b
def load_runtime(request):
    from runtime_binding_v4 import load_runtime as original
    b.require(request['runtime_reference']==b.RUNTIME_REF and request['max_wall_seconds']==1200,'specific inherited runtime authority and1200 budget')
    return original(b.document(b.RUNTIME_REF))
def serial_class(core,sources):
    from runtime_binding_v4 import serial_class as original
    return original(core,sources)
