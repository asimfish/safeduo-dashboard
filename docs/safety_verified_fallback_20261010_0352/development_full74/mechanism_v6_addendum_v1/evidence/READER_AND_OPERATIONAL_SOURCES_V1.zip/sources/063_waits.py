"""Actual V6 direct fork/wait4 observer; no projection to an old wait schema."""
import datetime, os, math
from pathlib import Path
from runtime import require
from closed_waits_v4 import closed_wait

BACKEND='EXTERNAL_WRAPPER_OBSERVER_NOT_NATIVE_OR_CPU_ONLY_WORKLOAD'

def instant(s):
    t=datetime.datetime.fromisoformat(s.replace('Z','+00:00'))
    require(t.tzinfo is not None,'timezone required'); return t.timestamp()

def argv_binding(argv,source,request,review,action):
    require(isinstance(argv,list) and argv[0]=='/home/liyufeng/miniforge3/envs/safeduo/bin/python' and argv[1:3]==['-B',str(source)] and argv.count(action)==1,'exact parent/native entry argv')
    for flag,r,key in [('--request',request,'path'),('--request-sha256',request,'sha256'),('--review',review,'path'),('--review-sha256',review,'sha256')]:
        require(argv.count(flag)==1 and argv[argv.index(flag)+1]==r[key],'argv bound '+flag)

def direct_wait(w,expected):
    require(w['schema']=='astra.full74.owned_cpu_wait.v1' and w['backend']==BACKEND,'direct observer wait domain')
    for k in ('child_pid','waited_pid','actual_wait_exit','raw_wait_status'):
        require(type(w[k]) is int,'typed direct wait '+k)
    require(w['waitpid_observed'] is True and w['child_pid']==w['waited_pid']>0 and os.waitstatus_to_exitcode(w['raw_wait_status'])==w['actual_wait_exit']==expected,'actual exact wait4 terminal status')
    require(w['wait_mechanism']=='os.wait4(owned_pid, WNOHANG)' and w['resource_abort'] is None and w.get('error') is None and w['signals']==[],'clean direct observer')
    own=w['owned_identities']
    require(len(own)==1 and own[0]['pid']==w['child_pid'] and type(own[0]['startticks']) is int and own[0]['startticks']>0 and own[0]['live'] is False,'retained direct PID/startticks reaped')
    require(own[0]['enrollment']['kind']=='direct_fork_handshake' and own[0]['enrollment']['parent_pid']==own[0]['ppid'],'direct fork provenance')
    require(math.isfinite(w['elapsed_seconds']) and w['elapsed_seconds']>=0 and instant(w['started_utc'])<=instant(w['closed_utc']),'finite closed direct interval')
    absent(own[0]); return own[0]

def chronology(outer,native,parent):
    observed=direct_wait(outer,0); root=closed_wait(native,0)
    require(native['schema']=='astra.full74.parent_native_wait.v1' and native['backend']=='isaac_physx_native','native-standard actual0 authority')
    require(native['max_wall_seconds']==1200 and math.isfinite(native['elapsed_seconds']) and native['elapsed_seconds']>=0,'original1200s native guardian')
    require(root['ppid']==observed['pid']==parent['pid'] and type(parent['startticks']) is int and parent['startticks']==observed['startticks'],'exact native parent PID/startticks')
    require(instant(outer['started_utc'])<=instant(native['started_utc'])<=instant(native['closed_utc'])<=instant(outer['closed_utc']),'native interval enclosed by actual parent wait')
    return root

def absent(identity):
    p=Path('/proc')/str(identity['pid'])/'stat'
    try:s=p.read_text();tail=s[s.rfind(')')+2:].split()
    except (FileNotFoundError,ProcessLookupError):return
    require(int(tail[19])!=identity['startticks'],'exact recorded PID/startticks still present (zombie included)')

def standard_log(e,w):
    for k in ('log','outer_monitor'):e.hash(w[k],w[k+'_sha256'])

def parent_files(e,outer,parent_wait_path):
    folder=Path(parent_wait_path).parent
    require(outer['log']==str(folder/'child.log') and outer['outer_monitor']==str(folder/'resources.jsonl'),'direct observer log namespace')
    standard_log(e,outer); started=e.js(folder/'STARTED_V1.json')
    recorded=outer['owned_identities'][0]; announced=started['child_identity']
    require({k:announced[k] for k in ('pid','ppid','startticks','enrollment')}=={k:recorded[k] for k in ('pid','ppid','startticks','enrollment')} and started['argv']==outer['argv'] and started['started_utc']==outer['started_utc'] and started['actual_exit_not_yet_observed'] is True,'STARTED handshake identity versus actual closed wait')
    return dict(schema=outer['schema'],backend=outer['backend'],actual_wait_exit=outer['actual_wait_exit'],direct_identity={k:recorded[k] for k in ('pid','ppid','startticks','enrollment')},log_sha256=outer['log_sha256'],monitor_sha256=outer['outer_monitor_sha256'])
