"""All scheduled lanes and dimensions; immutable independent arithmetic kernels."""
from runtime import *
import ast
import numpy as np
from evidence_io import ARMS, exact, equal_bits
from science import parameters_layout, flags, REASONS
from root_restore_reader import evaluate, verify_report, validate_protocol

def reused_functions():
    path=H/'astra/full74_independent_reader_v1/release_v9/reader.py'
    tree=ast.parse(raw(path,MANIFEST['files'][str(path)]))
    names={'contact_identity','contacts','geometry_evidence'}
    nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in names]
    require(len(nodes)==3,'three exact immutable independent kernels')
    scope=dict(globals());exec(compile(ast.Module(body=nodes,type_ignores=[]),str(path),'exec'),scope)
    return {n:scope[n] for n in names}

KERNELS=reused_functions()

def lane_bits(a,b):
    require(a.shape==b.shape==(32,74) and a.dtype==b.dtype==np.float32,'all32 full74 typed lanes')
    return np.all(a.view(np.uint8).reshape(32,-1)==b.view(np.uint8).reshape(32,-1),axis=1)

def timeline(f):
    exact(f['micro'],np.arange(13,dtype=np.int64),'all13 micro IDs')
    exact(f['macro_step'],np.array([-1]+[(i-1)//2 for i in range(1,13)],np.int64),'six controls')
    exact(f['substep'],np.array([-1]+[(i-1)%2 for i in range(1,13)],np.int64),'two actual substeps')
    exact(f['point_fresh'],np.array([False]+[True]*12),'freshness after actual step')
    exact(f['initial_point_freshness_unknown'],np.array([True]+[False]*12),'initial contact UNKNOWN')
    exact(f['simulation_step'],f['simulation_step'][0]+np.arange(13,dtype=np.int64),'consecutive actual steps')
    t=f['simulation_time_s'];require(t.shape==(13,) and np.isfinite(t).all(),'actual13 finite native clock; exact getter/callback check follows in prepare')

def fields(e,root,schema):
    folder=root/'native_fields';closed=e.js(folder/'CLOSED.json')
    require(closed['filled']==13,'all13 native rows must be completed')
    expected={str(folder/(k+'.npy')) for k in schema['native_fields']}
    require(set(closed['files'])==expected,'native field inventory')
    e.verify(closed['files'],folder)
    require({p.name for p in folder.glob('row_*_complete.json')}=={f'row_{i:03d}_complete.json' for i in range(13)},'all13 completion markers')
    for i in range(13):require(e.js(folder/f'row_{i:03d}_complete.json')=={'row':i},'actual row marker identity')
    f={k:e.npy(folder/(k+'.npy'),v['shape'],v['dtype']) for k,v in schema['native_fields'].items()}
    timeline(f);return f

def roots(e,root,f,initial,protocol):
    reported=e.js(root/'ROOT_ADMISSION.json');require(set(reported)==set(ARMS),'root four arms')
    valid=np.ones(32,bool);details={}
    for arm in ARMS:
        require(len(reported[arm])==32,'all32 root reports');details[arm]=[]
        for lane in range(32):
            args=[np.repeat(x[lane:lane+1],32,axis=0) for x in (f[arm+'_root_xyzw'][0],initial[arm+'_root'],f[arm+'_root_velocity'][0],initial[arm+'_root_velocity'])]
            try:computed=evaluate(*args,protocol)
            except ValueError as exc:
                valid[lane]=False;require(reported[arm][lane]['status']=='DENIED','root denial disagreement')
                details[arm].append(dict(proposal_id=lane,status='DENIED',reason=str(exc)))
            else:
                verify_report(computed,reported[arm][lane]);row=computed['lanes'][0];row['proposal_id']=lane
                details[arm].append(row)
    return valid,details

def prepare(e,c):
    b=c['original'];root=c['root']/'native';req=c['request'];a=c['anchors'];seed=req['seed_index']
    params=e.npz(b['parameter_path']);layout=parameters_layout(params)
    expected={k for k in params if k!='initial_strata' and not k.endswith('_full_initial_position_target')}
    original_geometry=e.js(b['geometry_identity_path']);original_geometry.pop('scope',None)
    measurements={}
    for label in ('before','after'):
        refs=c['producer']['measurements_'+label];measurements[label]=refs
        require(set(refs)=={'parameters','geometry'},'measurement boundary inventory')
        for key,name in [('parameters','PARAMETERS_'+label.upper()+'.npz'),('geometry','GEOMETRY_'+label.upper()+'.json')]:
            require(refs[key]['path']==str(root/name),'same attempt actual measurement path');e.hash(refs[key]['path'],refs[key]['sha256'])
        actual=e.npz(refs['parameters']['path']);require(set(actual)==expected,'all native parameter fields')
        for k in expected:exact(actual[k],params[k],'actual '+label+' '+k)
        require(e.js(refs['geometry']['path'])==original_geometry,'original geometry/tip identities')
    manifest=e.js(req['proposals_manifest'],req['proposals_sha256'])
    ident=e.js(a['identity']['path'],a['identity']['sha256']);folder=Path(req['proposals_manifest']).parent
    require(manifest['identity']==ident and manifest['purpose']=='DEVELOPMENT_ONLY','new four development cohorts')
    require(manifest['parameter_sha256']==b['files'][b['parameter_path']] and manifest['selected']==manifest['native_completed']==manifest['formal_holdout']==0 and manifest['no_outcome_resampling'] is True,'frozen cohort parameters and no outcome sampling')
    require(manifest['scheduled_native_ids_per_seed']==list(range(32)) and manifest['unscheduled']==8064,'fixed campaign first32 only')
    require(set(manifest['files'])=={str(folder/(k+'.npy')) for k in ('q74','qd74','family')},'8192 proposal file inventory')
    e.verify(manifest['files'],folder)
    allq=e.npy(folder/'q74.npy',(8192,74),'float32');allv=e.npy(folder/'qd74.npy',(8192,74),'float32')
    family=e.npy(folder/'family.npy',(8192,),'uint8');exact(family,np.tile(np.arange(2048,dtype=np.int64)%4,4).astype(np.uint8),'all8192 family ledger')
    require(np.isfinite(allq).all() and np.isfinite(allv).all() and np.all(allq>=layout['bounds'][:,0]) and np.all(allq<=layout['bounds'][:,1]) and np.all(abs(allv)<=layout['vmax']),'all74 full support bounds in8192 proposals')
    low=seed*2048+req['proposal_ids'][0];q=allq[low:low+32].copy();qd=allv[low:low+32].copy();del allq,allv
    exact(e.npy(root/'proposal_ids.npy',(32,),'int64'),np.asarray(req['proposal_ids'],dtype=np.int64),'fixed pilot proposal IDs')
    exact(e.npy(root/'requested_q74.npy',(32,74),'float32'),q,'requested q74')
    exact(e.npy(root/'requested_qd74.npy',(32,74),'float32'),qd,'requested qd74')
    exact(e.npy(root/'screen_hold_target74_6x32x74.npy',(6,32,74),'float32'),np.repeat(q[None],6,axis=0),'all six control targets')
    exact(e.npy(root/'original_task_goal74.npy',(32,74),'float32'),np.concatenate([params[arm+'_full_initial_position_target'] for arm in ARMS],axis=1),'original task goal retained')
    for micro in range(1,13):exact(e.npy(root/f'applied_target74_micro_{micro:03d}.npy',(32,74),'float32'),q,'all12 actual target getters')
    schema=e.js(a['numeric_schema']['path'],a['numeric_schema']['sha256']);f=fields(e,root,schema)
    from clock_binding_v1 import clock_fields
    clock=clock_fields(e,root,f)
    bits=lane_bits(f['q74'][0],q)&lane_bits(f['qd74'][0],qd)&lane_bits(f['target74'][0],q)
    initial=e.npz(b['initial_path']);proto=validate_protocol(e.js(a['root_protocol']['path'],a['root_protocol']['sha256']))
    root_ok,root_details=roots(e,root,f,initial,proto)
    computed=np.stack([flags({k:v[i] for k,v in f.items()},layout,q,i>0) for i in range(13)])
    exact(computed,f['violations'],'independent13x32x7 flags')
    body=e.npz(Path(b['parameter_path']).parent/'body_identity.npz')
    identity=KERNELS['contact_identity'](e,root,b,body);contact=KERNELS['contacts'](e,root,f,identity)
    disposition=np.zeros(8192,np.uint8);disposition[low:low+32]=2
    exact(e.npy(root/'all8192_observation_dispositions.npy',(8192,),'uint8'),disposition,'all8192 per-request dispositions/unused8160')
    origins=e.npy(root/'environment_origins_before.npy',(32,3),'float32')
    exact(origins,e.npy(root/'environment_origins_after.npy',(32,3),'float32'),'all32 actual origins held')
    require(np.isfinite(origins).all(),'finite actual origins')
    return dict(origins=origins,fields=f,layout=layout,body=body,identity=identity,flags=computed,exact=bits,root_ok=root_ok,
        summary=dict(clock=clock,measurements=measurements,root_equivalence=root_details,contact=contact,proposals=8192,observed32=32,unused_per_request=8160,campaign_unscheduled=8064))
