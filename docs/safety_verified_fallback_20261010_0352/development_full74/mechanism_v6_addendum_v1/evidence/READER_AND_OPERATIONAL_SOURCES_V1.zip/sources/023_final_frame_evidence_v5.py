"""NEW post-close frame data only. Never alter the prewrite evidence/registry.

Final evidence is made only from a real closed native wait/ENTRY plus the
distinct raw-tree review. A second independent review must bind that NEW
evidence before it becomes a model consumer's frame_binding.
"""
import argparse,copy
from pathlib import Path
import mechanism_bootstrap_v1 as b
from frame_reader_interface_v4 import binding_after_actual_closure
HERE=Path(__file__).resolve().parent

def source_scope(receipt,native_wait_ref,entry_ref):
    b.require(receipt['source_graph']==b.ref(HERE/'SOURCE_GRAPH_V4.json') and
        native_wait_ref['path']==str(b.BASE/'native_attempt1/native_process/ACTUAL_WAIT.json') and
        entry_ref['path']==str(b.BASE/'native_attempt1/entry/ENTRY_RECEIPT_V4.json'),
        'exact V5 mechanism graph/native namespace; no calibration or V4 history substitution')

def compose_closed_evidence(prewrite,receipt,receipt_ref,wait_ref,entry_ref,raw_review_ref):
    b.require(receipt['model'] is not None and receipt['native_frame_evidence'] is not None and receipt['model_errors']==[], 'MODEL_NOT_READY cannot be finalized')
    b.require(prewrite['schema']=='astra.full74.recorded_native_frame_evidence.v2' and
        prewrite['status']=='PROVISIONAL_PREWRITE_REQUIRES_ACTUAL_WAIT_ENTRY_AND_DISTINCT_REVIEW' and
        prewrite['native_wait']=='PENDING_AT_CAPTURE' and
        prewrite['model']==receipt['model'] and prewrite['source_graph']==receipt['source_graph'] and
        prewrite['request_sha256']==receipt['request_sha256'] and prewrite['source_artifacts']==receipt['source_artifacts'],
        'exact original prewrite model/source chain, not replacement evidence')
    b.require(len(receipt['source_artifacts'])==4,'original registry/readbacks/coupling four sources')
    sources=copy.deepcopy(receipt['source_artifacts'])
    for ref in [*receipt['raw_diagnostic_artifacts'],wait_ref,entry_ref]:
        b.require(type(ref) is dict and set(ref)=={'path','sha256'} and type(ref['path']) is str and type(ref['sha256']) is str and len(ref['sha256'])==64,'real pinned artifact reference, no future placeholder')
        if ref not in sources:sources.append(copy.deepcopy(ref))
    final=copy.deepcopy(prewrite)
    final.update(status='RECORDED_CLOSED_NATIVE_FRAMES_PENDING_SEPARATE_64_64_CALIBRATION',
        native_wait=wait_ref,ENTRY=entry_ref,source_artifacts=sources,
        prewrite_native_frame_evidence=receipt['native_frame_evidence'],
        frame_export_receipt=receipt_ref,raw_frame_replay_review=raw_review_ref,
        calibration='NOT_TESTED',native_admission=False,bank_count=0,
        CONTACT='UNKNOWN',ACTUAL_DRIVE_TORQUE='UNKNOWN',TERMINAL_SET='UNKNOWN')
    return final

def finalize(export_receipt_ref,native_wait_ref,entry_ref,raw_review_ref,out):
    # Exact closed V4 reader remains responsible for actual wait4/absence/log
    # checks, ENTRY measurement/device fields and independently recomputed tree.
    receipt=b.document(export_receipt_ref);entry=b.document(entry_ref)
    source_scope(receipt,native_wait_ref,entry_ref)
    binding=binding_after_actual_closure(export_receipt_ref,native_wait_ref,entry_ref,raw_review_ref)
    b.require(entry['status']=='mechanism_complete_pending_actual_wait_and_independent_audit' and
        entry['producer']['actual_micro_ids']==list(range(13)) and entry['producer']['physics_steps']==12 and
        entry['producer']['measurement_bytes_verified'] is True,'complete original diagnostic A/B lifecycle, never exit0 alone')
    prewrite=b.document(binding['native_frame_evidence'])
    final=compose_closed_evidence(prewrite,receipt,export_receipt_ref,native_wait_ref,entry_ref,raw_review_ref)
    for ref in final['source_artifacts']:b.raw_ref(ref)
    out=Path(out);b.require(out.is_relative_to(b.BASE/'frame_after_actual_closure') and out.resolve()==out and not out.exists(),'exclusive NEW NAS post-close data namespace')
    before={ref['path']:b.sha(ref['path']) for ref in [export_receipt_ref,binding['native_frame_evidence'],*final['source_artifacts']]}
    out.mkdir(parents=True,exist_ok=False)
    b.json_new(out/'FINAL_RECORDED_NATIVE_FRAME_EVIDENCE_V2.json',final)
    evidence_ref=b.ref(out/'FINAL_RECORDED_NATIVE_FRAME_EVIDENCE_V2.json')
    b.require(before=={p:b.sha(p) for p in before},'all prewrite/raw/closure source bytes unchanged')
    result=dict(schema='astra.full74.final_frame_data.v5',status='CLOSED_FRAME_DATA_PENDING_DISTINCT_FINAL_REVIEW',
        source_graph=b.ref(HERE/'SOURCE_GRAPH_V4.json'),frame_export_receipt=export_receipt_ref,
        native_wait=native_wait_ref,entry=entry_ref,raw_frame_review=raw_review_ref,
        native_frame_evidence=evidence_ref,model=binding['model'],identities=receipt['identities'],
        source_before=before,source_after={p:b.sha(p) for p in before},calibration='NOT_TESTED',native_admission=False,bank_count=0)
    b.json_new(out/'FINAL_FRAME_DATA_RECEIPT_V5.json',result)
    return b.ref(out/'FINAL_FRAME_DATA_RECEIPT_V5.json')

def final_review_gate(data,data_ref,review):
    b.require(review['status'] in ('PASS','COND_PASS') and review['blocking_findings']==[] and
        review['source_graph']==data['source_graph'] and review['final_frame_data']==data_ref and
        review['frame_export_receipt']==data['frame_export_receipt'] and
        review['native_frame_evidence']==data['native_frame_evidence'] and review['model']==data['model'] and
        review['native_wait']==data['native_wait'] and review['entry']==data['entry'] and
        review['raw_frame_review']==data['raw_frame_review'] and review['independent_final_frame_chain_recomputed'] is True,
        'distinct final review must bind the NEW evidence, same model and true native wait/ENTRY')

def binding_after_final_review(final_data_ref,final_review_ref):
    data=b.document(final_data_ref);review=b.document(final_review_ref)
    b.require(data['schema']=='astra.full74.final_frame_data.v5' and data['source_graph']==b.ref(HERE/'SOURCE_GRAPH_V4.json'),'source-bound new final frame data')
    source_scope(b.document(data['frame_export_receipt']),data['native_wait'],data['entry'])
    binding=binding_after_actual_closure(data['frame_export_receipt'],data['native_wait'],data['entry'],data['raw_frame_review'])
    receipt=b.document(data['frame_export_receipt']);prewrite=b.document(receipt['native_frame_evidence'])
    expected=compose_closed_evidence(prewrite,receipt,data['frame_export_receipt'],data['native_wait'],data['entry'],data['raw_frame_review'])
    b.require(b.document(data['native_frame_evidence'])==expected and data['identities']==receipt['identities'] and data['model']==binding['model'],'recompute final evidence lossless projection')
    for ref in expected['source_artifacts']:b.raw_ref(ref)
    final_review_gate(data,final_data_ref,review)
    return dict(binding,native_frame_evidence=data['native_frame_evidence'],frame_export_review=final_review_ref)

def main():
    p=argparse.ArgumentParser(allow_abbrev=False);p.add_argument('--mode',choices=('finalize','bind'),required=True);p.add_argument('--out',required=True)
    for key in ('export-receipt','native-wait','entry','raw-review','final-data','final-review'):
        p.add_argument('--'+key);p.add_argument('--'+key+'-sha256')
    a=p.parse_args();b.assert_threads()
    for path,digest in b.graph().items():
        if Path(path).is_relative_to(HERE):b.require(b.sha(path)==digest,'bound operational source '+path)
    def ref(key):
        path=getattr(a,key);digest=getattr(a,key+'_sha256');b.require(path and digest,'real source reference required '+key)
        r=dict(path=path,sha256=digest);b.raw_ref(r);return r
    if a.mode=='finalize':result=finalize(ref('export_receipt'),ref('native_wait'),ref('entry'),ref('raw_review'),a.out)
    else:
        value=binding_after_final_review(ref('final_data'),ref('final_review'));out=Path(a.out)
        b.require(out.is_relative_to(b.BASE/'frame_after_actual_closure') and out.resolve()==out and not out.exists(),'NEW consumer binding output')
        out.mkdir(parents=True,exist_ok=False);b.json_new(out/'NATIVE_FRAME_BINDING_V2.json',value);result=b.ref(out/'NATIVE_FRAME_BINDING_V2.json')
    print(result,flush=True);return 0
if __name__=='__main__':raise SystemExit(main())
