"""Independent exact interval oracle for FUTURE measured clock sidecars.

No producer predicate imports. Does not fill missing getter/events from old data.
Source/evidence SHA closure and row completion inventory remain reader duties.
"""
import math,struct

def require(v,message):
    if not v:raise ValueError(message)
def binary64(x):return struct.pack('<d',x)

def audit(snapshots,events,steps,times,expected_sources):
    require(len(snapshots)==len(steps)==len(times)==13 and len(events)==12,'all13 rows and12 actual callback events')
    first=steps[0]
    for i,s in enumerate(snapshots):
        require(s['schema']=='astra.native_clock.snapshot.v1' and s['getter_source']==expected_sources,'bound getter source')
        require(s['configured_dt_s']==.008333 and type(s['usd_time_steps_per_second']) is int and
            s['usd_time_steps_per_second']==120,'original configured120Hz')
        dt=s['actual_dt_s'];t=s['simulation_time_s']
        require(type(dt) is float and type(t) is float and math.isfinite(dt) and math.isfinite(t),'actual double scalars')
        require(binary64(dt)==binary64(1/120) and s['actual_dt_dtype']=='float64' and
            s['actual_dt_float64_le']==binary64(dt).hex(),'USD frequency/actual dt getter')
        require(s['simulation_time_float64_le']==binary64(t).hex() and binary64(t)==binary64(float(times[i])),'raw clock row identity')
        require(type(s['simulation_step']) is int and s['simulation_step']==int(steps[i])==int(first)+i and
            s['callback_count']==i,'all13 consecutive actual step/event counts')
        if i:
            event=events[i-1];value=event['step_size']
            require(event['type']=='float' and type(value) is float and math.isfinite(value) and
                event['float64_le']==binary64(value).hex(),'raw actual physics callback')
            from_getter=struct.unpack('<f',struct.pack('<f',dt))[0]
            require(binary64(value)==binary64(from_getter),'event float32 representation of actual getter')
            require(binary64(t)==binary64(snapshots[i-1]['simulation_time_s']+value),'exact interval recurrence, no epsilon enlargement')
    return dict(status='EXACT_CLOCK_INTERVALS_VERIFIED',micro_ids=list(range(13)),actual_dt_s=snapshots[0]['actual_dt_s'],
        native_pass=False,scope='CLOCK_ONLY_WITH_NATIVE_CLOSURE_REQUIRED',tolerance_increased=False)
