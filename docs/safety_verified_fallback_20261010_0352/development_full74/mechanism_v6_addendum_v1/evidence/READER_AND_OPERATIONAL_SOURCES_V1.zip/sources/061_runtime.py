"""Read-only independent CPU runtime; selected closed kernels, no producer imports."""
import os,sys,resource,hashlib,json,types,importlib.abc,importlib.util,ast
from pathlib import Path
HERE=Path(__file__).resolve().parent;PACKAGE=HERE.parent
H=Path('/home/liyufeng/safeduo/artifacts/safety_verified_fallback_20261010_0352')
R=Path('/mnt/nas/data/lyf/double_hand/safety_verified_fallback_20261010_0352')
OUTPUT=R/'astra_full74_native_constraint_reader_v6_release2'
assert sys.dont_write_bytecode and os.environ.get('PYTHONDONTWRITEBYTECODE')=='1'
assert os.environ.get('CUDA_VISIBLE_DEVICES')==''
assert all(os.environ.get(k)=='1' for k in ('OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS'))
resource.setrlimit(resource.RLIMIT_AS,(1024**3,1024**3));resource.setrlimit(resource.RLIMIT_CORE,(0,0))
def raw(p,d=None):
    with Path(p).open('rb') as f:b=f.read(2*1024**2+1)
    if len(b)>2*1024**2 or (d is not None and hashlib.sha256(b).hexdigest()!=d):raise ValueError('source SHA/size '+str(p))
    return b
GRAPH=json.loads(raw(PACKAGE/'PACKAGE_SOURCE_GRAPH_V1.json'))['files']
MANIFEST=json.loads(raw(PACKAGE/'REUSE_V1.json',GRAPH[str(PACKAGE/'REUSE_V1.json')]))
def verified_reuse():
    for p,d in MANIFEST['files'].items():raw(p,d)
    return dict(MANIFEST['files'])
class Loader(importlib.abc.MetaPathFinder,importlib.abc.Loader):
    def find_spec(self,name,path=None,target=None):
        if name.split('.')[0] in ('torch','isaaclab','isaacsim','omni','pxr','carb') or name in ('collector_v1','constraint_model_v1','native_inventory_v1','native_runner_v1','bindings_v1'):
            raise ImportError('native/producer import forbidden: '+name)
        if name in MANIFEST['modules']:return importlib.util.spec_from_loader(name,self)
    def create_module(self,spec):return None
    def exec_module(self,m):
        p=MANIFEST['modules'][m.__name__];m.__file__=p
        exec(compile(raw(p,GRAPH[p]),p,'exec'),m.__dict__)
sys.meta_path.insert(0,Loader())
alias=types.ModuleType('reuse_v6');alias.verified_reuse=verified_reuse;sys.modules['reuse_v6']=alias
from evidence_io import Evidence as OriginalEvidence,require,exact,equal_bits,parse_json,contained,fingerprint,ARMS,sha
class Evidence(OriginalEvidence):
    def __init__(self):
        super().__init__();self.pinned=dict(GRAPH);self.external_frozen=dict(GRAPH)
    def hash(self,path,expected=None,limit=None):
        key=str(Path(path).absolute());expected=expected or self.pinned.get(key)
        return super().hash(path,expected,limit)
def write_new(path,value):
    p=contained(path,OUTPUT);p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('x') as f:json.dump(value,f,indent=2,allow_nan=False);f.write('\n');f.flush();os.fsync(f.fileno())
def ref(e,r):
    require(isinstance(r,dict) and set(r)=={'path','sha256'} and isinstance(r['path'],str) and len(r['sha256'])==64,'actual path/SHA reference; placeholders deny')
    return e.js(r['path'],r['sha256'])
def sources():
    for p,d in GRAPH.items():raw(p,d) if p.endswith('.py') else None
    return dict(GRAPH)
def functions(path,names,scope):
    data=raw(path,GRAPH[str(path)]);tree=ast.parse(data)
    nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in names]
    require({n.name for n in nodes}==set(names),'all reused functions present')
    target=dict(scope);exec(compile(ast.Module(body=nodes,type_ignores=[]),str(path),'exec'),target)
    return {n:target[n] for n in names}
verified_reuse()
