"""Declared initialization intervention, never a safety or reachability certificate."""
import math
import numpy as np

def need(v,s):
    if not v:raise ValueError(s)

def affine_relations(records,names,controlled):
    """USD mimic: q_child + gearing*q_parent + offset(degrees) = 0."""
    index={n:i for i,n in enumerate(names)};out=[]
    for r in records:
        need(r['type']=='PhysicsRevoluteJoint' and r['reference_type']=='PhysicsRevoluteJoint','unsupported multi/linear DOF')
        need(r['enabled'] is True and r['same_articulation'] is True,'disabled/external relation')
        c,p=index[r['child']],index[r['parent']]
        need(c not in controlled and p not in controlled,'hand-only intervention')
        g,o=float(r['gearing']),float(r['offset_degrees'])
        need(math.isfinite(g) and math.isfinite(o) and c!=p,'invalid mimic coefficient')
        out.append(dict(child=c,parent=p,multiplier=-g,offset=-math.radians(o),authority='LIVE_USD_MIMIC_SCHEMA'))
    return ordered(out)

def ordered(relations):
    need(len({r['child'] for r in relations})==len(relations),'multiple constraints for child')
    remaining=list(relations);result=[]
    while remaining:
        children={r['child'] for r in remaining}
        ready=[r for r in remaining if r['parent'] not in children]
        need(bool(ready),'cyclic constraint graph: no projection')
        for r in ready:result.append(r);remaining.remove(r)
    return result

def project(q,qd,relations,bounds,vmax,controlled):
    """Hold all independent coordinates. Never clip/redraw/call this the raw sample."""
    q=np.asarray(q);qd=np.asarray(qd)
    need(q.shape==qd.shape==(74,) and q.dtype==qd.dtype==np.float32,'original full74 float32')
    need(np.isfinite(q).all() and np.isfinite(qd).all(),'finite raw challenge')
    x,y=q.copy(),qd.copy()
    for r in ordered(relations):
        c,p=r['child'],r['parent'];need(c not in controlled and p not in controlled,'hand-only')
        m,o=r['multiplier'],r['offset'];need(np.isfinite([m,o]).all(),'finite relation')
        x[c]=np.float32(float(x[p])*m+o);y[c]=np.float32(float(y[p])*m)
    valid=bool(relations) and bool(np.isfinite(x).all() and np.isfinite(y).all() and
        (x>=bounds[:,0]).all() and (x<=bounds[:,1]).all() and (np.abs(y)<=vmax).all())
    return x,y,dict(constructible=valid,no_projection=len(relations)==0,
        changed_q=np.flatnonzero(x.view(np.uint32)!=q.view(np.uint32)).tolist(),
        changed_qd=np.flatnonzero(y.view(np.uint32)!=qd.view(np.uint32)).tolist(),
        rejection=None if valid else 'NO_RELATIONS_OR_OUTSIDE_ORIGINAL_HARD_SOFT_VMAX',
        clipped=False,redrawn=False,original_sample_preserved_separately=True)

def residual(q,qd,relations):
    return dict(position=[float(q[r['child']])+r['multiplier']*-float(q[r['parent']])-r['offset'] for r in relations],
        velocity=[float(qd[r['child']])-r['multiplier']*float(qd[r['parent']]) for r in relations])

def paired_inputs(q,qd,ids,relations,layout,authority):
    need(q.shape==qd.shape==(16,74) and len(ids)==16,'exact16 latent proposals')
    x=np.empty((32,74),np.float32);y=x.copy();records=[];candidate_q=[];candidate_qd=[]
    for i,pid in enumerate(ids):
        a,b=(2*i,2*i+1) if i%2==0 else (2*i+1,2*i)
        bq,bv,proof=project(q[i],qd[i],relations,layout['bounds'],layout['vmax'],layout['controlled'])
        x[a],y[a]=q[i],qd[i];x[b],y[b]=(bq,bv) if proof['constructible'] else (q[i],qd[i])
        candidate_q.append(bq);candidate_qd.append(bv)
        records.append(dict(pair=i,seed_index=0,proposal_id=pid,family=pid%4,A_lane=a,B_lane=b,
            intervention_authority=authority,B_disposition='CONSTRUCTED_NOT_QUALIFIED' if proof['constructible'] else 'NOT_CONSTRUCTIBLE_BASELINE_DUPLICATE_RETAINED',
            **proof,original_residual=residual(q[i],qd[i],relations),candidate_residual=residual(bq,bv,relations)))
    return x,y,np.asarray(candidate_q),np.asarray(candidate_qd),records

def coverage(q,qd,layout):
    """Descriptive coverage only; no iid probability or manifold-volume claim."""
    unit=(q.astype(float)-layout['bounds'][:,0])/(layout['bounds'][:,1]-layout['bounds'][:,0])
    speed=qd.astype(float)/layout['vmax']
    edges=[0.,.1,.25,.5,.75,.9,1.]
    return dict(n=len(q),q_min=q.min(0).tolist(),q_max=q.max(0).tolist(),
        qd_min=qd.min(0).tolist(),qd_max=qd.max(0).tolist(),
        normalized_q_bins=edges,q_hist74=[np.histogram(unit[:,i],edges)[0].tolist() for i in range(74)],
        normalized_qd_bins=[-1,-.9,-.5,0,.5,.9,1],
        qd_hist74=[np.histogram(speed[:,i],[-1,-.9,-.5,0,.5,.9,1])[0].tolist() for i in range(74)],
        full148_independent_support_preserved_by_projection=False,reachable_from_safe_start='UNKNOWN')
