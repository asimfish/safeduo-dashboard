"""Descriptive paired effect, all denominators retained. No eligibility output."""
import numpy as np
from constraint_model_v1 import need,residual
def summarize(cases,flags,q,qd,layout,relations):
    need(flags.shape==(13,32,7) and flags.dtype==bool and q.shape==qd.shape==(13,32,74),'all13 rows required; partial is not complete')
    rows=[]
    for c in cases:
        r=dict(pair=c['pair'],proposal_id=c['proposal_id'],family=c['family'],comparable=c['constructible'])
        for label in ('A','B'):
            lane=c[label+'_lane'];v=flags[:,lane]
            r[label]=dict(lane=lane,any_original_numeric_denial=bool(v.any()),initial_denial=v[0].tolist(),
                prefix_denial_counts=v[1:].sum(0).tolist(),peak_sampled_abs_velocity_ratio=float((np.abs(qd[:,lane])/layout['vmax']).max()),
                max_sampled_delta_qd=float(np.abs(np.diff(qd[:,lane],axis=0)).max()),
                initial_residual=residual(q[0,lane],qd[0,lane],relations),final_residual=residual(q[-1,lane],qd[-1,lane],relations))
        rows.append(r)
    return dict(status='DESCRIPTIVE_NOT_INDEPENDENT_AUDIT',latent_denominator=16,physical_cases=32,rows=rows,
        constructible_denominator=sum(c['constructible'] for c in cases),
        camera='NOT_TESTED',eligible=0,bank_count=0,physical_safety='UNKNOWN',
        torque_peaks='UNKNOWN',within_micro_peaks='UNKNOWN',reachable_from_safe_state='UNKNOWN',
        inferential_claim='paired finite observed-state comparison; no iid/global bound; sentinels separately identified')
