"""Separate GPU0 operational mapping; no mutation of closed GPU1 modules."""
import os,sys,time
from bindings_v1 import require,resource_check,assert_dependencies,bound_json
from source_import_v3 import authority

def parent_helper():
    assert_dependencies()
    import mechanism_bootstrap_v1 as b
    from source_import_v3 import module_from_buffer
    path=b.HERE/'gpu_parent_v3.py'
    return module_from_buffer('_mechanism_gpu0_parent_v4',path,b.graph()[str(path)])

def example_binding():
    p=parent_helper()
    return dict(physical_index=p.PHYSICAL_GPU,physical_uuid=p.EXPECTED_UUID,CUDA_VISIBLE_DEVICES=p.VISIBLE_DEVICES,
        logical_device=p.CUDA_DEVICE,physics_gpu_logical=0,renderer_kit_index=0,renderer_uuid_prefix='b129224c',
        renderer_pci_bus_hex='41',multi_GPU=False)

def validate(binding):
    expected=example_binding()
    require(isinstance(binding,dict) and set(binding)==set(expected) and
        all(type(binding[k]) is type(v) and binding[k]==v for k,v in expected.items()),
        'exact reviewed V3 GPU0 physical/Kit/CUDA mapping required; no ordinal inference')
    return binding

def configure_app(binding,config):
    validate(binding)
    # Exact unchanged parent helper: incoming logical active0/physics0, then
    # renderer Kit index0/physics logical0. This does not inspect native physics.
    parent_helper().configure_single_gpu(config)
    return config

def observation(binding,value,*,initial):
    b=validate(binding)
    require(value['gpu_index']==b['physical_index'] and value['gpu_uuid']==b['physical_uuid'],'resource physical index/UUID mismatch')
    return resource_check(value,initial)

def permit(binding,document,request_sha,*,now=None):
    b=validate(binding);now=time.time() if now is None else now
    require(document['schema']=='astra.full74.per_state.gpu_permit.v3' and document['parent_authorized'] is True and
        document['request_sha256']==request_sha and document['gpu_binding']==b and document['single_owned_Kit'] is True and
        document['cpu_test_only'] is False,'same reviewed request/physical/Kit mapping permit')
    require(0<=now-document['observed_unix_s']<=30,'fresh permit <=30 seconds')
    return observation(b,document['prelaunch_observation'],initial=True)

def prelaunch(request,request_sha,document,environment,*,now=None):
    b=validate(request['gpu_binding']);permit(b,document,request_sha,now=now)
    require(environment['CUDA_VISIBLE_DEVICES']==b['CUDA_VISIBLE_DEVICES'] and
        environment['OMNI_KIT_ACCEPT_EULA']=='YES' and environment['PRIVACY_CONSENT']=='Y','child remap/consent binding')
    require(all(environment[k]=='1' for k in ['PYTHONDONTWRITEBYTECODE','OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS']),'single CPU thread pre-import environment')
    return dict(status='PRELAUNCH_BINDING_CHECKED_NOT_NATIVE_PASS',gpu_binding=b,
        renderer_actual_identity='PENDING_POST_APP_KIT_SETTINGS_AND_TABLE',native_SDK_compatibility='UNKNOWN')

def probe(binding,tree=None,*,initial=False,deadline=None):
    import runtime_core_v4 as core
    validate(binding);require(initial or tree is not None,'runtime whole-owned probe requires verified ownership tree')
    return observation(binding,core.probe_resources(tree,gpu=binding['physical_index'],deadline=deadline),initial=initial)

def self_probe(binding):
    from gpu_resource_observation_v2 import observe_resources
    validate(binding)
    value=observe_resources(dict(gpu_index=binding['physical_index']))
    require(value['ownership_scope']=='SELF_PID_ONLY','child PID scope; parent guardian separately covers descendants')
    return observation(binding,value,initial=False)

def check_before_app(request_path,request_sha,review_path,review_sha,permit_path,permit_sha):
    import runtime_core_v4 as core
    from mechanism_bootstrap_v1 import request_pair
    request,_=request_pair(request_path,request_sha,review_path,review_sha,native=True)
    result=prelaunch(request,request_sha,bound_json(permit_path,permit_sha),os.environ)
    result.update(request_sha256=request_sha,permit_sha256=permit_sha,child_identity=core.proc_identity(os.getpid()),
        checked_unix_s=time.time(),fresh_prelaunch_observation=probe(request['gpu_binding'],initial=True))
    return result

def runtime_identity(binding,torch_module,settings,kit_log_path):
    """Parent invokes only post-App. Missing/mismatched Kit evidence denies BEFORE env_factory."""
    validate(binding);p=parent_helper()
    import mechanism_bootstrap_v1 as b
    cuda=p.actual_cuda_identity(torch_module,'cuda:0')
    kit=p.actual_kit_identity(settings,kit_log_path)
    return dict(actual_cuda=cuda,actual_kit=kit,parent_helper_source=b.ref(b.HERE/'gpu_parent_v3.py'),
        scope='DEVICE_IDENTITY_ONLY_NOT_CAMERA_OR_NATIVE_COMPATIBILITY_PASS',native_pass=False)
