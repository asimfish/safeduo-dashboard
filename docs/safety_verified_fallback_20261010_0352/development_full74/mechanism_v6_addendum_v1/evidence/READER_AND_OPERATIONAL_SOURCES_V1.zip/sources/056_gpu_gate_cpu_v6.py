"""Independent GPU selection and actual identity checks. No CUDA imports."""
from pathlib import Path
from evidence_io import HERE, require
from reuse_v6 import verified_reuse
import hashlib
UUID = 'GPU-b129224c-c735-a03f-de6c-185d2a2724b1'

def gpu_identity(value):
    keys = {'physical_gpu_index', 'cuda_device', 'expected_uuid', 'actual_cuda_uuid', 'cuda_visible_devices', 'multi_gpu', 'active_renderer_gpu', 'physics_logical_gpu'}
    require(isinstance(value, dict) and set(value) == keys, 'actual CUDA identity exact fields')
    for key in ('physical_gpu_index', 'active_renderer_gpu'):
        require(type(value[key]) is int and value[key] == 0, 'actual GPU index ' + key)
    require(value['cuda_device'] == 'cuda:0' and value['expected_uuid'] == UUID and (value['cuda_visible_devices'] == '0') and (value['multi_gpu'] is False) and (type(value['physics_logical_gpu']) is int) and (value['physics_logical_gpu'] == 0), 'actual GPU selection')
    actual = value['actual_cuda_uuid']
    require(isinstance(actual, str) and actual.lower().removeprefix('gpu-') == UUID.lower().removeprefix('gpu-'), 'actual CUDA properties UUID mismatch')
    return dict(value, renderer_fields_evidence='SOURCE_BOUND_CONFIG_ASSERTION', actual_cuda_uuid_evidence='POST_APP_CUDA_PROPERTIES_READBACK')

def read_kit_table(e, path):
    """Hash closed log by streaming; scan only the bounded startup prefix."""
    e.hash(path)
    scanned = 0
    lines = []
    with Path(path).open('rb') as f:
        while len(lines) < 16:
            raw = f.readline(64 * 1024 + 1)
            require(raw and len(raw) <= 64 * 1024, 'bounded complete Kit table lines')
            scanned += len(raw)
            require(scanned <= 16 * 1024 ** 2, 'Kit table absent from bounded startup prefix')
            line = raw.decode('utf-8').rstrip('\r\n')
            if lines or line.startswith('| GPU | Name'):
                lines.append(line)
    return '\n'.join(lines)

def kit_identity(value, observed_table):
    require(isinstance(value, dict) and set(value) == {'actual_settings', 'active_renderer', 'actual_rows', 'actual_table', 'actual_table_sha256'}, 'exact actual Kit identity fields')
    expected = {'/renderer/activeGpu': 0, '/physics/cudaDevice': 0, '/renderer/multiGpu/enabled': False}
    settings = value['actual_settings']
    require(isinstance(settings, dict) and set(settings) == set(expected), 'exact Kit settings keys')
    for key, want in expected.items():
        require(type(settings[key]) is type(want) and settings[key] == want, 'actual Kit setting ' + key)
    table = value['actual_table']
    require(isinstance(table, str) and len(table.encode()) <= 64 * 1024 and (table == observed_table), 'entry raw table matches closed actual Kit log')
    require(hashlib.sha256(table.encode()).hexdigest() == value['actual_table_sha256'], 'raw Kit table SHA')
    lines = table.splitlines()
    require(len(lines) == 16 and lines[0].startswith('| GPU | Name'), 'complete raw Kit table')
    rows = []
    for i, line in enumerate(lines):
        cells = [v.strip() for v in line.split('|')]
        if len(cells) != 9 or not cells[1].isdecimal():
            continue
        require(i + 2 < len(lines), 'complete Kit UUID and bus rows')
        uuid = [v.strip() for v in lines[i + 1].split('|')]
        bus = [v.strip() for v in lines[i + 2].split('|')]
        require(len(uuid) == len(bus) == 9 and (not uuid[1]) and (not bus[1]), 'Kit continuation row structure')
        require(uuid[7].endswith('..') and len(uuid[7]) == 10, 'Kit exact eight hexadecimal UUID prefix')
        prefix = uuid[7][:-2].lower()
        require(all((c in '0123456789abcdef' for c in prefix)), 'Kit UUID prefix hexadecimal')
        rows.append(dict(renderer_index=int(cells[1]), active=cells[3], uuid_prefix=prefix, pci_bus_hex=bus[6].lower()))
    require(len(rows) == 2 and {r['renderer_index'] for r in rows} == {0, 1}, 'unique actual renderer indices')
    selected = [r for r in rows if r['active'].startswith('Yes:')]
    require(len(selected) == 1 and selected[0] == dict(renderer_index=0, active='Yes: 0', uuid_prefix='b129224c', pci_bus_hex='41'), 'actual GPU0 renderer identity')
    require(value['actual_rows'] == rows and value['active_renderer'] == selected[0], 'producer GPU summaries agree with independently parsed raw rows')
    require(all((type(r.get('renderer_index')) is int for r in value['actual_rows'])) and type(value['active_renderer'].get('renderer_index')) is int, 'typed raw table summaries')
    return dict(actual_settings=settings, actual_rows=rows, active_renderer=selected[0], actual_table_sha256=value['actual_table_sha256'], evidence='POST_APP_SETTINGS_AND_CLOSED_RAW_KIT_TABLE_INDEPENDENTLY_RECOMPUTED')
