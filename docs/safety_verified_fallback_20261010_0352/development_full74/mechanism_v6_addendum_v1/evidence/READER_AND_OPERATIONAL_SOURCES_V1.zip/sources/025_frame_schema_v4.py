"""Typed projection of retained LIVE joint frames; no fitting or native setters."""
import re
from collections.abc import Mapping
import numpy as np

ARMS=('F_L','F_R','U_L','U_R')
KINDS={'PhysicsFixedJoint':'fixed','PhysicsRevoluteJoint':'revolute','PhysicsPrismaticJoint':'prismatic'}
AXES={'X':[1.,0.,0.],'Y':[0.,1.,0.],'Z':[0.,0.,1.]}
def need(v,message):
    if not v:raise ValueError(message)
def normal(path):return re.sub(r'/env_\d+/', '/env_N/',path)
def metatype_parent_indices(meta):
    names=list(meta.link_names);mapping=meta.link_parent_indices
    need(isinstance(mapping,Mapping) and set(mapping)==set(names),'installed SDK name->parent index mapping')
    values=[mapping[n] for n in names]
    need(all(isinstance(i,(int,np.integer)) and not isinstance(i,(bool,np.bool_)) and -1<=int(i)<len(names) for i in values),'typed native parent index mapping')
    return [int(i) for i in values]
def finite(v,shape):
    a=np.asarray(v,np.float64);need(a.shape==shape and np.isfinite(a).all(),'finite frame shape '+str(shape));return a
def quaternion_matrix(wxyz,*,float32_source=True):
    q=finite(wxyz,(4,));n=float(q@q)
    # Preserve raw quaternion in registry. Unit-quaternion->rotation conversion
    # divides by its norm; this changes no native q, qd, pose or parameters.
    eps=8*np.finfo(np.float32).eps if float32_source else 1e-12
    need(n>0 and abs(np.sqrt(n)-1)<=eps,'nonunit recorded quaternion')
    w,x,y,z=q; s=2/n
    return np.array([[1-s*(y*y+z*z),s*(x*y-z*w),s*(x*z+y*w)],
        [s*(x*y+z*w),1-s*(x*x+z*z),s*(y*z-x*w)],
        [s*(x*z-y*w),s*(y*z+x*w),1-s*(x*x+y*y)]],np.float64)
def local_transform(pos,wxyz,meters_per_unit):
    need(type(meters_per_unit) is float and np.isfinite(meters_per_unit) and meters_per_unit>0,'positive actual stage units')
    t=np.eye(4);t[:3,:3]=quaternion_matrix(wxyz);t[:3,3]=finite(pos,(3,))*meters_per_unit;return t
def native_transform(xyzw,origin):
    p=finite(xyzw,(7,));t=np.eye(4);t[:3,3]=p[:3]-finite(origin,(3,));t[:3,:3]=quaternion_matrix(p[[6,3,4,5]]);return t
def topology(raw):
    need(raw['schema']=='astra.full74.live_joint_registry.v4' and raw['capture_stage']=='BEFORE_EXPERIMENT_STATE_WRITE','live prewrite registry schema')
    u=raw['units'];need(u['native_position']=='m' and u['native_revolute_angle']=='rad' and u['USD_revolute_limits']=='degree' and u['quaternion_USD']=='wxyz' and u['quaternion_native']=='xyzw','explicit native/USD units and quaternion order')
    need(type(u['meters_per_unit']) is float and u['meters_per_unit']>0 and u['up_axis'] in ('Y','Z'),'resolved stage units/up axis')
    need(len(raw['lanes'])==32 and [x['lane'] for x in raw['lanes']]==list(range(32)),'all32 ordered lanes')
    baseline=None
    for lane in raw['lanes']:
        need(set(lane['arms'])==set(ARMS),'allfour arms in every lane')
        normalized={}
        for arm in ARMS:
            a=lane['arms'][arm]
            for key in ('dof_paths','link_paths'):
                need(len(a[key])==len(set(a[key])) and all('/env_'+str(lane['lane'])+'/' in p for p in a[key]),'lane-owned unique tensor paths')
            need(len(a['joint_names'])==len(a['dof_paths']) and len(a['body_names'])==len(a['link_paths']),'native mapping widths')
            joints=[]
            for j in a['joints']:
                need(len(j['body0'])<=1 and len(j['body1'])<=1,'single joint endpoints')
                for p in j['body0']+j['body1']:
                    need('/env_'+str(lane['lane'])+'/' in p,'foreign body endpoint')
                for key in ('localPos0','localPos1'):finite(j[key],(3,))
                for key in ('localRot0','localRot1'):quaternion_matrix(j[key])
                z={k:v for k,v in j.items() if k not in ('path','body0','body1','attribute_sources')}
                z.update(path=normal(j['path']),body0=list(map(normal,j['body0'])),body1=list(map(normal,j['body1'])))
                joints.append(z)
            normalized[arm]=dict(joint_names=a['joint_names'],body_names=a['body_names'],dof_paths=list(map(normal,a['dof_paths'])),link_paths=list(map(normal,a['link_paths'])),link_parent_indices=a['link_parent_indices'],fixed_base=a['fixed_base'],joints=joints)
        if baseline is None:baseline=normalized
        need(normalized==baseline,'all32 normalized joint frames/topology must match')
    return baseline
def model_from_registry(raw,readback,layout,body_names):
    """Export a tree or deny. Never infer mimic projection or fit measured poses."""
    topology(raw);names=layout['names'].tolist();need(len(names)==74 and len(set(names))==74,'native74 order')
    origins=finite(readback['env_origins'],(32,3));arms={};used=[];roots_diagnostic={}
    units=float(raw['units']['meters_per_unit'])
    for lane in raw['lanes']:
        for spec in lane['arms'].values():
            matrices=finite(spec['body_USD_world_row_vectors'],(len(spec['body_names']),4,4))
            for row_matrix in matrices:
                column_matrix=row_matrix.T;rotation=column_matrix[:3,:3]
                need(np.max(abs(rotation.T@rotation-np.eye(3)))<=1e-7 and abs(np.linalg.det(rotation)-1)<=1e-7 and np.array_equal(column_matrix[3],[0,0,0,1]),'unsupported live USD scale/shear/projective body frame')
    for arm in ARMS:
        spec=raw['lanes'][0]['arms'][arm];lo,hi=layout['slices'][arm];bn=body_names[arm].tolist()
        need(spec['joint_names']==[n.split('/',1)[1] for n in names[lo:hi]] and spec['body_names']==bn,'original native74/body82 identity')
        links=spec['link_paths'];parents=spec['link_parent_indices'];need(len(parents)==len(links) and spec['fixed_base'] is True,'fixed actual articulation and metatype parent map')
        roots=[i for i,p in enumerate(parents) if p==-1];need(len(roots)==1,'one actual articulation root link')
        root=links[roots[0]];root_frame=normal(root);known={root};todo=[]
        dof_map={p:lo+i for i,p in enumerate(spec['dof_paths'])};seen=set()
        for j in spec['joints']:
            if j['enabled'] is False:
                need(j['path'] not in dof_map,'disabled joint cannot own native DOF');continue
            need(j['enabled'] is True and j['type'] in KINDS,'unsupported enabled tree joint')
            kind=KINDS[j['type']];idx=dof_map.get(j['path'])
            if not j['body0'] or not j['body1']:
                need(kind=='fixed' and idx is None and j['body1']==[root] and not j['body0'],'unsupported world-anchor orientation');continue
            parent,child=j['body0'][0],j['body1'][0]
            need(parent in links and child in links and parents[links.index(child)]==links.index(parent),'USD endpoints equal actual native parent map; no guessed reversal')
            need(j['path'] not in seen,'duplicate joint');seen.add(j['path'])
            if kind=='fixed':need(idx is None,'fixed sampled DOF')
            else:need(idx is not None and j['axis'] in AXES,'single-axis native DOF mapping');used.append(idx)
            todo.append(dict(parent=parent,child=child,kind=kind,q_index=idx,native_joint_name=names[idx] if idx is not None else arm+'/'+j['name'],axis=AXES[j['axis']] if kind!='fixed' else [0.,0.,0.],parent_to_joint=local_transform(j['localPos0'],j['localRot0'],units).tolist(),child_to_joint=local_transform(j['localPos1'],j['localRot1'],units).tolist()))
        ordered=[]
        while todo:
            available=[j for j in todo if j['parent'] in known]
            need(bool(available),'disconnected/cyclic joint tree')
            for j in available:
                need(j['child'] not in known,'multiple parent joint tree')
                known.add(j['child']);todo.remove(j);ordered.append({**j,'parent':normal(j['parent']),'child':normal(j['child'])})
        need(known==set(links),'all82 native link frames reachable')
        pose=np.asarray(readback[arm+'_link_xyzw']);need(pose.shape==(32,len(bn),7) and pose.dtype==np.float32,'actual native body pose float32')
        root_t=native_transform(pose[0,roots[0]],origins[0]);differences=[]
        for lane in range(32):
            tf=native_transform(pose[lane,roots[0]],origins[lane]);differences.append(float(np.max(abs(tf-root_t))))
        # Homogeneous MODEL root, explicit numerical diagnostic only. Native
        # root values remain untouched; actual64+64 calibration remains required.
        need(max(differences)<=5e-5,'heterogeneous root cannot form shared independent-coordinate model')
        roots_diagnostic[arm]=dict(root_link_index=roots[0],max_matrix_difference=max(differences),per_lane_matrix_difference=differences)
        arms[arm]=dict(root_frame=root_frame,root_world_no_env_origin=root_t.tolist(),body_names=bn,body_frames={n:normal(p) for n,p in zip(bn,links)},joints=ordered)
    need(sorted(used)==list(range(74)),'each original74 DOF exactly once')
    need(sum(len(x) for x in body_names.values())==82,'all82 original body identities')
    centers=finite(readback['table_centers_world_no_env_origin'],(2,3));half=finite(readback['table_half_extents'],(2,3));need(np.all(half>0),'actual original table boxes')
    return dict(schema='astra.full74.fk.frame_model.v2',coordinates='ALL74_INDEPENDENT_NO_MIMIC_PROJECTION',units={'position':'m','angle':'rad'},joint_names74=names,arms=arms,table_centers_world_no_env_origin=centers.tolist(),table_half_extents=half.tolist()),roots_diagnostic
