"""Independent relation constructor and paired-input oracle. No producer imports."""
import math,xml.etree.ElementTree as ET
import numpy as np
from runtime import require,exact

def relations(e,q,layout,inventory):
    names=layout['names'].tolist();control=set(layout['controlled'].tolist());out=[]
    if q['intervention']=='URDF_DFX_HAND_COHERENCE_HYPOTHESIS':
        require(set(q['urdf_sources'])=={'U_L','U_R'} and inventory['mimic_relations']==[],'URDF hypothesis cannot claim native coupling')
        for arm in ('U_L','U_R'):
            r=q['urdf_sources'][arm]
            for joint in ET.fromstring(e.raw(r['path'],r['sha256'])).findall('joint'):
                mimic=joint.find('mimic')
                if mimic is None:continue
                require(joint.attrib['type']=='revolute','URDF joint type')
                c,p=arm+'/'+joint.attrib['name'],arm+'/'+mimic.attrib['joint']
                require(c in names and p in names,'URDF relation maps to actual native DOF roster')
                out.append(dict(child=names.index(c),parent=names.index(p),multiplier=float(mimic.get('multiplier','1')),
                    offset=float(mimic.get('offset','0')),authority='URDF_KINEMATIC_HINT_NOT_NATIVE_CONSTRAINT',source=r))
        require(len(out)==12,'exact12 DFX relations, never F2 substitution')
    else:
        require(q['intervention']=='LIVE_USD_AFFINE_HAND_MIMIC','declared constructor mode')
        raw=[]
        pathmap={r['path']:r for r in inventory['records']}
        for r in inventory['records']:
            for s in r['schemas']:
                if not s.startswith('PhysxMimicJointAPI:'):continue
                prefix='physxMimicJoint:'+s.split(':')[-1]+':'
                refs=r['relationships'][prefix+'referenceJoint'];require(len(refs)==1 and refs[0] in pathmap,'same actual joint reference')
                p=pathmap[refs[0]];a=r['attributes']
                require(r['type']==p['type']=='PhysicsRevoluteJoint' and r['arm']==p['arm'] and a['physics:jointEnabled'] is True,'supported enabled hand revolute relation')
                cidx,pidx=names.index(r['joint_name']),names.index(p['joint_name'])
                out.append(dict(child=cidx,parent=pidx,multiplier=-float(a[prefix+'gearing']),offset=-float(a[prefix+'offset'])*(math.pi/180.),authority='LIVE_USD_MIMIC_SCHEMA'))
                raw.append(dict(child=r['joint_name'],parent=p['joint_name'],type=r['type'],reference_type=p['type'],same_articulation=True,enabled=True,
                    gearing=a[prefix+'gearing'],offset_degrees=a[prefix+'offset'],path=r['path'],axis=s.split(':')[-1]))
        require(raw==inventory['mimic_relations'] and bool(out),'summary matches actual USD registry')
    require(len({r['child'] for r in out})==len(out),'one independent relation per child')
    for r in out:require(r['child'] not in control and r['parent'] not in control and r['child']!=r['parent'] and math.isfinite(r['multiplier']) and math.isfinite(r['offset']),'hand-only finite relation')
    return out

def construct(rawq,rawv,rs):
    """Recursive dependency evaluation, independently from producer's Kahn loop."""
    by={r['child']:r for r in rs};x=rawq.copy();v=rawv.copy();done=set();visiting=set()
    def solve(c):
        if c not in by or c in done:return
        require(c not in visiting,'cyclic initialization relation');visiting.add(c);r=by[c];solve(r['parent'])
        x[c]=np.float32(np.float64(x[r['parent']])*np.float64(r['multiplier'])+np.float64(r['offset']))
        v[c]=np.float32(np.float64(v[r['parent']])*np.float64(r['multiplier']))
        visiting.remove(c);done.add(c)
    for c in by:solve(c)
    return x,v

def residual(q,v,rs):
    return dict(position=[float(q[r['child']])-r['multiplier']*float(q[r['parent']])-r['offset'] for r in rs],velocity=[float(v[r['child']])-r['multiplier']*float(v[r['parent']]) for r in rs])
def scalar_close(actual,expected,label):
    a=np.asarray(actual,np.float64);b=np.asarray(expected,np.float64)
    require(a.shape==b.shape and np.isfinite(a).all() and np.isfinite(b).all(),'finite paired statistic '+label)
    require(np.all(np.abs(a-b)<=8*np.finfo(np.float64).eps*np.maximum(1,np.abs(b))),'float64 summary arithmetic '+label)

def audit_arrays(ids,rawq,rawv,candidateq,candidatev,writtenq,writtenv,cases,rs,layout,mode):
    require(ids==list(range(92,108)) and len(cases)==16,'fixed16 IDs/all cases')
    require(rawq.shape==rawv.shape==candidateq.shape==candidatev.shape==(16,74) and writtenq.shape==writtenv.shape==(32,74),'all latent/candidate/written shapes')
    require(all(a.dtype==np.float32 and np.isfinite(a).all() for a in (rawq,rawv,candidateq,candidatev,writtenq,writtenv)),'typed finite q/qd')
    require(np.all(rawq>=layout['bounds'][:,0]) and np.all(rawq<=layout['bounds'][:,1]) and np.all(np.abs(rawv)<=layout['vmax']),'original challenge support')
    require({r['child'] for r in rs}.isdisjoint(layout['controlled']) and {r['parent'] for r in rs}.isdisjoint(layout['controlled']),'no controlled26 intervention')
    compared=[];lanes=[]
    for i,pid in enumerate(ids):
        row=cases[i];a=2*i+(i%2);b=2*i+1-(i%2);lanes.extend([a,b])
        require((row['pair'],row['seed_index'],row['proposal_id'],row['family'],row['A_lane'],row['B_lane'])==(i,0,pid,pid%4,a,b),'pair IDs/order/lane assignment')
        require(row['intervention_authority']==mode and row['clipped'] is False and row['redrawn'] is False and row['original_sample_preserved_separately'] is True,'explicit constructor provenance')
        x,v=construct(rawq[i],rawv[i],rs);exact(x,candidateq[i],'candidateq independent formula');exact(v,candidatev[i],'candidateqd independent formula')
        okay=bool(rs) and bool((x>=layout['bounds'][:,0]).all() and (x<=layout['bounds'][:,1]).all() and (np.abs(v)<=layout['vmax']).all())
        require(row['constructible'] is okay and row['no_projection'] is (not bool(rs)),'constructibility not a safety verdict')
        require(row['B_disposition']==('CONSTRUCTED_NOT_QUALIFIED' if okay else 'NOT_CONSTRUCTIBLE_BASELINE_DUPLICATE_RETAINED'),'retained no-clipping fallback')
        require(row['rejection']==(None if okay else 'NO_RELATIONS_OR_OUTSIDE_ORIGINAL_HARD_SOFT_VMAX'),'constructor rejection retained')
        require(row['changed_q']==np.flatnonzero(x.view(np.uint32)!=rawq[i].view(np.uint32)).tolist() and row['changed_qd']==np.flatnonzero(v.view(np.uint32)!=rawv[i].view(np.uint32)).tolist(),'every changed74 field')
        exact(writtenq[a],rawq[i],'A original q');exact(writtenv[a],rawv[i],'A original qd')
        exact(writtenq[b],x if okay else rawq[i],'B actual written q');exact(writtenv[b],v if okay else rawv[i],'B actual written qd')
        for label,q0,v0 in [('original_residual',rawq[i],rawv[i]),('candidate_residual',x,v)]:
            independent=residual(q0,v0,rs)
            for k in ('position','velocity'):scalar_close(row[label][k],independent[k],label+k)
        compared.append(dict(pair=i,proposal_id=pid,family=pid%4,A_lane=a,B_lane=b,comparable=okay,sentinel=pid<96))
    require(sorted(lanes)==list(range(32)),'all32 assigned once')
    return dict(rows=compared,latent_denominator=16,physical_cases=32,constructible=sum(r['comparable'] for r in compared),
        projection_and_readback_tolerance='EXACT_FLOAT32_BYTES',summary_tolerance='8*float64_epsilon*max(1,abs(expected)); metadata only',
        geometry_tolerance='unchanged5e-5m reconstruction only; raw9021<0 uses zero epsilon',camera='NOT_TESTED',bank_count=0)

def check_summary(reported,rows,flags,q,qd,layout,rs):
    require(reported['status']=='DESCRIPTIVE_NOT_INDEPENDENT_AUDIT' and reported['camera']=='NOT_TESTED' and reported['eligible']==reported['bank_count']==0,'no producer promotion')
    require(reported['latent_denominator']==16 and reported['physical_cases']==32 and len(reported['rows'])==16 and reported['constructible_denominator']==sum(r['comparable'] for r in rows),'summary denominator')
    for expected,r in zip(rows,reported['rows']):
        require(all(r[k]==expected[k] for k in ('pair','proposal_id','family','comparable')),'summary paired identity')
        for side in ('A','B'):
            lane=expected[side+'_lane'];v=flags[:,lane];s=r[side]
            require(s['lane']==lane and s['any_original_numeric_denial'] is bool(v.any()) and s['initial_denial']==v[0].tolist() and s['prefix_denial_counts']==v[1:].sum(0).tolist(),'independent numeric denial counts')
            scalar_close(s['peak_sampled_abs_velocity_ratio'],float((np.abs(qd[:,lane])/layout['vmax']).max()),'sampled velocity ratio')
            scalar_close(s['max_sampled_delta_qd'],float(np.abs(np.diff(qd[:,lane],axis=0)).max()),'sampled qd delta')
            for key,index in [('initial_residual',0),('final_residual',-1)]:
                calc=residual(q[index,lane],qd[index,lane],rs)
                for k in calc:scalar_close(s[key][k],calc[k],key+k)
    require(all(reported[k]=='UNKNOWN' for k in ('physical_safety','torque_peaks','within_micro_peaks','reachable_from_safe_state')),'unknown physical/peak/reachability scope')
