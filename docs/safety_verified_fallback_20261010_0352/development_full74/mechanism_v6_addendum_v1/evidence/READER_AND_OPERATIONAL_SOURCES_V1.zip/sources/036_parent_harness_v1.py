"""Parent-only single-seed supervisor. Consumes already frozen reviewed requests.

No freeze operation and no automatic four-seed continuation. Each explicit
native invocation requires fresh complete owned inventory and one serial lease.
"""
import argparse,datetime,json,os,sys,time
from pathlib import Path
from mechanism_bootstrap_v1 import bootstrap,assert_threads
HERE=Path(__file__).resolve().parent

def validate_recorded_device(b,binding,actual,kit_log):
    from mechanism_gpu_binding_v4 import validate,parent_helper
    validate(binding);cuda=actual['actual_cuda'];kit=actual['actual_kit']
    b.require(cuda['actual_cuda_uuid'].lower().removeprefix('gpu-')==binding['physical_uuid'].lower().removeprefix('gpu-') and
        cuda['cuda_device']=='cuda:0' and cuda['cuda_visible_devices']=='0' and cuda['physical_gpu_index']==0 and
        kit['actual_settings']=={'/renderer/activeGpu':0,'/physics/cudaDevice':0,'/renderer/multiGpu/enabled':False},
        'actual CUDA UUID and recorded Kit settings')
    # Reuse the exact helper's table parser and its canonical active token.
    # The startup table is in the bounded log prefix; later appended log bytes
    # are independently retained and hashed by the parent artifact receipt.
    with Path(kit_log).open('rb') as f:raw=f.read(16*1024**2)
    canonical=parent_helper().kit_table_identity(raw)
    b.require(all(kit[k]==v for k,v in canonical.items()),'recorded actual Kit identity differs from canonical helper/log')
    return canonical

def check_inventory(b,core,registration,*,fresh):
    b.require(registration['schema']=='astra.per_state.parent_serial_inventory.v4' and
        registration['parent_declares_complete_owned_inventory'] is True and
        registration['no_other_owned_Kit'] is True and bool(registration['closed_receipts']),
        'fresh complete parent-owned serial registration required')
    if fresh:
        age=time.time()-registration['observed_unix_s'];b.require(0<=age<=30,'inventory registration older than30s')
    b.verify_files(registration['closed_receipts'])
    rows=registration['owned_identities'];b.require(bool(rows),'nonempty owned history required')
    found=[]
    for row in rows:
        b.require(row['receipt_path'] in registration['closed_receipts'] and
            type(row['pid']) is int and row['pid']>0 and type(row['startticks']) is int and row['startticks']>0,
            'owned PID/startticks/closed receipt binding')
        receipt=b.bound_json(row['receipt_path'],registration['closed_receipts'][row['receipt_path']])
        b.require(receipt.get('waitpid_observed') is True and type(receipt.get('actual_wait_exit')) is int and
            os.waitstatus_to_exitcode(receipt['raw_wait_status'])==receipt['actual_wait_exit'] and
            receipt['child_pid']==receipt['waited_pid'] and bool(receipt.get('closed_utc')) and
            any(x['pid']==row['pid'] and x['startticks']==row['startticks'] and x['live'] is False
                for x in receipt['owned_identities']),'registered receipt actually closed/reaped')
        try:current=core.proc_identity(row['pid'])
        except (FileNotFoundError,ProcessLookupError):current=None
        b.require(current is None or current['startticks']!=row['startticks'],'prior owned identity still present (including zombie)')
        found.append(dict(identity=row,current_identity=current,previous_identity_absent=True))
    return dict(observed_utc=core.utc(),source_files=registration['closed_receipts'],rows=found,
        scope='REGISTERED_OWNED_ONLY_PARENT_COMPLETENESS_DECLARATION_NO_FOREIGN_SIGNALS')

def validate_products(b,request,request_sha,root,wait):
    from negative_prerequisite_v4 import normal_wait,PHASE
    normal_wait(wait,[0],native=True)
    entry=b.document(b.ref(root/'entry/ENTRY_RECEIPT_V4.json'))
    telemetry=entry['telemetry_startup_v5']
    b.require(telemetry['schema']=='astra.constraint.mechanism.telemetry_startup_readback.v5' and
        telemetry['excluded']==['omni.kit.telemetry'] and telemetry['structured_log_enabled'] is False and
        telemetry['anonymous_data_enabled'] is False and telemetry['enabled_extension_id'] in (None,'') and
        telemetry['disable_anonymous_environment']=='1' and telemetry['native_wait_waiver'] is False,
        'mandatory actual post-App telemetry exclusion/settings readback; no wait waiver')
    producer=b.document(b.ref(root/'native/MECHANISM_RECEIPT_V1.json'))
    b.require(entry['status']=='mechanism_complete_pending_actual_wait_and_independent_audit' and
        entry['receipt_phase']==PHASE and not entry.get('cleanup_errors') and not entry.get('entry_write_error') and
        not (root/'entry/APP_CLOSE_ERROR_V4.json').exists(),'clean actual lifecycle, not exitcode alone')
    b.require(entry['producer']==producer and entry['request_sha256']==producer['request_sha256']==request_sha and
        producer['status']=='MECHANISM_COLLECTION_COMPLETE_PENDING_WAIT_AND_INDEPENDENT_AUDIT' and
        producer['actual_micro_ids']==list(range(13)) and producer['physics_steps']==12 and
        producer['measurement_bytes_verified'] is True and producer['bank_count']==0,'complete diagnostic rows/measurement only')
    validate_recorded_device(b,request['gpu_binding'],entry['actual_gpu_identity'],root/'logs/kit.log')
    from fresh_exchange_mechanism_v1 import verify_closed_boundary
    from runtime_mechanism_v1 import load_runtime
    verify_closed_boundary(entry,request,request_sha,root,wait,load_runtime(request))
    b.verify_files(producer['artifacts'])
    return dict(status='MECHANISM_COMPLETE_PENDING_INDEPENDENT_RAW_AUDIT',eligible=False,bank_count=0,
        entry=b.ref(root/'entry/ENTRY_RECEIPT_V4.json'),producer=b.ref(root/'native/MECHANISM_RECEIPT_V1.json'))

def execute(args,b,request):
    from runtime_mechanism_v1 import load_runtime,serial_class
    from mechanism_gpu_binding_v4 import observation
    from negative_prerequisite_v4 import normal_wait
    core=load_runtime(request);SerialLease=serial_class(core,request['source_files'])
    registration=b.bound_json(args.serial_inventory,args.serial_inventory_sha256)
    root=Path(request['attempt_root']);lock=b.R/'astra_full74_screen_native_v2/.parent_owned_native_serial_v2.lock'
    with SerialLease(lock) as lease:
        serial=check_inventory(b,core,registration,fresh=True);serial['lease']=lease.assert_held()
        fresh=observation(request['gpu_binding'],core.probe_resources(gpu=0),initial=True)
        b.require(not root.exists(),'exclusive new native attempt root')
        root.mkdir(parents=True,exist_ok=False)
        for name in ['tmp','cache/ov','cache/cuda','cache/torch','cache/warp','config','data/ov','logs']:(root/name).mkdir(parents=True,exist_ok=True)
        b.json_new(root/'FRESH_SERIAL_INVENTORY_V4.json',serial);b.json_new(root/'PRELAUNCH_RESOURCES_V4.json',fresh)
        state=dict(status='failed',started_utc=core.utc(),parent_identity=core.proc_identity(os.getpid()),
            request_sha256=args.request_sha256,request_frozen_by_this_harness=False,native_launched=False)
        try:
            base=[sys.executable,'-B',str(HERE/'native_entry_v1.py'),'--request',args.request,
                '--request-sha256',args.request_sha256,'--review',args.review,'--review-sha256',args.review_sha256]
            cpu=core.bounded_child(base+['--check-cpu'],b.child_environment(root,native=False),root/'cpu_check',
                backend='CPU_REQUEST_CHECK_ONLY',max_wall=120,cpu_limit=True)
            state['CPU_check_actual_wait']=cpu;normal_wait(cpu,[0],native=False)
            # Validation/reaping precede permit time, so the permit measures the
            # last fresh pre-App resource observation, never an older log time.
            b.request_pair(args.request,args.request_sha256,args.review,args.review_sha256,native=True)
            serial=check_inventory(b,core,registration,fresh=False);lease.assert_held()
            fresh=observation(request['gpu_binding'],core.probe_resources(gpu=0),initial=True)
            permit=dict(schema='astra.full74.per_state.gpu_permit.v3',parent_authorized=True,cpu_test_only=False,
                request_sha256=args.request_sha256,review_sha256=args.review_sha256,gpu_binding=request['gpu_binding'],
                single_owned_Kit=True,observed_unix_s=time.time(),prelaunch_observation=fresh,
                parent_identity=core.proc_identity(os.getpid()),serial_lease=lease.assert_held(),
                freshness_protocol=request['freshness_protocol'],dispatch_monotonic_s=time.monotonic())
            pp=root/'LIVE_PERMIT_V4.json';b.json_new(pp,permit)
            from fresh_exchange_mechanism_v1 import ParentBroker
            broker=ParentBroker(root,request,args,dict(path=str(pp),sha256=b.sha(pp)),core,lease)
            previous=None
            with (root/'FRESH_STATUS_V4.jsonl').open('x') as status:
                def monitor(tree,deadline):
                    nonlocal previous
                    lease.assert_held()
                    broker.tick(tree,deadline)
                    value=observation(request['gpu_binding'],core.probe_resources(tree,gpu=0,deadline=deadline),initial=False)
                    pid=next(iter(tree.members));identity=tree.members[pid]['identity']
                    try:actual=core.proc_identity(pid)
                    except (FileNotFoundError,ProcessLookupError):actual=None
                    log=root/'native_process/child.log';st=log.stat() if log.exists() else None
                    mtime=st.st_mtime_ns if st else None
                    core.append_event(status,dict(observed_utc=core.utc(),identity=identity,actual_proc_stat=actual,
                        same_PID_startticks=bool(actual and core.same_identity(actual,identity)),
                        log_last_write_ns=mtime,log_advanced=previous is not None and mtime!=previous,
                        log_age_seconds=time.time()-st.st_mtime if st else None,
                        native_wait_receipt_present=(root/'native_process/ACTUAL_WAIT.json').exists(),
                        entry_receipt_present=(root/'entry/ENTRY_RECEIPT_V4.json').exists(),old_log_is_not_live_evidence=True))
                    previous=mtime;return value
                state['native_launched']=True
                wait=core.bounded_child(base+['--execute-native-screen','--permit',str(pp),'--permit-sha256',b.sha(pp),
                    '--headless','--enable_cameras','--device','cuda:0'],
                    b.child_environment(root,native=True,gpu_binding=request['gpu_binding']),root/'native_process',
                    backend='isaac_physx_native',max_wall=1200,monitor=monitor,cpu_limit=False)
            state['native_actual_wait']=wait
            state['products']=validate_products(b,request,args.request_sha256,root,wait)
            state['status']='PRODUCER_COMPLETE_PENDING_INDEPENDENT_AUDIT';return 0
        finally:
            state['closed_utc']=core.utc();b.json_new(root/'PARENT_RECEIPT_V4.json',state)

def main():
    p=argparse.ArgumentParser(allow_abbrev=False)
    for key in ['request','request-sha256','review','review-sha256']:p.add_argument('--'+key,required=True)
    g=p.add_mutually_exclusive_group(required=True);g.add_argument('--check-cpu',action='store_true');g.add_argument('--execute-reviewed',action='store_true')
    p.add_argument('--serial-inventory');p.add_argument('--serial-inventory-sha256')
    a=p.parse_args();assert_threads();b,runner,request,out=bootstrap(a,native=a.execute_reviewed)
    if a.check_cpu:
        b.require(os.environ.get('CUDA_VISIBLE_DEVICES')=='' and not any(k=='torch' or k.startswith(('isaac','omni.')) for k in sys.modules),'CPU only')
        print('PARENT_HARNESS_CPU_CHECKED_NO_FREEZE_NO_NATIVE',flush=True);return 0
    b.require(a.serial_inventory and a.serial_inventory_sha256,'fresh parent serial registration required')
    return execute(a,b,request)

if __name__=='__main__':raise SystemExit(main())
