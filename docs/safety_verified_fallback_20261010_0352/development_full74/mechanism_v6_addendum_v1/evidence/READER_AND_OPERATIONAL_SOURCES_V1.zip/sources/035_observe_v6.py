"""Exact old direct fork/wait4 observer; no signals or nested native guardian."""
import argparse,hashlib,json,os,resource,sys,types
from pathlib import Path
HERE=Path(__file__).resolve().parent;H=HERE.parents[1];R=Path('/mnt/nas/data/lyf/double_hand/safety_verified_fallback_20261010_0352')
PY='/home/liyufeng/miniforge3/envs/safeduo/bin/python'

def main():
    p=argparse.ArgumentParser(allow_abbrev=False);p.add_argument('--source-graph-sha256',required=True);p.add_argument('--attempt',required=True)
    mode=p.add_mutually_exclusive_group(required=True);mode.add_argument('--cpu',action='store_true');mode.add_argument('--execute-reviewed',action='store_true')
    for key in ['request','request-sha256','review','review-sha256','serial-inventory','serial-inventory-sha256']:p.add_argument('--'+key)
    a=p.parse_args();assert sys.dont_write_bytecode and a.attempt.replace('_','').isalnum()
    raw=(HERE/'SOURCE_GRAPH_V4.json').read_bytes();assert hashlib.sha256(raw).hexdigest()==a.source_graph_sha256;graph=json.loads(raw)
    for path,digest in graph['files'].items():
        if Path(path).is_relative_to(HERE):assert hashlib.sha256(Path(path).read_bytes()).hexdigest()==digest
    assert all(os.environ.get(k)=='1' for k in ['PYTHONDONTWRITEBYTECODE','OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS'])
    if a.cpu:
        assert os.environ.get('CUDA_VISIBLE_DEVICES')=='';resource.setrlimit(resource.RLIMIT_AS,(1024**3,1024**3))
        assert all(getattr(a,k.replace('-','_')) is None for k in ['request','request-sha256','review','review-sha256','serial-inventory','serial-inventory-sha256'])
        argv=[PY,'-B',str(HERE/'run_cpu_v6.py'),a.attempt]
    else:
        assert resource.getrlimit(resource.RLIMIT_AS)[1]==resource.RLIM_INFINITY
        argv=[PY,'-B',str(HERE/'parent_harness_v1.py')]
        for key in ['request','request-sha256','review','review-sha256','serial-inventory','serial-inventory-sha256']:
            value=getattr(a,key.replace('-','_'));assert value;argv+=['--'+key,value]
        argv+=['--execute-reviewed']
    path=H/'astra/full74_admissible_pilot_namespace_v2/observe_namespace_v2.py';raw=path.read_bytes();assert hashlib.sha256(raw).hexdigest()=='65503815d51c14cf94e42e41c01e63c8d01a8a150ee2a0ce77ad990e6d879fcc'
    observer=types.ModuleType('_unchanged_mechanism_gpu0_direct_observer');observer.__file__=str(path);exec(compile(raw,str(path),'exec'),observer.__dict__)
    root=(R/'astra_full74_independent_reader_v1/full74_native_constraint_mechanism_v6_stateapi/cpu_external' if a.cpu else R/'astra_full74_native_constraint_mechanism_v6_stateapi/native_external')/a.attempt
    wait=observer.observe(argv,root)
    assert wait['waitpid_observed'] and wait['owned_identities'] and all(row['live'] is False for row in wait['owned_identities'])
    print(json.dumps(dict(actual_outer_exit=wait['actual_wait_exit'],wait=observer.ref(root/'ACTUAL_WAIT.json'))),flush=True)
    return wait['actual_wait_exit'] if wait['actual_wait_exit']>=0 else 128-wait['actual_wait_exit']

if __name__=='__main__':raise SystemExit(main())
