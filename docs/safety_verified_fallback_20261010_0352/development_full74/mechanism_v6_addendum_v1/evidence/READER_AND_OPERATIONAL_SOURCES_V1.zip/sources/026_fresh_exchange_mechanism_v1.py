"""Source-reviewed two-phase IPC, called only by this new entry/harness.

All native-side work is inside the existing bounded_child1200 guardian.
Only that guardian owns process signals. This module sends no signals.
"""
import hashlib,json,os,threading,time
from pathlib import Path
from fresh_gate_v1 import make_ready,issue_grant,consume_at_app_boundary,exact_owned_root,identity,digest,fresh

def need(v,why):
    if not v:raise ValueError(why)
def main_thread():need(threading.current_thread() is threading.main_thread(),'foreign thread cannot issue/consume App authorization')
def clock():return time.time(),time.monotonic()
def raw(path,maximum=4*1024**2):
    with Path(path).open('rb') as f:value=f.read(maximum+1)
    need(len(value)<=maximum,'bounded IPC packet');return value
def read_ref(ref):
    data=raw(ref['path']);need(hashlib.sha256(data).hexdigest()==ref['sha256'],'IPC same-buffer SHA')
    def unique(items):
        d={}
        for k,v in items:need(k not in d,'duplicate IPC JSON key');d[k]=v
        return d
    return json.loads(data,object_pairs_hook=unique)
def write(path,value):
    data=(json.dumps(value,sort_keys=True,indent=2,allow_nan=False)+'\n').encode()
    with Path(path).open('xb') as f:f.write(data);f.flush();os.fsync(f.fileno())
    return dict(path=str(path),sha256=hashlib.sha256(data).hexdigest())
def put(folder,name,value):
    start=clock();r=write(folder/(name+'.json'),value);body_finished=clock()
    commit=write(folder/(name+'.COMMIT.json'),dict(body=r,body_write_started=start,body_write_finished=body_finished))
    return dict(body=r,commit=commit,commit_finished=clock())
def get(folder,name):
    path=folder/(name+'.COMMIT.json')
    commit_data=raw(path);commit=json.loads(commit_data)
    need(commit['body']['path']==str(folder/(name+'.json')),'exact fixed packet path')
    value=read_ref(commit['body'])
    return value,dict(body=commit['body'],commit=dict(path=str(path),sha256=hashlib.sha256(commit_data).hexdigest()),commit_record=commit)
def context(q,args,dispatch_ref):
    return dict(request=dict(path=args.request,sha256=args.request_sha256),review=dict(path=args.review,sha256=args.review_sha256),source_graph=q['pre_app_freshness_graph'],dispatch_permit=dispatch_ref,gpu_binding=q['gpu_binding'],resource=q['resource'],SSD_operational_reserve_bytes=q['SSD_operational_reserve_bytes'],min_NAS_free_bytes=q['min_NAS_free_bytes'])

class Timeline:
    def __init__(self,root):
        self.root=Path(root)/'pre_app_timing_v4';self.root.mkdir(exist_ok=False);self.events=[];self.index=0
    def phase(self,name,**extra):
        record=dict(schema='astra.pre_app.real_phase.v4',phase=name,pid=os.getpid(),thread_id=threading.get_ident(),unix_s=time.time(),monotonic_s=time.monotonic(),**extra)
        r=write(self.root/f'{self.index:03d}_{name}.json',record);self.events.append(r);self.index+=1;return r

def begin_timing(args):
    # First same-buffer request/review check; no request-driven execution.
    from mechanism_bootstrap_v1 import bounded_json
    q=bounded_json(args.request,args.request_sha256);r=bounded_json(args.review,args.review_sha256)
    need(r['request_sha256']==args.request_sha256 and r['status']=='REVIEWED','timing request authority')
    from mechanism_bootstrap_v1 import BASE
    root=Path(q['attempt_root']);need(root==BASE/'native_attempt1' and root.resolve()==root and root.is_dir(),'parent-created mechanism attempt')
    t=Timeline(root);t.phase('BEFORE_BOOTSTRAP');return t

class ParentBroker:
    def __init__(self,root,q,args,dispatch_ref,core,lease):
        main_thread();self.owner_thread=threading.get_ident();self.owner_pid=os.getpid()
        self.root=Path(root);self.folder=self.root/'app_boundary_v4';self.folder.mkdir(exist_ok=False)
        self.context=context(q,args,dispatch_ref);self.core=core;self.lease=lease;self.issued=None
        need(q['resource']==core.LIMITS and q['freshness_seconds']==30 and q['max_wall_seconds']==1200,'unchanged freshness/resources/wall')
    def tick(self,tree,deadline):
        main_thread();need(os.getpid()==self.owner_pid and threading.get_ident()==self.owner_thread,'foreign parent/thread')
        if self.issued is not None:return
        if not (self.folder/'READY.COMMIT.json').exists():return
        need(time.monotonic()<deadline,'original guardian deadline before renewal')
        ready,ready_ref=get(self.folder,'READY')
        owner=identity(self.core.proc_identity(os.getpid()))
        need(ready['parent_identity']==owner,'READY parent identity')
        grant=issue_grant(self.context,ready,owned_child=lambda:exact_owned_root(tree,self.core),lease_check=self.lease.assert_held,
            probe_initial=lambda:self.core.probe_resources(tree,gpu=self.context['gpu_binding']['physical_index'],deadline=deadline),resource_failures=self.core.resource_failures,clock=clock)
        grant.update(ready_packet=ready_ref,guardian_deadline_monotonic_s=deadline,issuer_thread_id=self.owner_thread,issuer_is_main_thread=True)
        self.issued=put(self.folder,'GRANT',grant)
        write(self.folder/'PARENT_ISSUED.json',dict(schema='astra.pre_app.parent_issue.v4',issued=self.issued,observed_unix_s=time.time(),observed_monotonic_s=time.monotonic(),enrolled_identity_at_issue=grant['child_identity'],original_deadline=deadline))

class ChildGate:
    def __init__(self,q,args,dispatch,core,verify_parent,timeline,resource_observer):
        main_thread();self.owner_thread=threading.get_ident();self.q=q;self.args=args;self.dispatch=dispatch;self.core=core
        self.verify_parent=verify_parent;self.timeline=timeline;self.observer=resource_observer;self.proof=None
        self.context=context(q,args,dict(path=args.permit,sha256=args.permit_sha256));self.folder=Path(q['attempt_root'])/'app_boundary_v4'
        need(dispatch['request_sha256']==args.request_sha256 and dispatch['review_sha256']==args.review_sha256 and dispatch['gpu_binding']==q['gpu_binding'] and dispatch['freshness_protocol']=='OWNED_READY_PARENT_RENEWAL_APP_BOUNDARY_V4','new bound dispatch authority')
        need(q['resource']==core.LIMITS and q['freshness_seconds']==30 and q['max_wall_seconds']==1200,'unchanged child criteria')
    def create_app(self,launch):
        main_thread();need(threading.get_ident()==self.owner_thread,'foreign child thread')
        self.verify_parent(self.dispatch,self.core)
        self.timeline.phase('VALIDATION_AND_APP_CONFIG_COMPLETE')
        validation=dict(status='COMPLETE_VALIDATION_AND_APP_CONFIG_NO_APP',request=self.context['request'],review=self.context['review'],source_graph=self.context['source_graph'],actual_phase_refs=list(self.timeline.events))
        child=self.core.proc_identity(os.getpid());parent=self.core.proc_identity(os.getppid())
        ready=make_ready(self.context,child,parent,validation,*clock());ready_ref=put(self.folder,'READY',ready)
        # This wait and every prior source/config step are under the new1200 guardian.
        deadline=self.dispatch['dispatch_monotonic_s']+1200
        while not (self.folder/'GRANT.COMMIT.json').exists():
            need(time.monotonic()<deadline,'original child dispatch deadline');self.verify_parent(self.dispatch,self.core);time.sleep(.05)
        grant,grant_ref=get(self.folder,'GRANT')
        need(grant['ready_packet']['body']==ready_ref['body'] and grant['ready_packet']['commit']==ready_ref['commit'],'same-owned READY nonce/hash')
        need(time.monotonic()<grant['guardian_deadline_monotonic_s'],'original guardian deadline before App')
        def persist(evidence):return put(self.folder,'PRECONSUMPTION',dict(evidence,ready_packet=ready_ref,grant_packet=grant_ref))
        def invoke(proof):
            need(time.monotonic()<grant['guardian_deadline_monotonic_s'],'original guardian deadline at constructor')
            # RAM only after final freshness check. Durable copy is in ENTRY.
            self.proof=dict(status='PRELAUNCH_BINDING_CHECKED_NOT_NATIVE_PASS',request_sha256=self.args.request_sha256,permit_sha256=self.args.permit_sha256,
                gpu_binding=self.q['gpu_binding'],child_identity=child,fresh_prelaunch_observation=proof['evidence']['child_observation'],
                checked_unix_s=proof['consumed_unix_s'],boundary_v4=proof,ready_packet=ready_ref,grant_packet=grant_ref)
            return launch()
        value,_=consume_at_app_boundary(self.context,ready,grant,current_child=lambda:self.core.proc_identity(os.getpid()),verify_live_parent=lambda p:self.verify_parent(p,self.core),
            probe_initial=lambda:self.observer.observe_resources(dict(gpu_index=self.q['gpu_binding']['physical_index'])),resource_failures=self.core.resource_failures,
            persist_evidence=persist,clock=clock,launch=invoke)
        return value

def verify_closed_boundary(entry,q,request_sha,root,wait,core):
    """Replay persisted timestamps; never reapply a current-time gate post-App."""
    p=entry['pre_app_proof_v4'];v=p['boundary_v4'];g,gr=get(Path(root)/'app_boundary_v4','GRANT');ready,rr=get(Path(root)/'app_boundary_v4','READY')
    need(p['request_sha256']==request_sha and p['gpu_binding']==q['gpu_binding'] and p['ready_packet']['body']==rr['body'] and p['grant_packet']['body']==gr['body'],'closed App proof binding')
    need(v['evidence']['grant']==g and g['ready_digest']==digest(ready) and g['request']['sha256']==request_sha and g['source_graph']==q['pre_app_freshness_graph'],'closed exact grant')
    own=next(x for x in wait['owned_identities'] if x['pid']==wait['child_pid'])
    need(identity(own)==g['child_identity']==identity(p['child_identity']) and g['parent_identity']['pid']==own['ppid'] and g['issuer_is_main_thread'] is True,'actual native root grant ownership')
    context_digest=g['context_digest'];need(context_digest==ready['context_digest'] and v['evidence']['ready_digest']==digest(ready),'actual ready nonce')
    pre,pre_ref=get(Path(root)/'app_boundary_v4','PRECONSUMPTION')
    need(v['persisted_evidence']['body']==pre_ref['body'] and pre['grant']==g and pre['child_observation']==v['evidence']['child_observation'],'durable sampled evidence')
    for name,start,end in [('parent wall',g['sample_started_unix_s'],v['consumed_unix_s']),('parent mono',g['sample_started_monotonic_s'],v['consumed_monotonic_s']),('child wall',v['evidence']['child_sample_started_unix_s'],v['consumed_unix_s']),('child mono',v['evidence']['child_sample_started_monotonic_s'],v['consumed_monotonic_s'])]:fresh(start,end,name)
    need(v['consumed_monotonic_s']<g['guardian_deadline_monotonic_s'],'consumption before original native deadline')
    for sample in (g['parent_observation'],v['evidence']['child_observation']):
        need(sample['gpu_index']==q['gpu_binding']['physical_index'] and sample['gpu_uuid']==q['gpu_binding']['physical_uuid'],'physical resource sample')
        failures=core.resource_failures(sample,q['resource'],initial=True,nas_floor=q['min_NAS_free_bytes'])
        need(not failures and sample['SSD_free_bytes']>=q['resource']['min_SSD_free_bytes']+q['SSD_operational_reserve_bytes'],'closed original resource criteria')
    need(entry['pre_app_phase_refs'] and ready['validation_receipt']['actual_phase_refs'],'actual timing evidence')
    for r in entry['pre_app_phase_refs']:read_ref(r)
    return dict(status='CLOSED_FRESH_GATE_EVIDENCE_ONLY',grant=gr,ready=rr,consumption_unix_s=v['consumed_unix_s'],native_or_safety_pass=False)
