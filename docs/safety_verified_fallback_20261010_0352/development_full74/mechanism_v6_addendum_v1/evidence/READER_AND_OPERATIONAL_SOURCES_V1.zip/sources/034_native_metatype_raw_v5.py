"""Bounded metadata observation, persisted before any parent-map interpretation.

Missing roots/keys and unfamiliar SDK types are evidence, never inferred data.
No native setter, App launch, physics step, rendering, or sampling.
"""
from collections.abc import Mapping
import math
import numpy as np
from frame_schema_v4 import ARMS,need,metatype_parent_indices
from types import SimpleNamespace

FIELDS=('link_count','joint_count','dof_count','link_names','link_parents',
        'joint_names','dof_names','link_indices','link_parent_indices',
        'joint_indices','dof_indices','joint_types','joint_dof_offsets',
        'joint_dof_counts','dof_types','fixed_base')
def typename(v):return type(v).__module__+'.'+type(v).__qualname__
def encoded(v,depth=0):
    if depth>8:return {'uninterpreted_type':typename(v),'reason':'depth limit'}
    if v is None or type(v) in (bool,int):return v
    if type(v) is str:
        return v if len(v)<=4096 else {'uninterpreted_type':typename(v),'reason':'string limit','prefix':v[:4096],'length':len(v)}
    if isinstance(v,(float,np.floating)):
        return float(v) if math.isfinite(v) else {'nonfinite_float':str(v)}
    if isinstance(v,np.integer):return {'numpy_integer':int(v),'dtype':str(v.dtype)}
    if isinstance(v,np.bool_):return {'numpy_bool':bool(v)}
    if isinstance(v,Mapping):
        if len(v)>4096:return {'uninterpreted_type':typename(v),'reason':'mapping limit','length':len(v)}
        return {'mapping_entries':[[encoded(k,depth+1),encoded(x,depth+1)] for k,x in v.items()]}
    if isinstance(v,(list,tuple,np.ndarray)):
        if len(v)>4096:return {'uninterpreted_type':typename(v),'reason':'sequence limit','length':len(v)}
        return [encoded(x,depth+1) for x in v]
    return {'uninterpreted_type':typename(v),'reason':'unsupported value type','repr':repr(v)[:4096]}
def property_record(obj,name):
    try:
        v=getattr(obj,name)
    except Exception as exc:return dict(python_type=None,is_mapping=None,value=None,error=type(exc).__name__+': '+str(exc)[:4096])
    record=dict(python_type=typename(v),is_mapping=isinstance(v,Mapping),value=None,error=None)
    try:record['value']=encoded(v)
    except Exception as exc:
        record.update(value={'uninterpreted_type':typename(v),'repr':repr(v)[:4096]},error=type(exc).__name__+': '+str(exc)[:4096])
    return record
def capture_metatypes(env,guard):
    lanes=[]
    for lane in range(32):
        guard();arms={}
        for arm in ARMS:
            try:
                art=env._arms[arm];meta=art.root_physx_view.get_metatype(lane)
                arms[arm]=dict(metatype_python_type=typename(meta),properties={k:property_record(meta,k) for k in FIELDS},error=None)
            except Exception as exc:arms[arm]=dict(error=type(exc).__name__+': '+str(exc)[:4096])
        lanes.append(dict(lane=lane,arms=arms))
    # No mapping/key/root/value interpretation or equality assertion here.
    return dict(schema='astra.full74.raw_native_metatype.v5',synthetic=False,
                capture_stage='BEFORE_EXPERIMENT_STATE_WRITE',lanes=lanes,
                bounded_values=True,interpretation='NOT_YET_ATTEMPTED')
def decoded(v):
    if v is None or type(v) in (str,bool,int,float):return v
    if type(v) is list:return [decoded(x) for x in v]
    need(type(v) is dict,'unsupported encoded native metadata')
    if set(v)=={'mapping_entries'}:
        pairs=[[decoded(k),decoded(x)] for k,x in v['mapping_entries']]
        d=dict(pairs);need(len(d)==len(pairs),'duplicate decoded map keys');return d
    if set(v)=={'numpy_integer','dtype'}:return np.asarray(v['numpy_integer'],dtype=v['dtype'])[()]
    if set(v)=={'numpy_bool'}:return np.bool_(v['numpy_bool'])
    raise ValueError('bounded/unsupported native metadata cannot form a model: '+str(v)[:256])
def property_value(record,name):
    prop=record['properties'][name];need(prop['error'] is None,'SDK property read failed '+name)
    return decoded(prop['value'])
def project_registry(raw_registry,raw_metatypes):
    """Strict V4 model contract. This runs ONLY after both raw JSON files exist."""
    import copy
    result=copy.deepcopy(raw_registry)
    need(not result['capture_errors'],'raw USD registry capture incomplete')
    for lane,meta_lane in zip(result['lanes'],raw_metatypes['lanes']):
        need(lane['lane']==meta_lane['lane'],'ordered matching raw32 lanes')
        for arm in ARMS:
            a=lane['arms'][arm];record=meta_lane['arms'][arm];need(record['error'] is None,'SDK metatype read failure')
            names=property_value(record,'link_names');dofs=property_value(record,'dof_names')
            need(names==a['body_names'] and dofs==a['joint_names'],'native metatype/body/DOF registered identity')
            prop=record['properties']['link_parent_indices']
            need(prop['is_mapping'] is True,'SDK parent mapping type unsupported')
            mapping=property_value(record,'link_parent_indices')
            # Unchanged strict kernel: root omission stays MODEL_NOT_READY.
            # Do NOT manufacture -1 or infer parents from names/USD endpoints.
            a['link_parent_indices']=metatype_parent_indices(SimpleNamespace(link_names=names,link_parent_indices=mapping))
            a['fixed_base']=property_value(record,'fixed_base')
            a['native_metatype']=record['properties']
    need(len(result['lanes'])==len(raw_metatypes['lanes'])==32,'complete raw32 registry/metatype')
    return result
