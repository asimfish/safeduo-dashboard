"""Typed recorded-native inventory consistency; no inference of actual impulses."""
import numpy as np
import re
from runtime import require,exact,ARMS
ORDINARY={'PhysicsFixedJoint','PhysicsRevoluteJoint','PhysicsPrismaticJoint','PhysicsSphericalJoint','PhysicsDistanceJoint'}
STATE_API='PhysicsJointStateAPI:angular'
STATE_KEYS={'state:angular:physics:position','state:angular:physics:velocity'}
APIS={'PhysicsArticulationRootAPI','PhysxArticulationAPI','PhysicsDriveAPI','PhysxJointAPI','PhysicsLimitAPI','PhysxLimitAPI'}
def topology(row):
    a=row['attributes'];kind=row['type'];joint='Joint' in kind;c=row['classification'];value=a.get('physics:jointEnabled')
    require(c['joint_enabled']==value and c['active_state']==('ENABLED' if value is True else 'DISABLED' if value is False else 'UNKNOWN'),'independent joint enabled interpretation')
    require(c['deny_before_state_writes'] is False,'producer completed despite rejected topology')
    require(not any(any(w in str(n).lower() for w in ('mimic','tendon')) for n in (*a,*row['relationships'])),'hidden native mimic/tendon attribute or relationship')
    if joint:require(type(value) is bool,'explicit native joint enabled boolean')
    require(not any('Tendon' in s for s in row['schemas']),'tendon outside supported comparison')
    if value is not False:
        require(not ('Constraint' in kind) and (not joint or kind in ORDINARY),'unsupported active typed gear/rack/unknown joint')
        for s in row['schemas']:
            api=s.split(':')[0]
            require(not any(w in s.lower() for w in ('mimic','tendon')),'native mimic/tendon schema is outside frozen V6 hypothesis')
            if api=='PhysicsJointStateAPI':
                require(s==STATE_API and kind=='PhysicsRevoluteJoint','only exact angular state API on ordinary revolute')
                types=row.get('state_attribute_types')
                require(isinstance(types,dict) and set(types)==STATE_KEYS and all(v=='float' for v in types.values()),'two exact USD float state attributes')
                continue
            require(not any(w in s.lower() for w in ('gear','rack','coupling','constraint')),'unsupported active applied coupling')
            if api.startswith(('Physics','Physx')) and joint:require(api in APIS,'unsupported active physics API')
            if api=='PhysxMimicJointAPI':require(kind=='PhysicsRevoluteJoint','only explicitly supported affine revolute mimic')

def audit(before,after,params,layout):
    require(before==after,'actual inventory BEFORE/AFTER changed')
    require(before['schema']=='astra.native.constraint_inventory.v2' and before['stage_scope']=='LIVE_ALL32_TOPOLOGY_EQUAL_PLUS_ALL32_TENSOR_GETTERS' and before['instance_proxies_traversed'] is True and before['registry_policy']=='TYPED_JOINT_AND_APPLIED_COUPLING_EXPLICIT_SUPPORT_BEFORE_STATE_WRITES' and before['ordinary_joint_types']==sorted(ORDINARY),'live all32 recorded scope and corrected typed registry')
    lanes=before['normalized_all32_registry'];require(set(lanes)=={str(i) for i in range(32)} and lanes['0'],'all32 registry evidence')
    require(all(v==lanes['0'] for v in lanes.values()),'all32 normalized native schema identity')
    require(before['unsupported']==[],'unsupported native constraints cannot support completed projection')
    require(set(before['tendon_getters'])==set(before['drive_configuration'])==set(ARMS),'four arm inventory')
    for r in lanes['0']:
        require('/env_N/' in r['path'] and isinstance(r['schemas'],list),'normalized actual paths')
        topology(r)
    require(before['mimic_relations']==[],'no native mimic relation, URDF relations are separate')
    allnames=set(layout['names'].tolist());seen=set()
    for arm in ARMS:
        g=before['tendon_getters'][arm];d=before['drive_configuration'][arm];width=len(params[arm+'_native_joint_names'])
        require(type(g['fixed_count']) is type(g['spatial_count']) is int and g['fixed_count']==g['spatial_count']==0,'native tendon getter counts')
        require(len(g['prim_paths'])==len(g['dof_paths'])==32 and all(len(x)==width for x in g['dof_paths']),'all32 tensor actual DOF paths')
        require(d['joint_names']==params[arm+'_native_joint_names'].tolist() and d['passive_DOF_proven'] is False and d['actual_drive_torque']=='UNKNOWN','drive identity versus passive inference')
        for key,param in [('stiffness','stiffness'),('damping','damping'),('force_cap','max_force')]:
            a=np.asarray(d[key],np.float64);require(a.shape==(32,width) and np.isfinite(a).all(),'drive getter full dimensions')
            exact(a,params[arm+'_'+param].astype(np.float64),'native inventory '+key)
        k=np.asarray(d['stiffness']);v=np.asarray(d['damping']);f=np.asarray(d['force_cap'])
        require(d['no_PD_coefficients']==((k==0)&(v==0)).tolist() and d['zero_drive_cap']==(f==0).tolist(),'configuration summary, not passive torque evidence')
        for lane in range(32):
            require(f'/env_{lane}/' in g['prim_paths'][lane] and all(f'/env_{lane}/' in s for s in g['dof_paths'][lane]),'tensor lane identity')
        pathset=set(g['dof_paths'][0])
        for r in before['records']:
            if r['arm']!=arm:continue
            if r['joint_name'] not in allnames:continue # fixed joints retained, not independent DOFs
            require(r['joint_name'] not in seen and r['path'] in pathset,'live DOF registry names/path linkage')
            seen.add(r['joint_name'])
            normalized=r['path'].replace('/env_0/','/env_N/')
            items=[x for x in lanes['0'] if x['path']==normalized]
            require(len(items)==1 and items[0]['type']==r['type'] and items[0]['schemas']==r['schemas'],'live detail versus all32 topology')
            require(items[0]['schemas'].count(STATE_API)==1 and items[0]['type']=='PhysicsRevoluteJoint','all74 native DOFs have one ordinary angular state API')
            for name,val in items[0]['attributes'].items():require(r['attributes'].get(name)==val,'coupling getter detail')
            for name,val in items[0]['relationships'].items():require([re.sub(r'/env_\d+/', '/env_N/',s) for s in r['relationships'].get(name,[])]==val,'coupling reference topology')
    require(seen==allnames,'all74 native registry accounted')
    require(all(before[k]=='UNKNOWN' for k in ('compiled_mimic_impulses','passive_constraint_impulses')) and
        before['eDRIVE_LIMITS_ARE_FORCES']=='UNKNOWN_NO_NATIVE_FLAG_GETTER_BOUND','force/impulse flag and actual impulses remain UNKNOWN')
    return dict(actual_recorded_lanes=32,actual_recorded_DOFs=74,fixed_tendons=0,spatial_tendons=0,mimic_schema_count=len(before['mimic_relations']),
        before_after_equal=True,angular_state_APIs_per_lane=74,angular_state_types_per_lane=148,
        USD_state_attribute_values_finite='UNKNOWN_NOT_RETAINED_IN_V6_VALID_REGISTRY',native_q_qd_finiteness='AUDITED_SEPARATELY_IN_FROZEN_NUMERIC_KERNEL',model_ready=False,compiled_impulses='UNKNOWN',force_limit_interpretation='UNKNOWN',independent_USD_reopen=False)
