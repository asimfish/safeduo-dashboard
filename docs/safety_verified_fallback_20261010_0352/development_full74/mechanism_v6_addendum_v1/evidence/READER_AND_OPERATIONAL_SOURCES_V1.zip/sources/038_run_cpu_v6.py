"""Only the new classifier boundary and two actual CPU request CLI checks."""
import hashlib,json,sys,types
from pathlib import Path
HERE=Path(__file__).resolve().parent;H=HERE.parents[1]
path=H/'astra/full74_clock3_reader_operations_v1/common_v1.py';raw=path.read_bytes()
assert hashlib.sha256(raw).hexdigest()=='4f8f6f698e1e62c2ecea0c9177f05e6962d677d1b652eccfce44b9b2442e33ca'
c=types.ModuleType('_mechanism_stateapi_CPU_v6');c.__file__=str(path);exec(compile(raw,str(path),'exec'),c.__dict__);c.cpu_limits()
root=c.R/'astra_full74_independent_reader_v1/full74_native_constraint_mechanism_v6_stateapi'/c.name(sys.argv[1]);root.mkdir(parents=True,exist_ok=False)
graph=c.read(c.ref(HERE/'SOURCE_GRAPH_V4.json'));own=graph['own_source_delta'];evidence=c.read(c.ref(HERE/'STATE_API_EVIDENCE_V6.json'))
external={r['path']:r['sha256'] for key,r in evidence['refs'].items() if isinstance(r,dict) and set(r)=={'path','sha256'}}
inputs={str(p):c.sha(p) for p in [HERE/'REQUEST_DRAFT_V6.json',HERE/'CPU_DRAFT_BINDING_V6.json']}
before={p:c.sha(p) for p in {**own,**external,**inputs}};assert before=={**own,**external,**inputs}
request=HERE/'REQUEST_DRAFT_V6.json';review=HERE/'CPU_DRAFT_BINDING_V6.json'
jobs=[('baseline_red',1,[str(HERE/'test_stateapi_v6.py'),'--out',str(root/'baseline_artifacts'),'--baseline-red']),('stateapi_green',0,[str(HERE/'test_stateapi_v6.py'),'--out',str(root/'stateapi_artifacts')])]
for name in ('native_entry_v1.py','parent_harness_v1.py'):
    jobs.append((Path(name).stem,0,[str(HERE/name),'--request',str(request),'--request-sha256',c.sha(request),'--review',str(review),'--review-sha256',c.sha(review),'--check-cpu']))
waits=[];error=None
try:
    for name,expected,argv in jobs:
        out=root/name;env=c.environment(out)
        w=c.core().bounded_child([c.PY,'-B',*argv],env,out,backend='CPU_ONLY_MECHANISM_STATE_API_V6',max_wall=180,cpu_limit=True,monitor=None)
        waits.append(dict(name=name,expected_actual_exit=expected,wait=c.ref(out/'ACTUAL_WAIT.json')))
        c.closed_wait(w,expected,'astra.full74.owned_cpu_wait.v1','CPU_ONLY_MECHANISM_STATE_API_V6')
        if name=='baseline_red':
            r=c.read(c.ref(root/'baseline_artifacts/EXPECTED_RED_V6.json'))
            assert r['status']=='EXPECTED_RED_OLD_CLASSIFIER_REJECTS_OBSERVED_STATE_API74' and r['old_unsupported']==74 and r['actual_native_mimic']==0
except BaseException as exc:error=type(exc).__name__+':'+str(exc);raise
finally:
    after={p:c.sha(p) for p in before};unchanged=before==after
    reports=[c.ref(root/p) for p in ['baseline_artifacts/EXPECTED_RED_V6.json','stateapi_artifacts/CPU_STATE_API_REPORT_V6.json'] if (root/p).is_file()]
    c.write(root/'CPU_RELEASE_V6.json',dict(status='CLOSED_CPU_ONLY_FOR_DISTINCT_REVIEW' if error is None and unchanged and len(waits)==4 else 'FAILED_PRESERVED',source_graph=c.ref(HERE/'SOURCE_GRAPH_V4.json'),source_before=before,source_after=after,source_unchanged=unchanged,waits=waits,reports=reports,error=error,reused_CPU=evidence['refs']['old_CPU'],old_source_mapping_preserved=True,no_old500_byte_rescan=True,native_launches=0,actual_GPU_observations=0,actual_physics_steps=0,bank_count=0,safety_acceptance=False))
    assert unchanged
print(c.ref(root/'CPU_RELEASE_V6.json'),flush=True)
