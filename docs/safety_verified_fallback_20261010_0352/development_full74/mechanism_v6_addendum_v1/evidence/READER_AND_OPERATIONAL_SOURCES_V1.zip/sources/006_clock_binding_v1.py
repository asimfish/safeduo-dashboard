"""Independent clock sidecar inventory; exact native rows, no producer code import."""
from runtime import *
import numpy as np
from clock_reader_v1 import audit

SDK=Path('/home/liyufeng/miniforge3/envs/safeduo/lib/python3.11/site-packages/isaacsim/exts')
PATHS=[SDK/'isaacsim.core.api/isaacsim/core/api/simulation_context/simulation_context.py',
       SDK/'isaacsim.core.api/isaacsim/core/api/physics_context/physics_context.py',
       SDK/'isaacsim.core.simulation_manager/isaacsim/core/simulation_manager/impl/simulation_manager.py']

def clock_fields(e,root,f):
    graph=e.js(HERE.parent/'PACKAGE_SOURCE_GRAPH_V1.json')['files']
    source={str(p):graph[str(p)] for p in PATHS};e.verify(source)
    folder=root/'clock';initial=e.js(folder/'INITIAL.json');final=e.js(folder/'FINAL.json')
    events=e.js(folder/'ALL_CALLBACKS.json');snapshots=[initial];expected={'INITIAL.json','FINAL.json','ALL_CALLBACKS.json'}
    require(f['micro'].shape==(13,) and f['simulation_time_s'].dtype==np.dtype('float64') and
        f['simulation_step'].dtype==np.dtype('int64'),'actual13 typed native clock rows')
    for i in range(1,13):
        names=[f'BEFORE_{i:03d}.json',f'AFTER_{i:03d}.json',f'CALLBACKS_{i:03d}.json'];expected.update(names)
        before,after,callback=[e.js(folder/n) for n in names]
        require(before==snapshots[-1],'BEFORE state exactly last native snapshot; no hidden camera steps')
        require(callback==events[:i] and len(callback)==i,'all cumulative raw callback records exact')
        snapshots.append(after)
    require(final==snapshots[-1],'AFTER final cameras equals last native clock')
    require({p.name for p in folder.iterdir() if p.is_file()}==expected,'complete clock artifacts with no omissions')
    result=audit(snapshots,events,f['simulation_step'],f['simulation_time_s'],source)
    result['actual_dt_before_s']=initial['actual_dt_s'];result['actual_dt_after_s']=final['actual_dt_s']
    result['raw_clock_callback_steps_s']=[r['step_size'] for r in events]
    result['source_files']=source;return result
