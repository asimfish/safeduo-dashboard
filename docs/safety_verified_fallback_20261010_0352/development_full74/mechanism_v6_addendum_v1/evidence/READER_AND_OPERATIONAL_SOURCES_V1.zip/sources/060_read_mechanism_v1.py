"""Parent-authorized closed raw audit. CPU template check never accesses native data."""
import argparse,datetime,traceback
from runtime import *

def main():
    p=argparse.ArgumentParser(allow_abbrev=False)
    g=p.add_mutually_exclusive_group(required=True);g.add_argument('--check-cpu',action='store_true');g.add_argument('--audit-closed',action='store_true')
    p.add_argument('--binding');p.add_argument('--binding-sha256');p.add_argument('--out');args=p.parse_args()
    sources()
    if args.check_cpu:
        require(not any((args.binding,args.binding_sha256,args.out)),'CPU check does not take actual evidence')
        from binding import MECH_GRAPH
        from data import audit
        print(json.dumps(dict(status='CPU_SOURCE_IMPORT_ONLY_NOT_RAW_AUDIT',producer_graph=MECH_GRAPH,native_launches=0,actual_raw_reads=0)),flush=True);return 0
    require(args.binding and args.binding_sha256 and args.out,'exact actual binding and new output required')
    out=contained(args.out,OUTPUT);require(not out.exists(),'new independent output only');out.mkdir(parents=True,exist_ok=False)
    e=Evidence();report=dict(schema='astra.constraint.mechanism.independent_raw.v6',status='FAILED_INDEPENDENT_DATA_AUDIT',errors=[],
        native_pass=False,bank_count=0,eligibility=False,safety_acceptance=False,task_acceptance=False,camera='NOT_TESTED_DIAGNOSTIC_ONLY',
        CONTACT='UNKNOWN',ACTUAL_DRIVE_TORQUE='UNKNOWN',PASSIVE_CONSTRAINT_IMPULSE='UNKNOWN',TERMINAL_SET='UNKNOWN',certified_error_bound=False,
        expected_denominators=dict(latent_proposals=16,proposal_ids=list(range(92,108)),AB_lanes=32,states_per_lane=13,physics_steps=12,registered_temporal_rows=416,sentinel_proposals=4,prospective_proposals=12),
        failed_or_nonconstructible_cases_retained=True,frame_model_ready=False,frame_status='MODEL_NOT_READY_NOT_PROMOTED_BY_THIS_READER',
        USD_state_attribute_value_finiteness='UNKNOWN_NOT_RETAINED_BY_PRODUCER_V6',
        actual_raw_input_binding=dict(path=args.binding,sha256=args.binding_sha256),source_graph=dict(path=str(PACKAGE/'PACKAGE_SOURCE_GRAPH_V1.json'),sha256=sha(PACKAGE/'PACKAGE_SOURCE_GRAPH_V1.json')))
    code=2
    with (out/'PHASES.jsonl').open('x') as log:
        def phase(name):
            row=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),pid=os.getpid(),phase=name)
            log.write(json.dumps(row)+'\n');log.flush();os.fsync(log.fileno());print(name,flush=True)
        try:
            from binding import closure
            from data import audit
            from waits import absent
            phase('actual parent/native closure, source authority, READY/GRANT and recorded GPU')
            c=closure(e,args.binding,args.binding_sha256)
            report['closure']=dict(native_wait=c['bind']['native_wait'],parent_wait=c['bind']['parent_wait'],parent_scope=c['parent_scope'],fresh=c['fresh'],actual_gpu=c['gpu'])
            report['data']=audit(e,c,phase)
            for item in c['wait']['owned_identities']:absent(item)
            absent(c['parent']['parent_identity'])
            phase('recheck consumed evidence SHA')
            e.recheck();report['status']='CLOSED_VALID_MECHANISM_DIAGNOSTIC_DATA';code=0
        except BaseException as exc:
            report['errors'].append(dict(type=type(exc).__name__,message=str(exc),traceback=traceback.format_exc()))
            # Reuse only already-read closed documents, not live/preallocated arrays.
            observed={}
            for path in e.ledger:
                name=Path(path).name
                if name in ('ACTUAL_WAIT.json','PARENT_RECEIPT_V4.json','ENTRY_RECEIPT_V4.json','MECHANISM_RECEIPT_V1.json'):
                    try:
                        doc=e.js(path)
                        observed[path]={k:doc[k] for k in ('schema','status','actual_wait_exit','raw_wait_status','resource_abort','error','signals','actual_micro_ids','physics_steps','registered_cases','measurement_bytes_verified') if k in doc}
                    except BaseException as err:
                        report['errors'].append(dict(type=type(err).__name__,message='failure receipt reread: '+str(err)))
            report['observed_closed_failure_documents']=observed
        finally:
            try:e.recheck()
            except BaseException as err:
                report['errors'].append(dict(type=type(err).__name__,message='final evidence recheck: '+str(err)));code=2;report['status']='FAILED_INDEPENDENT_DATA_AUDIT'
            report['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
            report['input_files_sha256']={p:r['sha256'] for p,r in e.ledger.items()}
            report['CPU_actual_wait']='REQUIRED_SEPARATE_REAL_GUARDIAN_RECEIPT_NOT_THIS_REPORT'
            write_new(out/'INDEPENDENT_MECHANISM_RAW_V1.json',report)
    print(report['status'],flush=True);return code
if __name__=='__main__':raise SystemExit(main())
