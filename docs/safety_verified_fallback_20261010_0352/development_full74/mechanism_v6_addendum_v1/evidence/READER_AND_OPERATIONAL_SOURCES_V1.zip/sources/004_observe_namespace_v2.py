"""Exact fork/handshake/wait4 observer; native harness remains the sole guardian."""
import argparse,datetime as dt,hashlib,json,os,resource,select,sys,time
from pathlib import Path
H=Path('/home/liyufeng/safeduo/artifacts/safety_verified_fallback_20261010_0352')
R=Path('/mnt/nas/data/lyf/double_hand/safety_verified_fallback_20261010_0352')
BASE=R/'parent_full74_admissible_pilot_v1'
WRAPPER=H/'astra/full74_admissible_pilot_namespace_v2/parent_wrapper_v2.py'
WRAPPER_SHA='ebaad43f0fb63e0418d678e60a73067a9b2fc14de209cd1e5067fdcb171221c9'
def need(v,why):
    if not v:raise ValueError(why)
def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda:f.read(1024**2),b''):h.update(b)
    return h.hexdigest()
def ref(p):return dict(path=str(p),sha256=sha(p))
def utc():return dt.datetime.now(dt.timezone.utc).isoformat()
def write(p,d):
    with p.open('x') as f:json.dump(d,f,indent=2,allow_nan=False);f.write('\n');f.flush();os.fsync(f.fileno())
def identity(pid):
    raw=Path('/proc',str(pid),'stat').read_text();fields=raw.rsplit(')',1)[1].split()
    return dict(pid=pid,ppid=int(fields[1]),pgid=int(fields[2]),sid=int(fields[3]),startticks=int(fields[19]),state=fields[0])
def same_live(i):
    try:return identity(i['pid'])['startticks']==i['startticks']
    except FileNotFoundError:return False
def observe(argv,root):
    root.mkdir(parents=True,exist_ok=False)
    started=utc();begin=time.monotonic();rr,rw=os.pipe();gr,gw=os.pipe()
    pid=None;raw=None;waited=None;usage=None;own=None;error=None
    with (root/'child.log').open('xb') as log,(root/'resources.jsonl').open('x') as events:
        def event(d):events.write(json.dumps(d,allow_nan=False)+'\n');events.flush();os.fsync(events.fileno())
        try:
            pid=os.fork()
            if pid==0:
                try:
                    os.close(rr);os.close(gw);os.setsid();resource.setrlimit(resource.RLIMIT_CORE,(0,0))
                    os.dup2(log.fileno(),1);os.dup2(log.fileno(),2)
                    os.write(rw,b'R');os.close(rw)
                    need(os.read(gr,1)==b'G','exact parent release');os.close(gr)
                    os.execve(argv[0],argv,os.environ.copy())
                except BaseException:
                    import traceback;traceback.print_exc();os._exit(127)
            os.close(rw);rw=None;os.close(gr);gr=None
            need(select.select([rr],[],[],5)[0] and os.read(rr,1)==b'R','direct handshake')
            own=identity(pid);need(own['ppid']==os.getpid() and own['pgid']==own['sid']==pid,'fork identity')
            own['enrollment']=dict(kind='direct_fork_handshake',parent_pid=os.getpid())
            event(dict(event='OWNED_ENROLLED',identities=[dict(own,live=True)],argv=argv,utc=utc()))
            write(root/'STARTED_V1.json',dict(child_identity=own,argv=argv,started_utc=started,actual_exit_not_yet_observed=True))
            os.write(gw,b'G')
        except BaseException as exc:error=type(exc).__name__+': '+str(exc)
        finally:
            # EOF makes a child awaiting a failed handshake exit127. Always wait our exact root.
            if gw is not None:os.close(gw);gw=None
            if pid is not None:
                while raw is None:
                    got,status,u=os.wait4(pid,os.WNOHANG)
                    if got:waited,raw,usage=got,status,u
                    else:time.sleep(.25)
            for fd in (rr,rw,gr,gw):
                if fd is not None:os.close(fd)
            identities=[dict(own,live=same_live(own))] if own else []
            event(dict(event='ACTUAL_WAIT',child_pid=pid,waited_pid=waited,raw_wait_status=raw,actual_wait_exit=os.waitstatus_to_exitcode(raw) if raw is not None else None,identities=identities,resource_abort=None,signals=[]))
            log.flush();os.fsync(log.fileno())
    wait=dict(schema='astra.full74.owned_cpu_wait.v1',backend='EXTERNAL_WRAPPER_OBSERVER_NOT_NATIVE_OR_CPU_ONLY_WORKLOAD',child_pid=pid,waited_pid=waited,waitpid_observed=raw is not None,
        raw_wait_status=raw,actual_wait_exit=os.waitstatus_to_exitcode(raw) if raw is not None else None,wait_mechanism='os.wait4(owned_pid, WNOHANG)',started_utc=started,closed_utc=utc(),
        elapsed_seconds=time.monotonic()-begin,resource_abort=None,error=error,owned_identities=identities,signals=[],child_max_rss_KiB=usage.ru_maxrss if usage else None,
        log=str(root/'child.log'),log_sha256=sha(root/'child.log'),outer_monitor=str(root/'resources.jsonl'),outer_monitor_sha256=sha(root/'resources.jsonl'),argv=argv,
        observer_scope='DIRECT_WRAPPER_ROOT_ONLY; native exact ownership/deadline/resources belong to reviewed harness',native_acceptance=False)
    write(root/'ACTUAL_WAIT.json',wait);return wait
def main():
    p=argparse.ArgumentParser(allow_abbrev=False);p.add_argument('--self-check',action='store_true');p.add_argument('--bundle');p.add_argument('--bundle-sha256');p.add_argument('--execution-name',required=True);a=p.parse_args()
    need(sys.dont_write_bytecode and all(os.environ.get(k)=='1' for k in ('PYTHONDONTWRITEBYTECODE','OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS')),'-B threads1')
    need(a.execution_name.replace('_','').isalnum(),'new execution name')
    root=BASE/'executions'/a.execution_name
    if a.self_check:
        need(os.environ.get('CUDA_VISIBLE_DEVICES')=='','CPU only');resource.setrlimit(resource.RLIMIT_AS,(1024**3,1024**3));root.mkdir(parents=True,exist_ok=False)
        checks=[]
        for code in (0,1):
            w=observe([sys.executable,'-B','-c',f'raise SystemExit({code})'],root/f'case_{code}')
            need(w['waitpid_observed'] and w['actual_wait_exit']==code and w['raw_wait_status']==code*256 and not w['error'] and len(w['owned_identities'])==1 and w['owned_identities'][0]['live'] is False,'actual exact wait selfcheck')
            checks.append(ref(root/f'case_{code}/ACTUAL_WAIT.json'))
        original_write=globals()['write']
        def fail_started(path,value):
            if path.name=='STARTED_V1.json':raise OSError('INJECTED_POST_FORK_START_WRITE_FAILURE')
            return original_write(path,value)
        globals()['write']=fail_started
        try:w=observe([sys.executable,'-B','-c','raise SystemExit(0)'],root/'case_start_failure')
        finally:globals()['write']=original_write
        need(w['waitpid_observed'] and w['actual_wait_exit']==127 and w['raw_wait_status']==127*256 and 'INJECTED_POST_FORK' in w['error'] and w['owned_identities'][0]['live'] is False,'post-fork exception exact child reaped')
        checks.append(ref(root/'case_start_failure/ACTUAL_WAIT.json'))
        write(root/'CPU_CHECK_V1.json',dict(status='PASS',checks=checks,GPU_started=False,signals_sent=[]));print(json.dumps(ref(root/'CPU_CHECK_V1.json')));return 0
    need(resource.getrlimit(resource.RLIMIT_AS)[1]==resource.RLIM_INFINITY,'unlimited native inheritance')
    need(sha(WRAPPER)==WRAPPER_SHA and a.bundle and sha(a.bundle)==a.bundle_sha256,'exact reviewed wrapper/bundle')
    bundle=json.loads(Path(a.bundle).read_bytes());need(bundle['status']=='PARENT_FROZEN_FIXED128','frozen fixed128')
    argv=[sys.executable,'-B',str(WRAPPER),'--run-reviewed','--bundle',a.bundle,'--bundle-sha256',a.bundle_sha256]
    w=observe(argv,root);owned_closed=bool(w['owned_identities']) and not any(x['live'] for x in w['owned_identities'])
    native_waits=[];missing=[]
    for item in bundle['requests']:
        q=json.loads(Path(item['request']['path']).read_bytes());attempt=Path(q['attempt_root']);np=attempt/'native_process/ACTUAL_WAIT.json'
        if np.exists():
            n=json.loads(np.read_bytes());native_waits.append(ref(np));owned_closed=owned_closed and n['waitpid_observed'] and all(x['live'] is False and not same_live(x) for x in n['owned_identities'])
        elif attempt.exists():
            # A missing finally receipt cannot prove that no native child launched.
            prpath=attempt/'PARENT_RECEIPT_V4.json'
            pr=json.loads(prpath.read_bytes()) if prpath.exists() else {}
            if pr.get('native_launched') is not False:missing.append(str(attempt));owned_closed=False
        cp=attempt/'cpu_check'
        if cp.exists():
            cw=cp/'ACTUAL_WAIT.json'
            if not cw.exists():missing.append(str(cp));owned_closed=False
            else:
                c=json.loads(cw.read_bytes());owned_closed=owned_closed and c['waitpid_observed'] and bool(c['owned_identities']) and all(x['live'] is False and not same_live(x) for x in c['owned_identities'])
    ex=dict(wait=ref(root/'ACTUAL_WAIT.json'),actual_exit=w['actual_wait_exit'],all_owned_reaped=bool(owned_closed),pid=w['child_pid'],argv=argv,log_sha256=w['log_sha256'],native_waits=native_waits,missing_launched_native_waits=missing,native_acceptance=False)
    write(root/'OUTER_EXECUTION_V1.json',ex);print(json.dumps(dict(actual_exit=w['actual_wait_exit'],all_owned_reaped=owned_closed,execution=ref(root/'OUTER_EXECUTION_V1.json'))),flush=True)
    return w['actual_wait_exit'] if w['actual_wait_exit']>=0 else 128-w['actual_wait_exit']
if __name__=='__main__':raise SystemExit(main())
