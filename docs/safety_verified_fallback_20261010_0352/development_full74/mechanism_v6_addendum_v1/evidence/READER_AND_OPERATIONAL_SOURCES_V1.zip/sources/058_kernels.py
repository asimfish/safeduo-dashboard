"""Exact AST reuse of closed independent kernels, no new numerical thresholds."""
from runtime import *
import numpy as np
from science import parameters_layout,flags,REASONS
from root_restore_reader import evaluate,verify_report,validate_protocol
numeric=H/'astra/full74_compound_reader_operations_v3/reader/numeric.py'
globals().update(functions(numeric,['lane_bits','timeline','fields','roots'],globals()))
original=H/'astra/full74_independent_reader_v1/release_v9/reader.py'
globals().update(functions(original,['contact_identity','contacts','geometry_evidence'],globals()))
