"""CPU-only primitives. Import does not launch, freeze, query GPU or signal.

Authority is a reviewed, SHA-bound parent plan plus actual predecessor receipts.
Process ownership comes only from our fork handshake or observed parent ancestry,
with pidfd/startticks/session provenance. Same PGID alone never grants ownership.
"""
from __future__ import annotations
import csv
import datetime
import hashlib
import json
import os
from pathlib import Path
import resource
import select
import signal
import subprocess
import time
from pidfd_compat_v1 import open_pidfd, send_pidfd_signal

H = Path('/home/liyufeng/safeduo/artifacts/safety_verified_fallback_20261010_0352')
R = Path('/mnt/nas/data/lyf/double_hand/safety_verified_fallback_20261010_0352')
D = H / 'astra/full74_screen'
OWN = Path(__file__).resolve().parent
PY = '/home/liyufeng/miniforge3/envs/safeduo/bin/python'
COMPLETE_STAGE = 'COMPLETE_FULL128_METHOD_WINDOWS_ONLY_INDEPENDENT_AND_TASK_AUDITS_REQUIRED'
FULL_PLAN_SHA = '3df1883af605b04a1c87c9b34523bee2368ed9ace74a3340c53293de16100edb'
LIMITS = dict(min_initial_free_MiB=11000, max_owned_process_MiB=12500,
    min_runtime_free_MiB=2500, min_initial_host_available_MiB=35000,
    min_runtime_host_available_MiB=12000, max_owned_host_RSS_MiB=46000,
    min_SSD_free_bytes=16106127360)


def require(ok, why):
    if not ok:
        raise ValueError(why)


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def unique_pairs(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, 'duplicate JSON key: ' + key)
        result[key] = value
    return result


def read(path):
    path = Path(path)
    require(path.is_file() and path.stat().st_size <= 128 * 1024**2, 'missing/oversize JSON: ' + str(path))
    return json.loads(path.read_text(), object_pairs_hook=unique_pairs)


def write_new(path, value):
    with Path(path).open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n'); stream.flush(); os.fsync(stream.fileno())


def verify(files):
    for path, digest in files.items():
        require(sha(path) == digest, 'source/input SHA changed: ' + str(path))


class Pending(Exception):
    pass


def prerequisite_gate(base=H):
    """No liveness inference or signals. Require the actual closed receipt chain."""
    paths = {name: base / name for name in ['QUEUE74_FULL_CONTINUATION_STATE_V1.json',
        'queue74_full_continuation_v1_execution.json', 'queue74_full_supervisor_v3_execution.json',
        'queue74_full_v3_execution.json', 'QUEUE74_FULL_PLAN_V3.json']}
    state_path = paths['QUEUE74_FULL_CONTINUATION_STATE_V1.json']
    if state_path.exists():
        state = read(state_path)
        require(state.get('stage') != 'FAILED_PRESERVED', 'predecessor failed; no screen')
    else:
        raise Pending('predecessor state absent')
    for tag in ['queue74_full_continuation_v1', 'queue74_full_supervisor_v3']:
        path = paths[tag + '_execution.json']
        if path.exists():
            receipt = read(path)
            require(type(receipt.get('actual_exit')) is int and receipt['actual_exit'] == 0,
                    'predecessor actual wait nonzero/unknown: ' + tag)
    if state.get('stage') != COMPLETE_STAGE or not all(p.exists() for p in paths.values()):
        raise Pending('entire four-method campaign and both actual wait0 receipts required')
    snapshots = {str(p): sha(p) for p in paths.values()}
    plan = read(paths['QUEUE74_FULL_PLAN_V3.json'])
    require(sha(paths['QUEUE74_FULL_PLAN_V3.json']) == FULL_PLAN_SHA, 'full plan changed')
    require(state['plan_sha256'] == FULL_PLAN_SHA and state['wrapper_actual_exit'] == 0,
            'continuation plan/wait binding')
    require((state['new_full_method_windows'], state['controls'], state['microsteps']) == (128, 480, 960), 'full campaign denominator')
    expected_argv = {
        'queue74_full_continuation_v1': [PY, '-B', str(H / 'continue_queue74_full_v1.py')],
        'queue74_full_supervisor_v3': [PY, '-B', str(H / 'execute_queue_plan_v4.py'), str(H / 'QUEUE74_FULL_PLAN_V3.json')]}
    closed_times = {}
    for tag, argv in expected_argv.items():
        receipt = read(paths[tag + '_execution.json'])
        require(receipt['tag'] == tag and receipt['argv'] == argv and type(receipt['pid']) is int and receipt['pid'] > 0, 'predecessor identity/argv')
        started = datetime.datetime.fromisoformat(receipt['started_utc'])
        ended = datetime.datetime.fromisoformat(receipt['closed_utc'])
        require(ended >= started, 'predecessor time order')
        closed_times[tag] = ended
        log = base / (tag + '.log')
        require(sha(log) == receipt['log_sha256'], 'predecessor log SHA')
        snapshots[str(log)] = receipt['log_sha256']
    require(closed_times['queue74_full_continuation_v1'] >= closed_times['queue74_full_supervisor_v3'], 'continuation closed before supervisor')
    execution = read(paths['queue74_full_v3_execution.json'])
    require(execution['status'] == 'complete' and execution['plan_sha256'] == FULL_PLAN_SHA, 'four-method execution not complete')
    require(len(plan['jobs']) == len(execution['jobs']) == 4, 'four method jobs required')
    for expected, actual in zip(plan['jobs'], execution['jobs']):
        require(actual['id'] == expected['id'] and actual['argv'] == expected['argv'] and actual['out'] == expected['out'], 'method job identity/order')
        require(actual['status'] == 'complete' and type(actual['actual_exit']) is int and actual['actual_exit'] == 0 and actual['resource_abort'] is None, 'method nonzero/abort/incomplete')
        log = base / ('queue74_full_v3_' + actual['id'] + '.log')
        require(sha(log) == actual['log_sha256'], 'method log SHA')
        snapshots[str(log)] = actual['log_sha256']
    verify(snapshots)
    return dict(status='FOUR_METHOD_ACTUAL_TERMINATION_RECEIPTS_VERIFIED', observed_utc=utc(),
        files=snapshots, stage=COMPLETE_STAGE, method_count=4, independent_or_task_audit_pass_claimed=False)


def proc_identity(pid):
    raw = Path(f'/proc/{pid}/stat').read_text()
    fields = raw[raw.rfind(')') + 1:].split()
    require(int(raw[:raw.find('(')].strip()) == pid, 'proc PID mismatch')
    return dict(pid=pid, ppid=int(fields[1]), pgid=int(fields[2]), sid=int(fields[3]),
                startticks=int(fields[19]), state=fields[0])


def same_identity(left, right):
    return all(left[k] == right[k] for k in ['pid', 'startticks'])


class OwnedTree:
    """Only fork-created root and individually proven descendants get pidfds."""
    def __init__(self, pid):
        root = proc_identity(pid)
        require(root['ppid'] == os.getpid() and root['pgid'] == root['sid'] == pid, 'fork/setsid root ownership')
        self.root = pid
        self.members = {}
        self.session_transitions = []
        self.enroll(root, dict(kind='direct_fork_handshake', parent_pid=os.getpid()))

    def enroll(self, identity, proof):
        fd = open_pidfd(identity['pid'])
        try:
            require(same_identity(identity, proc_identity(identity['pid'])), 'PID changed while opening pidfd')
            self.members[identity['pid']] = dict(identity=identity, pidfd=fd, proof=proof, last_session=(identity['pgid'], identity['sid']))
        except BaseException:
            os.close(fd)
            raise

    def active(self, member):
        return not select.select([member['pidfd']], [], [], 0)[0]

    def discovery_evidence(self):
        return dict(total_rejected=getattr(self, '_discovery_reject_total', 0),
                    retained_limit=64, last_rejections=list(getattr(self, '_discovery_rejects', [])))

    def _reject_discovery(self, reason, parent, pid, path, **observed):
        # A refused NEW candidate never grants authority to monitor or signal.
        event = dict(event='DISCOVERY_REFUSED', reason=reason, candidate_pid=pid,
                     parent_identity=parent, task_children_path=str(path), utc=utc(),
                     candidate_enrolled=False, **observed)
        self._discovery_reject_total = getattr(self, '_discovery_reject_total', 0) + 1
        recent = getattr(self, '_discovery_rejects', [])
        self._discovery_rejects = (recent + [event])[-64:]
        sink = getattr(self, 'discovery_reject_sink', None)
        n = self._discovery_reject_total
        if sink is not None and (n <= 64 or n & (n - 1) == 0):
            sink(dict(event='DISCOVERY_REJECTION_SAMPLE', total_rejected=n, detail=event))
        return False

    def _current_enrolled(self, member):
        if not self.active(member):
            return None
        try:
            current = proc_identity(member['identity']['pid'])
        except (FileNotFoundError, ProcessLookupError):
            require(not self.active(member), 'live enrolled identity unavailable')
            return None
        require(same_identity(current, member['identity']), 'owned identity changed')
        return current

    def _discover_candidate(self, parent, member, pid, path):
        """An old children snapshot alone never grants ownership.

        Commit only current ancestry verified around an opened pidfd.
        Refuse unproven reparented tasks; do not adopt arbitrary subreaper tasks.
        No exit status is inferred from pidfd readability.
        """
        if pid in self.members:
            self._current_enrolled(self.members[pid])
            return False  # Never overwrite an enrolled pidfd with a reused PID.
        fd = None
        try:
            first = proc_identity(pid)
            if first['ppid'] != parent['pid'] or first['startticks'] < parent['startticks']:
                return self._reject_discovery('UNPROVEN_CURRENT_ANCESTRY', parent, pid, path,
                                              candidate_first=first)
            fd = open_pidfd(pid)
            second = proc_identity(pid)
            if not same_identity(first, second):
                return self._reject_discovery('CANDIDATE_IDENTITY_CHANGED', parent, pid, path,
                                              candidate_first=first, candidate_second=second)
            current_parent = self._current_enrolled(member)
            if current_parent is None:
                return self._reject_discovery('ENROLLED_PARENT_EXITED', parent, pid, path,
                                              candidate_first=first, candidate_second=second)
            final = proc_identity(pid)
            if not same_identity(first, final):
                return self._reject_discovery('CANDIDATE_IDENTITY_CHANGED', parent, pid, path,
                                              candidate_first=first, candidate_final=final)
            if second['ppid'] != parent['pid'] or final['ppid'] != parent['pid']:
                return self._reject_discovery('CANDIDATE_REPARENTED', parent, pid, path,
                                              candidate_first=first, candidate_second=second, candidate_final=final)
            if select.select([fd], [], [], 0)[0] or final['state'] in ('Z', 'X', 'x'):
                return self._reject_discovery('CANDIDATE_EXITED', parent, pid, path,
                                              candidate_first=first, candidate_final=final)
            if not self.active(member):
                return self._reject_discovery('ENROLLED_PARENT_EXITED', parent, pid, path,
                                              candidate_final=final)
            self.members[pid] = dict(identity=final, pidfd=fd,
                proof=dict(kind='proc_task_children_and_current_ppid_pidfd', parent_identity=current_parent,
                    candidate_first=first, candidate_final=final, observed_utc=utc(), task_children_path=str(path)),
                last_session=(final['pgid'], final['sid']))
            fd = None
            return True
        except (FileNotFoundError, ProcessLookupError) as exc:
            return self._reject_discovery('CANDIDATE_OR_TASK_DISAPPEARED', parent, pid, path,
                                          exception_type=type(exc).__name__)
        finally:
            if fd is not None:
                os.close(fd)

    def refresh(self):
        for _ in range(8):
            changed = False
            for parent_pid, member in list(self.members.items()):
                parent = self._current_enrolled(member)
                if parent is None:
                    continue
                try:
                    tasks = list(Path(f'/proc/{parent_pid}/task').iterdir())
                except FileNotFoundError:
                    continue
                for task in tasks:
                    path = task / 'children'
                    try:
                        children = path.read_text().split()
                    except FileNotFoundError:
                        continue
                    for value in children:
                        changed = self._discover_candidate(parent, member, int(value), path) or changed
            if not changed:
                break
        else:
            raise ValueError('descendant discovery bound exceeded')

    def session_evidence(self):
        observations = []
        for pid, member in self.members.items():
            if not self.active(member): continue
            try: current = proc_identity(pid)
            except (FileNotFoundError, ProcessLookupError): continue
            require(same_identity(current, member['identity']), 'enrolled PID/startticks changed')
            session = (current['pgid'], current['sid'])
            if session != member['last_session']:
                self.session_transitions.append(dict(pid=pid, startticks=current['startticks'], previous_session=member['last_session'], current_session=session, utc=utc(), ownership_basis='unchanged enrolled PID/startticks and retained pidfd; session is telemetry, never enrollment authority'))
                member['last_session'] = session
            observations.append(dict(enrolled_identity=member['identity'], current_identity=current, ancestry_proof=member['proof']))
        return dict(observations=observations, transitions=list(self.session_transitions))

    def identities(self):
        return [dict(**v['identity'], enrollment=v['proof'], live=self.active(v)) for v in self.members.values()]

    def send(self, pid, sig):
        require(pid in self.members, 'signal target not enrolled as owned')
        member = self.members[pid]
        if not self.active(member):
            return False
        require(same_identity(proc_identity(pid), member['identity']), 'signal PID/startticks mismatch')
        # pidfd addresses the enrolled task even if PID exits/reuses after check.
        try:
            send_pidfd_signal(member['pidfd'], sig)
        except ProcessLookupError:
            return False
        return True

    def close(self):
        for member in self.members.values():
            os.close(member['pidfd'])


def resource_failures(observation, limits=LIMITS, *, initial=False, nas_floor=32*1024**3):
    return [name for name, okay in {
        'GPU_global_free': observation['GPU_free_MiB'] >= limits['min_initial_free_MiB' if initial else 'min_runtime_free_MiB'],
        'owned_GPU_footprint': observation['owned_GPU_MiB'] <= limits['max_owned_process_MiB'],
        'host_available': observation['host_available_MiB'] >= limits['min_initial_host_available_MiB' if initial else 'min_runtime_host_available_MiB'],
        'owned_RSS': observation['owned_RSS_MiB'] <= limits['max_owned_host_RSS_MiB'],
        'SSD_free': observation['SSD_free_bytes'] >= limits['min_SSD_free_bytes'],
        'NAS_free': observation['NAS_free_bytes'] >= nas_floor}.items() if not okay]


def account_gpu(gpu_csv, apps_csv, gpu, owned):
    devices = {}
    for row in csv.reader(gpu_csv.splitlines()):
        if not row: continue
        require(len(row) == 3, 'GPU CSV width')
        index, uuid, free = [x.strip() for x in row]
        require(index.isdecimal() and free.isdecimal() and int(index) not in devices, 'GPU telemetry malformed')
        devices[int(index)] = (uuid, int(free))
    require(gpu in devices, 'selected GPU absent')
    uuid, free = devices[gpu]
    total, rows = 0, []
    for row in csv.reader(apps_csv.splitlines()):
        if not row: continue
        require(len(row) == 3, 'apps CSV width')
        device, pid, memory = [x.strip() for x in row]
        require(pid.isdecimal() and int(pid) > 0, 'GPU PID malformed')
        selected_owned = device == uuid and int(pid) in owned
        if selected_owned:
            require(memory.isdecimal(), 'owned GPU memory unavailable')
            total += int(memory)
        rows.append(dict(gpu_uuid=device, pid=int(pid), memory_raw=memory,
            counted_in_owned=selected_owned, attribution='ENROLLED_PID' if int(pid) in owned else 'UNATTRIBUTED'))
    return dict(GPU_free_MiB=free, owned_GPU_MiB=total, process_observations=rows, gpu_uuid=uuid, gpu_index=gpu)


def probe_resources(tree=None, *, gpu=0, deadline=None):
    import shutil
    owned = {}
    if tree is not None:
        tree.refresh()
        owned = {pid: v for pid, v in tree.members.items() if tree.active(v)}
    queries = []
    for query in ['--query-gpu=index,uuid,memory.free', '--query-compute-apps=gpu_uuid,pid,used_memory']:
        timeout = 5 if deadline is None else min(5, deadline - time.monotonic())
        if timeout <= 0: raise TimeoutError('native wall deadline during probe')
        argv = ['nvidia-smi', query, '--format=csv,noheader,nounits']
        result = subprocess.run(argv, capture_output=True, text=True, timeout=timeout)
        queries.append(dict(argv=argv, actual_exit=result.returncode, stdout=result.stdout, stderr=result.stderr))
        require(result.returncode == 0, 'resource probe unavailable')
    owned = {pid: member for pid, member in owned.items() if tree.active(member)}
    for pid, member in owned.items():
        require(same_identity(proc_identity(pid), member['identity']), 'GPU observation PID identity changed')
    observation = account_gpu(queries[0]['stdout'], queries[1]['stdout'], gpu, owned)
    rss = 0
    for pid, member in owned.items():
        if not tree.active(member): continue
        try:
            require(same_identity(proc_identity(pid), member['identity']), 'resource PID reused')
            status = dict(line.split(':', 1) for line in Path(f'/proc/{pid}/status').read_text().splitlines() if ':' in line)
            rss += int(status.get('VmRSS', '0 kB').split()[0])
        except FileNotFoundError:
            continue
    mem = dict(line.split(':', 1) for line in Path('/proc/meminfo').read_text().splitlines())
    observation.update(owned_RSS_MiB=rss // 1024, host_available_MiB=int(mem['MemAvailable'].split()[0]) // 1024,
        SSD_free_bytes=shutil.disk_usage(H).free, NAS_free_bytes=shutil.disk_usage(R).free,
        observed_utc=utc(), queries=queries, ownership='FORK_ROOT_AND_PROVEN_DESCENDANTS_ONLY',
        owned_identities=tree.identities() if tree else [],
        owned_session_evidence=tree.session_evidence() if tree else None)
    return observation


def append_event(stream, event):
    stream.write(json.dumps(event, allow_nan=False) + '\n'); stream.flush(); os.fsync(stream.fileno())


def bounded_child(argv, environment, out, *, backend, max_wall, monitor=None, cpu_limit=False):
    """Real owned fork/exec/wait4; only PIDfd signals, all output in caller's NAS dir.

    Deadline triggers TERM at max_wall, then at most 10s grace +5s KILL reap.
    An uninterruptible task is reported UNREAPED, never a fabricated wait result.
    """
    require(0 < max_wall <= 3600, 'bounded child wall')
    out = Path(out).absolute()
    require(out.resolve().is_relative_to(R) and not out.exists(), 'exclusive NAS output required')
    out.mkdir(exist_ok=False)
    ready_r, ready_w = os.pipe(); go_r, go_w = os.pipe()
    start, started = time.monotonic(), utc()
    tree = None; pid = None; waited = None; raw = None; usage = None
    abort = None; signals = []; error = None
    with (out / 'child.log').open('xb') as log, (out / 'resources.jsonl').open('x') as events:
        try:
            pid = os.fork()
            if pid == 0:
                try:
                    os.close(ready_r); os.close(go_w)
                    os.setsid()
                    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
                    if cpu_limit:
                        resource.setrlimit(resource.RLIMIT_AS, (1024**3, 1024**3))
                    else:
                        _, hard = resource.getrlimit(resource.RLIMIT_AS)
                        require(hard == resource.RLIM_INFINITY, 'native needs inherited unlimited address space; RSS is monitored')
                        resource.setrlimit(resource.RLIMIT_AS, (hard, hard))
                    os.dup2(log.fileno(), 1); os.dup2(log.fileno(), 2)
                    os.write(ready_w, b'R'); os.close(ready_w)
                    require(os.read(go_r, 1) == b'G', 'parent did not enroll child')
                    os.close(go_r)
                    os.chdir(out)
                    os.execve(argv[0], argv, environment)
                except BaseException:
                    import traceback
                    traceback.print_exc()
                    os._exit(127)
            os.close(ready_w); ready_w = None
            os.close(go_r); go_r = None
            require(select.select([ready_r], [], [], min(5, max_wall))[0] and os.read(ready_r, 1) == b'R', 'child fork handshake failed')
            tree = OwnedTree(pid)
            tree.discovery_reject_sink = lambda event: append_event(events, event)
            append_event(events, dict(event='OWNED_ENROLLED', identities=tree.identities(), argv=argv, utc=utc()))
            os.write(go_w, b'G'); os.close(go_w); go_w = None
            deadline = start + max_wall
            while True:
                got, status, found_usage = os.wait4(pid, os.WNOHANG)
                if got:
                    waited, raw, usage = got, status, found_usage
                    break
                if time.monotonic() >= deadline:
                    raise TimeoutError('max_wall exceeded')
                tree.refresh()
                if monitor is not None:
                    observation = monitor(tree, deadline)
                    failures = resource_failures(observation)
                    append_event(events, dict(event='RESOURCE', observation=observation, failed=failures))
                    require(not failures, 'resource gates: ' + ','.join(failures))
                select.select([tree.members[pid]['pidfd']], [], [], min(.25, max(0, deadline - time.monotonic())))
        except BaseException as exc:
            abort = type(exc).__name__ + ': ' + str(exc)
            error = abort
            append_event(events, dict(event='ABORT', reason=abort, utc=utc()))
        finally:
            # Closing the gate ensures an un-enrolled child cannot exec on failure.
            if go_w is not None:
                os.close(go_w); go_w = None
            if tree is not None:
                for sig, grace in [(signal.SIGTERM, 10), (signal.SIGKILL, 5)]:
                    active = [p for p, member in tree.members.items() if tree.active(member)]
                    if not active: break
                    if raw is not None and abort is None:
                        abort = 'identified descendants survived root exit'
                    for target in reversed(active):
                        try:
                            if tree.send(target, sig): signals.append(dict(pid=target, signal=int(sig), identity=tree.members[target]['identity']))
                        except (ValueError, FileNotFoundError, ProcessLookupError) as exc:
                            abort = 'owned signal identity unavailable: ' + str(exc)
                    until = time.monotonic() + grace
                    while time.monotonic() < until and any(tree.active(v) for v in tree.members.values()):
                        time.sleep(.05)
                if any(tree.active(v) for v in tree.members.values()):
                    abort = 'UNREAPED_OWNED_TASK_REQUIRES_PARENT_REVIEW'
            if pid and raw is None:
                until = time.monotonic() + 5
                while time.monotonic() < until:
                    got, status, found_usage = os.wait4(pid, os.WNOHANG)
                    if got:
                        waited, raw, usage = got, status, found_usage
                        break
                    time.sleep(.05)
            identities = tree.identities() if tree else []
            discovery_rejections = tree.discovery_evidence() if tree else None
            session_transitions = list(tree.session_transitions) if tree else []
            if tree: tree.close()
            for fd in [ready_r, ready_w, go_r, go_w]:
                if fd is not None:
                    try: os.close(fd)
                    except OSError: pass
            log.flush(); os.fsync(log.fileno())
            append_event(events, dict(event='ACTUAL_WAIT', child_pid=pid, waited_pid=waited, raw_wait_status=raw,
                actual_wait_exit=os.waitstatus_to_exitcode(raw) if raw is not None else None,
                identities=identities, resource_abort=abort, signals=signals, discovery_rejections=discovery_rejections))
    receipt = dict(schema='astra.full74.parent_native_wait.v1' if backend == 'isaac_physx_native' else 'astra.full74.owned_cpu_wait.v1',
        backend=backend, child_pid=pid, waited_pid=waited, waitpid_observed=raw is not None,
        raw_wait_status=raw, actual_wait_exit=os.waitstatus_to_exitcode(raw) if raw is not None else None,
        wait_mechanism='os.wait4(owned_pid, WNOHANG)', started_utc=started, closed_utc=utc(),
        elapsed_seconds=time.monotonic() - start, max_wall_seconds=max_wall,
        resource_abort=abort, error=error, owned_identities=identities, owned_session_transitions=session_transitions, signals=signals,
        discovery_rejections=discovery_rejections,
        child_max_rss_KiB=usage.ru_maxrss if usage else None,
        log=str(out / 'child.log'), log_sha256=sha(out / 'child.log'),
        outer_monitor=str(out / 'resources.jsonl'), outer_monitor_sha256=sha(out / 'resources.jsonl'), argv=argv)
    write_new(out / 'ACTUAL_WAIT.json', receipt)
    return receipt
