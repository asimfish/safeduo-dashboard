"""Parent-only native entry. Default requires explicit --check-cpu or native flag."""
import argparse,os,sys,traceback
from pathlib import Path
from mechanism_bootstrap_v1 import bootstrap,assert_threads
HERE=Path(__file__).resolve().parent

def parser():
    p=argparse.ArgumentParser(allow_abbrev=False)
    for key in ['request','request-sha256','review','review-sha256']:p.add_argument('--'+key,required=True)
    g=p.add_mutually_exclusive_group(required=True)
    g.add_argument('--check-cpu',action='store_true');g.add_argument('--execute-native-screen',action='store_true')
    p.add_argument('--permit');p.add_argument('--permit-sha256')
    return p

def verify_live_parent(permit,core):
    identity=core.proc_identity(os.getppid())
    core.require(core.same_identity(identity,permit['parent_identity']),'live direct parent PID/startticks')
    lease=permit['serial_lease'];lock=lease['kernel_lock']
    core.require(lease['owner_pid']==identity['pid'] and lease['owner_startticks']==identity['startticks'],'serial owner identity')
    data=Path(f'/proc/{identity["pid"]}/fdinfo/{lock["fd"]}').read_text()
    core.require(any(line.split(':',1)[0]=='lock' and line.split(':',1)[1].split()==lock['lock_record']
        for line in data.splitlines() if ':' in line),'parent continuously retained serial FD')

def main():
    p=parser();args,unknown=p.parse_known_args();assert_threads()
    import time
    start_unix,start_mono=time.time(),time.monotonic();timing=gate=None
    b,runner,request,out=bootstrap(args,native=args.execute_native_screen)
    if args.execute_native_screen:
        from fresh_exchange_mechanism_v1 import begin_timing
        timing=begin_timing(args);timing.phase('AFTER_BOOTSTRAP',entry_started_unix_s=start_unix,entry_started_monotonic_s=start_mono)
    b.require(request['source_files'].get(str(HERE/'native_entry_v1.py'))==b.sha(__file__),'bound native entry')
    if args.check_cpu:
        b.require(not unknown and not args.permit and os.environ.get('CUDA_VISIBLE_DEVICES')=='','CPU check has no native arguments/device')
        b.require(not any(k=='torch' or k.startswith(('isaac','omni.')) for k in sys.modules),'CPU check imported native SDK')
        print('CPU_REQUEST_VALID_NATIVE0_NOT_ADOPTED_BY_CHECK',flush=True);return 0
    from mechanism_gpu_binding_v4 import configure_app,self_probe
    from runtime_mechanism_v1 import load_runtime
    b.require(args.permit and args.permit_sha256,'source-bound parent permit required')
    timing.phase('BEFORE_RUNTIME_LOAD');core=load_runtime(request);timing.phase('AFTER_RUNTIME_LOAD')
    permit=b.bound_json(args.permit,args.permit_sha256);verify_live_parent(permit,core)
    # Dated dispatch remains authority/history; only the new READY grant is fresh resource authorization.
    b.require(permit['schema']=='astra.full74.per_state.gpu_permit.v3' and permit['parent_authorized'] is True and permit['cpu_test_only'] is False and permit['single_owned_Kit'] is True,'dispatch authority')
    b.require(permit['request_sha256']==args.request_sha256 and permit['review_sha256']==args.review_sha256 and permit['gpu_binding']==request['gpu_binding'],'dispatch exact bindings')
    b.require(os.environ['CUDA_VISIBLE_DEVICES']==request['gpu_binding']['CUDA_VISIBLE_DEVICES'] and os.environ['OMNI_KIT_ACCEPT_EULA']=='YES' and os.environ['PRIVACY_CONSENT']=='Y','child mapping/consent')
    timing.phase('DISPATCH_PARENT_LEASE_VERIFIED')
    lifecycle=b.verified_module(b.LIFECYCLE,request['source_files'][str(b.LIFECYCLE)])
    # The only native imports are below validated request, negative, adoption,
    # runtime proof, parent continuous lease, and fresh samephysical resources.
    timing.phase('BEFORE_APP_LAUNCHER_IMPORT')
    from isaaclab.app import AppLauncher
    timing.phase('AFTER_APP_LAUNCHER_IMPORT')
    class SingleThreadAppLauncher(AppLauncher):
        def _config_resolution(self,launcher_args):
            timing.phase('BEFORE_APP_CONFIG')
            super()._config_resolution(launcher_args)
            self._sim_app_config['limit_cpu_threads']=1
            configure_app(request['gpu_binding'],self._sim_app_config)
            from telemetry_startup_v5 import configure
            configure(self._sim_app_config)
            root=Path(request['attempt_root'])
            self._sim_app_config.setdefault('extra_args',[]).extend([
                '--/log/file='+str(root/'logs/kit.log'),'--/app/tokens/cache='+str(root/'cache/ov'),
                '--/app/tokens/data='+str(root/'data/ov'),'--/app/userConfigPath='+str(root/'config/kit.config.json')])
            timing.phase('AFTER_APP_CONFIG')
        def _create_app(self):
            return gate.create_app(lambda:super(SingleThreadAppLauncher,self)._create_app())
    AppLauncher.add_app_launcher_args(p);args=p.parse_args()
    b.require(args.headless and args.enable_cameras and args.device=='cuda:0','fixed logical native configuration')
    root=Path(request['attempt_root']);entry=root/'entry';entry.mkdir(exist_ok=False)
    from fresh_exchange_mechanism_v1 import ChildGate
    from source_import_v3 import module_from_buffer
    resource_path=b.H/'astra/full74_screen/gpu_resource_observation_v2.py'
    resource_observer=module_from_buffer('_fresh_v4_resource_observer',resource_path,request['source_files'][str(resource_path)])
    gate=ChildGate(request,args,permit,core,verify_live_parent,timing,resource_observer)
    state=dict(schema='astra.constraint.mechanism.entry.v1',status='failed',request_sha256=args.request_sha256,
        review_sha256=args.review_sha256,cleanup_errors=[],policy_actions=0,acceptance=False)
    app=launcher=trace=None;delegated=False
    def write_entry(value):
        if 'telemetry_startup_v5' in state:value['telemetry_startup_v5']=state['telemetry_startup_v5']
        value.update(schema='astra.constraint.mechanism.entry.v1',review_sha256=args.review_sha256,policy_actions=0,acceptance=False,pre_app_proof_v4=gate.proof if gate else None,pre_app_phase_refs=list(timing.events))
        try:
            if trace is not None:trace.close()
        except BaseException as exc:
            value['status']='failed';value.setdefault('cleanup_errors',[]).append('trace: '+str(exc))
        finally:b.json_new(entry/'ENTRY_RECEIPT_V4.json',value)
    def write_error(value):b.json_new(entry/'APP_CLOSE_ERROR_V4.json',value)
    try:
        from source_import_v3 import module_from_buffer
        mod=module_from_buffer('phase_trace_mechanism_v1',HERE/'phase_trace_mechanism_v1.py',request['source_files'][str(HERE/'phase_trace_mechanism_v1.py')])
        trace=mod.PhaseTrace(root);trace.phase('BEFORE_APP_LAUNCH')
        launcher=SingleThreadAppLauncher.__new__(SingleThreadAppLauncher);launcher.__init__(args);app=launcher.app
        trace.phase('AFTER_APP_LAUNCH');assert_threads()
        import torch
        import carb.settings
        import omni.kit.app
        from telemetry_startup_v5 import capture
        state['telemetry_startup_v5']=capture(carb.settings.get_settings(),omni.kit.app.get_app().get_extension_manager(),os.environ)
        def env_factory():
            trace.phase('BEFORE_ENV_CREATE');env=runner.create_environment_in_existing_app('cuda:0')
            try:trace.phase('AFTER_ENV_CREATE')
            except BaseException:
                env.close();raise
            return env
        delegated=True
        runner.run_in_existing_parent_app(app,env_factory,request_path=args.request,request_sha256=args.request_sha256,
            review_path=args.review,review_sha256=args.review_sha256,resource_probe=lambda:self_probe(request['gpu_binding']),
            write_entry=write_entry,write_app_error=write_error,gpu_permit_path=args.permit,gpu_permit_sha256=args.permit_sha256,
            pre_app_proof=gate.proof,native_torch=torch,kit_settings=carb.settings.get_settings(),kit_log_path=root/'logs/kit.log')
    except BaseException as exc:
        state.update(status='failed',error=type(exc).__name__+': '+str(exc),traceback=traceback.format_exc());raise
    finally:
        if not delegated:
            if app is None and launcher is not None:app=getattr(launcher,'_app',None)
            lifecycle.close_environment_and_app(state,None,app,write_entry,write_error)
    return 0

if __name__=='__main__':raise SystemExit(main())
