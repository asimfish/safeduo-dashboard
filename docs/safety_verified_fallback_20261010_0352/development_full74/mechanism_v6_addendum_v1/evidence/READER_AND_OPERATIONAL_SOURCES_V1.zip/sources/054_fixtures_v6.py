"""Explicit synthetic metadata for CPU contracts; never native evidence."""
import copy,struct
import numpy as np
from runtime import ARMS
import inventories
def paired_fixture():
    q = np.zeros((16, 74), np.float32)
    v = q.copy()
    q[:, 26] = 0.2
    v[:, 26] = 0.1
    q[0, 26] = 0.8
    rs = [dict(child=27, parent=26, multiplier=2.0, offset=0.0, authority='SYNTHETIC'), dict(child=28, parent=27, multiplier=0.5, offset=0.0, authority='SYNTHETIC')]
    cq = q.copy()
    cv = v.copy()
    cq[:, 27] = q[:, 26] * np.float32(2)
    cv[:, 27] = v[:, 26] * np.float32(2)
    cq[:, 28] = cq[:, 27] * np.float32(0.5)
    cv[:, 28] = cv[:, 27] * np.float32(0.5)
    x = np.zeros((32, 74), np.float32)
    y = x.copy()
    cases = []
    layout = dict(bounds=np.tile(np.array([-1, 1], np.float32), (74, 1)), vmax=np.ones(74, np.float32), controlled=np.arange(26, dtype=np.int64))
    for i in range(16):
        a, b = (2 * i + i % 2, 2 * i + 1 - i % 2)
        ok = i != 0
        x[a] = q[i]
        y[a] = v[i]
        x[b] = cq[i] if ok else q[i]
        y[b] = cv[i] if ok else v[i]

        def residual(z, w):
            return dict(position=[float(z[27]) - 2 * float(z[26]), float(z[28]) - 0.5 * float(z[27])], velocity=[float(w[27]) - 2 * float(w[26]), float(w[28]) - 0.5 * float(w[27])])
        cases.append(dict(pair=i, seed_index=0, proposal_id=92 + i, family=i % 4, A_lane=a, B_lane=b, intervention_authority='SYNTHETIC', clipped=False, redrawn=False, original_sample_preserved_separately=True, constructible=ok, no_projection=False, B_disposition='CONSTRUCTED_NOT_QUALIFIED' if ok else 'NOT_CONSTRUCTIBLE_BASELINE_DUPLICATE_RETAINED', rejection=None if ok else 'NO_RELATIONS_OR_OUTSIDE_ORIGINAL_HARD_SOFT_VMAX', changed_q=np.flatnonzero(cq[i].view(np.uint32) != q[i].view(np.uint32)).tolist(), changed_qd=np.flatnonzero(cv[i].view(np.uint32) != v[i].view(np.uint32)).tolist(), original_residual=residual(q[i], v[i]), candidate_residual=residual(cq[i], cv[i])))
    return [list(range(92, 108)), q, v, cq, cv, x, y, cases, rs, layout, 'SYNTHETIC']

def native_fixture(outer):
    pid = 900000001
    ppid = outer['child_pid']
    root = dict(pid=pid, ppid=ppid, startticks=999999999, live=False, enrollment=dict(kind='direct_fork_handshake', parent_pid=ppid))
    w = dict(schema='astra.full74.parent_native_wait.v1', backend='isaac_physx_native', child_pid=pid, waited_pid=pid, actual_wait_exit=0, raw_wait_status=0, waitpid_observed=True, wait_mechanism='os.wait4(owned_pid, WNOHANG)', resource_abort=None, error=None, signals=[], owned_identities=[root], max_wall_seconds=1200, elapsed_seconds=0.0, started_utc=outer['started_utc'], closed_utc=outer['closed_utc'])
    return (w, dict(pid=ppid, startticks=123456))

def clock_fixture():
    snapshots = []
    events = []
    t = 0.025000001303851604
    dt = 1 / 120
    event = struct.unpack('<f', struct.pack('<f', dt))[0]
    sources = {'CPU_FIXTURE': 'not_native'}
    binary = lambda x: struct.pack('<d', x).hex()
    for i in range(13):
        if i:
            t += event
            events.append(dict(type='float', step_size=event, float64_le=binary(event)))
        snapshots.append(dict(schema='astra.native_clock.snapshot.v1', getter_source=sources, configured_dt_s=0.008333, usd_time_steps_per_second=120, actual_dt_s=dt, actual_dt_dtype='float64', actual_dt_float64_le=binary(dt), simulation_time_s=t, simulation_time_float64_le=binary(t), simulation_step=3 + i, callback_count=i))
    return [snapshots, events, np.arange(3, 16, dtype=np.int64), np.array([s['simulation_time_s'] for s in snapshots]), sources]

def inventory_fixture():
    p = {}
    records = []
    registry = []
    getters = {}
    drives = {}
    names = []
    for arm, width in zip(ARMS, (19, 19, 18, 18)):
        ns = ['j' + str(i) for i in range(width)]
        p[arm + '_native_joint_names'] = np.array(ns)
        paths = [[f'/World/envs/env_{i}/{arm}/{n}' for n in ns] for i in range(32)]
        getters[arm] = dict(fixed_count=0, spatial_count=0, dof_paths=paths, prim_paths=[f'/World/envs/env_{i}/{arm}' for i in range(32)])
        d = dict(joint_names=ns, passive_DOF_proven=False, actual_drive_torque='UNKNOWN')
        for key, param, value in [('stiffness', 'stiffness', 5.0), ('damping', 'damping', 0.5), ('force_cap', 'max_force', 2.0)]:
            p[arm + '_' + param] = np.full((32, width), value, np.float32)
            d[key] = p[arm + '_' + param].tolist()
        d.update(no_PD_coefficients=np.zeros((32, width), bool).tolist(), zero_drive_cap=np.zeros((32, width), bool).tolist())
        drives[arm] = d
        for j, n in enumerate(ns):
            names.append(arm + '/' + n)
            records.append(dict(arm=arm, joint_name=arm + '/' + n, path=paths[0][j], type='PhysicsRevoluteJoint', schemas=[], attributes={'physics:jointEnabled': True}, relationships={}))
            registry.append(dict(path=paths[0][j].replace('/env_0/', '/env_N/'), type='PhysicsRevoluteJoint', schemas=[], attributes={'physics:jointEnabled': True}, relationships={}, classification=dict(joint_enabled=True, active_state='ENABLED', unsupported_reasons=[], deny_before_state_writes=False)))
    inv = dict(schema='astra.native.constraint_inventory.v2', stage_scope='LIVE_ALL32_TOPOLOGY_EQUAL_PLUS_ALL32_TENSOR_GETTERS', instance_proxies_traversed=True, registry_policy='TYPED_JOINT_AND_APPLIED_COUPLING_EXPLICIT_SUPPORT_BEFORE_STATE_WRITES', ordinary_joint_types=sorted(inventories.ORDINARY), normalized_all32_registry={str(i): copy.deepcopy(registry) for i in range(32)}, unsupported=[], tendon_getters=getters, drive_configuration=drives, records=records, mimic_relations=[], compiled_mimic_impulses='UNKNOWN', passive_constraint_impulses='UNKNOWN', eDRIVE_LIMITS_ARE_FORCES='UNKNOWN_NO_NATIVE_FLAG_GETTER_BOUND')
    return (inv, p, dict(names=np.array(names)))
