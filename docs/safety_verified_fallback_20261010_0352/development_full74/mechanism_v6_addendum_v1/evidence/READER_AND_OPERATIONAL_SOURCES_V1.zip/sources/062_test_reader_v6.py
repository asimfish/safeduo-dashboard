"""V6-only meaningful regressions. All native-looking documents are synthetic."""
import copy,sys,types,unittest
from runtime import *
import numpy as np
import pairs,inventories,kernels
from fixtures_v6 import paired_fixture,native_fixture,clock_fixture,inventory_fixture
from clock_reader_v1 import audit as clock_audit
from waits import chronology,direct_wait,parent_files
from gpu_gate_cpu_v6 import gpu_identity,kit_identity,UUID

ART=Path(sys.argv.pop(1));require(ART.is_relative_to(OUTPUT),'new CPU fixture output only');ART.mkdir(parents=True,exist_ok=False)
DENIALS=[]
def deny(name,call):
    try:call()
    except (ValueError,KeyError,TypeError) as exc:
        DENIALS.append(dict(name=name,error=type(exc).__name__,message=str(exc),fixture_not_native=True));return
    raise AssertionError('negative was accepted: '+name)

def typed_inventory():
    inv,p,l=inventory_fixture()
    for rows in inv['normalized_all32_registry'].values():
        for row in rows:
            row['schemas']=[inventories.STATE_API]
            row['state_attribute_types']={n:'float' for n in inventories.STATE_KEYS}
    for row in inv['records']:row['schemas']=[inventories.STATE_API]
    return inv,p,l

def kit_fixture():
    # This is a controlled raw-table parser fixture, not an actual Kit readback.
    lines=['| GPU | Name']
    for index,active,uuid,bus in [(0,'Yes: 0','b129224c','41'),(1,'','828bb172','81')]:
        lines.append('| '+ ' | '.join([str(index),'fixture',active,'','','',''])+' |')
        lines.append('| '+ ' | '.join(['','','','','','',uuid+'..'])+' |')
        lines.append('| '+ ' | '.join(['','','','','',bus,''])+' |')
    lines+=['fixture footer']*(16-len(lines));table='\n'.join(lines)
    rows=[dict(renderer_index=0,active='Yes: 0',uuid_prefix='b129224c',pci_bus_hex='41'),dict(renderer_index=1,active='',uuid_prefix='828bb172',pci_bus_hex='81')]
    return dict(actual_settings={'/renderer/activeGpu':0,'/physics/cudaDevice':0,'/renderer/multiGpu/enabled':False},actual_rows=rows,active_renderer=rows[0],actual_table=table,actual_table_sha256=__import__('hashlib').sha256(table.encode()).hexdigest()),table

class Adapter(unittest.TestCase):
    def test_typed_angular_all74_and_mimic_guard(self):
        inv,p,l=typed_inventory();result=inventories.audit(inv,copy.deepcopy(inv),p,l)
        self.assertEqual(result['angular_state_APIs_per_lane'],74)
        self.assertEqual(result['USD_state_attribute_values_finite'],'UNKNOWN_NOT_RETAINED_IN_V6_VALID_REGISTRY')
        edits=[('wrong instance',lambda row:row.__setitem__('schemas',['PhysicsJointStateAPI:linear'])),
               ('double type',lambda row:row['state_attribute_types'].__setitem__('state:angular:physics:position','double')),
               ('missing velocity type',lambda row:row['state_attribute_types'].pop('state:angular:physics:velocity')),
               ('extra state attribute',lambda row:row['state_attribute_types'].__setitem__('state:linear:physics:position','float')),
               ('angular on fixed',lambda row:row.__setitem__('type','PhysicsFixedJoint')),
               ('mimic schema',lambda row:row['schemas'].append('PhysxMimicJointAPI:rotX')),
               ('hidden gear',lambda row:row.__setitem__('type','PhysxPhysicsGearJoint')),
               ('unknown API',lambda row:row['schemas'].append('PhysicsMysteryAPI')),
               ('mimic relationship',lambda row:row['relationships'].__setitem__('physxMimicJoint:referenceJoint',['/World/env_N/other'])),
               ('missing all74 API',lambda row:row.__setitem__('schemas',[]))]
        for name,edit in edits:
            bad=copy.deepcopy(inv)
            for rows in bad['normalized_all32_registry'].values():edit(rows[0])
            deny(name,lambda:inventories.audit(bad,copy.deepcopy(bad),p,l))
        for name,edit in [('missing lane31',lambda v:v['normalized_all32_registry'].pop('31')),
                          ('gains changed',lambda v:v['drive_configuration']['U_R']['stiffness'][3].__setitem__(0,6.)),
                          ('tendon getter',lambda v:v['tendon_getters']['F_L'].__setitem__('fixed_count',1)),
                          ('mimic list hidden',lambda v:v['mimic_relations'].append({'synthetic':True}))]:
            bad=copy.deepcopy(inv);edit(bad);deny(name,lambda:inventories.audit(bad,copy.deepcopy(bad),p,l))
        bad=copy.deepcopy(inv);bad['drive_configuration']['U_R']['force_cap'][0][0]=1.
        deny('before-after inventory drift',lambda:inventories.audit(inv,bad,p,l))

    def test_preserved_16_denominator_and_original_intervention(self):
        x=paired_fixture();r=pairs.audit_arrays(*x)
        self.assertEqual((r['latent_denominator'],r['constructible']),(16,15))
        for name,edit in [('changed ID',lambda z:z[0].__setitem__(0,91)),
                          ('duplicate lane',lambda z:z[7][1].__setitem__('A_lane',0)),
                          ('invalid B declared constructible',lambda z:z[7][0].__setitem__('constructible',True)),
                          ('written q changed',lambda z:z[5].__setitem__((2,0),np.float32(.1))),
                          ('written qd changed',lambda z:z[6].__setitem__((2,0),np.float32(.1))),
                          ('controlled coordinate projected',lambda z:z[8][0].__setitem__('parent',3))]:
            z=copy.deepcopy(x);edit(z);deny(name,lambda:pairs.audit_arrays(*z))

    def test_exact_clock_no_missing_step_or_relaxed_decimal(self):
        x=clock_fixture();self.assertEqual(clock_audit(*x)['status'],'EXACT_CLOCK_INTERVALS_VERIFIED')
        for name,edit in [('12 states not13',lambda z:z[0].pop()),('11 callbacks not12',lambda z:z[1].pop()),
                          ('configured decimal as actual',lambda z:z[0][5].__setitem__('actual_dt_s',.008333)),
                          ('double callback instead of actualfloat32',lambda z:z[1][0].__setitem__('step_size',1/120)),
                          ('clock state shifted1ns',lambda z:z[3].__setitem__(12,z[3][12]+1e-9))]:
            z=copy.deepcopy(x);edit(z);deny(name,lambda:clock_audit(*z))

    def test_real_direct_wait_zero_nonzero_and_parent_startticks(self):
        ref=MANIFEST['observer'];m=types.ModuleType('_V6_CPU_actual_observer');m.__file__=ref['path'];exec(compile(raw(ref['path'],ref['sha256']),ref['path'],'exec'),m.__dict__)
        for code in (0,1):
            folder=ART/f'real_owned_wait_{code}';w=m.observe([sys.executable,'-B','-c',f'raise SystemExit({code})'],folder)
            direct_wait(w,code);parent_files(Evidence(),w,folder/'ACTUAL_WAIT.json')
            self.assertEqual(w['raw_wait_status'],code*256)
            if code:
                deny('actual parent1 cannot become0',lambda:direct_wait(w,0));continue
            native,parent=native_fixture(w);parent['startticks']=w['owned_identities'][0]['startticks']
            chronology(w,native,parent)
            bad=copy.deepcopy(parent);bad['startticks']+=1
            deny('parent startticks mismatch',lambda:chronology(w,native,bad))
            for name,edit in [('raw status disagrees',lambda z:z.__setitem__('raw_wait_status',256)),('live owned root',lambda z:z['owned_identities'][0].__setitem__('live',True)),('wrong wait domain',lambda z:z.__setitem__('schema','parent.wrapper.direct_actual_wait.v1'))]:
                z=copy.deepcopy(w);edit(z);deny(name,lambda:direct_wait(z,0))

    def test_exact_gpu0_and_closed_kit_table(self):
        value=dict(physical_gpu_index=0,cuda_device='cuda:0',expected_uuid=UUID,actual_cuda_uuid=UUID,cuda_visible_devices='0',multi_gpu=False,active_renderer_gpu=0,physics_logical_gpu=0)
        gpu_identity(value);kit,table=kit_fixture();kit_identity(kit,table)
        bad=dict(value,actual_cuda_uuid='GPU-828bb172-121c-cc55-7f4f-ef09a2bd7599')
        deny('wrong CUDA UUID',lambda:gpu_identity(bad))
        bad=copy.deepcopy(kit);bad['actual_settings']['/renderer/activeGpu']=1
        deny('GPU1 renderer settings',lambda:kit_identity(bad,table))
        altered=table.replace('b129224c','b129224d');bad=copy.deepcopy(kit);bad['actual_table']=altered;bad['actual_table_sha256']=__import__('hashlib').sha256(altered.encode()).hexdigest()
        deny('raw renderer UUID drift',lambda:kit_identity(bad,altered))

    def test_complete13_real_field_files_and_preallocated_tail_denied(self):
        schema=ref(Evidence(),MANIFEST['anchors']['numeric_schema']);folder=ART/'native_field_metadata';stream=folder/'native_fields';stream.mkdir(parents=True)
        for i in range(13):(stream/f'row_{i:03d}_complete.json').write_text(json.dumps({'row':i}))
        arrays={n:np.zeros(s['shape'],dtype=s['dtype']) for n,s in schema['native_fields'].items()}
        arrays.update(micro=np.arange(13,dtype=np.int64),macro_step=np.array([-1]+[(i-1)//2 for i in range(1,13)],np.int64),substep=np.array([-1]+[(i-1)%2 for i in range(1,13)],np.int64),point_fresh=np.array([False]+[True]*12),initial_point_freshness_unknown=np.array([True]+[False]*12),simulation_step=np.arange(3,16,dtype=np.int64))
        closed=dict(filled=13,files={str(stream/(n+'.npy')):'SYNTHETIC_NOT_SHA_AUTHORITY' for n in arrays})
        class E:
            def js(self,p):return closed if p.name=='CLOSED.json' else json.loads(p.read_bytes())
            def verify(self,*a):pass # only field inventory fixture, never production Evidence
            def npy(self,p,shape,dtype):
                a=arrays[p.stem];require(a.shape==tuple(shape) and a.dtype==np.dtype(dtype),'fixture dimensions');return a
        self.assertEqual(kernels.fields(E(),folder,schema)['q74'].shape,(13,32,74))
        closed['filled']=12;deny('zero preallocation tail claimed complete',lambda:kernels.fields(E(),folder,schema))
        closed['filled']=13;(stream/'row_012_complete.json').unlink()
        deny('missing committed state12',lambda:kernels.fields(E(),folder,schema))

    def test_template_and_source_math_boundary(self):
        from binding import closure
        template=PACKAGE/'FUTURE_BINDING_TEMPLATE_V1.json'
        deny('future authority missing before RAW access',lambda:closure(Evidence(),template,sha(template)))
        sources()
        for n in ('data.py','pairs.py','kernels.py','clock_reader_v1.py','clock_binding_v1.py','fresh_gate_reader.py'):
            self.assertEqual((HERE/n).read_bytes(),(H/'astra/full74_native_constraint_reader_v1/reader'/n).read_bytes())
        self.assertFalse(any(n in sys.modules for n in ('torch','pxr','collector_v1','constraint_model_v1','native_inventory_v1')))

if __name__=='__main__':
    result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(Adapter))
    write_new(ART/'CPU_NEGATIVE_REPORT_V6.json',dict(status='PASS_CPU_CONTRACTS_ONLY' if result.wasSuccessful() else 'FAILED_CPU_CONTRACTS',test_groups=result.testsRun,expected_denials=DENIALS,errors=len(result.errors),failures=len(result.failures),native_launches=0,actual_RAW_reads=0,synthetic_fixtures_are_not_native_evidence=True))
    raise SystemExit(0 if result.wasSuccessful() else 2)
