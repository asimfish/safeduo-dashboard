"""Mechanism metadata adapter around unchanged independent 74/9021/82 kernels."""
from runtime import *
import numpy as np
import kernels as k
import pairs,inventories
from clock_binding_v1 import clock_fields

def distributions(actual,q,v,layout):
    require(actual['n']==len(q) and actual['full148_independent_support_preserved_by_projection'] is False and actual['reachable_from_safe_start']=='UNKNOWN','conditional constructor coverage only')
    for key,x,op in [('q_min',q,np.min),('q_max',q,np.max),('qd_min',v,np.min),('qd_max',v,np.max)]:
        pairs.scalar_close(actual[key],op(x,axis=0),'coverage '+key)
    qe=[0.,.1,.25,.5,.75,.9,1.];ve=[-1,-.9,-.5,0,.5,.9,1]
    require(actual['normalized_q_bins']==qe and actual['normalized_qd_bins']==ve,'fixed descriptive histogram edges')
    unit=(q.astype(np.float64)-layout['bounds'][:,0])/(layout['bounds'][:,1]-layout['bounds'][:,0]);speed=v.astype(np.float64)/layout['vmax']
    for name,x,edges in [('q_hist74',unit,qe),('qd_hist74',speed,ve)]:
        require(actual[name]==[np.histogram(x[:,i],edges)[0].tolist() for i in range(74)],'independent coverage '+name)

def audit(e,c,progress):
    root=c['root']/'native';p=c['producer'];q=c['request'];b=c['original'];anchors=MANIFEST['anchors']
    progress('parameters/geometry identity and recorded native inventories')
    params=e.npz(b['parameter_path']);layout=k.parameters_layout(params)
    expected={n for n in params if n!='initial_strata' and not n.endswith('_full_initial_position_target')}
    original_geometry=e.js(b['geometry_identity_path']);original_geometry.pop('scope',None)
    require(p['measurement_bytes_verified'] is True and not any(p.get(n) for n in ('error','measurement_error','clock_close_error')),'completed measurement boundary')
    for label in ('before','after'):
        refs=p['measurements_'+label];require(set(refs)=={'parameters','geometry'},'measurement inventory')
        for key,name in [('parameters',f'PARAMETERS_{label.upper()}.npz'),('geometry',f'GEOMETRY_{label.upper()}.json')]:
            require(refs[key]['path']==str(root/name),'actual same-attempt boundary');e.hash(refs[key]['path'],refs[key]['sha256'])
        actual=e.npz(refs['parameters']['path']);require(set(actual)==expected,'all original native parameter fields')
        for n in expected:exact(actual[n],params[n],label+' parameter '+n)
        require(e.js(refs['geometry']['path'])==original_geometry,'exact original geometry before/after')
    inv=e.js(root/'CONSTRAINTS_BEFORE.json');inventory=inventories.audit(inv,e.js(root/'CONSTRAINTS_AFTER.json'),params,layout)
    rs=pairs.relations(e,q,layout,inv)
    # Producer may topologically order the independent XML definitions. Validate
    # the entire multiset first; only metadata residual columns follow its order.
    canon=lambda r:json.dumps(r,sort_keys=True,separators=(',',':'),allow_nan=False)
    require(sorted(map(canon,rs))==sorted(map(canon,p['relations'])),'independent relation definitions versus producer')
    lookup={canon(r):r for r in rs};rs=[lookup[canon(r)] for r in p['relations']]
    require(p['intervention']==q['intervention'] and p['native_constraint_consistency_claim'] is False and p['native_mimic_schema_count']==len(inv['mimic_relations']),'no URDF-to-native claim')
    progress('exact original cohort slice, constructor, written/readback all74')
    manifest=ref(e,q['cohort']);folder=Path(q['cohort']['path']).parent
    require(manifest['purpose']=='DEVELOPMENT_ONLY' and manifest['no_outcome_resampling'] is True and manifest['formal_holdout']==0 and manifest['parameter_sha256']==b['files'][b['parameter_path']],'original development cohort')
    require(set(manifest['files'])=={str(folder/(n+'.npy')) for n in ('q74','qd74','family')},'original three input files')
    e.verify(manifest['files'],folder)
    ids=q['proposal_ids'];allq=e.npy(folder/'q74.npy',(8192,74),'float32');allv=e.npy(folder/'qd74.npy',(8192,74),'float32')
    latentq=allq[ids].copy();latentv=allv[ids].copy();del allq,allv
    family=e.npy(folder/'family.npy',(8192,),'uint8');exact(family[ids],(np.array(ids)%4).astype(np.uint8),'exact16 families')
    for name,a in [('latent_q74',latentq),('latent_qd74',latentv)]:exact(e.npy(root/(name+'.npy'),(16,74),'float32'),a,'unaltered latent '+name)
    cq=e.npy(root/'candidate_q74.npy',(16,74),'float32');cv=e.npy(root/'candidate_qd74.npy',(16,74),'float32')
    written=e.npy(root/'requested_q74.npy',(32,74),'float32');velocity=e.npy(root/'requested_qd74.npy',(32,74),'float32')
    cases=e.js(root/'CASES.json');paired=pairs.audit_arrays(ids,latentq,latentv,cq,cv,written,velocity,cases,rs,layout,q['intervention'])
    distribution=e.js(root/'DISTRIBUTION.json')
    require(distribution['denominator']==16 and distribution['constructible']==paired['constructible'] and distribution['sentinel_ids']==list(range(92,96)) and distribution['prospective_ids']==list(range(96,108)) and distribution['not_new_draws'] is True,'all comparison denominators')
    distributions(distribution['latent'],latentq,latentv,layout);distributions(distribution['written'],written,velocity,layout)
    exact(e.npy(root/'held_target74.npy',(32,74),'float32'),written,'assigned held full74 target')
    exact(e.npy(root/'original_task_goal74.npy',(32,74),'float32'),np.concatenate([params[a+'_full_initial_position_target'] for a in ARMS],axis=1),'original task goal separately retained')
    f=k.fields(e,root,ref(e,anchors['numeric_schema']));clock=clock_fields(e,root,f)
    for name,a in [('q74',written),('qd74',velocity),('target74',written)]:exact(f[name][0],a,'actual point0 '+name)
    for micro in range(13):
        exact(f['target74'][micro],written,'all13 same applied target')
        if micro:exact(e.npy(root/f'applied_target74_micro_{micro:03d}.npy',(32,74),'float32'),written,'all12 native target getters')
        require(e.js(root/f'PROGRESS_{micro:03d}.json')==dict(committed_micro=micro,clock_validated=True,native_step=int(f['simulation_step'][micro]),native_time=float(f['simulation_time_s'][micro])),'progress bound to actual committed row and clock')
    initial=e.npz(b['initial_path']);protocol=k.validate_protocol(ref(e,anchors['root_protocol']))
    valid,root_details=k.roots(e,root,f,initial,protocol);require(valid.all(),'all32 initial actual root equivalence')
    computed=np.stack([k.flags({n:a[i] for n,a in f.items()},layout,written,i>0) for i in range(13)])
    exact(computed,f['violations'],'independent all13x32x7 predicate values')
    body=e.npz(Path(b['parameter_path']).parent/'body_identity.npz');identity=k.contact_identity(e,root,b,body)
    progress('all13/all32/all82 actual contact points and scalar sums')
    contact=k.contacts(e,root,f,identity)
    origins=e.npy(root/'environment_origins_before.npy',(32,3),'float32');require(np.isfinite(origins).all(),'finite origins')
    exact(origins,e.npy(root/'environment_origins_after.npy',(32,3),'float32'),'all32 origins held')
    progress('all13/all32/raw9021 independent pose reconstruction')
    geometry=k.geometry_evidence(e,dict(geometry_identity=p['measurements_before']['geometry']),b,f,origins)
    reported=e.js(root/'DESCRIPTIVE_PAIRED_OUTCOMES.json');pairs.check_summary(reported,paired['rows'],computed,f['q74'],f['qd74'],layout,rs)
    by_family=[]
    for family_id in range(4):
        selected=[r for r in paired['rows'] if r['family']==family_id]
        by_family.append(dict(family=family_id,latent_denominator=4,physical_case_denominator=8,constructible=sum(r['comparable'] for r in selected),
            A_initial_denial_counts=np.sum([computed[0,r['A_lane']] for r in selected],axis=0).tolist(),
            B_initial_denial_counts=np.sum([computed[0,r['B_lane']] for r in selected],axis=0).tolist()))
    return dict(native_rows=13,lanes=32,joints=74,scalar_owners=82,raw_distance_rows=9021,clock=clock,parameters_before_after_exact=True,
        inventory=inventory,paired=paired,descriptive_paired_outcomes=reported,distribution=distribution,root_equivalence=root_details,
        contact=contact,geometry=geometry,reason_order=k.REASONS,denial13x32x7=computed.tolist(),family_counts=by_family,
        camera='NOT_TESTED_DIAGNOSTIC_ONLY',held_camera_snapshots=0,conditional_constructor_not_full_range_uniform=True,
        arm_geometry_remedy_claim=False,reachable_from_safe_state='UNKNOWN',no_within_micro_peak_bound=True)
