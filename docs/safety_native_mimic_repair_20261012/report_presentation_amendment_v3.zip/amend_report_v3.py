"""Clarify units and historical protocol; preserve previous presentation and manifests."""
from pathlib import Path
import hashlib,json,shutil,zipfile
P=Path(__file__).resolve().parent;W=Path('/home/liyufeng/safeduo-dashboard-native-mimic-repair-20261011');R=W/'docs/safety_native_mimic_repair_20261012'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert not (P/'BUILD_MANIFEST_V3.json').exists()
snap=P/'presentation_v2_preserved';snap.mkdir();shutil.copyfile(R/'index.html',snap/'index.html')
s=(R/'index.html').read_text();before='速度≤0.05、关节余量≥0.02 rad';assert s.count(before)==1
s=s.replace(before,'手关节速度≤0.05 rad/s、关节余量≥0.02 rad')
before='<h3>5.1 历史同输入开发对照：违规减少与功能损失</h3>';assert s.count(before)==1
s=s.replace(before,before+'<p>该历史评测每输入480个控制周期、每周期2个物理子步，位置/速度迭代64/0，机器人根与手固定且无操作物体。其配置不同于最新960 Hz传动短窗；表1复核历史记录，不进行跨配置的机制效果归因。</p>')
(R/'index.html').write_text(s)
with zipfile.ZipFile(R/'report_presentation_amendment_v3.zip','w',compression=zipfile.ZIP_DEFLATED) as z:z.writestr(Path(__file__).name,Path(__file__).read_bytes())
d=json.loads((P/'BUILD_MANIFEST_V2.json').read_text());d['public_files']=[]
for f in sorted(R.rglob('*')):
    if f.is_file() and f.name!='PUBLIC_MANIFEST_V3.json':d['public_files'].append({'path':f.relative_to(W).as_posix(),'bytes':f.stat().st_size,'sha256':sha(f)})
d['source_amendment_sha256']=sha(Path(__file__))
for f in [P/'BUILD_MANIFEST_V3.json',R/'PUBLIC_MANIFEST_V3.json']:f.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
print('AMENDED_V3',len(d['public_files'])+2,flush=True)
