"""Bind the visible download to the current final presentation manifest."""
from pathlib import Path
import hashlib,json,zipfile
P=Path(__file__).resolve().parent;W=Path('/home/liyufeng/safeduo-dashboard-native-mimic-repair-20261011');R=W/'docs/safety_native_mimic_repair_20261012'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert not (P/'BUILD_MANIFEST_V4.json').exists()
s=(R/'index.html').read_text();assert s.count('href="PUBLIC_MANIFEST_V2.json"')==1
(P/'presentation_v3_index_preserved.html').write_bytes((R/'index.html').read_bytes())
(R/'index.html').write_text(s.replace('href="PUBLIC_MANIFEST_V2.json"','href="PUBLIC_MANIFEST_V4.json"'))
with zipfile.ZipFile(R/'report_manifest_binding_v4.zip','w',compression=zipfile.ZIP_DEFLATED) as z:z.writestr(Path(__file__).name,Path(__file__).read_bytes())
d=json.loads((P/'BUILD_MANIFEST_V3.json').read_text());d['public_files']=[]
for f in sorted(R.rglob('*')):
    if f.is_file() and f.name!='PUBLIC_MANIFEST_V4.json':d['public_files'].append({'path':f.relative_to(W).as_posix(),'bytes':f.stat().st_size,'sha256':sha(f)})
d['final_manifest_binding_sha256']=sha(Path(__file__))
for f in [P/'BUILD_MANIFEST_V4.json',R/'PUBLIC_MANIFEST_V4.json']:f.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
print('FINAL_MANIFEST',len(d['public_files'])+2,flush=True)
