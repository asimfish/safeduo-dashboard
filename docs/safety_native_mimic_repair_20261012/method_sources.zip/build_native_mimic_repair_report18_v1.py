"""Publish closed clock/disabled/native8 results; exclude unlaunched long windows."""
from pathlib import Path
import copy,datetime,hashlib,html,json,shutil,subprocess,zipfile
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
H=Path(__file__).resolve().parent
P=H/'native_mimic_repair_delivery_v1';W=Path('/home/liyufeng/safeduo-dashboard-native-mimic-repair-20261011')
BASE='23fd54124598ed394c226cdc22b9b5d50f26d6a7';SLUG='docs/safety_native_mimic_repair_20261012'
read=lambda p:json.loads(Path(p).read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()

def main():
    assert P.exists() and not (P/'BUILD_MANIFEST_V1.json').exists() and not (W/SLUG).exists()
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip()==BASE
    assert not subprocess.check_output(['git','status','--porcelain'],cwd=W)
    clock=read(H/'fourhand_native_probe_v91/NATIVE_CLOCK91_DIAGNOSTIC_DECISION_V1.json')
    pure=read(H/'fourhand_native_probe_v92/OWNED_NATIVE_SWEEP92_PURITY_V1.json')
    fixed=read(H/'fourhand_native_probe_v93/NATIVE_SWEEP93_DIAGNOSTIC_DECISION_V1.json')
    assert clock['native_clock_qualified'] and pure['disabled_boundary_bytewise_pure'] and fixed['short_diagnostic_pass']
    assert not clock['checks']['original_q_AND_qd'] and fixed['physics_events']==64
    out=W/SLUG;out.mkdir();custody=[];rows=[]
    def deliver(source,relative):
        source=Path(source);target=out/relative;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,target)
        custody.append(dict(source=str(source),public_path=target.relative_to(W).as_posix(),bytes=source.stat().st_size,sha256=sha(source)))
    for version in [91,92,93]:
        probe=H/f'fourhand_native_probe_v{version}'
        assert read(probe/f'ACTUAL_COMPLETION_EXIT_V{version}.json')['actual_outer_exit']==0
        assert all(x['actual_exit']==0 for x in read(probe/f'CORE_ACTUAL_EXIT_RECEIPTS_V{version}.json')['actual_outer_exits'].values())
        raw=Path(read(probe/'RESOURCE_EXECUTION_V1.json')['out']);capture=read(probe/'INDEPENDENT_CAPTURE_AUDIT_V1.json');model=read(probe/'INDEPENDENT_NATIVE_MIMIC_WINDOW_V6.json')
        assert capture['record_integrity_verified'] and capture['all_owned_native_children_reaped']
        forces=[]
        for c in read(raw/'physics_chunks.json'):
            f=raw/c['path'];assert sha(f)==c['sha256']
            with np.load(f,allow_pickle=False) as z:forces.append(z['four_hand_normal_N'].copy())
        force=np.concatenate(forces);n=len(force);assert n==capture['physics_events']==model['physics_events']
        for f in sorted(raw.rglob('*')):
            if f.is_file():deliver(f,f'native_v{version}/raw/'+f.relative_to(raw).as_posix())
        for f in sorted(probe.iterdir()):
            if f.suffix in ['.json','.jsonl'] and 'KIT_USER_CONFIG' not in f.name and 'SHARED_CONFIG' not in f.name:
                deliver(f,f'native_v{version}/audit/'+f.name)
        archive=out/f'native_v{version}/source_archive.zip';members=[]
        with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED) as z:
            for f in sorted(probe.iterdir()):
                if f.suffix in ['.py','.usda']:
                    z.writestr(f.name,f.read_bytes());members.append(dict(name=f.name,bytes=f.stat().st_size,sha256=sha(f)))
        (archive.parent/'SOURCE_ARCHIVE_CUSTODY_V1.json').write_text(json.dumps(dict(archive_sha256=sha(archive),members=members),indent=2)+'\n')
        rows.append(dict(version=version,kind='关闭边界的观测复现' if version==92 else '已知状态候选',physics_events=n,duration_s=n/960,
            model_pass=model['model_window_pass'],physical_pass=capture['physical_gates_pass'],q_error_rad=model['maximum_q_residual_rad'],
            qd_error_rad_s=model['maximum_qd_residual_rad_s'],per_hand_peak_N=force.max(axis=0).tolist(),
            four_hand_window_s=capture['measured_stage_windows_s']['four_hand_close'],fulltask_pass=False,actual_outer_exit=0))
    assert [r['physics_events'] for r in rows]==[16,16,64] and all(r['four_hand_window_s']==0 and not r['fulltask_pass'] for r in rows)
    extras=['NATIVE_CLOCK_BINDING87_PROSPECTIVE_PLAN_V1.json','NATIVE_CLOCK_ADMISSION91_PROSPECTIVE_PLAN_V1.json',
        'NATIVE_MIMIC_SWEEP92_93_PROSPECTIVE_PLAN_V1.json','LOADED_NATIVE_WINDOW94_PROSPECTIVE_PLAN_V1.json',
        'LOADED_NATIVE95_RESOURCE_RETRY_PROSPECTIVE_PLAN_V1.json','fourhand_native_probe_v87/ACTUAL_UNLAUNCHED_RESOURCE_REJECTION_V87.json',
        'fourhand_native_probe_v88/ACTUAL_UNLAUNCHED_RESOURCE_REJECTION_V88.json','fourhand_native_probe_v89/PRELAUNCH_REVIEW_V1.json',
        'fourhand_native_probe_v90/ACTUAL_INCOMPLETE_SETUP_EXIT_V90.json','fourhand_native_probe_v94/ACTUAL_UNLAUNCHED_RESOURCE_REJECTION_V94.json']
    for rel in extras:deliver(H/rel,'evidence/'+rel.replace('/','__'))
    timed=read(H/'fourhand_native_probe_v95/RESOURCE_EXECUTION_V1.json');assert timed['status']=='failed' and timed['native_launches']==0
    deliver(H/'fourhand_native_probe_v95/RESOURCE_EXECUTION_V1.json','evidence/LONG_WINDOW95_RESOURCE_TIMEOUT_V1.json')
    method_sources=[Path(__file__),H/'native_clock_binding_v1.py',H/'test_native_clock_binding_v1.py',H/'audit_native_clock91_v1.py',
        H/'prepare_native_mimic_sweep92_93_v1.py',H/'audit_native_sweep92_purity_v1.py',H/'audit_native_sweep93_candidate_v1.py',
        H/'prepare_loaded_native_window94_v1.py',H/'audit_loaded_native94_v1.py',H/'audit_loaded_native95_v1.py',
        H/'spike/native_mimic_sweep_v1/bridge.cpp',H/'spike/native_mimic_sweep_v1/native_boundary.py',
        H/'spike/native_mimic_sweep_v1/fake_driver.cpp',H/'spike/native_mimic_sweep_v1/test_boundary.py',
        H/'spike/native_mimic_loaded_window_v1/bridge.cpp',H/'spike/native_mimic_loaded_window_v1/test_boundary.py',
        Path('/home/liyufeng/safeduo/docs/adr/20261011-native-mimic-sweep-spike.md'),Path('/home/liyufeng/safeduo/docs/adr/20261011-native-mimic-loaded-window.md')]
    archive=out/'method_sources.zip';members=[]
    with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED) as z:
        for f in method_sources:
            name=f.relative_to(H).as_posix() if f.is_relative_to(H) else 'adr/'+f.name
            z.writestr(name,f.read_bytes());members.append(dict(name=name,bytes=f.stat().st_size,sha256=sha(f)))
    (out/'METHOD_SOURCE_ARCHIVE_CUSTODY_V1.json').write_text(json.dumps(dict(archive_sha256=sha(archive),members=members),indent=2)+'\n')
    for rel in ['spike/native_mimic_sweep_v1/CPU_BOUNDARY_VERIFICATION_V3.json','spike/native_mimic_loaded_window_v1/CPU_BOUNDARY_VERIFICATION_V1.json']:
        deliver(H/rel,'evidence/'+rel.replace('/','__'))
    summary=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),rows=rows,unique_known_initial_cases=1,new_independent_random_cases=0,
        scored_candidate_records=2,candidate_physics_events=80,observer_physics_events=16,
        clock_native_Hz=960,control_Hz=60,FIFO_controls=6,FIFO_s=.1,
        qd_improvement_factor=rows[0]['qd_error_rad_s']/rows[2]['qd_error_rad_s'],
        long1024_window_started=False,long1024_window_qualified=False,long95_scheduler_actual_exit=1,
        fulltask_pass=False,canonical_profile_qualified=False,learned_System0_tested=False,
        formal_holdout_count=0,all9_jointly_accepted=False,fullSystem0_accepted=False)
    (out/'SUMMARY_V1.json').write_text(json.dumps(summary,indent=2)+'\n')
    matrix=copy.deepcopy(read(H/'full_requirements_v1/EVIDENCE_MATRIX_V27.json'))
    assert len(matrix['rows'])==9 and all(not r['joint_requirement_accepted'] for r in matrix['rows'])
    matrix['native_mimic_short_window93_evidence']=summary
    matrixfile=H/'full_requirements_v1/EVIDENCE_MATRIX_V28.json';assert not matrixfile.exists();matrixfile.write_text(json.dumps(matrix,indent=2)+'\n');deliver(matrixfile,'EVIDENCE_MATRIX_V28.json')
    fig,axes=plt.subplots(1,2,figsize=(15,5))
    axes[0].bar(['Clock baseline91','Native8 sweeps93'],[rows[0]['qd_error_rad_s'],rows[2]['qd_error_rad_s']],color=['#b91c1c','#15803d'])
    axes[0].axhline(1e-4,color='#172033',ls='--',label='Original qd tolerance: 1e-4 rad/s');axes[0].set_yscale('log');axes[0].set_ylabel('Maximum original qd residual (rad/s)');axes[0].legend();axes[0].set_title('One known state;16-step baseline vs64-step candidate')
    axes[1].bar(['F_L','F_R','U_L','U_R'],rows[2]['per_hand_peak_N'],color='#2563eb');axes[1].axhline(.1,color='#172033',ls='--',label='Original per-hand grasp minimum:0.1N');axes[1].legend();axes[1].set_title('Only weak left-thumb contact; four-hand grasp fails');axes[1].set_ylabel('Per-hand maximum normal force (N)')
    fig.tight_layout();fig.savefig(out/'model_and_contact.png',dpi=150);fig.savefig(out/'model_and_contact.svg');plt.close(fig)
    f=out/'model_and_contact.svg';f.write_text('\n'.join(s.rstrip() for s in f.read_text().splitlines())+'\n')
    table=''.join(f"<tr><td>{r['version']}</td><td>{r['kind']}</td><td>{r['physics_events']}</td><td>{r['q_error_rad']:.6g}</td><td>{r['qd_error_rad_s']:.6g}</td><td>{'短窗通过' if r['model_pass'] else '未通过'}</td><td>{r['per_hand_peak_N'][0]:.6g}</td><td>未通过</td></tr>" for r in rows)
    gates=''.join(f"<tr><td>{html.escape(str(r['requirement']))}</td><td>{html.escape(str(r['gate']))}</td><td>联合验收未通过</td></tr>" for r in matrix['rows'])
    raw93=Path(read(H/'fourhand_native_probe_v93/RESOURCE_EXECUTION_V1.json')['out']);frames=read(raw93/'camera_frames.json')
    views=''.join(f'<figure><img src="native_v93/raw/{next(r for r in frames if r["view"]==v and r["control"]==4)["path"]}" alt="原生93的{v}完整视角"><figcaption>{v} · 实际物理时刻0.066667秒</figcaption></figure>' for v in ['top','front','side','overview'])
    links=''.join(f'<li>版本{v}：<a href="native_v{v}/audit/INDEPENDENT_CAPTURE_AUDIT_V1.json">物理审计</a> · <a href="native_v{v}/audit/INDEPENDENT_NATIVE_MIMIC_WINDOW_V6.json">原传动关系</a> · <a href="native_v{v}/audit/INDEPENDENT_FULL_MOTOR_EFFORT_V4.json">全50电机力矩</a> · <a href="native_v{v}/source_archive.zip">本版本源码</a></li>' for v in [91,92,93])
    page=f'''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>原生传动约束短窗修复 · SafeDuo</title>
<style>body{{font:16px/1.7 system-ui,sans-serif;max-width:1150px;margin:auto;padding:24px;color:#172033;background:#f5f7fb}}a{{color:#1750a3;overflow-wrap:anywhere}}h1{{line-height:1.25}}section,.notice{{background:white;border:1px solid #d6dce7;border-radius:12px;padding:22px;margin:20px 0}}.notice{{border-left:6px solid #b91c1c}}.scroll{{overflow:auto}}table{{border-collapse:collapse;width:100%;font-size:14px}}th,td{{text-align:left;vertical-align:top;padding:9px;border-bottom:1px solid #d6dce7}}th{{background:#eef2f7}}img{{width:100%;height:auto}}.views{{display:grid;grid-template-columns:1fr 1fr;gap:16px}}figure{{margin:0}}@media(max-width:600px){{body{{padding:12px}}section,.notice{{padding:15px}}.views{{grid-template-columns:1fr}}}}</style>
<p><a href="../../#scientific">← 主面板</a> · <a href="../safety_kernel_evidence_20261011/">先前失败与内核观测</a> · <a href="../safety_loaded_rate_20261011/">先前原生视频</a></p>
<h1>原生传动约束短窗通过，四手夹持仍待验收</h1>
<div class="notice"><b>九项要求尚未全部达标。学习System 0关闭，正式留出数量为0。</b><p>新机制在一个已知初态的64个物理子步中通过原始位置、速度耦合与物理门槛。速度误差约降低{summary['qd_improvement_factor']:.1f}倍。三只手仍没有合格接触，四手持续夹持为0秒，完整任务未通过。</p><p>这里是2条候选记录、合计80个物理子步，另有16步的关闭边界观测复现；只有1个已知初始状态，没有新增独立随机案例。更长1024步窗口因资源准入阻塞而没有启动，不能列入样本量。</p></div>
<section><h2>原门槛下的实际对照</h2><p>24条原URDF传动关系每物理步均要求位置和速度误差≤0.0001。93保留原50个电机的控制公式、参数、目标和物理属性，追加8次匹配的原生mimic求解，没有新增被动关节用户力矩或写入q/qd。64步结果通过独立关系、物理、力矩和目标审计；左手接触仍只有约0.025N。</p><img src="model_and_contact.png" alt="速度误差通过原门槛，但四手接触门槛仍未通过"><p><a href="model_and_contact.svg">矢量图</a> · <a href="SUMMARY_V1.json">完整数值与范围</a></p><div class="scroll"><table id="results"><thead><tr><th>版本</th><th>类型</th><th>物理步</th><th>位置误差rad</th><th>速度误差rad/s</th><th>原模型</th><th>左手峰值N</th><th>完整任务</th></tr></thead><tbody>{table}</tbody></table></div></section>
<section><h2>如何验证追加求解</h2><p>原生运行时getter与USD步频直接确认960Hz，控制频率60Hz，FIFO六步为0.1秒。75项物理参数与旧基线逐字节一致；两项登记时钟标量明确修正，原始旧记录没有改写。旧87计划中“全部77项字节相同”与时钟修正的文字矛盾已保留，没有据此宣称原计划全项通过。</p><p>92将追加数设为0，原生77项参数、13项初态和164项物理字段与91逐字节一致；实际追加调用为0，关闭边界通过后才开启93。93记录到16896次追加原生调用，返回码与每步计数均通过。只复制仍有效的CPU参数，GPU描述符保持不透明；上下文、线程、流、事件或描述符不匹配即拒绝。</p><p>安装版精确源码提交仍未知。上述结果只验证这个已知状态的短窗，不能推断强载荷、完整操作空间、视觉输入、正式机器人配置或学习策略安全。CPU边界的12项检查与长窗容量的13项检查也不算原生随机试验。</p></section>
<section><h2>实际原生四视图</h2><p>以下是64步末端的真实模拟帧，分别覆盖俯视、正视、侧视和全景。这里只显示静态短窗结果；1秒窗口未启动，没有新的操作视频。</p><div class="views">{views}</div></section>
<section><h2>完整证据和保留的失败</h2><ul>{links}</ul><p><a href="native_v91/audit/NATIVE_CLOCK91_DIAGNOSTIC_DECISION_V1.json">时钟资格与75项物理参数</a> · <a href="native_v92/audit/OWNED_NATIVE_SWEEP92_PURITY_V1.json">关闭边界的字节一致性</a> · <a href="native_v93/audit/NATIVE_SWEEP93_DIAGNOSTIC_DECISION_V1.json">开启8次后的预注册判定</a> · <a href="native_v93/raw/owned_native_sweep_launches_v1.jsonl">完整调用记录</a></p><p>87、88和94未启动原生进程；89在启动前发现路径问题被拦住；90因模块路径缺失而初始化失败，计分物理步为0。95等待900秒仍未满足GPU准入，计分物理步同样为0。原始记录和失败均保留，不纳入已完成实验数。</p><p><a href="method_sources.zip">方法、测试与审计源码</a> · <a href="SOURCE_CUSTODY_V1.json">原始字节来源</a> · <a href="PUBLIC_MANIFEST_V1.json">全量文件与哈希</a> · <a href="evidence/LONG_WINDOW95_RESOURCE_TIMEOUT_V1.json">长窗资源超时</a></p></section>
<section><h2>九项要求联合验收</h2><div class="scroll"><table id="matrix"><thead><tr><th>原要求</th><th>原门槛</th><th>状态</th></tr></thead><tbody>{gates}</tbody></table></div><p><a href="EVIDENCE_MATRIX_V28.json">证据矩阵28</a>保留9项原要求与门槛，联合验收为false。下一步是长窗载荷稳定性、四手真实夹持和预抬升资格，然后才允许完整任务及正式同输入安全对照。</p></section></html>'''
    (out/'index.html').write_text(page)
    (out/'SOURCE_CUSTODY_V1.json').write_text(json.dumps(dict(source_entries=custody,source_bytes_unchanged=True),indent=2)+'\n')
    card=f'<div class="sci-note" id="nativeMimicRepairEvidence"><b>原生传动约束短窗修复：</b>追加8次原生求解后，64个物理子步的原模型与物理门槛通过，速度误差降低约{summary["qd_improvement_factor"]:.1f}倍。四手夹持和完整System 0验收仍未通过；1秒窗口未启动，正式留出0。<a href="{SLUG}/">打开最新对照、四视图与完整证据</a></div>\n'
    root=W/'index.html';text=root.read_text();marker='<div class="sci-note" id="kernelEvidence">';assert text.count(marker)==1 and 'id="nativeMimicRepairEvidence"' not in text;root.write_text(text.replace(marker,card+marker,1))
    public=[]
    for f in sorted(out.rglob('*')):
        if f.is_file():public.append(dict(path=f.relative_to(W).as_posix(),bytes=f.stat().st_size,sha256=sha(f)))
    manifest=dict(base_commit=BASE,slug=SLUG,old_tracked_paths=len(subprocess.check_output(['git','ls-tree','-r','--name-only',BASE],cwd=W,text=True).splitlines()),public_files=public,all9_jointly_accepted=False,formal_holdout_count=0,fullSystem0_accepted=False)
    (out/'PUBLIC_MANIFEST_V1.json').write_text(json.dumps(manifest,indent=2)+'\n');(P/'BUILD_MANIFEST_V1.json').write_text(json.dumps(manifest,indent=2)+'\n')
    print('BUILT_P18_SHORT_MODEL_PASS_FOUR_HAND_FAIL',len(public)+2,'PUBLIC_FILES',flush=True)
if __name__=='__main__':main()
