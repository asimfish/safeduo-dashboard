"""Qualify only actual native clock binding; retain original model rejection."""
from pathlib import Path
import datetime,hashlib,json
import numpy as np
from audit_owned_kernel_trace81_v1 import compare
from audit_short_hand_pd_filter_decision_v1 import longest
from native_clock_binding_v1 import validate_native_clock
H=Path(__file__).resolve().parent
read=lambda p:json.loads(Path(p).read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
    p=H/'fourhand_native_probe_v91';target=p/'NATIVE_CLOCK91_DIAGNOSTIC_DECISION_V1.json';assert not target.exists()
    assert read(p/'ACTUAL_COMPLETION_EXIT_V91.json')['actual_outer_exit']==0
    assert all(x['actual_exit']==0 for x in read(p/'CORE_ACTUAL_EXIT_RECEIPTS_V91.json')['actual_outer_exits'].values())
    r=read(p/'RESOURCE_EXECUTION_V1.json');assert r['actual_exit']==r['actual_native_exit']==0 and r['native_launches']==1
    reg=read(p/'REGISTRATION_V1.json')
    for f,d in reg['source_sha256'].items():assert sha(f)==d,f
    root=Path(r['out']);prior=Path(read(H/'fourhand_native_probe_v71/RESOURCE_EXECUTION_V1.json')['out'])
    capture=read(p/'INDEPENDENT_CAPTURE_AUDIT_V1.json');model=read(p/'INDEPENDENT_NATIVE_MIMIC_WINDOW_V6.json')
    assert capture['record_integrity_verified'] and capture['all_owned_native_children_reaped']
    job=read(H/'fourhand_native_probe_v91_execution.json')['jobs'][0]
    assert job['actual_native_exit']==job['actual_exit']==0 and job['native_owned_process_reaped_and_absent']
    aliases=read(p/'SUCCESSFUL_DISPATCH_ALIAS_CUSTODY_V1.json')['aliases']
    assert all(sha(a['original'])==sha(a['alias'])==a['sha256'] for a in aliases)
    clocks=read(root/'native_clock_binding_v1.json');assert clocks['SDK_direct_getter_and_USD_scene_rate_agree']
    assert len(clocks['native_clocks'])==1
    clock=clocks['native_clocks'][0]
    assert validate_native_clock(reg,clock['native_scene_Hz'],clock['native_getter_dt_s'])['qualified']
    changed={'actual_control_dt_s','actual_physics_dt_s'};rows=[]
    with np.load(root/'native_parameters.npz',allow_pickle=False) as a,np.load(prior/'native_parameters.npz',allow_pickle=False) as b:
        assert set(a.files)==set(b.files) and len(a.files)==77
        for k in sorted(set(a.files)-changed):
            assert a[k].shape==b[k].shape and a[k].dtype==b[k].dtype and a[k].tobytes()==b[k].tobytes(),k
        for k in sorted(changed):
            expected=reg['control_dt_s' if k=='actual_control_dt_s' else 'physics_dt_s']
            assert float(a[k])==expected
            rows.append(dict(key=k,previous=float(b[k]),corrected=float(a[k]),expected=expected))
    seed=compare(root/'actual_initial_seed_binding.npz',prior/'actual_initial_seed_binding.npz',13)
    assert seed['all_fields_byte_identical']
    force=[];sources=[]
    for x in read(root/'physics_chunks.json'):
        f=root/x['path'];assert sha(f)==x['sha256'];sources.append(f)
        with np.load(f,allow_pickle=False) as z:force.append(z['four_hand_normal_N'].copy())
    force=np.concatenate(force);n=len(force);assert n==model['physics_events']==capture['physics_events'] and 0<n<=64
    checks=dict(complete64=n==64,original_q_AND_qd=model['model_window_pass'],original_physical=capture['physical_gates_pass'],
        additional_weak_contact20=longest(force[:,0]>.005)>=20,native_clock_binding=True)
    refs=[Path(__file__),p/'REGISTRATION_V1.json',root/'native_clock_binding_v1.json',p/'CORE_ACTUAL_EXIT_RECEIPTS_V91.json',p/'SUCCESSFUL_DISPATCH_ALIAS_CUSTODY_V1.json',*sources]
    target.write_text(json.dumps(dict(status='CLOSED_NATIVE_CLOCK_METADATA_QUALIFICATION_ORIGINAL_MODEL_GATE_RETAINED',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        native_clock_qualified=True,registered_and_native_scene_Hz=960,control_dt_s=1/60,FIFO_controls=6,FIFO_s=.1,
        unchanged_native_physical_parameter_arrays=75,changed_declared_clock_scalars=rows,
        original87_literal_all77_byte_equality=False,original87_array_custody_contradiction_not_silently_relaxed=True,
        all13_seed_fields_byte_identical71=True,physics_events=n,checks=checks,
        original_q_error_rad=model['maximum_q_residual_rad'],original_qd_error_rad_s=model['maximum_qd_residual_rad_s'],
        maximum_F_L_normal_N=float(force[:,0].max()),short_diagnostic_pass=all(checks.values()),
        candidate_adopted=False,fulltask_qualified=False,canonical_profile_qualified=False,
        new_independent_random_cases=0,formal_holdout_count=0,all9_jointly_accepted=False,fullSystem0_accepted=False,
        source_sha256={str(f):sha(f) for f in refs}),indent=2)+'\n')
    print('NATIVE960_CONTROL60_CLOCK_METADATA_PASS_ORIGINAL_MODEL',checks,'qd',model['maximum_qd_residual_rad_s'],flush=True)
if __name__=='__main__':main()
