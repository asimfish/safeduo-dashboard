"""Regression for the observed SDK integer-rate quantization, including stale metadata."""
import unittest
from native_clock_binding_v1 import validate_native_clock
class ClockBindingTest(unittest.TestCase):
    def registration(self):return dict(physics_dt_s=1/960,control_dt_s=1/60,physics_substeps_per_control=16,position_target_FIFO_controls=6)
    def test_actual_integer_rate_matches_exact_controller(self):
        self.assertEqual(validate_native_clock(self.registration(),960,1/960)['FIFO_s'],.1)
    def test_observed_old_cfg_is_rejected_even_when_internal_registration_is_consistent(self):
        reg=self.registration();reg.update(physics_dt_s=.001041625,control_dt_s=.016666)
        self.assertEqual(int(1/reg['physics_dt_s']),960)
        with self.assertRaisesRegex(AssertionError,'Registered dt'):validate_native_clock(reg,960,1/960)
    def test_getter_and_scene_disagreement_is_rejected(self):
        with self.assertRaisesRegex(AssertionError,'getter and USD'):validate_native_clock(self.registration(),480,1/960)
    def test_control_alias_is_rejected(self):
        reg=self.registration();reg['control_dt_s']=.016666
        with self.assertRaisesRegex(AssertionError,'Control clock'):validate_native_clock(reg,960,1/960)
if __name__=='__main__':unittest.main()
