"""Independent disabled boundary purity is mandatory before numerical candidate93."""
from pathlib import Path
import datetime,json
from audit_owned_kernel_trace81_v1 import compare,sha
H=Path(__file__).resolve().parent
read=lambda p:json.loads(Path(p).read_text())
def main():
    p=H/'fourhand_native_probe_v92';target=p/'OWNED_NATIVE_SWEEP92_PURITY_V1.json';assert not target.exists()
    planfile=H/'NATIVE_MIMIC_SWEEP92_93_PROSPECTIVE_PLAN_V1.json';plan=read(planfile)
    assert read(p/'ACTUAL_COMPLETION_EXIT_V92.json')['actual_outer_exit']==0
    assert all(x['actual_exit']==0 for x in read(p/'CORE_ACTUAL_EXIT_RECEIPTS_V92.json')['actual_outer_exits'].values())
    assert sha(p/'REGISTRATION_V1.json')==plan['candidates']['92']['registration_sha256']
    for f,d in plan['source_sha256'].items():assert sha(f)==d,f
    reg=read(p/'REGISTRATION_V1.json')
    assert reg['native_sweep_spike']['extra_pass_count']==0
    for f,d in reg['source_sha256'].items():assert sha(f)==d,f
    assert read(H/'fourhand_native_probe_v91/NATIVE_CLOCK91_DIAGNOSTIC_DECISION_V1.json')['native_clock_qualified']
    raw=[];chunks=[]
    for v in [91,92]:
        r=read(H/f'fourhand_native_probe_v{v}/RESOURCE_EXECUTION_V1.json');assert r['actual_exit']==r['actual_native_exit']==0 and r['native_launches']==1
        root=Path(r['out']);raw.append(root);index=read(root/'physics_chunks.json');assert len(index)==1
        f=root/index[0]['path'];assert sha(f)==index[0]['sha256'];chunks.append(f)
    parity=dict(native_parameters=compare(raw[0]/'native_parameters.npz',raw[1]/'native_parameters.npz',77),
        seed=compare(raw[0]/'actual_initial_seed_binding.npz',raw[1]/'actual_initial_seed_binding.npz',13),
        physics=compare(chunks[0],chunks[1],164))
    pure=all(x['all_fields_byte_identical'] for x in parity.values())
    log=raw[1]/'owned_native_sweep_launches_v1.jsonl';rows=[json.loads(s) for s in log.read_text().splitlines()]
    assert rows[0]['kind']=='start' and rows[0]['extra_pass_count']==0
    assert len([r for r in rows if r['kind']=='prepared'])==1
    assert not any(r['kind']=='failure' for r in rows)
    events=[r for r in rows if r['kind']=='event_end'];capture=read(p/'INDEPENDENT_CAPTURE_AUDIT_V1.json');n=capture['physics_events']
    assert 0<n<=64 and [r['event'] for r in events]==list(range(n))
    assert all(r['pass'] and r['errors']==r['extra']==0 and r['native_mimic']==r['native_internal']==33 for r in events)
    launches=[r for r in rows if r['kind']=='launch'];assert len(launches)==n*66 and all(r['extra']==r['CUDA_status']==0 for r in launches)
    assert rows[-1]['kind']=='close' and rows[-1]['interrupted_event']==-1
    job=read(H/'fourhand_native_probe_v92_execution.json')['jobs'][0];assert job['actual_native_exit']==0 and job['native_owned_process_reaped_and_absent']
    assert job['env']['LD_PRELOAD']==reg['native_sweep_spike']['library']
    target.write_text(json.dumps(dict(status='PASS_DISABLED_NATIVE_SWEEP_BOUNDARY_BYTEWISE_PURITY' if pure else 'REJECT_DISABLED_BOUNDARY_CHANGED_PHYSICS',
        utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),disabled_boundary_bytewise_pure=pure,
        baseline=91,observation_replica=92,physics_events=n,parity=parity,native_mimic_calls=n*33,native_internal_calls=n*33,
        added_solver_calls=0,all_observed_launch_returns_success=True,fulltask_or_safety_adoption=False,
        original_model_pass=read(p/'INDEPENDENT_NATIVE_MIMIC_WINDOW_V6.json')['model_window_pass'],
        original_physical_pass=capture['physical_gates_pass'],new_independent_random_cases=0,formal_holdout_count=0,
        all9_jointly_accepted=False,fullSystem0_accepted=False,
        source_sha256={str(f):sha(f) for f in [Path(__file__),planfile,log,p/'CORE_ACTUAL_EXIT_RECEIPTS_V92.json',*chunks]}),indent=2)+'\n')
    print('DISABLED92_BYTEWISE_PURITY',pure,'physics_events',n,flush=True)
if __name__=='__main__':main()
