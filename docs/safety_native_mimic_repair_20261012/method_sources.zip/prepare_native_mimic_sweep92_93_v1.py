"""Freeze disabled purity92 and conditional extra8 sweeps93 before native trials."""
from pathlib import Path
import ast,copy,datetime,hashlib,json,shutil
H=Path(__file__).resolve().parent
S=H/'spike/native_mimic_sweep_v1'
read=lambda p:json.loads(Path(p).read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
    verification=read(S/'CPU_BOUNDARY_VERIFICATION_V3.json')
    assert verification['actual_exit']==0 and verification['CPU_boundary_scenarios']==12
    for f,d in verification['source_sha256'].items():assert sha(f)==d,f
    base=H/'fourhand_native_probe_v91';candidates={}
    for version,passes in [(92,0),(93,8)]:
        p=H/f'fourhand_native_probe_v{version}';assert not p.exists();p.mkdir()
        reg=copy.deepcopy(read(base/'REGISTRATION_V1.json'))
        for f,d in reg['source_sha256'].items():assert sha(f)==d,f
        for f in base.iterdir():
            if f.suffix in ['.py','.usda']:shutil.copyfile(f,p/f.name)
        shutil.copyfile(S/'native_boundary.py',p/'native_sweep_boundary_v1.py')
        private=p/'private_kit_user_data';private.mkdir();frozen=p/'PRIVATE_KIT_USER_CONFIG_FROZEN_V1.json'
        shutil.copyfile(base/frozen.name,frozen);shutil.copyfile(frozen,private/'user.config.json')
        source=(base/'native_common_beam_v1.py').read_text()
        source=source.replace('env=None;observer=None;completed=0;','env=None;observer=None;sweep=None;completed=0;')
        needle='    try:\n        import isaaclab.sim as sim_utils';assert source.count(needle)==1
        source=source.replace(needle,"    try:\n        from native_sweep_boundary_v1 import NativeSweepBoundary\n        sweep=NativeSweepBoundary(reg['native_sweep_spike'],out/'owned_native_sweep_launches_v1.jsonl')\n        import isaaclab.sim as sim_utils")
        needle="        dt=control_clock(env.step_dt,reg['control_dt_s'],1/60)";assert source.count(needle)==1
        source=source.replace(needle,'        sweep.prepare()\n'+needle)
        needle='                env.sim.step(render=False);env.scene.update(cfg.sim.dt)';assert source.count(needle)==1
        source=source.replace(needle,'                sweep.begin(substeps*step+sub)\n'+needle+'\n                sweep.end(substeps*step+sub)')
        needle="        if env is not None:env.close()";assert source.count(needle)==1
        source=source.replace(needle,'        if sweep is not None:sweep.close()\n'+needle)
        ast.parse(source);(p/'native_common_beam_v1.py').write_text(source)
        launcher=H/f'launch_native_clock_admission_v{version}.py'
        assert not launcher.exists()
        text=(H/'launch_native_clock_admission_v91.py').read_text().replace('probe_v91',f'probe_v{version}').replace('PLAN_V91',f'PLAN_V{version}').replace('convergence-v91',f'convergence-v{version}')
        needle="    reg=read(P/'REGISTRATION_V1.json')";assert text.count(needle)==1
        guard="    qualified=read(H/'fourhand_native_probe_v91/NATIVE_CLOCK91_DIAGNOSTIC_DECISION_V1.json')\n    assert qualified['native_clock_qualified'] and qualified['unchanged_native_physical_parameter_arrays']==75\n"
        if version==93:guard+="    assert read(H/'fourhand_native_probe_v92/OWNED_NATIVE_SWEEP92_PURITY_V1.json')['disabled_boundary_bytewise_pure']\n"
        text=text.replace(needle,guard+needle)
        needle="            job['argv']=argv";assert text.count(needle)==1
        text=text.replace(needle,needle+"\n            job['env']['LD_PRELOAD']=reg['native_sweep_spike']['library']")
        ast.parse(text);launcher.write_text(text)
        reg.update(attempt_version=version,scientific_candidate_version=(91 if passes==0 else 93),registered_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
        reg['private_asset_settings']=dict(reg['private_asset_settings'],private_directory=str(private))
        reg['native_sweep_spike']=dict(library=str(S/'bridge.so'),extra_pass_count=passes,expected_native_sweeps_per_event=33,
            disabled_purity_baseline=91,original_constraint_rows_and_user_actuation_unchanged=True,no_GPU_descriptor_reads=True,no_q_or_qd_tensor_writes=True)
        reg['change_scope']='Owned process native mimic sweep spike; disabled0 must byte-reproduce91 before separately frozen extra8 after same-thread/context/stream/opaque-descriptor matched native internal call. All original physical/model qANDqd1e-4/clock960 FIFO6/full50 effort/targets unchanged. Not a fulltask, canonical, formal or learned System0 result.'
        files=[*p.iterdir(),Path(__file__),launcher,frozen,S/'bridge.cpp',S/'bridge.so',S/'native_boundary.py',S/'CPU_BOUNDARY_VERIFICATION_V3.json',Path('/home/liyufeng/safeduo/docs/adr/20261011-native-mimic-sweep-spike.md')]
        for f in files:
            if f.is_file():reg['source_sha256'][str(f)]=sha(f)
        (p/'REGISTRATION_V1.json').write_text(json.dumps(reg,indent=2)+'\n')
        candidates[str(version)]=dict(extra_pass_count=passes,registration_sha256=sha(p/'REGISTRATION_V1.json'),native_launch_allowed_only_after91_clock_qualification=True,
            enabled93_allowed_only_after92_all164_physics77_parameters13seed_byte_identical91=True)
    f=H/'NATIVE_MIMIC_SWEEP92_93_PROSPECTIVE_PLAN_V1.json';assert not f.exists()
    f.write_text(json.dumps(dict(frozen_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),baseline=91,candidates=candidates,
        original_q_AND_qd_tolerance=1e-4,maximum_physics_events=64,maximum_native_wall_s=600,maximum_native_executions_per_trial=1,
        all_native_physical_parameter_arrays_unchanged_vs91=True,original26arm_and24hand_motor_effort_formulas_unchanged=True,
        original24_mimic_relations_unchanged=True,additional_weak_contact=dict(F_L_normal_gt_N=.005,consecutive_events_ge=20),
        further_loaded_qualification_only_if_complete64_original_model_physical_and_additional_weak_contact_pass=True,
        original_four_hand_grasp_min_N=.1,original_continuous_four_hand_grasp_s=.25,
        no_adoption_from_residual_only_improvement=True,installed_source_commit_unknown=True,
        new_independent_random_cases=0,formal_holdout_count=0,all9_jointly_accepted=False,fullSystem0_accepted=False,
        source_sha256={str(p):sha(p) for p in [Path(__file__),S/'bridge.cpp',S/'bridge.so',S/'native_boundary.py',S/'CPU_BOUNDARY_VERIFICATION_V3.json']}),indent=2)+'\n')
    print('FROZEN_DISABLED92_THEN_CONDITIONAL_NATIVE_EXTRA8_93_ORIGINAL_GATES',flush=True)
if __name__=='__main__':main()
