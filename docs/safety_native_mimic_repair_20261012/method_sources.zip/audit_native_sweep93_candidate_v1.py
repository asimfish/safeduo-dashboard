"""Apply every original gate to the frozen8-sweep diagnostic; no residual-only adoption."""
from pathlib import Path
import datetime,json
import numpy as np
from audit_owned_kernel_trace81_v1 import compare,sha
from audit_short_hand_pd_filter_decision_v1 import longest
H=Path(__file__).resolve().parent
read=lambda p:json.loads(Path(p).read_text())
def main():
    p=H/'fourhand_native_probe_v93';target=p/'NATIVE_SWEEP93_DIAGNOSTIC_DECISION_V1.json';assert not target.exists()
    planfile=H/'NATIVE_MIMIC_SWEEP92_93_PROSPECTIVE_PLAN_V1.json';plan=read(planfile)
    for f,d in plan['source_sha256'].items():assert sha(f)==d,f
    assert read(p/'ACTUAL_COMPLETION_EXIT_V93.json')['actual_outer_exit']==0
    assert all(x['actual_exit']==0 for x in read(p/'CORE_ACTUAL_EXIT_RECEIPTS_V93.json')['actual_outer_exits'].values())
    assert read(H/'fourhand_native_probe_v92/OWNED_NATIVE_SWEEP92_PURITY_V1.json')['disabled_boundary_bytewise_pure']
    assert sha(p/'REGISTRATION_V1.json')==plan['candidates']['93']['registration_sha256']
    reg=read(p/'REGISTRATION_V1.json');assert reg['native_sweep_spike']['extra_pass_count']==8
    for f,d in reg['source_sha256'].items():assert sha(f)==d,f
    resource=read(p/'RESOURCE_EXECUTION_V1.json');assert resource['actual_exit']==resource['actual_native_exit']==0 and resource['native_launches']==1
    root=Path(resource['out']);base=Path(read(H/'fourhand_native_probe_v91/RESOURCE_EXECUTION_V1.json')['out'])
    native=compare(root/'native_parameters.npz',base/'native_parameters.npz',77)
    seed=compare(root/'actual_initial_seed_binding.npz',base/'actual_initial_seed_binding.npz',13)
    assert native['all_fields_byte_identical'] and seed['all_fields_byte_identical']
    clock=read(root/'native_clock_binding_v1.json');assert clock['SDK_direct_getter_and_USD_scene_rate_agree'] and clock['native_clocks'][0]['native_scene_Hz']==960
    capture=read(p/'INDEPENDENT_CAPTURE_AUDIT_V1.json');model=read(p/'INDEPENDENT_NATIVE_MIMIC_WINDOW_V6.json')
    assert capture['record_integrity_verified'] and capture['all_owned_native_children_reaped']
    n=capture['physics_events'];assert n==model['physics_events'] and 0<n<=64
    assert model['predeclared_relation_tolerance']==plan['original_q_AND_qd_tolerance']==1e-4
    log=root/'owned_native_sweep_launches_v1.jsonl';rows=[json.loads(s) for s in log.read_text().splitlines()]
    assert rows[0]['kind']=='start' and rows[0]['extra_pass_count']==8
    assert len([r for r in rows if r['kind']=='prepared'])==1 and not any(r['kind']=='failure' for r in rows)
    events=[r for r in rows if r['kind']=='event_end'];assert [r['event'] for r in events]==list(range(n))
    assert all(r['pass'] and r['errors']==0 and r['native_mimic']==r['native_internal']==33 and r['extra']==264 for r in events)
    launches=[r for r in rows if r['kind']=='launch'];assert len(launches)==n*330 and all(r['CUDA_status']==0 for r in launches)
    assert sum(r['extra'] for r in launches)==n*264
    assert rows[-1]['kind']=='close' and rows[-1]['interrupted_event']==-1
    job=read(H/'fourhand_native_probe_v93_execution.json')['jobs'][0];assert job['actual_native_exit']==0 and job['native_owned_process_reaped_and_absent']
    force=[];files=[]
    for row in read(root/'physics_chunks.json'):
        f=root/row['path'];assert sha(f)==row['sha256'];files.append(f)
        with np.load(f,allow_pickle=False) as z:force.append(z['four_hand_normal_N'].copy())
    force=np.concatenate(force);assert len(force)==n
    spec=plan['additional_weak_contact'];weak=longest(force[:,0]>spec['F_L_normal_gt_N'])
    checks=dict(complete64=n==64,original_q_AND_qd_model=model['model_window_pass'],original_physical=capture['physical_gates_pass'],
        additional_weak_contact20=weak>=spec['consecutive_events_ge'],native_clock_binding=True,matched_native_extra_calls=True)
    prior=read(H/'fourhand_native_probe_v91/INDEPENDENT_NATIVE_MIMIC_WINDOW_V6.json')['maximum_qd_residual_rad_s']
    target.write_text(json.dumps(dict(status='CLOSED_PREDECLARED_NATIVE_MIMIC_EXTRA8_DIAGNOSTIC',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        version=93,baseline=91,physics_events=n,extra_pass_count=8,added_native_mimic_calls=n*264,
        original_native_parameter_arrays_and_seed_byte_identical91=True,checks=checks,
        original_q_error_rad=model['maximum_q_residual_rad'],original_qd_error_rad_s=model['maximum_qd_residual_rad_s'],
        qd_residual_ratio_to91=model['maximum_qd_residual_rad_s']/prior,maximum_F_L_normal_N=float(force[:,0].max()),
        longest_additional_weak_contact_events=weak,short_diagnostic_pass=all(checks.values()),
        eligible_for_further_loaded_qualification=all(checks.values()),candidate_adopted=False,
        actual_installed_source_commit_unknown=True,fulltask_qualified=False,canonical_profile_qualified=False,
        new_independent_random_cases=0,formal_holdout_count=0,all9_jointly_accepted=False,fullSystem0_accepted=False,
        source_sha256={str(f):sha(f) for f in [Path(__file__),planfile,log,p/'CORE_ACTUAL_EXIT_RECEIPTS_V93.json',*files]}),indent=2)+'\n')
    print('NATIVE_EXTRA8_CLOSED',checks,'qd',model['maximum_qd_residual_rad_s'],'ratio',model['maximum_qd_residual_rad_s']/prior,flush=True)
if __name__=='__main__':main()
