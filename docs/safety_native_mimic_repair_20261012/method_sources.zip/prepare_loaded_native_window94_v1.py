"""Extend only duration/observer capacity after independently qualified short93."""
from pathlib import Path
import ast,copy,datetime,hashlib,json,shutil
H=Path(__file__).resolve().parent
S=H/'spike/native_mimic_loaded_window_v1'
read=lambda p:json.loads(Path(p).read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
    assert read(H/'fourhand_native_probe_v93/NATIVE_SWEEP93_DIAGNOSTIC_DECISION_V1.json')['eligible_for_further_loaded_qualification']
    cpu=read(S/'CPU_BOUNDARY_VERIFICATION_V1.json');assert cpu['CPU_boundary_scenarios']==13 and cpu['actual_exit']==0
    for f,d in cpu['source_sha256'].items():assert sha(f)==d,f
    base=H/'fourhand_native_probe_v93';p=H/'fourhand_native_probe_v94';assert not p.exists();p.mkdir()
    reg=copy.deepcopy(read(base/'REGISTRATION_V1.json'))
    for f,d in reg['source_sha256'].items():assert sha(f)==d,f
    for f in base.iterdir():
        if f.suffix in ['.py','.usda']:shutil.copyfile(f,p/f.name)
    private=p/'private_kit_user_data';private.mkdir();frozen=p/'PRIVATE_KIT_USER_CONFIG_FROZEN_V1.json'
    shutil.copyfile(base/frozen.name,frozen);shutil.copyfile(frozen,private/'user.config.json')
    source=(base/'native_common_beam_v1.py').read_text().replace('Short known-contact target replay','Long known-contact target replay').replace('SHORT_NATIVE60_PRECONTACT_STATE_TARGET_REPLAY','LONG_NATIVE60_PRECONTACT_STATE_TARGET_REPLAY')
    ast.parse(source);(p/'native_common_beam_v1.py').write_text(source)
    launcher=H/'launch_native_clock_admission_v94.py';assert not launcher.exists()
    text=(H/'launch_native_clock_admission_v93.py').read_text().replace('probe_v93','probe_v94').replace('PLAN_V93','PLAN_V94').replace('convergence-v93','convergence-v94').replace('ACTUAL_WAIT_NATIVE89','ACTUAL_WAIT_NATIVE94')
    needle="    reg=read(P/'REGISTRATION_V1.json')";assert text.count(needle)==1
    text=text.replace(needle,"    assert read(H/'fourhand_native_probe_v93/NATIVE_SWEEP93_DIAGNOSTIC_DECISION_V1.json')['eligible_for_further_loaded_qualification']\n"+needle)
    ast.parse(text);launcher.write_text(text)
    capture=H/'audit_loaded_native_capture94_v1.py';tape=H/'audit_loaded_native_target_tape94_v1.py';assert not capture.exists() and not tape.exists()
    text=(H/'audit_short_contact_capture_v1.py').read_text()
    needle="assert reg['contact_reproducer']['maximum_physics_events']==64 and reg['maximum_controls']==4";assert text.count(needle)==1
    text=text.replace(needle,"assert reg['contact_reproducer']['maximum_physics_events']==1024 and reg['maximum_controls']==64")
    text=text.replace('declared short contact replay','declared1024-step known contact replay');ast.parse(text);capture.write_text(text)
    text=(H/'audit_short_contact_target_tape_v1.py').read_text();needle="0 < capture['physics_events'] <= 64";assert text.count(needle)==1
    text=text.replace(needle,"0 < capture['physics_events'] <= 1024");ast.parse(text);tape.write_text(text)
    reg.update(attempt_version=94,scientific_candidate_version=94,registered_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),maximum_controls=64)
    reg['contact_reproducer']=dict(reg['contact_reproducer'],maximum_physics_events=1024)
    reg['private_asset_settings']=dict(reg['private_asset_settings'],private_directory=str(private))
    reg['native_sweep_spike']=dict(reg['native_sweep_spike'],library=str(S/'bridge.so'),event_ledger_capacity=2048)
    reg['change_scope']='Extend qualified93 known-state target replay from64 to1024 physics steps; hold its last recorded target. Same native8 mimic sweeps/full50effort/original24relations/native75properties/correct960Hz/FIFO6. Bridge ledger capacity only64->2048; first64 physical samples must byte-match93. No task feedback/lifting, new random case, formal or learned System0 result.'
    files=[*p.iterdir(),Path(__file__),launcher,capture,tape,frozen,S/'bridge.cpp',S/'bridge.so',S/'CPU_BOUNDARY_VERIFICATION_V1.json',Path('/home/liyufeng/safeduo/docs/adr/20261011-native-mimic-loaded-window.md')]
    for f in files:
        if f.is_file():reg['source_sha256'][str(f)]=sha(f)
    (p/'REGISTRATION_V1.json').write_text(json.dumps(reg,indent=2)+'\n')
    f=H/'LOADED_NATIVE_WINDOW94_PROSPECTIVE_PLAN_V1.json';assert not f.exists()
    f.write_text(json.dumps(dict(frozen_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),baseline=93,candidate=94,
        maximum_physics_events=1024,maximum_controls=64,registered_duration_s=64/60,native_extra_pass_count=8,
        event_ledger_capacity=2048,bridge_algorithm_unchanged_except_event_capacity=True,
        original_q_AND_qd_tolerance=1e-4,all_original_physical_gates_unchanged=True,
        every_native_parameter_array_and_seed_field_byte_identical93_required=True,
        first64_all164_physics_fields_byte_identical93_required=True,
        original_four_hand_contact_min_N=.1,original_continuous_grasp_s=.25,
        fulltask_launch_still_forbidden_without_closed_four_hand_prelift_qualification=True,
        new_independent_random_cases=0,formal_holdout_count=0,all9_jointly_accepted=False,fullSystem0_accepted=False,
        source_sha256={str(f):sha(f) for f in [Path(__file__),launcher,capture,tape,p/'REGISTRATION_V1.json',S/'bridge.cpp',S/'bridge.so',S/'CPU_BOUNDARY_VERIFICATION_V1.json']}),indent=2)+'\n')
    print('FROZEN94_LONG1024_STEPS_SAME8_SWEEPS_ORIGINAL_GATES_AND_PREFIX_CUSTODY',flush=True)
if __name__=='__main__':main()
