# ADR: Bounded native mimic solver sweep diagnostic

## Status

Proposed, reversible owned-process spike only. No controller, canonical asset,
learned System 0, formal bank or production adoption. Maximum one disabled and
one enabled short native trial after the exact native clock is qualified.

## Context

The original24 URDF relations require both q and qd residuals <=1e-4 at every
physical step. Candidates78/82/83/84 fail qd on one known initial case; original
physical gates pass, but weak left-thumb contact never proves four-hand grasping.
Observer81 reproduces77 byte-for-byte across164 physical fields. Its owned GPU
trace places internal articulation constraints after the mimic kernel. Observer86
reproduces82 byte-for-byte and observes the installed mimic6-parameter signature,
while the internal kernel has15 parameters rather than the reference source12.
Later stages causing the residual remains a hypothesis. The installed source
commit is unknown. Published source signatures must not supply a guessed ABI.

Clock87 has no native execution: utilization89% violates the unchanged80%
supervisor admission ceiling despite enough memory. Resource-only88 aligns the
outer check and preserves the87 scientific worker bytes. Clock qualification is
a prerequisite, not proof of any model, contact or task gate.

## Driving factors

- Preserve original relations, six independent motors per hand, masses, inertia,
  geometry, armature, gains, effort bounds, targets, FIFO6 and physical thresholds.
- Never overwrite native q/qd, add passive user effort, duplicate constraint rows
  or change shared SDK/driver files. Keep all failures and originals immutable.
- Exact native960Hz/control60Hz binding precedes the critical window.
- GPU1 only under the existing finite admission/isolation/resource contract;
  foreign pipelines are read-only. No retry on another GPU to bypass this contract.
- Use metadata from the installed driver and original live launch arguments;
  never dereference a GPU descriptor or guess the unknown internal ABI.

## Candidates

| Candidate | Benefit | Limitation and decision |
| --- | --- | --- |
| A: Existing SDK solver settings and equivalent native constraint graphs | Supported configuration, small boundary | The frozen settings and graph candidates remain rejected; keep their evidence |
| B: Append native mimic sweeps immediately after the matching native internal solve | Tests whether joint constraints can recover within the same native solver phase; existing native impulse/reaction implementation | Process-local CUDA interception, phase/lifetime risks and unknown source identity; only a bounded reversible diagnostic |
| C: Project measured q/qd or add passive follower torques | Could reduce the recorded residual | Changes physical behavior and violates original requirements; rejected |

## Decision and interface

Prepare B as one time-boxed spike under
`artifacts/safety_physical_qualified_random_20261009_1613/spike/native_mimic_sweep_v1/`.
Do not merge it into the controller or modify the SDK. The installed GPU library
imports `cuLaunchKernel` dynamically, as verified by readelf. An owned preload
library forwards that symbol and fails closed if warmup does not observe the two
expected function identities. It does not override dlsym or intercept other CUDA
APIs. It calls CUDA only from an ordinary launch wrapper, never a CUPTI callback.

The C interface is `start(log_path, extra_pass_count)`, `prepare()`,
`event_begin(index)`, `event_end(index)`, `stop()`. Pass count is registration
data, with an implementation bound0..8. The first native trial MUST use0 and
match its clock-qualified baseline across all164 physical arrays,77 native
parameter arrays and13 seed fields. A valid disabled result proves only this
observer boundary for that case. Only then may a separately frozen8-pass trial run.

Warmup caches function identities by exact installed function name. Preparation
queries the actual binary mimic argument sizes [8,4,4,4,1,1]. During an enabled
critical window, the wrapper copies the six CPU argument values while valid;
the eight-byte descriptor value stays opaque. After the corresponding original
internal solve succeeds, on the same thread, stream, context and descriptor, it
launches the same mimic function with those unchanged values. It consumes that
cache once. No pointer values are published. Unsupported layouts, missing pairs,
CUDA errors or count mismatches fail the trial. Original launches retain their
original arguments and ordering. The unknown internal extra parameters are never
read or interpreted.

The extra native sweeps change numerical execution; they are not a certified
physics repair. Their impulse/contact effects require original native q AND qd,
geometry, contact, friction, limits, force, target and effort audits. No residual
improvement alone licenses adoption. If64 steps do not pass the original model
and physical gates and the additional20-event weak-contact diagnostic, reject
the candidate; the latter does not replace four-hand .1N/.25s qualification.

## Impact and evidence

Only new owned spike sources, registrations, finite launchers and diagnostic
records change. Existing JSON metadata/receipts and NPZ physical chunks remain
the canonical boundaries. Freeze source/library hashes before native execution.
Compile with warnings as errors. Offline checks must exercise argument copying,
freshness, descriptor/stream/context mismatch and failed original/extra launches.
Keep compile and setup failures even when no physical steps exist. Disabled
purity is a required native gate, never inferred from source inspection.

The conclusion is feasible, infeasible or conditional within this bounded spike.
It cannot establish source identity, generalization, broad operation coverage,
cooked collision certification, real grasping, full task or System 0 safety.
