# ADR: Extend the qualified native mimic diagnostic window

## Status

Proposed bounded second spike: known-state loaded stability only. Original short
spike92/93 is closed. No canonical, full-task, formal or learned safety adoption.

## Context and candidates

Clock91 agrees with native960Hz/control60Hz/FIFO6. Disabled92 matches91 across
164 physical fields,77 native arrays and13 seed fields. Candidate93 adds eight
native mimic sweeps after matching native internal solves. Independent original
q AND qd, physical, full50 effort and target audits pass64 steps. Maximum qd
residual is1.3445504009723663e-5rad/s versus unchanged1e-4. Left-thumb force is
only .024828N; other hands have no demonstrated qualified contact. This is one
known case, not a new random sample or four-hand grasp.

| Approach | Benefit | Limitation |
| --- | --- | --- |
| A: Repeat the same64-step short window | Checks replication | Does not test sustained dynamics |
| B: Continue the same target tape, then hold its last command for1024 steps | Tests longer native dynamics while keeping physical inputs and solver fixed | Still one known state with weak contact; cannot prove task or workspace safety |
| C: Immediately run full2400-control task | Could expose task behavior | Independent four-hand/prelift qualification is absent; not allowed |

## Decision and interface

Select B under `spike/native_mimic_loaded_window_v1/`. Copy the frozen bridge
source; change only the bounded event ledger capacity from64 to2048. Keep its
three-argument C start interface, native8 extra sweeps, original live arguments,
context/stream/opaque-descriptor matching, error propagation and cleanup. The
prospective native registration caps actual physics at1024 steps/64 controls,
about1.066667seconds. Existing JSON metadata and NPZ physical packets remain the
data boundaries. Original library and all92/93 source hashes stay immutable.

Compile with warnings as errors. Retain the twelve CPU boundary cases and add
a CPU-only capacity exhaustion check. Before native execution freeze source and
library hashes. The first64 physical samples MUST reproduce93 byte-for-byte
across all164 recorded fields. All77 native parameters and13 seeds must match93.
Every1024 sample must pass original24 q AND qd<=1e-4 and every original physical,
effort/target/contact/friction/force/joint-limit gate. Measure weak-contact and
original four-hand .1N/.25s/prelift capacity; do not replace those requirements.

## Impact

Only new owned spike files, finite launcher, registration and scope-specific
capture/target audit copies change. Capture and target audit copies extend only
their declared window bound; original physical and target oracles are unchanged.
The model and full50 effort auditors remain the existing original versions.
Native execution is finite600seconds on admitted GPU1 with the same memory and
utilization contract. All failures remain preserved. No physical parameter,
target, constraint graph, user actuation or shared SDK/driver is changed.
